# Porting status (Amulets of Norine → Fabric 1.21.11)

NOT yet compiled by anyone – the first GitHub Actions run will list the remaining compile errors (see build-errors.txt in the artifact).

## Done
- Gradle/Loom project (official Fabric template for 1.21.11), GitHub Actions workflow with error log artifact
- Data pack: recipes (new ingredient format), item model definitions (`assets/amuletmod/items`), dimension type for the 1.21.11 format
- NeoForge compatibility shim (`com.amuletmod.neo`), Fabric hooks + mixins, Curios replacement (`AmuletSlots`)
- Registries (ModItems/ModBlocks/ModEntities...), networking (`ModNetwork`), AmuletItem, Amulets, StackData

## Pending / to verify
- Client side (renderers, HUD, shaders, key mappings, Jeweler's Bench/obelisk screens, JEI) – parked in `porting_pending/`
- Mixins for events with no hook yet: explosion Detonate/Knockback, ItemExpire, EntityTeleport, MobGriefing, PlayerFlyableFall, ChangeGameMode, LivingExperienceDrop, LivingConversion
- Mixin targets are unverified at runtime
