package com.amuletmod.command;

import com.amuletmod.amulet.AbilityCooldowns;
import com.amuletmod.seal.SealPrison;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.RegisterCommandsEvent;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class ModCommands {
   private ModCommands() {
   }

   @SubscribeEvent
   public static void onRegisterCommands(RegisterCommandsEvent event) {
      CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
      dispatcher.register(
         (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("amuletmod")
                     .requires(source -> source.hasPermission(2)))
                  .then(Commands.literal("refresh").executes(context -> {
                     ServerPlayer player = ((CommandSourceStack)context.getSource()).getPlayerOrException();
                     int refreshed = AbilityCooldowns.clearAll(player);
                     ((CommandSourceStack)context.getSource())
                        .sendSuccess(() -> Component.translatable("commands.amuletmod.refresh", new Object[]{refreshed}), false);
                     return refreshed;
                  })))
               .then(
                  Commands.literal("unseal")
                     .then(
                        Commands.argument("player", EntityArgument.player())
                           .executes(
                              context -> {
                                 ServerPlayer player = EntityArgument.getPlayer(context, "player");
                                 boolean freed = SealPrison.pardon(player);
                                 ((CommandSourceStack)context.getSource())
                                    .sendSuccess(
                                       () -> Component.translatable(
                                          freed ? "commands.amuletmod.unseal" : "commands.amuletmod.unseal.none", new Object[]{player.getDisplayName()}
                                       ),
                                       freed
                                    );
                                 return freed ? 1 : 0;
                              }
                           )
                     )
               ))
            .then(
               ((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("cooldowns").executes(context -> {
                     ServerPlayer player = ((CommandSourceStack)context.getSource()).getPlayerOrException();
                     return setCooldowns((CommandSourceStack)context.getSource(), AbilityCooldowns.disabled(player));
                  })).then(Commands.literal("on").executes(context -> setCooldowns((CommandSourceStack)context.getSource(), true))))
                  .then(Commands.literal("off").executes(context -> setCooldowns((CommandSourceStack)context.getSource(), false)))
            )
      );
   }

   private static int setCooldowns(CommandSourceStack source, boolean on) throws CommandSyntaxException {
      ServerPlayer player = source.getPlayerOrException();
      AbilityCooldowns.setDisabled(player, !on);
      source.sendSuccess(() -> Component.translatable(on ? "commands.amuletmod.cooldowns.on" : "commands.amuletmod.cooldowns.off"), false);
      return on ? 1 : 0;
   }
}
