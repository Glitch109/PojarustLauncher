package com.amuletmod.advancement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.advancements.critereon.ContextAwarePredicate;
import net.minecraft.advancements.critereon.EntityPredicate;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger.SimpleInstance;
import net.minecraft.server.level.ServerPlayer;

public class FeatTrigger extends SimpleCriterionTrigger<FeatTrigger.Instance> {
   public Codec<FeatTrigger.Instance> codec() {
      return FeatTrigger.Instance.CODEC;
   }

   public void trigger(ServerPlayer player, String feat) {
      this.trigger(player, instance -> instance.feat.equals(feat));
   }

   public record Instance(Optional<ContextAwarePredicate> player, String feat) implements SimpleInstance {
      public static final Codec<FeatTrigger.Instance> CODEC = RecordCodecBuilder.create(
         instance -> instance.group(
               EntityPredicate.ADVANCEMENT_CODEC.optionalFieldOf("player").forGetter(FeatTrigger.Instance::player),
               Codec.STRING.fieldOf("feat").forGetter(FeatTrigger.Instance::feat)
            )
            .apply(instance, FeatTrigger.Instance::new)
      );
   }
}
