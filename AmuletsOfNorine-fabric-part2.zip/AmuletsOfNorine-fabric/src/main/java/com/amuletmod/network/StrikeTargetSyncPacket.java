package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.strike.StrikeTarget;
import com.amuletmod.client.StrikeTargetMarker;
import com.amuletmod.util.ClientSide;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import com.amuletmod.neo.IPayloadContext;
import org.jetbrains.annotations.Nullable;

public record StrikeTargetSyncPacket(@Nullable StrikeTarget target) implements CustomPacketPayload {
   public static final Type<StrikeTargetSyncPacket> TYPE = new Type(AmuletMod.id("strike_target_sync"));
   public static final StreamCodec<FriendlyByteBuf, StrikeTargetSyncPacket> STREAM_CODEC = StreamCodec.ofMember(
      StrikeTargetSyncPacket::encode, StrikeTargetSyncPacket::decode
   );

   public static void encode(StrikeTargetSyncPacket packet, FriendlyByteBuf buf) {
      buf.writeBoolean(packet.target != null);
      if (packet.target != null) {
         packet.target.write(buf);
      }
   }

   public static StrikeTargetSyncPacket decode(FriendlyByteBuf buf) {
      return new StrikeTargetSyncPacket(buf.readBoolean() ? StrikeTarget.read(buf) : null);
   }

   public static void handle(StrikeTargetSyncPacket packet, IPayloadContext context) {
      ClientSide.run(() -> () -> StrikeTargetMarker.update(packet.target));
   }

   public Type<StrikeTargetSyncPacket> type() {
      return TYPE;
   }
}
