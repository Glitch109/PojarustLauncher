package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.ScreenEffects;
import com.amuletmod.util.ClientSide;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import com.amuletmod.neo.IPayloadContext;

public record RewindEffectPacket(int durationTicks) implements CustomPacketPayload {
   public static final Type<RewindEffectPacket> TYPE = new Type(AmuletMod.id("rewind_effect"));
   public static final StreamCodec<FriendlyByteBuf, RewindEffectPacket> STREAM_CODEC = StreamCodec.ofMember(
      RewindEffectPacket::encode, RewindEffectPacket::decode
   );

   public static void encode(RewindEffectPacket packet, FriendlyByteBuf buf) {
      buf.writeVarInt(packet.durationTicks);
   }

   public static RewindEffectPacket decode(FriendlyByteBuf buf) {
      return new RewindEffectPacket(buf.readVarInt());
   }

   public static void handle(RewindEffectPacket packet, IPayloadContext context) {
      ClientSide.run(() -> () -> ScreenEffects.startRewind(packet.durationTicks));
   }

   public Type<RewindEffectPacket> type() {
      return TYPE;
   }
}
