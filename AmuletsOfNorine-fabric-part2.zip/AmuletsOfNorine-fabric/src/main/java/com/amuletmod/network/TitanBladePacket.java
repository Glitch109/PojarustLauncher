package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.titan.TitanBlades;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.server.level.ServerPlayer;
import com.amuletmod.neo.IPayloadContext;

public record TitanBladePacket(float yaw, float pitch) implements CustomPacketPayload {
   public static final Type<TitanBladePacket> TYPE = new Type(AmuletMod.id("titan_blade"));
   public static final StreamCodec<FriendlyByteBuf, TitanBladePacket> STREAM_CODEC = StreamCodec.ofMember(TitanBladePacket::encode, TitanBladePacket::decode);

   public static void encode(TitanBladePacket packet, FriendlyByteBuf buf) {
      buf.writeFloat(packet.yaw);
      buf.writeFloat(packet.pitch);
   }

   public static TitanBladePacket decode(FriendlyByteBuf buf) {
      return new TitanBladePacket(buf.readFloat(), buf.readFloat());
   }

   public static void handle(TitanBladePacket packet, IPayloadContext context) {
      if (context.player() instanceof ServerPlayer player && Float.isFinite(packet.yaw) && Float.isFinite(packet.pitch)) {
         TitanBlades.click(player, packet.yaw, packet.pitch);
      }
   }

   public Type<TitanBladePacket> type() {
      return TYPE;
   }
}
