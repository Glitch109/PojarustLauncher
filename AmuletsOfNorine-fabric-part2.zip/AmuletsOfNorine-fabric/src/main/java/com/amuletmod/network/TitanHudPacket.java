package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.TitanHud;
import com.amuletmod.util.ClientSide;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import com.amuletmod.neo.IPayloadContext;

public record TitanHudPacket(int fists, int blades, int glyph, int[] readyIn, int cuts, int comboLeft, int swords, int windowLeft)
   implements CustomPacketPayload {
   public static final Type<TitanHudPacket> TYPE = new Type(AmuletMod.id("titan_hud"));
   public static final StreamCodec<FriendlyByteBuf, TitanHudPacket> STREAM_CODEC = StreamCodec.ofMember(TitanHudPacket::encode, TitanHudPacket::decode);

   public static void encode(TitanHudPacket packet, FriendlyByteBuf buf) {
      buf.writeByte(packet.fists);
      buf.writeByte(packet.blades);
      buf.writeByte(packet.glyph);
      buf.writeVarIntArray(packet.readyIn);
      buf.writeByte(packet.cuts);
      buf.writeVarInt(packet.comboLeft);
      buf.writeByte(packet.swords);
      buf.writeVarInt(packet.windowLeft);
   }

   public static TitanHudPacket decode(FriendlyByteBuf buf) {
      return new TitanHudPacket(
         buf.readByte(), buf.readByte(), buf.readByte(), buf.readVarIntArray(8), buf.readByte(), buf.readVarInt(), buf.readByte(), buf.readVarInt()
      );
   }

   public static void handle(TitanHudPacket packet, IPayloadContext context) {
      ClientSide.run(() -> () -> TitanHud.state(packet));
   }

   public Type<TitanHudPacket> type() {
      return TYPE;
   }
}
