package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.PetalOrbitClient;
import com.amuletmod.util.ClientSide;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import com.amuletmod.neo.IPayloadContext;

public record PetalSwarmPacket(int entityId, int[] colors, int[] petals) implements CustomPacketPayload {
   public static final Type<PetalSwarmPacket> TYPE = new Type(AmuletMod.id("petal_swarm"));
   public static final StreamCodec<FriendlyByteBuf, PetalSwarmPacket> STREAM_CODEC = StreamCodec.ofMember(PetalSwarmPacket::encode, PetalSwarmPacket::decode);

   public static void encode(PetalSwarmPacket packet, FriendlyByteBuf buf) {
      buf.writeVarInt(packet.entityId);

      for (int slot = 0; slot < 5; slot++) {
         buf.writeInt(packet.colors[slot]);
         buf.writeByte(packet.petals[slot]);
      }
   }

   public static PetalSwarmPacket decode(FriendlyByteBuf buf) {
      int entityId = buf.readVarInt();
      int[] colors = new int[5];
      int[] petals = new int[5];

      for (int slot = 0; slot < 5; slot++) {
         colors[slot] = buf.readInt();
         petals[slot] = buf.readByte();
      }

      return new PetalSwarmPacket(entityId, colors, petals);
   }

   public static void handle(PetalSwarmPacket packet, IPayloadContext context) {
      ClientSide.run(() -> () -> PetalOrbitClient.update(packet.entityId, packet.colors, packet.petals));
   }

   public Type<PetalSwarmPacket> type() {
      return TYPE;
   }
}
