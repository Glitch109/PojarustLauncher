package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.GodStrikeClient;
import com.amuletmod.util.ClientSide;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.IPayloadContext;
import org.jetbrains.annotations.Nullable;

public record GodStrikePacket(int id, ResourceKey<Level> dimension, Vec3 target, Vec3 source, @Nullable Vec3 entry, float radius, int age)
   implements CustomPacketPayload {
   public static final Type<GodStrikePacket> TYPE = new Type(AmuletMod.id("god_strike"));
   public static final StreamCodec<FriendlyByteBuf, GodStrikePacket> STREAM_CODEC = StreamCodec.ofMember(GodStrikePacket::encode, GodStrikePacket::decode);

   public static void encode(GodStrikePacket packet, FriendlyByteBuf buf) {
      buf.writeVarInt(packet.id);
      buf.writeResourceKey(packet.dimension);
      buf.writeDouble(packet.target.x);
      buf.writeDouble(packet.target.y);
      buf.writeDouble(packet.target.z);
      buf.writeDouble(packet.source.x);
      buf.writeDouble(packet.source.y);
      buf.writeDouble(packet.source.z);
      buf.writeBoolean(packet.entry != null);
      if (packet.entry != null) {
         buf.writeDouble(packet.entry.x);
         buf.writeDouble(packet.entry.y);
         buf.writeDouble(packet.entry.z);
      }

      buf.writeFloat(packet.radius);
      buf.writeVarInt(packet.age);
   }

   public static GodStrikePacket decode(FriendlyByteBuf buf) {
      return new GodStrikePacket(
         buf.readVarInt(),
         buf.readResourceKey(Registries.DIMENSION),
         new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()),
         new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()),
         buf.readBoolean() ? new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()) : null,
         buf.readFloat(),
         buf.readVarInt()
      );
   }

   public static void handle(GodStrikePacket packet, IPayloadContext context) {
      ClientSide.run(() -> () -> GodStrikeClient.start(packet));
   }

   public Type<GodStrikePacket> type() {
      return TYPE;
   }
}
