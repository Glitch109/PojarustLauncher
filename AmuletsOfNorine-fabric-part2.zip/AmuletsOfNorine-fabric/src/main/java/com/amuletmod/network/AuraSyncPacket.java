package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.AuraVisionClient;
import com.amuletmod.util.ClientSide;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import com.amuletmod.neo.IPayloadContext;

public record AuraSyncPacket(boolean active, int[] ids, float[] powers) implements CustomPacketPayload {
   public static final Type<AuraSyncPacket> TYPE = new Type(AmuletMod.id("aura_sync"));
   public static final StreamCodec<FriendlyByteBuf, AuraSyncPacket> STREAM_CODEC = StreamCodec.ofMember(AuraSyncPacket::encode, AuraSyncPacket::decode);

   public static AuraSyncPacket off() {
      return new AuraSyncPacket(false, new int[0], new float[0]);
   }

   public static void encode(AuraSyncPacket packet, FriendlyByteBuf buf) {
      buf.writeBoolean(packet.active);
      buf.writeVarInt(packet.ids.length);

      for (int i = 0; i < packet.ids.length; i++) {
         buf.writeVarInt(packet.ids[i]);
         buf.writeFloat(packet.powers[i]);
      }
   }

   public static AuraSyncPacket decode(FriendlyByteBuf buf) {
      boolean active = buf.readBoolean();
      int count = Math.min(buf.readVarInt(), 1024);
      int[] ids = new int[count];
      float[] powers = new float[count];

      for (int i = 0; i < count; i++) {
         ids[i] = buf.readVarInt();
         powers[i] = buf.readFloat();
      }

      return new AuraSyncPacket(active, ids, powers);
   }

   public static void handle(AuraSyncPacket packet, IPayloadContext context) {
      ClientSide.run(() -> () -> AuraVisionClient.update(packet.active, packet.ids, packet.powers));
   }

   public Type<AuraSyncPacket> type() {
      return TYPE;
   }
}
