package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.titan.TitanFists;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.server.level.ServerPlayer;
import com.amuletmod.neo.IPayloadContext;

public record TitanPunchPacket(float yaw, float pitch) implements CustomPacketPayload {
   public static final Type<TitanPunchPacket> TYPE = new Type(AmuletMod.id("titan_punch"));
   public static final StreamCodec<FriendlyByteBuf, TitanPunchPacket> STREAM_CODEC = StreamCodec.ofMember(TitanPunchPacket::encode, TitanPunchPacket::decode);

   public static void encode(TitanPunchPacket packet, FriendlyByteBuf buf) {
      buf.writeFloat(packet.yaw);
      buf.writeFloat(packet.pitch);
   }

   public static TitanPunchPacket decode(FriendlyByteBuf buf) {
      return new TitanPunchPacket(buf.readFloat(), buf.readFloat());
   }

   public static void handle(TitanPunchPacket packet, IPayloadContext context) {
      if (context.player() instanceof ServerPlayer player && Float.isFinite(packet.yaw) && Float.isFinite(packet.pitch)) {
         TitanFists.punch(player, packet.yaw, packet.pitch);
      }
   }

   public Type<TitanPunchPacket> type() {
      return TYPE;
   }
}
