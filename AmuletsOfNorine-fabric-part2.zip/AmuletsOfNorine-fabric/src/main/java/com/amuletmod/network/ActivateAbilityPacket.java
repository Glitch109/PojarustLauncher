package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.Amulets;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.server.level.ServerPlayer;
import com.amuletmod.neo.IPayloadContext;

public record ActivateAbilityPacket(int slot) implements CustomPacketPayload {
   public static final Type<ActivateAbilityPacket> TYPE = new Type(AmuletMod.id("activate_ability"));
   public static final StreamCodec<FriendlyByteBuf, ActivateAbilityPacket> STREAM_CODEC = StreamCodec.ofMember(
      ActivateAbilityPacket::encode, ActivateAbilityPacket::decode
   );

   public static void encode(ActivateAbilityPacket packet, FriendlyByteBuf buf) {
      buf.writeVarInt(packet.slot);
   }

   public static ActivateAbilityPacket decode(FriendlyByteBuf buf) {
      return new ActivateAbilityPacket(buf.readVarInt());
   }

   public static void handle(ActivateAbilityPacket packet, IPayloadContext context) {
      if (context.player() instanceof ServerPlayer player && player.isAlive() && !player.isSpectator()) {
         if (packet.slot >= 0 && packet.slot < 3) {
            Amulets.tryActivateAbility(player, packet.slot);
         }
      }
   }

   public Type<ActivateAbilityPacket> type() {
      return TYPE;
   }
}
