package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.ShadowMarkClient;
import com.amuletmod.util.ClientSide;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import com.amuletmod.neo.IPayloadContext;

public record ShadowMarkSyncPacket(int entityId) implements CustomPacketPayload {
   public static final Type<ShadowMarkSyncPacket> TYPE = new Type(AmuletMod.id("shadow_mark_sync"));
   public static final StreamCodec<FriendlyByteBuf, ShadowMarkSyncPacket> STREAM_CODEC = StreamCodec.ofMember(
      ShadowMarkSyncPacket::encode, ShadowMarkSyncPacket::decode
   );

   public static void encode(ShadowMarkSyncPacket packet, FriendlyByteBuf buf) {
      buf.writeVarInt(packet.entityId + 1);
   }

   public static ShadowMarkSyncPacket decode(FriendlyByteBuf buf) {
      return new ShadowMarkSyncPacket(buf.readVarInt() - 1);
   }

   public static void handle(ShadowMarkSyncPacket packet, IPayloadContext context) {
      ClientSide.run(() -> () -> ShadowMarkClient.update(packet.entityId));
   }

   public Type<ShadowMarkSyncPacket> type() {
      return TYPE;
   }
}
