package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.ShadowSoldierClient;
import com.amuletmod.util.ClientSide;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import com.amuletmod.neo.IPayloadContext;

public record ShadowSoldierPacket(int entityId, int age) implements CustomPacketPayload {
   public static final Type<ShadowSoldierPacket> TYPE = new Type(AmuletMod.id("shadow_soldier"));
   public static final StreamCodec<FriendlyByteBuf, ShadowSoldierPacket> STREAM_CODEC = StreamCodec.ofMember(
      ShadowSoldierPacket::encode, ShadowSoldierPacket::decode
   );

   public static void encode(ShadowSoldierPacket packet, FriendlyByteBuf buf) {
      buf.writeVarInt(packet.entityId);
      buf.writeVarInt(Math.max(0, packet.age));
   }

   public static ShadowSoldierPacket decode(FriendlyByteBuf buf) {
      return new ShadowSoldierPacket(buf.readVarInt(), buf.readVarInt());
   }

   public static void handle(ShadowSoldierPacket packet, IPayloadContext context) {
      ClientSide.run(() -> () -> ShadowSoldierClient.add(packet.entityId, packet.age));
   }

   public Type<ShadowSoldierPacket> type() {
      return TYPE;
   }
}
