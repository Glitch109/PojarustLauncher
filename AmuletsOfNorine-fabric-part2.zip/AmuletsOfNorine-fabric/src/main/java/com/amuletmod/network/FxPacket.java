package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.ClientFx;
import com.amuletmod.util.ClientSide;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.IPayloadContext;

public record FxPacket(FxPacket.Kind kind, Vec3 at, Vec3 to, float size) implements CustomPacketPayload {
   public static final Type<FxPacket> TYPE = new Type(AmuletMod.id("fx"));
   public static final StreamCodec<FriendlyByteBuf, FxPacket> STREAM_CODEC = StreamCodec.ofMember(FxPacket::encode, FxPacket::decode);

   public FxPacket(FxPacket.Kind kind, Vec3 at, float size) {
      this(kind, at, at, size);
   }

   public static void encode(FxPacket packet, FriendlyByteBuf buf) {
      buf.writeEnum(packet.kind);
      buf.writeDouble(packet.at.x);
      buf.writeDouble(packet.at.y);
      buf.writeDouble(packet.at.z);
      buf.writeDouble(packet.to.x);
      buf.writeDouble(packet.to.y);
      buf.writeDouble(packet.to.z);
      buf.writeFloat(packet.size);
   }

   public static FxPacket decode(FriendlyByteBuf buf) {
      return new FxPacket(
         (FxPacket.Kind)buf.readEnum(FxPacket.Kind.class),
         new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()),
         new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()),
         buf.readFloat()
      );
   }

   public static void handle(FxPacket packet, IPayloadContext context) {
      ClientSide.run(() -> () -> ClientFx.play(packet.kind, packet.at, packet.to, packet.size));
   }

   public Type<FxPacket> type() {
      return TYPE;
   }

   public static enum Kind {
      FIREBALL,
      HOUND_SUMMON,
      MONARCH_CALL,
      KNELL,
      HELL_VIGNETTE,
      BOLT,
      DASH,
      SHOCK_VIGNETTE,
      SHADOW_VANISH,
      SHADOW_REVEAL,
      SHADOW_VIGNETTE,
      SHADOW_EXTRACT,
      SHADOW_POOL,
      SHADOW_DISSOLVE,
      ARISE,
      METEOR_BLAST,
      METEOR_LOCK,
      METEOR_IMPACT,
      METEOR_HIT,
      PAGE_CUT,
      SEAL_RELEASE,
      SEAL_FLASH,
      SEAL_VIGNETTE;
   }
}
