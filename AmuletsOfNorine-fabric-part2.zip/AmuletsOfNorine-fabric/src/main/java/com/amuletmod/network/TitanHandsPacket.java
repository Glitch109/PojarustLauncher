package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.TitanHands;
import com.amuletmod.util.ClientSide;
import java.util.UUID;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import com.amuletmod.neo.IPayloadContext;

public record TitanHandsPacket(UUID player, int fists, int blades) implements CustomPacketPayload {
   public static final Type<TitanHandsPacket> TYPE = new Type(AmuletMod.id("titan_hands"));
   public static final StreamCodec<FriendlyByteBuf, TitanHandsPacket> STREAM_CODEC = StreamCodec.ofMember(TitanHandsPacket::encode, TitanHandsPacket::decode);

   public static void encode(TitanHandsPacket packet, FriendlyByteBuf buf) {
      buf.writeUUID(packet.player);
      buf.writeByte(packet.fists);
      buf.writeByte(packet.blades);
   }

   public static TitanHandsPacket decode(FriendlyByteBuf buf) {
      return new TitanHandsPacket(buf.readUUID(), buf.readByte(), buf.readByte());
   }

   public static void handle(TitanHandsPacket packet, IPayloadContext context) {
      ClientSide.run(() -> () -> TitanHands.state(packet.player, packet.fists, packet.blades));
   }

   public Type<TitanHandsPacket> type() {
      return TYPE;
   }
}
