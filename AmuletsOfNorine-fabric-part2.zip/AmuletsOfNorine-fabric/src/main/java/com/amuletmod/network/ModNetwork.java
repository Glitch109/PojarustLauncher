package com.amuletmod.network;

import com.amuletmod.neo.IPayloadContext;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public final class ModNetwork {
   private ModNetwork() {
   }

   /** Common (both sides): payload types + server-bound receivers. */
   public static void registerPayloads() {
      PayloadTypeRegistry.playS2C().register(ReturnPointSyncPacket.TYPE, ReturnPointSyncPacket.STREAM_CODEC);
      PayloadTypeRegistry.playS2C().register(RewindEffectPacket.TYPE, RewindEffectPacket.STREAM_CODEC);
      PayloadTypeRegistry.playS2C().register(StrikeTargetSyncPacket.TYPE, StrikeTargetSyncPacket.STREAM_CODEC);
      PayloadTypeRegistry.playS2C().register(GodStrikePacket.TYPE, GodStrikePacket.STREAM_CODEC);
      PayloadTypeRegistry.playS2C().register(PetalSwarmPacket.TYPE, PetalSwarmPacket.STREAM_CODEC);
      PayloadTypeRegistry.playS2C().register(FxPacket.TYPE, FxPacket.STREAM_CODEC);
      PayloadTypeRegistry.playS2C().register(ShadowMarkSyncPacket.TYPE, ShadowMarkSyncPacket.STREAM_CODEC);
      PayloadTypeRegistry.playS2C().register(AuraSyncPacket.TYPE, AuraSyncPacket.STREAM_CODEC);
      PayloadTypeRegistry.playS2C().register(ShadowSoldierPacket.TYPE, ShadowSoldierPacket.STREAM_CODEC);
      PayloadTypeRegistry.playS2C().register(TitanHudPacket.TYPE, TitanHudPacket.STREAM_CODEC);
      PayloadTypeRegistry.playS2C().register(TitanHandsPacket.TYPE, TitanHandsPacket.STREAM_CODEC);
      PayloadTypeRegistry.playC2S().register(ActivateAbilityPacket.TYPE, ActivateAbilityPacket.STREAM_CODEC);
      ServerPlayNetworking.registerGlobalReceiver(ActivateAbilityPacket.TYPE, (payload, ctx) -> ActivateAbilityPacket.handle(payload, ctx::player));
      PayloadTypeRegistry.playC2S().register(TitanPunchPacket.TYPE, TitanPunchPacket.STREAM_CODEC);
      ServerPlayNetworking.registerGlobalReceiver(TitanPunchPacket.TYPE, (payload, ctx) -> TitanPunchPacket.handle(payload, ctx::player));
      PayloadTypeRegistry.playC2S().register(TitanBladePacket.TYPE, TitanBladePacket.STREAM_CODEC);
      ServerPlayNetworking.registerGlobalReceiver(TitanBladePacket.TYPE, (payload, ctx) -> TitanBladePacket.handle(payload, ctx::player));
   }

   /** Client only: called from AmuletModClient. */
   public static void registerClientReceivers() {
      net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(ReturnPointSyncPacket.TYPE, (payload, ctx) -> ReturnPointSyncPacket.handle(payload, ctx::player));
      net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(RewindEffectPacket.TYPE, (payload, ctx) -> RewindEffectPacket.handle(payload, ctx::player));
      net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(StrikeTargetSyncPacket.TYPE, (payload, ctx) -> StrikeTargetSyncPacket.handle(payload, ctx::player));
      net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(GodStrikePacket.TYPE, (payload, ctx) -> GodStrikePacket.handle(payload, ctx::player));
      net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(PetalSwarmPacket.TYPE, (payload, ctx) -> PetalSwarmPacket.handle(payload, ctx::player));
      net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(FxPacket.TYPE, (payload, ctx) -> FxPacket.handle(payload, ctx::player));
      net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(ShadowMarkSyncPacket.TYPE, (payload, ctx) -> ShadowMarkSyncPacket.handle(payload, ctx::player));
      net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(AuraSyncPacket.TYPE, (payload, ctx) -> AuraSyncPacket.handle(payload, ctx::player));
      net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(ShadowSoldierPacket.TYPE, (payload, ctx) -> ShadowSoldierPacket.handle(payload, ctx::player));
      net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(TitanHudPacket.TYPE, (payload, ctx) -> TitanHudPacket.handle(payload, ctx::player));
      net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(TitanHandsPacket.TYPE, (payload, ctx) -> TitanHandsPacket.handle(payload, ctx::player));
   }
}
