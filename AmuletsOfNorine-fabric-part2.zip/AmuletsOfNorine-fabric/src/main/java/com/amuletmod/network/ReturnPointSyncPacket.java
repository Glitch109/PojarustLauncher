package com.amuletmod.network;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.recall.ReturnPoint;
import com.amuletmod.client.ReturnPointMarker;
import com.amuletmod.util.ClientSide;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import com.amuletmod.neo.IPayloadContext;
import org.jetbrains.annotations.Nullable;

public record ReturnPointSyncPacket(@Nullable ReturnPoint point, boolean justSet) implements CustomPacketPayload {
   public static final Type<ReturnPointSyncPacket> TYPE = new Type(AmuletMod.id("return_point_sync"));
   public static final StreamCodec<FriendlyByteBuf, ReturnPointSyncPacket> STREAM_CODEC = StreamCodec.ofMember(
      ReturnPointSyncPacket::encode, ReturnPointSyncPacket::decode
   );

   public static void encode(ReturnPointSyncPacket packet, FriendlyByteBuf buf) {
      buf.writeBoolean(packet.point != null);
      if (packet.point != null) {
         packet.point.write(buf);
      }

      buf.writeBoolean(packet.justSet);
   }

   public static ReturnPointSyncPacket decode(FriendlyByteBuf buf) {
      ReturnPoint point = buf.readBoolean() ? ReturnPoint.read(buf) : null;
      return new ReturnPointSyncPacket(point, buf.readBoolean());
   }

   public static void handle(ReturnPointSyncPacket packet, IPayloadContext context) {
      ClientSide.run(() -> () -> ReturnPointMarker.update(packet.point, packet.justSet));
   }

   public Type<ReturnPointSyncPacket> type() {
      return TYPE;
   }
}
