package com.amuletmod.amulet.ability.glacial;

import com.amuletmod.entity.IceSpikeEntity;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.Direction.Axis;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import com.amuletmod.util.VanillaEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

public final class Frost {
   private Frost() {
   }

   public static void chill(LivingEntity target, int ticks) {
      target.setTicksFrozen(Math.max(target.getTicksFrozen(), target.getTicksRequiredToFreeze() + ticks * 2));
      target.addEffect(new MobEffectInstance(VanillaEffects.MOVEMENT_SLOWDOWN, ticks, 2));
   }

   public static boolean canHarm(LivingEntity target, @Nullable Entity owner) {
      return target.isAlive() && !target.isSpectator() && !(target instanceof ArmorStand) && target.isAttackable()
         ? owner == null || target != owner && !target.isAlliedTo(owner) && !owner.isAlliedTo(target)
         : false;
   }

   @Nullable
   public static Double groundY(Level level, double x, double fromY, double z, int up, int down) {
      MutableBlockPos pos = new MutableBlockPos();
      int bx = Mth.floor(x);
      int by = Mth.floor(fromY + 0.5);
      int bz = Mth.floor(z);

      for (int y = by + up; y >= by - down; y--) {
         pos.set(bx, y, bz);
         if (level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) {
            pos.move(Direction.DOWN);
            VoxelShape floor = level.getBlockState(pos).getCollisionShape(level, pos);
            if (!floor.isEmpty()) {
               return pos.getY() + floor.max(Axis.Y);
            }
         }
      }

      return null;
   }

   public static void erupt(
      ServerLevel level, Vec3 base, float height, float tiltYaw, float tilt, int lifetime, @Nullable ServerPlayer owner, float damage, Set<UUID> hits
   ) {
      level.addFreshEntity(new IceSpikeEntity(level, base, height, tiltYaw, tilt, lifetime, owner, damage, hits));
   }
}
