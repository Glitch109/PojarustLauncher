package com.amuletmod.amulet.ability.stealth;

import com.amuletmod.amulet.ActiveAbility;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public record StealthAbility(int durationTicks, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.stealth", new Object[]{this.durationTicks / 20});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      Stealth.start(player, this.durationTicks);
      return true;
   }
}
