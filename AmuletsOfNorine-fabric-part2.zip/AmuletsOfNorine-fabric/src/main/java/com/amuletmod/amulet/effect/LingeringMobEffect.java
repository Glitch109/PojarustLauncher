package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public record LingeringMobEffect(Holder<MobEffect> effect, int amplifier, int lingerTicks) implements AmuletEffect {
   private static final int REFRESH_SLACK = 20;

   @Override
   public Component description() {
      return Component.translatable(
            "tooltip.amuletmod.effect.lingering_mob_effect",
            new Object[]{
               ((MobEffect)this.effect.value()).getDisplayName(), Component.translatable("enchantment.level." + (this.amplifier + 1)), this.lingerTicks / 20
            }
         )
         .withStyle(ChatFormatting.RED);
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      MobEffectInstance current = wearer.getEffect(this.effect);
      if (current == null
         || current.getAmplifier() <= this.amplifier
            && !current.isInfiniteDuration()
            && (current.getAmplifier() != this.amplifier || current.getDuration() <= this.lingerTicks - 20)) {
         wearer.addEffect(new MobEffectInstance(this.effect, this.lingerTicks, this.amplifier, false, true, true));
      }
   }

   @Override
   public boolean isDrawback() {
      return ((MobEffect)this.effect.value()).getCategory() == MobEffectCategory.HARMFUL;
   }
}
