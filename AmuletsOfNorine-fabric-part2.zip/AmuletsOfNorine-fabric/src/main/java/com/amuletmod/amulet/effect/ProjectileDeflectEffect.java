package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import com.amuletmod.amulet.ability.aegis.Deflection;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.event.ProjectileImpactEvent;

public record ProjectileDeflectEffect(float chance) implements AmuletEffect {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.effect.projectile_deflect", new Object[]{Math.round(this.chance * 100.0F)});
   }

   @Override
   public void onWearerHitByProjectile(ProjectileImpactEvent event, LivingEntity wearer, ItemStack amulet) {
      Projectile projectile = event.getProjectile();
      if (!event.isCanceled() && projectile.getOwner() != wearer) {
         if (Deflection.recentlyDeflected(projectile)) {
            event.setCanceled(true);
         } else if (!(wearer.getRandom().nextFloat() >= this.chance)) {
            event.setCanceled(true);
            Vec3 at = projectile.position();
            Deflection.returnToSender(projectile, wearer, projectile.getDeltaMovement().reverse());
            Deflection.sparks((ServerLevel)wearer.level(), at);
         }
      }
   }
}
