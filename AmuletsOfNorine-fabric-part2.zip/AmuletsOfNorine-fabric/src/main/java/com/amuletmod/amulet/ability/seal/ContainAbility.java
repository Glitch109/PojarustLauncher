package com.amuletmod.amulet.ability.seal;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.AmuletItem;
import com.amuletmod.amulet.ability.sovereign.AuraSight;
import com.amuletmod.entity.ContainmentEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public record ContainAbility(float mostReach, int holdTicks, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.contain", new Object[]{(int)this.mostReach, this.holdTicks / 20});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      ContainmentEntity walls = ContainmentEntity.of(player);
      if (walls == null) {
         float reach = SealRank.containReach(AuraSight.power(player), this.mostReach);
         level.addFreshEntity(
            new ContainmentEntity(level, player, reach, this.holdTicks, ((AmuletItem)amulet.getItem()).originOf(amulet, this), this.cooldownTicks)
         );
         player.displayClientMessage(
            Component.translatable("message.amuletmod.contain_spreading", new Object[]{Math.round(reach)}).withStyle(ChatFormatting.LIGHT_PURPLE), true
         );
      } else if (walls.isSpreading()) {
         walls.set();
         player.displayClientMessage(
            Component.translatable("message.amuletmod.contain_set", new Object[]{Math.round(walls.reach(0.0F)), this.holdTicks / 20})
               .withStyle(ChatFormatting.LIGHT_PURPLE),
            true
         );
      } else if (player.isShiftKeyDown()) {
         walls.drop();
         player.displayClientMessage(Component.translatable("message.amuletmod.contain_dropped").withStyle(ChatFormatting.LIGHT_PURPLE), true);
      } else {
         player.displayClientMessage(
            Component.translatable("message.amuletmod.contain_standing", new Object[]{(walls.ticksLeft() + 19) / 20}).withStyle(ChatFormatting.GRAY), true
         );
      }

      return false;
   }
}
