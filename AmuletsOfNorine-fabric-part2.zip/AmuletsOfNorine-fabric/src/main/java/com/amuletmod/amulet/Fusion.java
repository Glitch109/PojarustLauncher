package com.amuletmod.amulet;

import com.amuletmod.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import org.jetbrains.annotations.Nullable;

public final class Fusion {
   public static final int INPUTS = 3;
   public static final int BASE_COST = 20;
   private static final int[] SLOT_COSTS = new int[]{0, 2, 3};
   public static final int PARAGON_COST = 2;

   private Fusion() {
   }

   @Nullable
   public static List<FusionChoice> choices(List<ItemStack> inputs, int[] picks) {
      List<FusionChoice> choices = new ArrayList<>();

      for (int i = 0; i < 3; i++) {
         ItemStack stack = inputs.get(i);
         if (!(stack.getItem() instanceof AmuletItem amulet)) {
            return null;
         }

         List var7 = amulet.fusionChoices(stack);
         if (picks[i] < 0 || picks[i] >= var7.size()) {
            return null;
         }

         choices.add((FusionChoice)var7.get(picks[i]));
      }

      return choices;
   }

   @Nullable
   public static Fusion.Problem problem(List<ItemStack> inputs, int[] picks) {
      for (int i = 0; i < 3; i++) {
         if (!(inputs.get(i).getItem() instanceof AmuletItem)) {
            return Fusion.Problem.MISSING_AMULET;
         }
      }

      List<FusionChoice> choices = choices(inputs, picks);
      if (choices == null) {
         return Fusion.Problem.NO_CHOICE;
      } else {
         for (int ix = 0; ix < 3; ix++) {
            for (int j = ix + 1; j < 3; j++) {
               if (choices.get(ix).overlaps(choices.get(j))) {
                  return Fusion.Problem.SAME_POWER;
               }
            }
         }

         return null;
      }
   }

   public static Fusion.Cost cost(List<ItemStack> inputs, int[] picks) {
      int powers = 0;
      int chains = 0;
      int paragons = 0;

      for (int i = 0; i < 3; i++) {
         ItemStack stack = inputs.get(i);
         if (stack.getItem() instanceof AmuletItem amulet) {
            chains += amulet.definition(stack).tier().fusionCost();
            if (amulet instanceof ParagonAmuletItem) {
               paragons += 2;
            }

            List<FusionChoice> offered = amulet.fusionChoices(stack);
            if (picks[i] >= 0 && picks[i] < offered.size()) {
               powers += SLOT_COSTS[Math.min(offered.get(picks[i]).ability().slot(), SLOT_COSTS.length - 1)];
            }
         }
      }

      return new Fusion.Cost(powers, chains, paragons);
   }

   public static ItemStack fuse(List<ItemStack> inputs, int[] picks, RandomSource random) {
      List<FusionChoice> keys = choices(inputs, picks);
      if (keys == null) {
         throw new IllegalArgumentException("Nothing to fuse");
      } else {
         List<EffectOrigin> boons = new ArrayList<>();
         List<EffectOrigin> banes = new ArrayList<>();
         int charges = Integer.MAX_VALUE;
         int maxCharges = 0;

         for (int i = 0; i < 3; i++) {
            ItemStack stack = inputs.get(i);
            AmuletItem amulet = (AmuletItem)stack.getItem();

            for (EffectOrigin passive : amulet.fusionPassives(stack)) {
               (passive.effect().isDrawback() ? banes : boons).add(passive);
            }

            if (keys.get(i).consumesCharge() && amulet.definition(stack).charges() > 0) {
               charges = Math.min(charges, amulet.charges(stack));
               maxCharges = Math.max(maxCharges, amulet.definition(stack).charges());
            }
         }

         ItemStack paragon = new ItemStack((ItemLike)ModItems.PARAGON_AMULET.get());
         ParagonAmuletItem.bestow(paragon, keys, pick(boons, random), pick(banes, random), maxCharges > 0 ? charges : 0, maxCharges);
         return paragon;
      }
   }

   @Nullable
   private static EffectOrigin pick(List<EffectOrigin> from, RandomSource random) {
      return from.isEmpty() ? null : from.get(random.nextInt(from.size()));
   }

   public record Cost(int powers, int chains, int paragons) {
      public int total() {
         return 20 + this.powers + this.chains + this.paragons;
      }
   }

   public static enum Problem {
      MISSING_AMULET("missing_amulet"),
      NO_CHOICE("no_choice"),
      SAME_POWER("same_power");

      public final String key;

      private Problem(String key) {
         this.key = "gui.amuletmod.obelisk." + key;
      }
   }
}
