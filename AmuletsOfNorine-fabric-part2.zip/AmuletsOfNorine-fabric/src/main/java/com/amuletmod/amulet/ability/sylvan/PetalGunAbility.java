package com.amuletmod.amulet.ability.sylvan;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.util.Sounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public record PetalGunAbility(double range, float damage, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.petal_gun", new Object[]{5, (int)this.range, 5});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      InteractionHand hand = null;

      for (InteractionHand candidate : InteractionHand.values()) {
         if (player.getItemInHand(candidate).is(ItemTags.FLOWERS)) {
            hand = candidate;
            break;
         }
      }

      if (hand == null) {
         player.displayClientMessage(Component.translatable("message.amuletmod.petal_need_flower").withStyle(ChatFormatting.RED), true);
         return false;
      } else {
         int slot = PetalSwarms.freeSlot(player);
         if (slot < 0) {
            player.displayClientMessage(Component.translatable("message.amuletmod.petal_swarm_full", new Object[]{5}).withStyle(ChatFormatting.RED), true);
            return false;
         } else {
            ItemStack flower = player.getItemInHand(hand);
            Component name = flower.getHoverName();
            PetalSwarms.bloom(player, slot, flower.getItem(), this.range, this.damage);
            if (!player.getAbilities().instabuild) {
               flower.shrink(1);
            }

            player.swing(hand, true);
            ServerLevel level = ((ServerLevel) player.level());
            Vec3 at = player.getEyePosition().add(player.getLookAngle().scale(0.6)).add(0.0, -0.3, 0.0);
            level.sendParticles(ParticleTypes.CHERRY_LEAVES, at.x, at.y, at.z, 10, 0.2, 0.2, 0.2, 0.02);
            Sounds.play(level, at, SoundEvents.ALLAY_ITEM_TAKEN, 0.9F, 1.3F);
            Sounds.play(level, at, SoundEvents.AMETHYST_BLOCK_RESONATE, 0.7F, 1.6F);
            Sounds.play(level, at, SoundEvents.PINK_PETALS_PLACE, 1.0F, 1.0F);
            player.displayClientMessage(
               Component.translatable("message.amuletmod.petal_bloom", new Object[]{name, PetalSwarms.blossoms(player), 5})
                  .withStyle(ChatFormatting.LIGHT_PURPLE),
               true
            );
            return true;
         }
      }
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (wearer instanceof ServerPlayer player) {
         PetalSwarms.worn(player);
      }
   }
}
