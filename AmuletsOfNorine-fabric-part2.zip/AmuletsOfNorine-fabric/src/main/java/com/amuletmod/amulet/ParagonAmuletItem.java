package com.amuletmod.amulet;

import com.amuletmod.util.StackData;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.Item.TooltipContext;
import org.jetbrains.annotations.Nullable;

public class ParagonAmuletItem extends AmuletItem {
   private static final String POWERS = "Paragon";
   private static final String KEYS = "Keys";
   private static final String BOON = "Boon";
   private static final String BANE = "Bane";
   private static final String MAX_CHARGES = "MaxCharges";
   private static final int CACHE_LIMIT = 256;
   private static final Map<CompoundTag, ParagonAmuletItem.Powers> CACHE = new ConcurrentHashMap<>();
   private final ParagonAmuletItem.Powers blank = new ParagonAmuletItem.Powers(this.definition(), List.of(), List.of());

   public ParagonAmuletItem(Properties properties) {
      super(properties, AmuletItem.Definition.builder(AmuletTier.SHULKER).build());
   }

   public static void bestow(ItemStack stack, List<FusionChoice> keys, @Nullable EffectOrigin boon, @Nullable EffectOrigin bane, int charges, int maxCharges) {
      CompoundTag powers = new CompoundTag();
      ListTag list = new ListTag();
      keys.forEach(key -> list.add(key.save()));
      powers.put("Keys", list);
      if (boon != null) {
         powers.put("Boon", boon.save());
      }

      if (bane != null) {
         powers.put("Bane", bane.save());
      }

      if (maxCharges > 0) {
         powers.putInt("MaxCharges", maxCharges);
         setCharges(stack, charges);
      }

      StackData.putElement(stack, "Paragon", powers);
   }

   public static boolean isForged(ItemStack stack) {
      return StackData.getElement(stack, "Paragon") != null;
   }

   private ParagonAmuletItem.Powers powers(ItemStack stack) {
      CompoundTag tag = StackData.getElement(stack, "Paragon");
      if (tag == null) {
         return this.blank;
      } else {
         ParagonAmuletItem.Powers powers = CACHE.get(tag);
         if (powers == null) {
            if (CACHE.size() >= 256) {
               CACHE.clear();
            }

            powers = read(tag);
            CACHE.put(tag.copy(), powers);
         }

         return powers;
      }
   }

   private static ParagonAmuletItem.Powers read(CompoundTag tag) {
      List<FusionChoice> keys = new ArrayList<>();
      ListTag list = tag.getList("Keys", 10);

      for (int i = 0; i < Math.min(list.size(), 3); i++) {
         keys.add(FusionChoice.load(list.getCompound(i)));
      }

      List<EffectOrigin> passives = new ArrayList<>();

      for (String key : new String[]{"Boon", "Bane"}) {
         if (tag.contains(key)) {
            EffectOrigin passive = EffectOrigin.load(tag.getCompound(key));
            if (passive != null) {
               passives.add(passive);
            }
         }
      }

      List<ActiveAbility> abilities = keys.stream().filter(Objects::nonNull).map(keyx -> keyx.ability().ability()).toList();
      List<AmuletEffect> effects = passives.stream().map(EffectOrigin::effect).toList();
      AmuletItem.Definition definition = new AmuletItem.Definition(AmuletTier.SHULKER, effects, abilities, tag.getInt("MaxCharges"), Map.of());
      return new ParagonAmuletItem.Powers(definition, Collections.unmodifiableList(keys), List.copyOf(passives));
   }

   @Override
   public AmuletItem.Definition definition(ItemStack stack) {
      return this.powers(stack).definition();
   }

   @Nullable
   @Override
   public AbilityOrigin abilityAt(ItemStack stack, int slot) {
      FusionChoice key = this.powers(stack).key(slot);
      return key == null ? null : key.ability();
   }

   @Nullable
   @Override
   public AbilityOrigin sneakAbilityAt(ItemStack stack, int slot) {
      FusionChoice key = this.powers(stack).key(slot);
      return key == null ? null : key.sneak();
   }

   @Override
   public List<FusionChoice> fusionChoices(ItemStack stack) {
      return this.powers(stack).keys().stream().filter(Objects::nonNull).toList();
   }

   @Override
   public List<EffectOrigin> fusionPassives(ItemStack stack) {
      return this.powers(stack).passives();
   }

   public boolean isFoil(ItemStack stack) {
      return true;
   }

   @Override
   public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
      if (!isForged(stack)) {
         tooltip.add(Component.translatable("tooltip.amuletmod.paragon_blank").withStyle(new ChatFormatting[]{ChatFormatting.GRAY, ChatFormatting.ITALIC}));
      } else {
         tooltip.add(Component.translatable("tooltip.amuletmod.paragon").withStyle(new ChatFormatting[]{ChatFormatting.LIGHT_PURPLE, ChatFormatting.ITALIC}));
         super.appendHoverText(stack, context, tooltip, flag);
      }
   }

   private record Powers(AmuletItem.Definition definition, List<FusionChoice> keys, List<EffectOrigin> passives) {
      @Nullable
      FusionChoice key(int slot) {
         return slot >= 0 && slot < this.keys.size() ? this.keys.get(slot) : null;
      }
   }
}
