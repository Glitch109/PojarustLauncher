package com.amuletmod.amulet.ability.rift;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.entity.RiftEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public record RiftAbility(RiftKind kind, int cooldownTicks) implements ActiveAbility {
   private static final double DISTANCE = 2.5;
   private static final double MIN_DISTANCE = 1.2;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.rift", new Object[]{this.kind.displayName()});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      if (level.dimension() == this.kind.dimension()) {
         return fail(player, Component.translatable("message.amuletmod.rift_already_here", new Object[]{this.kind.displayName()}));
      } else if (RiftDestinations.targetLevel(player.server, this.kind) == null) {
         return fail(player, Component.translatable("message.amuletmod.rift_sealed", new Object[]{this.kind.displayName()}));
      } else {
         float yaw = player.getYRot();
         Vec3 forward = Vec3.directionFromRotation(0.0F, yaw);
         Vec3 chest = player.position().add(0.0, 1.0, 0.0);
         BlockHitResult hit = level.clip(new ClipContext(chest, chest.add(forward.scale(3.1)), Block.COLLIDER, Fluid.NONE, player));
         double distance = hit.getType() == Type.MISS ? 2.5 : Math.min(2.5, hit.getLocation().distanceTo(chest) - 0.7);
         if (distance < 1.2) {
            return fail(player, Component.translatable("message.amuletmod.rift_no_room"));
         } else {
            level.addFreshEntity(RiftEntity.entrance(level, player.position().add(forward.scale(distance)), yaw, this.kind, player));
            player.displayClientMessage(
               Component.translatable("message.amuletmod.rift_open", new Object[]{this.kind.displayName()}).withStyle(this.kind.chatColor()), true
            );
            return true;
         }
      }
   }

   private static boolean fail(ServerPlayer player, Component message) {
      player.displayClientMessage(message.copy().withStyle(ChatFormatting.RED), true);
      return false;
   }
}
