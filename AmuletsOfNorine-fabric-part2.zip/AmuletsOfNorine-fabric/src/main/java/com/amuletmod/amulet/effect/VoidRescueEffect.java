package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AbilityCooldowns;
import com.amuletmod.amulet.AmuletEffect;
import com.amuletmod.amulet.ability.rift.RiftKind;
import com.amuletmod.entity.RiftEntity;
import com.amuletmod.util.PlayerData;
import com.amuletmod.util.Sounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public record VoidRescueEffect(int cooldownTicks) implements AmuletEffect {
   private static final String ANCHOR_KEY = "void_anchor";
   private static final String READY_KEY = "void_rescue_ready_at";
   private static final double CATCH_DEPTH = 8.0;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.effect.void_rescue", new Object[]{this.cooldownTicks / 20});
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (wearer instanceof ServerPlayer player && !player.isSpectator()) {
         ServerLevel level = ((ServerLevel) player.level());
         if (player.getY() < level.getMinBuildHeight() - 8.0) {
            this.rescue(player, level);
         } else {
            BlockPos below = player.getOnPos();
            if (player.onGround() && player.tickCount % 10 == 0 && level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) {
               CompoundTag anchor = new CompoundTag();
               anchor.putString("dim", level.dimension().location().toString());
               anchor.putDouble("x", player.getX());
               anchor.putDouble("y", player.getY());
               anchor.putDouble("z", player.getZ());
               PlayerData.get(player).put("void_anchor", anchor);
            }
         }
      }
   }

   private void rescue(ServerPlayer player, ServerLevel level) {
      CompoundTag data = PlayerData.get(player);
      long now = player.server.overworld().getGameTime();
      boolean recharges = !AbilityCooldowns.disabled(player);
      CompoundTag anchor = data.getCompound("void_anchor");
      if ((!recharges || data.getLong("void_rescue_ready_at") <= now) && anchor.getString("dim").equals(level.dimension().location().toString())) {
         Vec3 pos = new Vec3(anchor.getDouble("x"), anchor.getDouble("y"), anchor.getDouble("z"));
         player.teleportTo(level, pos.x, pos.y, pos.z, player.getYRot(), player.getXRot());
         player.setDeltaMovement(Vec3.ZERO);
         player.hurtMarked = true;
         player.resetFallDistance();
         if (recharges) {
            data.putLong("void_rescue_ready_at", now + this.cooldownTicks);
         }

         Vec3 behind = pos.subtract(Vec3.directionFromRotation(0.0F, player.getYRot()).scale(1.2));
         level.addFreshEntity(RiftEntity.exit(level, behind, player.getYRot(), RiftKind.END));
         level.sendParticles(ParticleTypes.REVERSE_PORTAL, pos.x, pos.y + 1.0, pos.z, 40, 0.4, 0.8, 0.4, 0.05);
         Sounds.play(level, pos, SoundEvents.ENDERMAN_TELEPORT, 1.0F, 0.6F);
         Sounds.play(level, pos, SoundEvents.RESPAWN_ANCHOR_SET_SPAWN, 0.8F, 1.4F);
         player.displayClientMessage(Component.translatable("message.amuletmod.void_rescue").withStyle(ChatFormatting.LIGHT_PURPLE), true);
      }
   }
}
