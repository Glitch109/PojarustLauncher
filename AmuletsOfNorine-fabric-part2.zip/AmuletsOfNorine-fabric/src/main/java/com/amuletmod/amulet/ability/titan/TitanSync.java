package com.amuletmod.amulet.ability.titan;

import com.amuletmod.amulet.AbilityCooldowns;
import com.amuletmod.amulet.Amulets;
import com.amuletmod.network.TitanHandsPacket;
import com.amuletmod.network.TitanHudPacket;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedInEvent;
import com.amuletmod.neo.event.PlayerEvent.StartTracking;
import com.amuletmod.neo.PacketDistributor;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class TitanSync {
   public static final int GLYPH_NONE = -1;
   public static final int GLYPH_SLASH = 3;
   public static final int GLYPH_STORM = 4;
   public static final int GLYPH_OFF = 5;
   public static final int MOVES = 5;

   private TitanSync() {
   }

   public static int glyph(@Nullable Stance stance) {
      return stance == null ? 5 : stance.ordinal();
   }

   public static int glyph(@Nullable BladeMode mode) {
      return mode == null ? 5 : 3 + mode.ordinal();
   }

   public static void hud(ServerPlayer player, int glyph) {
      int[] readyIn = new int[5];
      Amulets.Found<TitanFistsAbility> fists = Amulets.find(player, TitanFistsAbility.class);
      if (fists != null) {
         for (Stance stance : Stance.values()) {
            readyIn[stance.ordinal()] = (int)AbilityCooldowns.remainingTicks(player, fists.origin(), stance.id());
         }
      }

      Amulets.Found<TitanBladesAbility> blades = Amulets.find(player, TitanBladesAbility.class);
      if (blades != null) {
         for (BladeMode mode : BladeMode.values()) {
            readyIn[3 + mode.ordinal()] = (int)AbilityCooldowns.remainingTicks(player, blades.origin(), mode.id());
         }
      }

      TitanBlades.Status status = TitanBlades.status(player);
      PacketDistributor.sendToPlayer(
         player,
         new TitanHudPacket(
            Stance.code(Stance.of(player)),
            BladeMode.code(BladeMode.of(player)),
            glyph,
            readyIn,
            status.cuts(),
            status.comboLeft(),
            status.swords(),
            status.windowLeft()
         ),
         new CustomPacketPayload[0]
      );
   }

   public static void hands(ServerPlayer player) {
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, handsOf(player), new CustomPacketPayload[0]);
   }

   private static TitanHandsPacket handsOf(ServerPlayer player) {
      return new TitanHandsPacket(player.getUUID(), Stance.code(Stance.of(player)), BladeMode.code(BladeMode.of(player)));
   }

   @SubscribeEvent
   public static void onStartTracking(StartTracking event) {
      if (event.getTarget() instanceof ServerPlayer target && event.getEntity() instanceof ServerPlayer viewer) {
         PacketDistributor.sendToPlayer(viewer, handsOf(target), new CustomPacketPayload[0]);
      }
   }

   @SubscribeEvent
   public static void onLogin(PlayerLoggedInEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         hud(player, -1);
         hands(player);
      }
   }
}
