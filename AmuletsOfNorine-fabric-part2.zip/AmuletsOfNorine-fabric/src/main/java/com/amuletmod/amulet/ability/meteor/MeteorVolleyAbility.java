package com.amuletmod.amulet.ability.meteor;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.amulet.ability.glacial.Frost;
import com.amuletmod.entity.MeteorVolleyEntity;
import com.amuletmod.network.FxPacket;
import com.amuletmod.util.Aim;
import com.amuletmod.util.Sounds;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.PacketDistributor;

public record MeteorVolleyAbility(double range, float damage, float blastRadius, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.meteor_volley", new Object[]{(int)this.range, 5});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      LivingEntity target = Aim.lookedAt(player, this.range, living -> Frost.canHarm(living, player) && !Summons.isSummonedBy(living, player));
      if (target == null) {
         player.displayClientMessage(
            Component.translatable("message.amuletmod.meteor_no_target", new Object[]{(int)this.range}).withStyle(ChatFormatting.RED), true
         );
         return false;
      } else {
         ServerLevel level = ((ServerLevel) player.level());
         level.addFreshEntity(new MeteorVolleyEntity(level, player, target, this.damage, this.blastRadius));
         Vec3 eye = player.getEyePosition();
         Sounds.play(level, eye, SoundEvents.BEACON_POWER_SELECT, 0.9F, 1.4F);
         Sounds.play(level, eye, SoundEvents.FIRECHARGE_USE, 0.6F, 0.5F);
         Vec3 at = target.position();
         Sounds.play(level, at, SoundEvents.RESPAWN_ANCHOR_CHARGE, 1.0F, 1.3F);
         if (target instanceof ServerPlayer victim) {
            PacketDistributor.sendToPlayer(victim, new FxPacket(FxPacket.Kind.METEOR_LOCK, at, 1.0F), new CustomPacketPayload[0]);
         }

         player.displayClientMessage(
            Component.translatable("message.amuletmod.meteor_volley", new Object[]{target.getDisplayName()}).withStyle(ChatFormatting.GOLD), true
         );
         return true;
      }
   }
}
