package com.amuletmod.amulet.ability.stealth;

import com.amuletmod.network.FxPacket;
import com.amuletmod.util.ServerScheduler;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import com.amuletmod.util.VanillaEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.LivingChangeTargetEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedOutEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerRespawnEvent;
import com.amuletmod.neo.event.ServerStoppedEvent;
import com.amuletmod.neo.event.ServerTickEvent.Post;
import com.amuletmod.neo.PacketDistributor;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class Stealth {
   private static final double MOB_FORGET_RADIUS = 48.0;
   private static final int VANISH_TICKS = 8;
   private static final int REVEAL_TICKS = 8;
   private static final double REVEAL_AUDIENCE = 48.0;
   private static final Map<UUID, Long> ACTIVE = new HashMap<>();
   private static final Set<UUID> REVEALING = new HashSet<>();
   private static final Set<UUID> VANISHING = new HashSet<>();

   private Stealth() {
   }

   public static boolean isStealthed(Player player) {
      return ACTIVE.containsKey(player.getUUID());
   }

   public static void start(ServerPlayer player, int durationTicks) {
      if (VANISHING.add(player.getUUID())) {
         ServerLevel level = ((ServerLevel) player.level());
         PacketDistributor.sendToPlayersTrackingEntityAndSelf(
            player, new FxPacket(FxPacket.Kind.SHADOW_VANISH, player.position(), player.getBbHeight()), new CustomPacketPayload[0]
         );
         level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.PLAYERS, 0.35F, 0.6F);
         ServerScheduler.schedule(8, () -> {
            VANISHING.remove(player.getUUID());
            if (!player.isRemoved() && player.isAlive()) {
               hide(player, durationTicks);
            }
         });
      }
   }

   private static void hide(ServerPlayer player, int durationTicks) {
      ServerLevel level = ((ServerLevel) player.level());
      ACTIVE.put(player.getUUID(), player.server.overworld().getGameTime() + durationTicks);
      player.addEffect(new MobEffectInstance(VanillaEffects.INVISIBILITY, durationTicks, 0, false, false, true));

      for (Mob mob : level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(48.0), mobx -> mobx.getTarget() == player)) {
         mob.setTarget(null);
      }

      level.sendParticles(ParticleTypes.SQUID_INK, player.getX(), player.getY() + 1.0, player.getZ(), 14, 0.25, 0.5, 0.25, 0.02);
      level.sendParticles(ParticleTypes.LARGE_SMOKE, player.getX(), player.getY() + 0.8, player.getZ(), 8, 0.2, 0.4, 0.2, 0.01);
      level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.CANDLE_EXTINGUISH, SoundSource.PLAYERS, 0.9F, 0.5F);
      player.displayClientMessage(Component.translatable("message.amuletmod.stealth_start").withStyle(ChatFormatting.DARK_PURPLE), true);
      refreshTracking(player);
   }

   private static void beginReveal(ServerPlayer player, long now) {
      REVEALING.add(player.getUUID());
      ACTIVE.put(player.getUUID(), now + 8L);
      ServerLevel level = ((ServerLevel) player.level());
      PacketDistributor.sendToPlayersNear(
         level,
         null,
         player.getX(),
         player.getY(),
         player.getZ(),
         48.0,
         new FxPacket(FxPacket.Kind.SHADOW_REVEAL, player.position(), player.getBbHeight()),
         new CustomPacketPayload[0]
      );
      level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ILLUSIONER_PREPARE_MIRROR, SoundSource.PLAYERS, 0.3F, 0.8F);
   }

   private static void end(ServerPlayer player) {
      ACTIVE.remove(player.getUUID());
      REVEALING.remove(player.getUUID());
      player.removeEffect(VanillaEffects.INVISIBILITY);
      refreshTracking(player);
      player.displayClientMessage(Component.translatable("message.amuletmod.stealth_end").withStyle(ChatFormatting.GRAY), true);
   }

   private static void refreshTracking(ServerPlayer player) {
      ((ServerLevel) player.level()).getChunkSource().move(player);
   }

   @SubscribeEvent
   public static void onServerTick(Post event) {
      if (!ACTIVE.isEmpty()) {
         MinecraftServer server = event.getServer();
         long now = server.overworld().getGameTime();
         Iterator<Entry<UUID, Long>> it = ACTIVE.entrySet().iterator();
         Set<ServerPlayer> reveal = new HashSet<>();

         while (it.hasNext()) {
            Entry<UUID, Long> entry = it.next();
            if (entry.getValue() <= now) {
               ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
               if (player == null) {
                  it.remove();
                  REVEALING.remove(entry.getKey());
               } else if (REVEALING.contains(entry.getKey())) {
                  it.remove();
                  end(player);
               } else {
                  reveal.add(player);
               }
            }
         }

         reveal.forEach(playerx -> beginReveal(playerx, now));
      }
   }

   @SubscribeEvent
   public static void onChangeTarget(LivingChangeTargetEvent event) {
      if (event.getNewAboutToBeSetTarget() instanceof Player player && !player.level().isClientSide() && isStealthed(player)) {
         event.setNewAboutToBeSetTarget(null);
      }
   }

   @SubscribeEvent
   public static void onRespawn(PlayerRespawnEvent event) {
      if (event.getEntity() instanceof ServerPlayer player && isStealthed(player)) {
         end(player);
      }
   }

   @SubscribeEvent
   public static void onLogout(PlayerLoggedOutEvent event) {
      ACTIVE.remove(event.getEntity().getUUID());
      REVEALING.remove(event.getEntity().getUUID());
      VANISHING.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      ACTIVE.clear();
      REVEALING.clear();
      VANISHING.clear();
   }
}
