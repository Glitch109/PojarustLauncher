package com.amuletmod.amulet.ability.librarian;

import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.Holder;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.CombatRules;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments.Mutable;

public final class PageLoad {
   private final List<PageLoad.Inscription> inscriptions;
   private final Map<PageEnchant, Integer> spent = new HashMap<>();

   private PageLoad(List<PageLoad.Inscription> inscriptions) {
      this.inscriptions = inscriptions;
   }

   public static PageLoad of(ItemStack book) {
      List<PageLoad.Inscription> inscriptions = new ArrayList<>();

      for (Entry<Holder<Enchantment>> entry : EnchantmentHelper.getEnchantmentsForCrafting(book).entrySet()) {
         Holder<Enchantment> enchantment = (Holder<Enchantment>)entry.getKey();
         int level = entry.getIntValue();
         if (level > 0) {
            inscriptions.add(new PageLoad.Inscription(enchantment, PageEnchants.of(enchantment), level));
         }
      }

      return new PageLoad(List.copyOf(inscriptions));
   }

   public boolean isEnchanted() {
      return !this.inscriptions.isEmpty();
   }

   public PageLook look() {
      PageLook look = PageLook.PLAIN;

      for (PageLoad.Inscription inscription : this.inscriptions) {
         if (inscription.effect().look().ordinal() > look.ordinal()) {
            look = inscription.effect().look();
         }
      }

      return look;
   }

   public float damage(float base, LivingEntity target) {
      float multiplier = 1.0F;

      for (PageLoad.Inscription inscription : this.inscriptions) {
         multiplier += inscription.effect().damageBonus(inscription.level(), target);
      }

      return base * Math.max(0.0F, multiplier);
   }

   public int volley() {
      int volley = 3;

      for (PageLoad.Inscription inscription : this.inscriptions) {
         volley = Math.max(volley, inscription.effect().volley(inscription.level()));
      }

      return volley;
   }

   public float breach(LivingEntity target, DamageSource source, float amount) {
      float breach = 0.0F;

      for (PageLoad.Inscription inscription : this.inscriptions) {
         breach += inscription.effect().armorBreach(inscription.level());
      }

      if (!(breach <= 0.0F) && !(amount <= 0.0F) && !source.is(DamageTypeTags.BYPASSES_ARMOR)) {
         float after = CombatRules.getDamageAfterAbsorb(
            target, amount, source, target.getArmorValue(), (float)target.getAttributeValue(Attributes.ARMOR_TOUGHNESS)
         );
         float stopped = 1.0F - after / amount;
         return stopped <= 0.0F ? amount : amount * (1.0F - Math.max(0.0F, stopped - breach)) / (1.0F - stopped);
      } else {
         return amount;
      }
   }

   public boolean spend(PageEnchant effect, int ration) {
      int used = this.spent.getOrDefault(effect, 0);
      if (used >= ration) {
         return false;
      } else {
         this.spent.put(effect, used + 1);
         return true;
      }
   }

   public boolean piercesArmor() {
      for (PageLoad.Inscription inscription : this.inscriptions) {
         if (inscription.effect().piercesArmor()) {
            return true;
         }
      }

      return false;
   }

   public float cuttingPower() {
      float power = 0.0F;

      for (PageLoad.Inscription inscription : this.inscriptions) {
         power = Math.max(power, inscription.effect().cuttingPower(inscription.level()));
      }

      return power;
   }

   public ItemStack cuttingTool() {
      Mutable enchantments = new Mutable(ItemEnchantments.EMPTY);
      boolean silkTouch = false;

      for (PageLoad.Inscription inscription : this.inscriptions) {
         enchantments.set(inscription.enchantment(), inscription.level());
         silkTouch |= inscription.enchantment().is(Enchantments.SILK_TOUCH);
      }

      ItemStack tool = new ItemStack(silkTouch ? Items.SHEARS : Items.BOOK);
      EnchantmentHelper.setEnchantments(tool, enchantments.toImmutable());
      return tool;
   }

   public int looting() {
      int looting = 0;

      for (PageLoad.Inscription inscription : this.inscriptions) {
         if (inscription.effect() instanceof PageEnchants.Plunder) {
            looting = Math.max(looting, inscription.level());
         }
      }

      return looting;
   }

   public void wound(PageStrike strike) {
      for (PageLoad.Inscription inscription : this.inscriptions) {
         inscription.effect().onWound(strike, inscription.level());
      }
   }

   public void touch(PageStrike strike) {
      for (PageLoad.Inscription inscription : this.inscriptions) {
         inscription.effect().onTouch(strike, inscription.level());
      }
   }

   private record Inscription(Holder<Enchantment> enchantment, PageEnchant effect, int level) {
   }
}
