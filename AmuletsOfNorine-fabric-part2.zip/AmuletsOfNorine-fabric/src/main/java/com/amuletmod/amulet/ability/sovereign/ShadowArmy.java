package com.amuletmod.amulet.ability.sovereign;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.AbilityCooldowns;
import com.amuletmod.amulet.Amulets;
import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.amulet.ability.glacial.Frost;
import com.amuletmod.entity.ShadowPlayerEntity;
import com.amuletmod.network.FxPacket;
import com.amuletmod.network.ShadowSoldierPacket;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.PlayerData;
import com.amuletmod.util.ServerScheduler;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Unit;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.FlyingMob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.TraceableEntity;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.MemoryStatus;
import net.minecraft.world.entity.ai.memory.WalkTarget;
import net.minecraft.world.entity.animal.AbstractGolem;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.monster.hoglin.Hoglin;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.EventPriority;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.EntityJoinLevelEvent;
import com.amuletmod.neo.event.EntityMobGriefingEvent;
import com.amuletmod.neo.event.LivingChangeTargetEvent;
import com.amuletmod.neo.event.LivingDeathEvent;
import com.amuletmod.neo.event.LivingDropsEvent;
import com.amuletmod.neo.event.LivingExperienceDropEvent;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;
import com.amuletmod.neo.event.MobEffectEvent.Added;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedOutEvent;
import com.amuletmod.neo.event.PlayerEvent.StartTracking;
import com.amuletmod.neo.event.ExplosionEvent.Detonate;
import com.amuletmod.neo.event.ServerStoppedEvent;
import com.amuletmod.neo.event.EntityTickEvent.Pre;
import com.amuletmod.neo.event.ServerTickEvent.Post;
import com.amuletmod.neo.PacketDistributor;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class ShadowArmy {
   public static final int RISE_TICKS = 24;
   public static final int EXTRACT_LAUNCH_TICKS = 22;
   public static final int EXTRACT_ARRIVE_TICKS = 38;
   private static final String ROSTER_KEY = "shadow_army";
   private static final String SOLDIER_TAG = "amuletmod.shadow_soldier";
   private static final int COMMAND_TICKS = 5;
   private static final int STAGGER_TICKS = 3;
   private static final double GUARD_RADIUS = 20.0;
   private static final double FOLLOW_DISTANCE = 7.0;
   private static final double LEASH_DISTANCE = 40.0;
   public static final int PLAYER_COST = 5;
   private static final Map<EntityType<?>, Integer> COSTS = Map.ofEntries(
      Map.entry(EntityType.WITHER_SKELETON, 2),
      Map.entry(EntityType.ENDERMAN, 2),
      Map.entry(EntityType.BLAZE, 2),
      Map.entry(EntityType.WITCH, 2),
      Map.entry(EntityType.VINDICATOR, 2),
      Map.entry(EntityType.HOGLIN, 2),
      Map.entry(EntityType.ZOGLIN, 2),
      Map.entry(EntityType.GHAST, 2),
      Map.entry(EntityType.GUARDIAN, 2),
      Map.entry(EntityType.SHULKER, 2),
      Map.entry(EntityType.POLAR_BEAR, 2),
      Map.entry(EntityType.IRON_GOLEM, 3),
      Map.entry(EntityType.EVOKER, 3),
      Map.entry(EntityType.ILLUSIONER, 3),
      Map.entry(EntityType.PIGLIN_BRUTE, 3),
      Map.entry(EntityType.RAVAGER, 5),
      Map.entry(EntityType.ELDER_GUARDIAN, 8),
      Map.entry(EntityType.WITHER, 10),
      Map.entry(EntityType.WARDEN, 15),
      Map.entry(EntityType.ENDER_DRAGON, 50)
   );
   private static final Set<String> KEPT_DETAILS = Set.of(
      "Size", "IsBaby", "powered", "VillagerData", "Variant", "variant", "Type", "Color", "MainGene", "HiddenGene", "HandItems", "ArmorItems"
   );
   private static final Map<UUID, ShadowArmy.Soldier> SOLDIERS = new ConcurrentHashMap<>();
   private static int clock;

   private ShadowArmy() {
   }

   @Nullable
   public static UUID ownerOf(Entity entity) {
      ShadowArmy.Soldier soldier = SOLDIERS.get(entity.getUUID());
      return soldier != null && soldier.mob == entity ? soldier.owner : null;
   }

   @Nullable
   private static UUID commanderOf(@Nullable Entity entity) {
      for (int depth = 0; entity != null && depth < 3; depth++) {
         UUID owner = ownerOf(entity);
         if (owner != null) {
            return owner;
         }

         entity = entity instanceof TraceableEntity traceable ? traceable.getOwner() : null;
      }

      return null;
   }

   @Nullable
   private static UUID commanderOf(DamageSource source) {
      UUID owner = commanderOf(source.getEntity());
      return owner != null ? owner : commanderOf(source.getDirectEntity());
   }

   public static List<ShadowArmy.Recruit> roster(ServerPlayer player) {
      ListTag list = PlayerData.get(player).getList("shadow_army", 10);
      List<ShadowArmy.Recruit> roster = new ArrayList<>();

      for (int i = 0; i < list.size(); i++) {
         ShadowArmy.Recruit recruit = ShadowArmy.Recruit.load(list.getCompound(i));
         if (recruit != null) {
            roster.add(recruit);
         }
      }

      return roster;
   }

   private static void setRoster(ServerPlayer player, List<ShadowArmy.Recruit> roster) {
      ListTag list = new ListTag();
      roster.forEach(recruit -> list.add(recruit.save()));
      PlayerData.get(player).put("shadow_army", list);
   }

   public static int strength(List<ShadowArmy.Recruit> roster) {
      return roster.stream().mapToInt(ShadowArmy.Recruit::cost).sum();
   }

   public static int cost(Mob mob) {
      Integer cost = COSTS.get(mob.getType());
      return cost != null ? cost : Math.max(1, Math.round(mob.getMaxHealth() / 30.0F));
   }

   private static boolean canExtract(LivingEntity dead, ServerPlayer killer) {
      return dead instanceof ServerPlayer victim
         ? victim != killer
         : dead instanceof Mob mob
            && (mob instanceof Enemy || mob instanceof NeutralMob || mob instanceof AbstractGolem)
            && !(mob instanceof Summons.Owned)
            && ownerOf(mob) == null
            && BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType()) != null;
   }

   private static void extract(ServerPlayer player, LivingEntity dead, int budget) {
      int cost = dead instanceof Mob mob ? cost(mob) : 5;
      Component name = dead instanceof Player ? dead.getName() : dead.getType().getDescription();
      if (cost > budget) {
         player.displayClientMessage(
            Component.translatable("message.amuletmod.arise_too_mighty", new Object[]{name}).withStyle(ChatFormatting.DARK_PURPLE), true
         );
      } else {
         List<ShadowArmy.Recruit> roster = new ArrayList<>(roster(player));
         int used = strength(roster);
         if (used + cost > budget) {
            player.displayClientMessage(
               Component.translatable("message.amuletmod.arise_full", new Object[]{name, used, budget}).withStyle(ChatFormatting.GRAY), true
            );
         } else {
            roster.add(recruit(dead, cost));
            setRoster(player, roster);
            extraction(player, dead, name, used + cost, budget);
         }
      }
   }

   private static ShadowArmy.Recruit recruit(LivingEntity dead, int cost) {
      if (dead instanceof ServerPlayer victim) {
         return new ShadowArmy.Recruit(
            BuiltInRegistries.ENTITY_TYPE.getKey((EntityType)ModEntities.SHADOW_PLAYER.get()), cost, ShadowPlayerEntity.snapshot(victim)
         );
      } else {
         CompoundTag saved = dead.saveWithoutId(new CompoundTag());
         CompoundTag details = new CompoundTag();

         for (String key : KEPT_DETAILS) {
            Tag value = saved.get(key);
            if (value != null) {
               details.put(key, value.copy());
            }
         }

         return new ShadowArmy.Recruit(BuiltInRegistries.ENTITY_TYPE.getKey(dead.getType()), cost, details);
      }
   }

   private static void extraction(ServerPlayer player, LivingEntity dead, Component name, int used, int budget) {
      ServerLevel level = ((ServerLevel) player.level());
      Vec3 feet = dead.position();
      Vec3 body = feet.add(0.0, dead.getBbHeight() * 0.5, 0.0);
      Vec3 chest = player.position().add(0.0, player.getBbHeight() * 0.6, 0.0);
      FxPacket fx = new FxPacket(FxPacket.Kind.SHADOW_EXTRACT, feet, chest, dead.getBbHeight());
      PacketDistributor.sendToPlayersNear(level, null, feet.x, feet.y, feet.z, 96.0, fx, new CustomPacketPayload[0]);
      if (player.distanceToSqr(feet) > 9216.0) {
         PacketDistributor.sendToPlayer(player, fx, new CustomPacketPayload[0]);
      }

      Sounds.play(level, feet, SoundEvents.ILLUSIONER_CAST_SPELL, 1.0F, 0.6F);
      Sounds.play(level, feet, SoundEvents.SCULK_CATALYST_BLOOM, 1.4F, 0.7F);
      ServerScheduler.schedule(3, () -> Sounds.play(level, feet, SoundEvents.DEEPSLATE_BREAK, 1.2F, 0.5F));
      ServerScheduler.schedule(5, () -> Sounds.play(level, feet, SoundEvents.LIGHTNING_BOLT_IMPACT, 0.4F, 1.8F));
      ServerScheduler.schedule(10, () -> Sounds.play(level, body, (SoundEvent)SoundEvents.SOUL_ESCAPE.value(), 1.2F, 0.55F));
      ServerScheduler.schedule(14, () -> Sounds.play(level, feet, SoundEvents.LIGHTNING_BOLT_IMPACT, 0.3F, 2.0F));
      ServerScheduler.schedule(22, () -> {
         Sounds.play(level, body, SoundEvents.ENDER_EYE_LAUNCH, 1.0F, 0.5F);
         Sounds.play(level, body, (SoundEvent)SoundEvents.SOUL_ESCAPE.value(), 1.0F, 0.8F);
      });
      ServerScheduler.schedule(
         38,
         () -> {
            if (!player.isRemoved() && player.level() == level) {
               Vec3 at = player.position();
               Sounds.play(level, at, SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.9F, 0.8F);
               Sounds.play(level, at, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0F, 0.6F);
               player.playNotifySound(SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 0.5F, 1.8F);
               player.displayClientMessage(
                  Component.translatable("message.amuletmod.arise_extracted", new Object[]{name, used, budget}).withStyle(ChatFormatting.DARK_PURPLE), true
               );
            }
         }
      );
   }

   public static int raise(ServerPlayer player, int lifetimeTicks) {
      List<ShadowArmy.Recruit> roster = roster(player);
      setRoster(player, List.of());
      ServerLevel level = ((ServerLevel) player.level());
      float yaw = player.getYRot() * (float) (Math.PI / 180.0);
      int raised = 0;

      for (ShadowArmy.Recruit recruit : roster) {
         if (BuiltInRegistries.ENTITY_TYPE.containsKey(recruit.type())) {
            EntityType<?> type = (EntityType<?>)BuiltInRegistries.ENTITY_TYPE.get(recruit.type());
            if (type != null) {
               Vec3 spot = spot(level, player, type, raised, yaw);
               ServerScheduler.schedule(8 + raised * 3, () -> rise(level, player, recruit, type, spot, lifetimeTicks));
               raised++;
            }
         }
      }

      return raised;
   }

   private static Vec3 spot(ServerLevel level, ServerPlayer player, EntityType<?> type, int index, float yaw) {
      int rank = index / 7;
      int place = index % 7;
      double halfWidth = type.getWidth() * 0.5;

      for (int attempt = 0; attempt < 8; attempt++) {
         double angle = yaw + Math.PI + (place - 3) * 0.42 + (attempt % 2 == 0 ? 1 : -1) * (attempt / 2) * 0.3;
         double distance = 3.0 + rank * 2.2 + halfWidth + attempt / 3 * 0.8;
         double x = player.getX() - Math.sin(angle) * distance;
         double z = player.getZ() + Math.cos(angle) * distance;
         Double ground = Frost.groundY(level, x, player.getY(), z, 3, 6);
         if (ground != null) {
            AABB box = new AABB(x - halfWidth, ground, z - halfWidth, x + halfWidth, ground + type.getHeight(), z + halfWidth);
            if (level.noCollision(box)) {
               return new Vec3(x, ground, z);
            }
         }
      }

      return player.position();
   }

   private static void rise(ServerLevel level, ServerPlayer owner, ShadowArmy.Recruit recruit, EntityType<?> type, Vec3 at, int lifetimeTicks) {
      if (!owner.isRemoved() && owner.isAlive() && owner.level() == level) {
         if (type.create(level) instanceof Mob mob) {
            try {
               mob.load(recruit.details().copy());
            } catch (RuntimeException var12) {
               AmuletMod.LOGGER.warn("Couldn't restore the look of a shadow {}", recruit.type(), var12);
            }

            float yaw = owner.getYRot();
            mob.moveTo(at.x, at.y, at.z, yaw, 0.0F);
            mob.setYHeadRot(yaw);
            mob.setYBodyRot(yaw);
            mob.setAirSupply(mob.getMaxAirSupply());
            mob.setHealth(mob.getMaxHealth());
            mob.setPersistenceRequired();
            mob.setCanPickUpLoot(false);

            for (EquipmentSlot slot : EquipmentSlot.values()) {
               mob.setDropChance(slot, 0.0F);
            }

            mob.setCustomName(
               Component.translatable(
                  "entity.amuletmod.shadow_soldier", new Object[]{mob instanceof ShadowPlayerEntity shadow ? shadow.victimName() : type.getDescription()}
               )
            );
            if (mob instanceof AbstractPiglin piglin) {
               piglin.setImmuneToZombification(true);
            }

            if (mob instanceof Hoglin hoglin) {
               hoglin.setImmuneToZombification(true);
            }

            if (mob instanceof Warden) {
               holdAboveGround(mob);
            }

            mob.setNoAi(true);
            mob.setInvulnerable(true);
            enlist(mob, owner.getUUID(), level.getGameTime(), level.getGameTime() + lifetimeTicks, false);
            if (!level.addFreshEntity(mob)) {
               SOLDIERS.remove(mob.getUUID());
            } else {
               PacketDistributor.sendToPlayersTrackingEntity(mob, new FxPacket(FxPacket.Kind.SHADOW_POOL, at, mob.getBbWidth()), new CustomPacketPayload[0]);
               level.sendParticles(ParticleTypes.SQUID_INK, at.x, at.y + 0.1, at.z, 10, mob.getBbWidth() * 0.4, 0.05, mob.getBbWidth() * 0.4, 0.02);
               level.sendParticles(ParticleTypes.REVERSE_PORTAL, at.x, at.y + 0.2, at.z, 16, mob.getBbWidth() * 0.5, 0.3, mob.getBbWidth() * 0.5, 0.03);
               Sounds.play(level, at, SoundEvents.SCULK_CATALYST_BLOOM, 1.2F, 0.6F);
               Sounds.play(level, at, (SoundEvent)SoundEvents.SOUL_ESCAPE.value(), 1.0F, 0.45F + level.random.nextFloat() * 0.2F);
            }
         }
      }
   }

   private static void enlist(Mob mob, UUID owner, long spawnedAt, long expiresAt, boolean risen) {
      ShadowArmy.Soldier soldier = new ShadowArmy.Soldier(owner, mob, spawnedAt, expiresAt);
      soldier.risen = risen;
      SOLDIERS.put(mob.getUUID(), soldier);
      mob.addTag("amuletmod.shadow_soldier");
   }

   @SubscribeEvent
   public static void onLivingTick(Pre event) {
      if (!SOLDIERS.isEmpty() && event.getEntity() instanceof LivingEntity entity && !entity.level().isClientSide()) {
         ShadowArmy.Soldier soldier = SOLDIERS.get(entity.getUUID());
         if (soldier != null && soldier.mob == entity && entity.isAlive()) {
            ServerLevel level = (ServerLevel)entity.level();
            ServerPlayer owner = level.getServer().getPlayerList().getPlayer(soldier.owner);
            long now = level.getGameTime();
            if (owner != null && owner.isAlive() && owner.level() == level && now < soldier.expiresAt) {
               Mob mob = soldier.mob;
               mob.clearFire();
               if (!soldier.risen) {
                  if (now - soldier.spawnedAt < 24L) {
                     return;
                  }

                  soldier.risen = true;
                  mob.setNoAi(false);
                  mob.setInvulnerable(false);
                  mob.playAmbientSound();
               }

               keepLoyal(mob, owner);
               if (--soldier.command <= 0) {
                  soldier.command = 5;
                  command(mob, owner);
               }
            } else {
               dissolve(soldier);
               event.setCanceled(true);
            }
         }
      }
   }

   private static void keepLoyal(Mob mob, ServerPlayer owner) {
      Brain<?> brain = mob.getBrain();
      forgetUnless(brain, MemoryModuleType.ATTACK_TARGET, owner);
      if (mob instanceof Warden warden) {
         warden.clearAnger(owner);
         forgetUnless(brain, MemoryModuleType.ROAR_TARGET, owner);
         if (mob.tickCount % 100 == 0 || !brain.hasMemoryValue(MemoryModuleType.DIG_COOLDOWN)) {
            holdAboveGround(warden);
         }
      }

      LivingEntity target = mob.getTarget();
      if (target != null && !Summons.isFoe(owner, target)) {
         mob.setTarget(null);
      }
   }

   private static void holdAboveGround(Mob warden) {
      warden.getBrain().setMemoryWithExpiry(MemoryModuleType.DIG_COOLDOWN, Unit.INSTANCE, 1200L);
   }

   private static void forgetUnless(Brain<?> brain, MemoryModuleType<LivingEntity> memory, ServerPlayer owner) {
      if (brain.checkMemory(memory, MemoryStatus.REGISTERED)) {
         LivingEntity target = (LivingEntity)brain.getMemory(memory).orElse(null);
         if (target != null && !Summons.isFoe(owner, target)) {
            brain.eraseMemory(memory);
         }
      }
   }

   @Nullable
   private static LivingEntity currentTarget(Mob mob) {
      Brain<?> brain = mob.getBrain();
      if (brain.checkMemory(MemoryModuleType.ATTACK_TARGET, MemoryStatus.REGISTERED)) {
         LivingEntity target = (LivingEntity)brain.getMemory(MemoryModuleType.ATTACK_TARGET).orElse(null);
         if (target != null) {
            return target;
         }
      }

      return mob.getTarget();
   }

   private static void command(Mob mob, ServerPlayer owner) {
      LivingEntity target = currentTarget(mob);
      double leash = 28.0;
      if (target == null || !target.isAlive() || target.distanceToSqr(owner) > leash * leash) {
         target = Summons.findTarget(owner, mob.position(), 20.0, null);
         if (target != null && target.distanceToSqr(owner) <= leash * leash) {
            attack(mob, target);
         } else {
            target = null;
            mob.setTarget(null);
            if (mob.getBrain().checkMemory(MemoryModuleType.ATTACK_TARGET, MemoryStatus.REGISTERED)) {
               mob.getBrain().eraseMemory(MemoryModuleType.ATTACK_TARGET);
            }
         }
      }

      if (target == null) {
         follow(mob, owner);
      }
   }

   private static void attack(Mob mob, LivingEntity target) {
      mob.setTarget(target);
      if (mob instanceof Warden warden) {
         warden.increaseAngerAt(target, 100, false);
         warden.setAttackTarget(target);
      } else {
         Brain<?> brain = mob.getBrain();
         if (brain.checkMemory(MemoryModuleType.ATTACK_TARGET, MemoryStatus.REGISTERED)) {
            brain.setMemory(MemoryModuleType.ATTACK_TARGET, target);
         }
      }
   }

   private static void follow(Mob mob, ServerPlayer owner) {
      double distance = mob.distanceToSqr(owner);
      if (distance > 1600.0) {
         recall(mob, owner);
      } else if (!(distance < 49.0)) {
         if (mob instanceof FlyingMob) {
            mob.getMoveControl().setWantedPosition(owner.getX(), owner.getY() + 3.0, owner.getZ(), 1.0);
         } else if (mob.getBrain().checkMemory(MemoryModuleType.WALK_TARGET, MemoryStatus.REGISTERED)) {
            mob.getBrain().setMemory(MemoryModuleType.WALK_TARGET, new WalkTarget(owner, 1.2F, 3));
         } else {
            mob.getNavigation().moveTo(owner, 1.25);
         }
      }
   }

   private static void recall(Mob mob, ServerPlayer owner) {
      ServerLevel level = (ServerLevel)mob.level();

      for (int attempt = 0; attempt < 10; attempt++) {
         double x = owner.getX() + (level.random.nextDouble() - 0.5) * 6.0;
         double z = owner.getZ() + (level.random.nextDouble() - 0.5) * 6.0;
         Double ground = Frost.groundY(level, x, owner.getY(), z, 3, 6);
         if (ground != null) {
            AABB box = mob.getBoundingBox().move(x - mob.getX(), ground - mob.getY(), z - mob.getZ());
            if (level.noCollision(mob, box)) {
               PacketDistributor.sendToPlayersTrackingEntity(
                  mob, new FxPacket(FxPacket.Kind.SHADOW_VANISH, mob.position(), mob.getBbHeight()), new CustomPacketPayload[0]
               );
               mob.teleportTo(x, ground, z);
               mob.getNavigation().stop();
               PacketDistributor.sendToPlayersTrackingEntity(
                  mob, new FxPacket(FxPacket.Kind.SHADOW_REVEAL, mob.position(), mob.getBbHeight()), new CustomPacketPayload[0]
               );
               return;
            }
         }
      }
   }

   private static void dissolve(ShadowArmy.Soldier soldier) {
      SOLDIERS.remove(soldier.mob.getUUID(), soldier);
      Mob mob = soldier.mob;
      if (!mob.isRemoved()) {
         if (mob.level() instanceof ServerLevel level) {
            Vec3 at = mob.position();
            PacketDistributor.sendToPlayersTrackingEntity(mob, new FxPacket(FxPacket.Kind.SHADOW_DISSOLVE, at, mob.getBbHeight()), new CustomPacketPayload[0]);
            level.sendParticles(
               ParticleTypes.SQUID_INK,
               at.x,
               at.y + mob.getBbHeight() * 0.5,
               at.z,
               14,
               mob.getBbWidth() * 0.4,
               mob.getBbHeight() * 0.3,
               mob.getBbWidth() * 0.4,
               0.02
            );
            Sounds.play(level, at, (SoundEvent)SoundEvents.SOUL_ESCAPE.value(), 0.9F, 0.55F);
         }

         if (mob instanceof Slime slime) {
            slime.setSize(1, false);
         }

         mob.discard();
      }
   }

   public static void dismiss(UUID owner) {
      for (ShadowArmy.Soldier soldier : List.copyOf(SOLDIERS.values())) {
         if (soldier.owner.equals(owner)) {
            dissolve(soldier);
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public static void onLivingDeath(LivingDeathEvent event) {
      LivingEntity dead = event.getEntity();
      if (!dead.level().isClientSide()) {
         ShadowArmy.Soldier soldier = SOLDIERS.get(dead.getUUID());
         if (soldier != null && soldier.mob == dead) {
            ServerScheduler.schedule(1, () -> dissolve(soldier));
         } else if (event.getSource().getEntity() instanceof ServerPlayer player && canExtract(dead, player)) {
            Amulets.Found<AriseAbility> arise = Amulets.find(player, AriseAbility.class);
            if (arise != null && AbilityCooldowns.remainingTicks(player, arise.origin()) <= 0L) {
               extract(player, dead, arise.ability().budget());
            }
         }
      }
   }

   @SubscribeEvent
   public static void onLivingDrops(LivingDropsEvent event) {
      if (ownerOf(event.getEntity()) != null) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void onExperienceDrop(LivingExperienceDropEvent event) {
      if (ownerOf(event.getEntity()) != null) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void onChangeTarget(LivingChangeTargetEvent event) {
      LivingEntity target = event.getNewAboutToBeSetTarget();
      if (target != null && !SOLDIERS.isEmpty() && !event.getEntity().level().isClientSide()) {
         UUID ownerId = ownerOf(event.getEntity());
         if (ownerId != null) {
            ServerPlayer owner = event.getEntity().getServer().getPlayerList().getPlayer(ownerId);
            if (owner == null || !Summons.isFoe(owner, target)) {
               event.setCanceled(true);
            }
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGH
   )
   public static void onLivingAttack(LivingIncomingDamageEvent event) {
      LivingEntity victim = event.getEntity();
      if (!SOLDIERS.isEmpty() && !victim.level().isClientSide()) {
         UUID commander = commanderOf(event.getSource());
         if (commander != null) {
            ServerPlayer owner = victim.getServer().getPlayerList().getPlayer(commander);
            if (owner == null || !Summons.isFoe(owner, victim)) {
               event.setCanceled(true);
            }
         } else {
            UUID master = ownerOf(victim);
            Entity attacker = event.getSource().getEntity();
            if (master != null
               && attacker != null
               && (master.equals(attacker.getUUID()) || attacker instanceof Summons.Owned owned && master.equals(owned.summonerId()))) {
               event.setCanceled(true);
            }
         }
      }
   }

   @SubscribeEvent
   public static void onExplosion(Detonate event) {
      if (!SOLDIERS.isEmpty()) {
         Explosion explosion = event.getExplosion();
         UUID commander = commanderOf(explosion.getIndirectSourceEntity());
         if (commander == null) {
            commander = commanderOf(explosion.getDirectSourceEntity());
         }

         if (commander != null) {
            event.getAffectedBlocks().clear();
            Player owner = event.getLevel().getPlayerByUUID(commander);
            event.getAffectedEntities().removeIf(entity -> !(owner != null && entity instanceof LivingEntity living) || !Summons.isFoe(owner, living));
         }
      }
   }

   @SubscribeEvent
   public static void onMobGriefing(EntityMobGriefingEvent event) {
      if (event.getEntity() != null && ownerOf(event.getEntity()) != null) {
         event.setCanGrief(false);
      }
   }

   @SubscribeEvent
   public static void onConversion(com.amuletmod.neo.event.LivingConversionEvent.Pre event) {
      if (ownerOf(event.getEntity()) != null) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void onEffectAdded(Added event) {
      Entity source = event.getEffectSource();
      if (source != null && event.getEntity() instanceof ServerPlayer player && player.getUUID().equals(commanderOf(source))) {
         Holder<MobEffect> effect = event.getEffectInstance().getEffect();
         ServerScheduler.schedule(1, () -> player.removeEffect(effect));
      }
   }

   @SubscribeEvent
   public static void onEntityJoin(EntityJoinLevelEvent event) {
      Entity entity = event.getEntity();
      if (!entity.level().isClientSide()) {
         if (event.loadedFromDisk()) {
            if (entity.getTags().contains("amuletmod.shadow_soldier")) {
               event.setCanceled(true);
            }
         } else {
            if (entity instanceof Mob mob && entity instanceof TraceableEntity traceable && traceable.getOwner() != null) {
               ShadowArmy.Soldier master = SOLDIERS.get(traceable.getOwner().getUUID());
               if (master != null && master.mob == traceable.getOwner()) {
                  enlist(mob, master.owner, entity.level().getGameTime() - 24L, master.expiresAt, true);
               }
            }
         }
      }
   }

   @SubscribeEvent
   public static void onStartTracking(StartTracking event) {
      Entity target = event.getTarget();
      ShadowArmy.Soldier soldier = SOLDIERS.get(target.getUUID());
      if (soldier != null && soldier.mob == target && event.getEntity() instanceof ServerPlayer player) {
         int age = (int)Math.min(2147483647L, target.level().getGameTime() - soldier.spawnedAt);
         PacketDistributor.sendToPlayer(player, new ShadowSoldierPacket(target.getId(), age), new CustomPacketPayload[0]);
      }
   }

   @SubscribeEvent
   public static void onLogout(PlayerLoggedOutEvent event) {
      dismiss(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onServerTick(Post event) {
      if (++clock % 200 == 0) {
         SOLDIERS.values().removeIf(soldier -> soldier.mob.isRemoved());
      }
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      SOLDIERS.clear();
   }

   public record Recruit(Identifier type, int cost, CompoundTag details) {
      CompoundTag save() {
         CompoundTag tag = new CompoundTag();
         tag.putString("type", this.type.toString());
         tag.putInt("cost", this.cost);
         tag.put("details", this.details);
         return tag;
      }

      @Nullable
      static ShadowArmy.Recruit load(CompoundTag tag) {
         Identifier type = Identifier.tryParse(tag.getString("type"));
         return type == null ? null : new ShadowArmy.Recruit(type, Math.max(1, tag.getInt("cost")), tag.getCompound("details"));
      }
   }

   private static final class Soldier {
      final UUID owner;
      final Mob mob;
      final long spawnedAt;
      final long expiresAt;
      boolean risen;
      int command;

      Soldier(UUID owner, Mob mob, long spawnedAt, long expiresAt) {
         this.owner = owner;
         this.mob = mob;
         this.spawnedAt = spawnedAt;
         this.expiresAt = expiresAt;
      }
   }
}
