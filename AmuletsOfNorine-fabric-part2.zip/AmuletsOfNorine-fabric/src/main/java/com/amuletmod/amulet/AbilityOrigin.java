package com.amuletmod.amulet;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.Identifier;
import org.jetbrains.annotations.Nullable;

public record AbilityOrigin(AmuletItem amulet, int slot) {
   public ActiveAbility ability() {
      ActiveAbility ability = this.amulet.definition().ability(this.slot);
      if (ability == null) {
         throw new IllegalStateException(BuiltInRegistries.ITEM.getKey(this.amulet) + " has no ability " + this.slot);
      } else {
         return ability;
      }
   }

   public CompoundTag save() {
      CompoundTag tag = new CompoundTag();
      tag.putString("Amulet", String.valueOf(BuiltInRegistries.ITEM.getKey(this.amulet)));
      tag.putInt("Slot", this.slot);
      return tag;
   }

   @Nullable
   public static AbilityOrigin load(CompoundTag tag) {
      Identifier id = Identifier.tryParse(tag.getString("Amulet"));
      int slot = tag.getInt("Slot");
      return id != null && BuiltInRegistries.ITEM.get(id) instanceof AmuletItem amulet && amulet.definition().ability(slot) != null
         ? new AbilityOrigin(amulet, slot)
         : null;
   }
}
