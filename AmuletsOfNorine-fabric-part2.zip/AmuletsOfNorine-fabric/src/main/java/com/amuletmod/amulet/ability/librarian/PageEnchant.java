package com.amuletmod.amulet.ability.librarian;

import net.minecraft.world.entity.LivingEntity;

public interface PageEnchant {
   default float damageBonus(int level, LivingEntity target) {
      return 0.0F;
   }

   default boolean piercesArmor() {
      return false;
   }

   default float armorBreach(int level) {
      return 0.0F;
   }

   default int volley(int level) {
      return 0;
   }

   default float cuttingPower(int level) {
      return 0.0F;
   }

   default void onWound(PageStrike strike, int level) {
   }

   default void onTouch(PageStrike strike, int level) {
   }

   default PageLook look() {
      return PageLook.ENCHANTED;
   }
}
