package com.amuletmod.amulet.ability.aegis;

import com.amuletmod.util.Sounds;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public final class Deflection {
   private static final double MAX_AIM_DISTANCE = 64.0;
   private static final Map<Projectile, Long> RECENT = new WeakHashMap<>();

   private Deflection() {
   }

   public static boolean recentlyDeflected(Projectile projectile) {
      Long at = RECENT.get(projectile);
      return at != null && projectile.level().getGameTime() - at < 20L;
   }

   public static void returnToSender(Projectile projectile, @Nullable Entity newOwner, Vec3 fallback) {
      Vec3 motion = projectile.getDeltaMovement();
      double speed = Math.max(motion.length(), 1.0);
      Entity shooter = projectile.getOwner();
      Vec3 direction = fallback;
      if (shooter != null && shooter.isAlive() && shooter != newOwner && shooter.level() == projectile.level() && shooter.distanceToSqr(projectile) < 4096.0) {
         Vec3 toShooter = shooter.position().add(0.0, shooter.getBbHeight() * 0.6, 0.0).subtract(projectile.position());
         direction = toShooter;
         if (!projectile.isNoGravity()) {
            double gravity = projectile instanceof AbstractArrow ? 0.05 : (projectile instanceof ThrowableProjectile ? 0.03 : 0.0);
            double ticks = toShooter.length() / speed;
            direction = toShooter.add(0.0, 0.5 * gravity * ticks * ticks, 0.0);
         }
      }

      if (direction.lengthSqr() < 1.0E-6) {
         direction = motion.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 1.0, 0.0) : motion.reverse();
      }

      redirect(projectile, direction.normalize().scale(speed), newOwner);
   }

   public static void redirect(Projectile projectile, Vec3 velocity, @Nullable Entity newOwner) {
      projectile.setDeltaMovement(velocity);
      if (projectile instanceof AbstractHurtingProjectile fireball) {
         fireball.accelerationPower = 0.1;
      }

      if (newOwner != null) {
         projectile.setOwner(newOwner);
      }

      float yRot = (float)(Mth.atan2(velocity.x, velocity.z) * 180.0F / (float)Math.PI);
      float xRot = (float)(Mth.atan2(velocity.y, velocity.horizontalDistance()) * 180.0F / (float)Math.PI);
      projectile.setYRot(yRot);
      projectile.setXRot(xRot);
      projectile.yRotO = yRot;
      projectile.xRotO = xRot;
      projectile.hasImpulse = true;
      RECENT.put(projectile, projectile.level().getGameTime());
   }

   public static void sparks(ServerLevel level, Vec3 at) {
      level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 12, 0.15, 0.15, 0.15, 0.3);
      level.sendParticles(ParticleTypes.END_ROD, at.x, at.y, at.z, 4, 0.1, 0.1, 0.1, 0.08);
      Sounds.play(level, at, SoundEvents.SHIELD_BLOCK, 0.8F, 1.3F + level.random.nextFloat() * 0.2F);
      Sounds.play(level, at, SoundEvents.AMETHYST_BLOCK_HIT, 1.0F, 1.6F);
   }
}
