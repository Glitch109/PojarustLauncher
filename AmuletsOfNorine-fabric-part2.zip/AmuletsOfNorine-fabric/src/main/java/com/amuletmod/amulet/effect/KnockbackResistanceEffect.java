package com.amuletmod.amulet.effect;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.AmuletEffect;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.item.ItemStack;

public record KnockbackResistanceEffect(float amount) implements AmuletEffect {
   private static final Identifier MODIFIER = AmuletMod.id("amulet_knockback_resistance");

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.effect.knockback_resistance", new Object[]{Math.round(this.amount * 100.0F)});
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      AttributeInstance resistance = wearer.getAttribute(Attributes.KNOCKBACK_RESISTANCE);
      if (resistance != null && resistance.getModifier(MODIFIER) == null) {
         resistance.addTransientModifier(new AttributeModifier(MODIFIER, this.amount, Operation.ADD_VALUE));
      }
   }

   @Override
   public void onUnequip(LivingEntity wearer, ItemStack amulet) {
      AttributeInstance resistance = wearer.getAttribute(Attributes.KNOCKBACK_RESISTANCE);
      if (resistance != null && resistance.getModifier(MODIFIER) != null) {
         resistance.removeModifier(MODIFIER);
      }
   }
}
