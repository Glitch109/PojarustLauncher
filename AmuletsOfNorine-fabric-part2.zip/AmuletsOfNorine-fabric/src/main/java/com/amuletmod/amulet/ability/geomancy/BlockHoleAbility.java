package com.amuletmod.amulet.ability.geomancy;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.entity.BlockHoleEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public record BlockHoleAbility(double travelDistance, int radius, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.block_hole", new Object[]{this.radius});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      ItemStack held = player.getMainHandItem();
      if (held.getItem() instanceof BlockItem blockItem) {
         Block block = blockItem.getBlock();
         BlockState state = block.defaultBlockState();
         if (!state.isAir() && !state.hasBlockEntity() && !(state.getDestroySpeed(level, player.blockPosition()) < 0.0F)) {
            Vec3 eye = player.getEyePosition();
            Vec3 look = player.getLookAngle();
            Vec3 from = eye.add(look.scale(0.6));
            Vec3 end = eye.add(look.scale(0.6 + this.travelDistance));
            BlockHitResult hit = level.clip(new ClipContext(eye, end, net.minecraft.world.level.ClipContext.Block.COLLIDER, Fluid.NONE, player));
            Vec3 to = hit.getType() == Type.MISS ? end : hit.getLocation().subtract(look.scale(0.5));
            level.addFreshEntity(new BlockHoleEntity(level, player, from, to, block, this.radius));
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0F, 0.6F);
            player.displayClientMessage(
               Component.translatable("message.amuletmod.block_hole_cast", new Object[]{block.getName()}).withStyle(ChatFormatting.YELLOW), true
            );
            return true;
         } else {
            return fail(player, Component.translatable("message.amuletmod.block_hole_invalid_block", new Object[]{block.getName()}));
         }
      } else {
         return fail(player, Component.translatable("message.amuletmod.block_hole_need_block"));
      }
   }

   private static boolean fail(ServerPlayer player, Component message) {
      player.displayClientMessage(message.copy().withStyle(ChatFormatting.RED), true);
      return false;
   }
}
