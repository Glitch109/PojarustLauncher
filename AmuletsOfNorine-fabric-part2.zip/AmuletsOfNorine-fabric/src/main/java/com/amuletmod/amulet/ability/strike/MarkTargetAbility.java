package com.amuletmod.amulet.ability.strike;

import com.amuletmod.amulet.ActiveAbility;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public record MarkTargetAbility(double range, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.mark_target", new Object[]{(int)this.range});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      HitResult hit = player.pick(this.range, 1.0F, true);
      if (hit instanceof BlockHitResult blockHit && hit.getType() == Type.BLOCK) {
         Vec3 target = Vec3.atBottomCenterOf(blockHit.getBlockPos().above());
         StrikeTargets.set(player, new StrikeTarget(player.level().dimension(), target));
         player.playNotifySound(SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0F, 1.6F);
         player.playNotifySound(SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 0.7F);
         player.displayClientMessage(
            Component.translatable("message.amuletmod.target_marked", new Object[]{(int)Math.round(player.position().distanceTo(target))})
               .withStyle(ChatFormatting.LIGHT_PURPLE),
            true
         );
         return true;
      } else {
         player.displayClientMessage(
            Component.translatable("message.amuletmod.target_out_of_range", new Object[]{(int)this.range}).withStyle(ChatFormatting.RED), true
         );
         return false;
      }
   }
}
