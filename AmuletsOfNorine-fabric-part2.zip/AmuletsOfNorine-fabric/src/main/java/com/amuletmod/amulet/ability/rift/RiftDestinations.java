package com.amuletmod.amulet.ability.rift;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public final class RiftDestinations {
   private static final int SEARCH_RADIUS = 16;
   private static final List<int[]> SEARCH_ORDER = new ArrayList<>();

   private RiftDestinations() {
   }

   @Nullable
   public static ServerLevel targetLevel(MinecraftServer server, RiftKind kind) {
      ServerLevel level = server.getLevel(kind.dimension());
      return level != null && server.isLevelEnabled(level) ? level : null;
   }

   public static Vec3 arrival(ServerPlayer player, ServerLevel target) {
      if (target.dimension() == Level.END) {
         return Vec3.atBottomCenterOf(ServerLevel.END_SPAWN_POINT);
      } else {
         ServerLevel source = ((ServerLevel) player.level());
         Vec3 from;
         DimensionType fromType;
         if (source.dimension() != Level.OVERWORLD && source.dimension() != Level.NETHER) {
            ServerLevel overworld = player.server.overworld();
            BlockPos respawn = player.getRespawnDimension() == Level.OVERWORLD ? player.getRespawnPosition() : null;
            from = Vec3.atBottomCenterOf(respawn != null ? respawn : overworld.getSharedSpawnPos());
            fromType = overworld.dimensionType();
         } else {
            from = player.position();
            fromType = source.dimensionType();
         }

         double scale = DimensionType.getTeleportationScale(fromType, target.dimensionType());
         BlockPos anchor = target.getWorldBorder().clampToBounds(from.x * scale, from.y, from.z * scale);
         return target.dimensionType().hasCeiling() ? findInCavern(target, anchor) : findOnSurface(target, anchor);
      }
   }

   private static Vec3 findOnSurface(ServerLevel level, BlockPos anchor) {
      for (int[] offset : SEARCH_ORDER) {
         int x = anchor.getX() + offset[0];
         int z = anchor.getZ() + offset[1];
         BlockPos feet = new BlockPos(x, surfaceHeight(level, Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
         if (feet.getY() > level.getMinBuildHeight() && isSafe(level, feet)) {
            return Vec3.atBottomCenterOf(feet);
         }
      }

      int y = surfaceHeight(level, Types.MOTION_BLOCKING, anchor.getX(), anchor.getZ());
      return Vec3.atBottomCenterOf(new BlockPos(anchor.getX(), Math.max(y, level.getMinBuildHeight() + 1), anchor.getZ()));
   }

   private static int surfaceHeight(ServerLevel level, Types type, int x, int z) {
      return level.getChunk(x >> 4, z >> 4).getHeight(type, x & 15, z & 15) + 1;
   }

   private static Vec3 findInCavern(ServerLevel level, BlockPos anchor) {
      int floor = level.getMinBuildHeight() + 2;
      int ceiling = level.getMinBuildHeight() + level.getLogicalHeight() - 4;
      int preferred = Mth.clamp(anchor.getY(), floor + 30, ceiling - 30);
      MutableBlockPos pos = new MutableBlockPos();

      for (int[] offset : SEARCH_ORDER) {
         int x = anchor.getX() + offset[0];
         int z = anchor.getZ() + offset[1];

         for (int dy = 0; dy <= ceiling - floor; dy++) {
            int above = preferred + dy;
            if (above <= ceiling && isSafe(level, pos.set(x, above, z))) {
               return Vec3.atBottomCenterOf(pos);
            }

            int below = preferred - dy;
            if (dy > 0 && below >= floor && isSafe(level, pos.set(x, below, z))) {
               return Vec3.atBottomCenterOf(pos);
            }
         }
      }

      BlockPos center = new BlockPos(anchor.getX(), preferred, anchor.getZ());

      for (int dx = -1; dx <= 1; dx++) {
         for (int dz = -1; dz <= 1; dz++) {
            level.setBlockAndUpdate(center.offset(dx, -1, dz), Blocks.OBSIDIAN.defaultBlockState());

            for (int dy = 0; dy < 3; dy++) {
               level.setBlockAndUpdate(center.offset(dx, dy, dz), Blocks.AIR.defaultBlockState());
            }
         }
      }

      return Vec3.atBottomCenterOf(center);
   }

   private static boolean isSafe(ServerLevel level, BlockPos feet) {
      BlockPos below = feet.below();
      BlockState ground = level.getBlockState(below);
      return ground.isFaceSturdy(level, below, Direction.UP) && ground.getFluidState().isEmpty() && !ground.is(Blocks.MAGMA_BLOCK)
         ? isOpen(level, feet) && isOpen(level, feet.above())
         : false;
   }

   private static boolean isOpen(ServerLevel level, BlockPos pos) {
      BlockState state = level.getBlockState(pos);
      return state.getCollisionShape(level, pos).isEmpty() && state.getFluidState().isEmpty() && !state.is(BlockTags.FIRE) && !state.is(Blocks.POWDER_SNOW);
   }

   static {
      for (int dx = -16; dx <= 16; dx++) {
         for (int dz = -16; dz <= 16; dz++) {
            SEARCH_ORDER.add(new int[]{dx, dz});
         }
      }

      SEARCH_ORDER.sort(Comparator.comparingInt(offset -> offset[0] * offset[0] + offset[1] * offset[1]));
   }
}
