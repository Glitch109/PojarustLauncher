package com.amuletmod.amulet.ability.lightning;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.network.FxPacket;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import com.amuletmod.util.VanillaEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.PacketDistributor;

public record LightningDashAbility(double distance, float damage, int cooldownTicks) implements ActiveAbility {
   private static final double STEP = 0.5;
   private static final Map<UUID, Vec3[]> RECENT = new HashMap<>();
   private static final int HISTORY = 4;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.lightning_dash", new Object[]{(int)this.distance});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      Vec3 direction = direction(player);
      Vec3 start = player.position();
      Vec3 end = this.destination(player, direction);
      if (end.distanceTo(start) < 1.5) {
         player.displayClientMessage(Component.translatable("message.amuletmod.dash_blocked").withStyle(ChatFormatting.RED), true);
         return false;
      } else {
         Vec3 chest = new Vec3(0.0, player.getBbHeight() * 0.5, 0.0);
         Vec3 from = start.add(chest);
         Vec3 to = end.add(chest);

         for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, new AABB(from, to).inflate(1.5), targetx -> Summons.isFoe(player, targetx))) {
            AABB body = target.getBoundingBox().inflate(0.6);
            if (body.contains(from) || !body.clip(from, to).isEmpty()) {
               if (target.hurt(ModDamage.source(level, ModDamage.SHOCK, player, player), this.damage)) {
                  target.addEffect(new MobEffectInstance(VanillaEffects.MOVEMENT_SLOWDOWN, 30, 2), player);
               }

               level.sendParticles(
                  ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(), 16, 0.3, 0.4, 0.3, 0.3
               );
            }
         }

         player.stopRiding();
         player.teleportTo(end.x, end.y, end.z);
         player.fallDistance = 0.0F;
         player.setDeltaMovement(direction.scale(0.45));
         player.hurtMarked = true;
         RECENT.remove(player.getUUID());
         PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new FxPacket(FxPacket.Kind.DASH, from, to, 1.0F), new CustomPacketPayload[0]);
         PacketDistributor.sendToPlayer(player, new FxPacket(FxPacket.Kind.SHOCK_VIGNETTE, to, 1.0F), new CustomPacketPayload[0]);

         for (double t = 0.0; t <= 1.0; t += 1.5 / Math.max(1.5, from.distanceTo(to))) {
            Vec3 at = from.lerp(to, t);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 2, 0.15, 0.3, 0.15, 0.05);
         }

         Sounds.play(level, from, SoundEvents.LIGHTNING_BOLT_IMPACT, 0.7F, 1.6F);
         Sounds.play(level, to, SoundEvents.LIGHTNING_BOLT_IMPACT, 0.9F, 1.2F);
         Sounds.play(level, to, (SoundEvent)SoundEvents.TRIDENT_RIPTIDE_1.value(), 0.6F, 1.5F);
         return true;
      }
   }

   private static Vec3 direction(ServerPlayer player) {
      Vec3[] recent = RECENT.get(player.getUUID());
      if (recent != null && recent[3] != null) {
         Vec3 moved = player.position().subtract(recent[3]).multiply(1.0, 0.0, 1.0);
         if (moved.lengthSqr() > 0.04) {
            return moved.normalize();
         }
      }

      return Vec3.directionFromRotation(0.0F, player.getYRot());
   }

   private Vec3 destination(ServerPlayer player, Vec3 direction) {
      Vec3 start = player.position();
      AABB box = player.getBoundingBox();
      Vec3 at = start;

      for (int step = 0; step < this.distance / 0.5; step++) {
         Vec3 next = at.add(direction.scale(0.5));
         if (fits(player, box, next.subtract(start))) {
            at = next;
         } else {
            if (!fits(player, box, at.add(0.0, 1.0, 0.0).subtract(start)) || !fits(player, box, next.add(0.0, 1.0, 0.0).subtract(start))) {
               break;
            }

            at = next.add(0.0, 1.0, 0.0);
         }
      }

      return at;
   }

   private static boolean fits(ServerPlayer player, AABB box, Vec3 offset) {
      return player.level().noCollision(player, box.move(offset)) && player.level().getWorldBorder().isWithinBounds(box.move(offset));
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (wearer instanceof ServerPlayer) {
         Vec3[] recent = RECENT.computeIfAbsent(wearer.getUUID(), id -> new Vec3[4]);
         System.arraycopy(recent, 0, recent, 1, 3);
         recent[0] = wearer.position();
      }
   }
}
