package com.amuletmod.amulet.ability.librarian;

import com.amuletmod.amulet.ability.glacial.Frost;
import com.amuletmod.entity.PageBindEntity;
import com.amuletmod.util.LightningStrikes;
import com.amuletmod.util.Sounds;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import com.amuletmod.util.VanillaEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public final class PageEnchants {
   private static final int SECONDS = 20;
   public static final PageEnchant UNKNOWN = new PageEnchants.Honed(0.2F);
   private static final Map<Identifier, PageEnchant> EFFECTS = new HashMap<>();

   private PageEnchants() {
   }

   private static void vanilla(String id, PageEnchant effect) {
      EFFECTS.put(Identifier.fromNamespaceAndPath("minecraft", id), effect);
   }

   public static PageEnchant of(Holder<Enchantment> enchantment) {
      return enchantment.unwrapKey().map(key -> EFFECTS.getOrDefault(key.location(), UNKNOWN)).orElse(UNKNOWN);
   }

   private static int curseTicks(LivingEntity target) {
      return 60 + target.getRandom().nextInt(81);
   }

   static {
      vanilla("sharpness", new PageEnchants.Keen(0.8F, null));
      vanilla("power", new PageEnchants.Keen(0.8F, null));
      vanilla("smite", new PageEnchants.Keen(1.2F, EntityTypeTags.SENSITIVE_TO_SMITE));
      vanilla("bane_of_arthropods", new PageEnchants.Keen(1.2F, EntityTypeTags.SENSITIVE_TO_BANE_OF_ARTHROPODS));
      vanilla("impaling", new PageEnchants.Keen(1.2F, EntityTypeTags.SENSITIVE_TO_IMPALING));
      vanilla("knockback", new PageEnchants.Shove(0.6F));
      vanilla("punch", new PageEnchants.Shove(0.6F));
      vanilla("fire_aspect", new PageEnchants.Ignite(4));
      vanilla("flame", new PageEnchants.Ignite(5));
      vanilla("sweeping_edge", new PageEnchants.Sweep());
      vanilla("looting", new PageEnchants.Plunder());
      vanilla("piercing", new PageEnchants.Pierce());
      vanilla("multishot", new PageEnchants.Volley());
      vanilla("wind_burst", new PageEnchants.Gust());
      vanilla("density", new PageEnchants.Heavy());
      vanilla("breach", new PageEnchants.Breach());
      vanilla("channeling", new PageEnchants.Channel());
      vanilla("efficiency", new PageEnchants.Cutting(0.24F, true));
      vanilla("silk_touch", new PageEnchants.Cutting(0.8F, false));
      vanilla("protection", new PageEnchants.Boon(VanillaEffects.DAMAGE_RESISTANCE, 1));
      vanilla("blast_protection", new PageEnchants.Boon(VanillaEffects.DAMAGE_RESISTANCE, 1));
      vanilla("projectile_protection", new PageEnchants.Boon(VanillaEffects.DAMAGE_RESISTANCE, 1));
      vanilla("fire_protection", new PageEnchants.Boon(VanillaEffects.FIRE_RESISTANCE, 0));
      vanilla("feather_falling", new PageEnchants.Boon(VanillaEffects.SLOW_FALLING, 0));
      vanilla("respiration", new PageEnchants.Boon(VanillaEffects.WATER_BREATHING, 0));
      vanilla("aqua_affinity", new PageEnchants.Boon(VanillaEffects.CONDUIT_POWER, 0));
      vanilla("depth_strider", new PageEnchants.Boon(VanillaEffects.DOLPHINS_GRACE, 0));
      vanilla("soul_speed", new PageEnchants.Boon(VanillaEffects.MOVEMENT_SPEED, 1));
      vanilla("thorns", new PageEnchants.Backlash());
      vanilla("frost_walker", new PageEnchants.Chill(30));
      vanilla("binding_curse", new PageEnchants.Bind());
      vanilla("vanishing_curse", new PageEnchants.Fade());
   }

   public record Backlash() implements PageEnchant {
      @Override
      public void onTouch(PageStrike strike, int level) {
         LivingEntity thrower = strike.thrower();
         if (thrower != null && thrower.isAlive()) {
            float damage = level > 10 ? level - 10 : 1 + thrower.getRandom().nextInt(4);
            thrower.hurt(thrower.damageSources().thorns(strike.target()), damage);
            Sounds.play(strike.level(), thrower.position(), SoundEvents.THORNS_HIT, 1.0F, 1.0F);
         }
      }
   }

   public record Bind() implements PageEnchant {
      @Override
      public void onWound(PageStrike strike, int level) {
         PageBindEntity.bind(strike.level(), strike.target(), PageEnchants.curseTicks(strike.target()));
      }

      @Override
      public PageLook look() {
         return PageLook.CURSED;
      }
   }

   public record Boon(Holder<MobEffect> effect, int maxAmplifier) implements PageEnchant {
      @Override
      public void onTouch(PageStrike strike, int level) {
         LivingEntity target = strike.target();
         if (target.isAlive()) {
            target.addEffect(new MobEffectInstance(this.effect, Mth.clamp(level, 1, 4) * 20, Math.min(this.maxAmplifier, (level - 1) / 2)), strike.thrower());
         }
      }
   }

   public record Breach() implements PageEnchant {
      @Override
      public float armorBreach(int level) {
         return 0.15F * level;
      }

      @Override
      public void onWound(PageStrike strike, int level) {
         LivingEntity target = strike.target();
         if (target.getArmorValue() > 0) {
            ServerLevel world = strike.level();
            Vec3 at = target.position().add(0.0, target.getBbHeight() * 0.6, 0.0);
            ItemStack piece = armorPiece(target);
            if (piece.isEmpty()) {
               world.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 8, 0.25, 0.3, 0.25, 0.3);
            } else {
               world.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, piece), at.x, at.y, at.z, 8, 0.2, 0.25, 0.2, 0.12);
            }

            Sounds.play(world, at, SoundEvents.SHIELD_BREAK, 0.5F, 1.5F + world.random.nextFloat() * 0.2F);
         }
      }

      private static ItemStack armorPiece(LivingEntity target) {
         ItemStack chest = target.getItemBySlot(EquipmentSlot.CHEST);
         if (!chest.isEmpty()) {
            return chest;
         } else {
            for (EquipmentSlot slot : EquipmentSlot.values()) {
               if (slot.isArmor() && !target.getItemBySlot(slot).isEmpty()) {
                  return target.getItemBySlot(slot);
               }
            }

            return ItemStack.EMPTY;
         }
      }
   }

   public record Channel() implements PageEnchant {
      @Override
      public void onWound(PageStrike strike, int level) {
         LivingEntity target = strike.target();
         ServerLevel world = strike.level();
         Vec3 at = target.position().add(0.0, target.getBbHeight() * 0.5, 0.0);
         world.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 10, 0.3, 0.4, 0.3, 0.3);
         if (world.canSeeSky(BlockPos.containing(at)) && (world.isThundering() || strike.page().load().spend(this, level))) {
            LightningStrikes.strike(world, target, strike.thrower() instanceof ServerPlayer player ? player : null);
            Sounds.play(world, at, (SoundEvent)SoundEvents.TRIDENT_THUNDER.value(), 1.5F, 1.0F);
         }
      }

      @Override
      public PageLook look() {
         return PageLook.STORMY;
      }
   }

   public record Chill(int ticksPerLevel) implements PageEnchant {
      @Override
      public void onWound(PageStrike strike, int level) {
         Frost.chill(strike.target(), this.ticksPerLevel * level);
      }

      @Override
      public PageLook look() {
         return PageLook.FROSTY;
      }
   }

   public record Cutting(float power, boolean perLevel) implements PageEnchant {
      @Override
      public float cuttingPower(int level) {
         return this.perLevel ? this.power * level : this.power;
      }
   }

   public record Fade() implements PageEnchant {
      @Override
      public void onTouch(PageStrike strike, int level) {
         LivingEntity target = strike.target();
         if (target.isAlive()) {
            target.addEffect(new MobEffectInstance(VanillaEffects.INVISIBILITY, PageEnchants.curseTicks(target), 0), strike.thrower());
         }
      }

      @Override
      public PageLook look() {
         return PageLook.CURSED;
      }
   }

   public record Gust() implements PageEnchant {
      private static final double MAX_LIFT = 3.0;

      @Override
      public void onWound(PageStrike strike, int level) {
         LivingEntity target = strike.target();
         ServerLevel world = strike.level();
         launch(target, Vec3.ZERO, Math.min(3.0, 0.5 + 0.4 * level));
         double radius = 2.5 + 0.5 * level;

         for (LivingEntity other : world.getEntitiesOfClass(
            LivingEntity.class,
            target.getBoundingBox().inflate(radius),
            otherx -> otherx != target && otherx != strike.thrower() && strike.page().canStrike(otherx)
         )) {
            Vec3 away = other.position().subtract(target.position()).multiply(1.0, 0.0, 1.0);
            double distance = away.length();
            if (!(distance > radius)) {
               double falloff = 1.0 - distance / radius;
               Vec3 push = distance < 0.001 ? Vec3.ZERO : away.scale(Math.min(3.0, 0.6 + 0.25 * level) * falloff / distance);
               launch(other, push, Math.min(3.0, 0.3 + 0.15 * level) * falloff);
            }
         }

         Vec3 at = target.position().add(0.0, target.getBbHeight() * 0.5, 0.0);
         world.sendParticles(ParticleTypes.GUST_EMITTER_SMALL, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
         Sounds.play(world, at, (SoundEvent)SoundEvents.WIND_CHARGE_BURST.value(), 1.0F, 0.9F + world.random.nextFloat() * 0.2F);
      }

      private static void launch(LivingEntity entity, Vec3 push, double lift) {
         double give = 1.0 - entity.getAttributeValue(Attributes.EXPLOSION_KNOCKBACK_RESISTANCE);
         if (!(give <= 0.0)) {
            Vec3 motion = entity.getDeltaMovement().add(push.scale(give));
            entity.setDeltaMovement(motion.x, Math.max(motion.y, lift * give), motion.z);
            entity.resetFallDistance();
            entity.hasImpulse = true;
            entity.hurtMarked = true;
         }
      }

      @Override
      public PageLook look() {
         return PageLook.WINDY;
      }
   }

   public record Heavy() implements PageEnchant {
      private static final double MAX_DROP = 3.0;

      @Override
      public float damageBonus(int level, LivingEntity target) {
         return 0.1F * level * target.fallDistance;
      }

      @Override
      public void onWound(PageStrike strike, int level) {
         LivingEntity target = strike.target();
         ServerLevel world = strike.level();
         Vec3 at = target.position();
         if (target.onGround()) {
            BlockState ground = world.getBlockState(target.getBlockPosBelowThatAffectsMyMovement());
            if (!ground.isAir()) {
               world.sendParticles(new BlockParticleOption(ParticleTypes.DUST_PILLAR, ground), at.x, at.y, at.z, 12, 0.3, 0.0, 0.3, 0.15);
            }

            Sounds.play(world, at, SoundEvents.MACE_SMASH_GROUND, 0.6F, 1.2F);
         } else {
            if (target instanceof Player player && player.isFallFlying()) {
               player.stopFallFlying();
            }

            Vec3 motion = target.getDeltaMovement();
            target.setDeltaMovement(motion.x * 0.5, Math.min(motion.y, -Math.min(3.0, 0.8 + 0.2 * level)), motion.z * 0.5);
            target.hasImpulse = true;
            target.hurtMarked = true;
            Sounds.play(world, at, SoundEvents.MACE_SMASH_AIR, 0.7F, 1.1F);
         }

         if (target.isAlive()) {
            target.addEffect(new MobEffectInstance(VanillaEffects.MOVEMENT_SLOWDOWN, Mth.clamp(level, 1, 5) * 20, Math.min(2, (level - 1) / 2)), strike.thrower());
         }
      }
   }

   public record Honed(float bonus) implements PageEnchant {
      @Override
      public float damageBonus(int level, LivingEntity target) {
         return this.bonus;
      }
   }

   public record Ignite(int secondsPerLevel) implements PageEnchant {
      @Override
      public void onWound(PageStrike strike, int level) {
         strike.target().igniteForSeconds(this.secondsPerLevel * level);
      }

      @Override
      public PageLook look() {
         return PageLook.FIERY;
      }
   }

   public record Keen(float perLevel, @Nullable TagKey<EntityType<?>> prey) implements PageEnchant {
      @Override
      public float damageBonus(int level, LivingEntity target) {
         return this.prey != null && !target.getType().is(this.prey) ? 0.0F : this.perLevel * level;
      }
   }

   public record Pierce() implements PageEnchant {
      @Override
      public boolean piercesArmor() {
         return true;
      }
   }

   public record Plunder() implements PageEnchant {
      private static final float SHARE_PER_LEVEL = 0.11111111F;
      private static final int ORBS = 5;
      private static final int PICKUP_DELAY = 30;

      @Override
      public void onWound(PageStrike strike, int level) {
         if (strike.target() instanceof ServerPlayer victim) {
            int amount = Math.min(points(victim), Math.max(1, Math.round(victim.getXpNeededForNextLevel() * 0.11111111F * level)));
            if (amount > 0) {
               victim.giveExperiencePoints(-amount);
               victim.takeXpDelay = Math.max(victim.takeXpDelay, 30);
               ServerLevel world = strike.level();
               Vec3 at = victim.position().add(0.0, victim.getBbHeight() * 0.6, 0.0);
               int orbs = Math.min(amount, 5);
               float start = victim.getRandom().nextFloat() * (float) (Math.PI * 2);

               for (int i = 0; i < orbs; i++) {
                  int value = amount / orbs + (i < amount % orbs ? 1 : 0);
                  ExperienceOrb orb = new ExperienceOrb(world, at.x, at.y, at.z, value);
                  float angle = start + i * (float) (Math.PI * 2) / orbs;
                  orb.setDeltaMovement(Mth.cos(angle) * 0.38, 0.3 + victim.getRandom().nextDouble() * 0.15, Mth.sin(angle) * 0.38);
                  world.addFreshEntity(orb);
               }

               Sounds.play(world, at, SoundEvents.EXPERIENCE_ORB_PICKUP, 0.9F, 0.5F);
            }
         }
      }

      private static int points(Player player) {
         long level = player.experienceLevel;
         double base = level <= 16L
            ? level * level + 6L * level
            : (level <= 31L ? 2.5 * level * level - 40.5 * level + 360.0 : 4.5 * level * level - 162.5 * level + 2220.0);
         return (int)Math.min(2147483647L, Math.round(base + player.experienceProgress * player.getXpNeededForNextLevel()));
      }
   }

   public record Shove(float perLevel) implements PageEnchant {
      @Override
      public void onWound(PageStrike strike, int level) {
         Vec3 direction = strike.direction();
         strike.target().knockback(this.perLevel * level, -direction.x, -direction.z);
      }
   }

   public record Sweep() implements PageEnchant {
      @Override
      public void onWound(PageStrike strike, int level) {
         LivingEntity target = strike.target();
         float share = level / (level + 1.0F);

         for (LivingEntity other : strike.level()
            .getEntitiesOfClass(
               LivingEntity.class,
               target.getBoundingBox().inflate(1.0, 0.25, 1.0),
               otherx -> otherx != target && otherx != strike.thrower() && strike.page().canStrike(otherx)
            )) {
            other.hurt(strike.source(), strike.damage() * share);
         }

         Vec3 at = target.position().add(0.0, target.getBbHeight() * 0.5, 0.0);
         strike.level().sendParticles(ParticleTypes.SWEEP_ATTACK, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
         Sounds.play(strike.level(), at, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0F, 1.2F);
      }
   }

   public record Volley() implements PageEnchant {
      @Override
      public int volley(int level) {
         return Math.min(18, 3 * (1 + level));
      }
   }
}
