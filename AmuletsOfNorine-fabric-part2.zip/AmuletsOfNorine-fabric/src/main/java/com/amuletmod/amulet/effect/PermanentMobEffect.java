package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public record PermanentMobEffect(Holder<MobEffect> effect, int amplifier) implements AmuletEffect {
   @Override
   public Component description() {
      return Component.translatable(
         "tooltip.amuletmod.effect.permanent_mob_effect",
         new Object[]{((MobEffect)this.effect.value()).getDisplayName(), Component.translatable("enchantment.level." + (this.amplifier + 1))}
      );
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      MobEffectInstance current = wearer.getEffect(this.effect);
      if (current == null || current.getAmplifier() <= this.amplifier && (current.getAmplifier() != this.amplifier || !current.isInfiniteDuration())) {
         wearer.addEffect(new MobEffectInstance(this.effect, -1, this.amplifier, true, false, true));
      }
   }

   @Override
   public void onUnequip(LivingEntity wearer, ItemStack amulet) {
      MobEffectInstance current = wearer.getEffect(this.effect);
      if (current != null && current.isInfiniteDuration() && current.getAmplifier() == this.amplifier) {
         wearer.removeEffect(this.effect);
      }
   }

   @Override
   public boolean isDrawback() {
      return ((MobEffect)this.effect.value()).getCategory() == MobEffectCategory.HARMFUL;
   }
}
