package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.biome.Biome;
import com.amuletmod.neo.event.ProjectileImpactEvent;
import com.amuletmod.neo.event.EnderManAngerEvent;
import com.amuletmod.neo.event.LivingDeathEvent;
import com.amuletmod.neo.event.LivingFallEvent;
import com.amuletmod.neo.event.LivingHealEvent;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;
import org.jetbrains.annotations.Nullable;

public record InBiomeEffect(TagKey<Biome> biomes, @Nullable TagKey<Biome> except, AmuletEffect inner) implements AmuletEffect {
   @Override
   public Component description() {
      Identifier id = this.biomes.location();
      return Component.translatable(
         "tooltip.amuletmod.effect.in_biome",
         new Object[]{Component.translatable("tooltip.amuletmod.biomes." + id.getNamespace() + "." + id.getPath()), this.inner.description()}
      );
   }

   private boolean isIn(LivingEntity wearer) {
      Holder<Biome> biome = wearer.level().getBiome(wearer.blockPosition());
      return biome.is(this.biomes) && (this.except == null || !biome.is(this.except));
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onWearerTick(wearer, amulet);
      } else {
         this.inner.onUnequip(wearer, amulet);
      }
   }

   @Override
   public void onUnequip(LivingEntity wearer, ItemStack amulet) {
      this.inner.onUnequip(wearer, amulet);
   }

   @Override
   public void onWearerFall(LivingFallEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onWearerFall(event, wearer, amulet);
      }
   }

   @Override
   public void onWearerHurt(LivingIncomingDamageEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onWearerHurt(event, wearer, amulet);
      }
   }

   @Override
   public void onWearerHitByProjectile(ProjectileImpactEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onWearerHitByProjectile(event, wearer, amulet);
      }
   }

   @Override
   public void onWearerDeath(LivingDeathEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onWearerDeath(event, wearer, amulet);
      }
   }

   @Override
   public void onWearerHeal(LivingHealEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onWearerHeal(event, wearer, amulet);
      }
   }

   @Override
   public void onEndermanStare(EnderManAngerEvent event, Player wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onEndermanStare(event, wearer, amulet);
      }
   }

   @Override
   public boolean isDrawback() {
      return this.inner.isDrawback();
   }
}
