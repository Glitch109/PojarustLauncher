package com.amuletmod.amulet.ability.sylvan;

import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.entity.PetalEntity;
import com.amuletmod.network.PetalSwarmPacket;
import com.amuletmod.util.Sounds;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.PlayerEvent.PlayerChangedDimensionEvent;
import com.amuletmod.neo.event.PlayerEvent.StartTracking;
import com.amuletmod.neo.event.ServerStoppedEvent;
import com.amuletmod.neo.event.ServerTickEvent.Post;
import com.amuletmod.neo.PacketDistributor;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class PetalSwarms {
   private static final int FIRE_INTERVAL = 2;
   private static final int RETARGET_CYCLES = 5;
   private static final int GRACE_TICKS = 3;
   private static final Map<UUID, PetalSwarms.Swarm> SWARMS = new HashMap<>();

   private PetalSwarms() {
   }

   public static int freeSlot(ServerPlayer player) {
      PetalSwarms.Swarm swarm = SWARMS.get(player.getUUID());
      if (swarm == null) {
         return 0;
      } else {
         for (int slot = 0; slot < 5; slot++) {
            if (swarm.petals[slot] == 0) {
               return slot;
            }
         }

         return -1;
      }
   }

   public static int blossoms(ServerPlayer player) {
      PetalSwarms.Swarm swarm = SWARMS.get(player.getUUID());
      return swarm == null ? 0 : swarm.blossoms();
   }

   public static void bloom(ServerPlayer player, int slot, Item flower, double range, float damage) {
      PetalSwarms.Swarm swarm = SWARMS.computeIfAbsent(player.getUUID(), id -> new PetalSwarms.Swarm());
      int color = FlowerColors.of(flower, player.level());
      swarm.colors[slot] = color;
      swarm.petals[slot] = 5;
      swarm.flowers[slot] = flower;
      swarm.range = range;
      swarm.damage = damage;
      swarm.lastWorn = player.server.getTickCount();
      sync(player, swarm);
      ServerLevel level = ((ServerLevel) player.level());
      Vec3 at = PetalOrbit.blossom(PetalOrbit.center(player, player.getX(), player.getY(), player.getZ()), slot, level.getGameTime());
      level.sendParticles(new DustParticleOptions(rgb(color), 1.2F), at.x, at.y, at.z, 14, 0.25, 0.25, 0.25, 0.0);
      level.sendParticles(ParticleTypes.CHERRY_LEAVES, at.x, at.y, at.z, 4, 0.3, 0.2, 0.3, 0.0);
   }

   public static void worn(ServerPlayer player) {
      PetalSwarms.Swarm swarm = SWARMS.get(player.getUUID());
      if (swarm != null) {
         swarm.lastWorn = player.server.getTickCount();
      }
   }

   public static void track(@Nullable UUID ownerId, int fromTarget, int toTarget) {
      PetalSwarms.Swarm swarm = ownerId == null ? null : SWARMS.get(ownerId);
      if (swarm != null) {
         if (fromTarget >= 0 && swarm.inFlight.addTo(fromTarget, -1) <= 1) {
            swarm.inFlight.remove(fromTarget);
         }

         if (toTarget >= 0) {
            swarm.inFlight.addTo(toTarget, 1);
         }
      }
   }

   public static Vector3f rgb(int color) {
      return new Vector3f((color >> 16 & 0xFF) / 255.0F, (color >> 8 & 0xFF) / 255.0F, (color & 0xFF) / 255.0F);
   }

   @SubscribeEvent
   public static void onServerTick(Post event) {
      if (!SWARMS.isEmpty()) {
         MinecraftServer server = event.getServer();
         Iterator<Entry<UUID, PetalSwarms.Swarm>> it = SWARMS.entrySet().iterator();

         while (it.hasNext()) {
            Entry<UUID, PetalSwarms.Swarm> entry = it.next();
            PetalSwarms.Swarm swarm = entry.getValue();
            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            if (player == null) {
               it.remove();
            } else if (!player.isAlive() || server.getTickCount() - swarm.lastWorn > 3) {
               scatter(player, swarm);
               it.remove();
            } else if (swarm.blossoms() == 0) {
               if (swarm.inFlight.isEmpty()) {
                  it.remove();
               }
            } else {
               fire(player, swarm);
            }
         }
      }
   }

   private static void fire(ServerPlayer player, PetalSwarms.Swarm swarm) {
      if (--swarm.fireCooldown <= 0) {
         swarm.fireCooldown = 2;
         LivingEntity current = swarm.target;
         if (current != null
            && (
               !current.isAlive()
                  || current.level() != player.level()
                  || !Summons.isFoe(player, current)
                  || current.distanceToSqr(player) > swarm.range * swarm.range
            )) {
            swarm.target = null;
            swarm.retarget = 0;
         }

         if (--swarm.retarget <= 0) {
            swarm.retarget = 5;
            swarm.target = Summons.findTarget(player, player.getEyePosition(), swarm.range, player);
         }

         LivingEntity target = swarm.target;
         if (target != null) {
            if (!(swarm.inFlight.get(target.getId()) * swarm.damage >= target.getHealth() + target.getAbsorptionAmount())) {
               int slot = -1;

               for (int i = 0; i < 5; i++) {
                  if (swarm.petals[i] > 0 && (slot < 0 || swarm.petals[i] < swarm.petals[slot])) {
                     slot = i;
                  }
               }

               int petal = --swarm.petals[slot];
               ServerLevel level = ((ServerLevel) player.level());
               double time = level.getGameTime();
               Vec3 center = PetalOrbit.center(player, player.getX(), player.getY(), player.getZ());
               Vec3 from = PetalOrbit.petal(center, slot, petal, time);
               Vec3 launch = PetalOrbit.petalDirection(slot, petal, time).scale(0.3).add(PetalOrbit.outward(slot, time).scale(0.3)).add(0.0, 0.25, 0.0);
               level.addFreshEntity(new PetalEntity(level, player, target, from, launch, swarm.colors[slot], swarm.flowers[slot], swarm.damage));
               track(player.getUUID(), -1, target.getId());
               if (swarm.petals[slot] == 0) {
                  swarm.colors[slot] = 0;
                  swarm.flowers[slot] = null;
               }

               sync(player, swarm);
               Sounds.play(level, from, SoundEvents.PLAYER_ATTACK_SWEEP, 0.2F, 1.8F + level.random.nextFloat() * 0.3F);
               Sounds.play(level, from, SoundEvents.PINK_PETALS_PLACE, 0.5F, 1.4F + level.random.nextFloat() * 0.3F);
            }
         }
      }
   }

   private static void scatter(ServerPlayer player, PetalSwarms.Swarm swarm) {
      if (swarm.blossoms() != 0) {
         ServerLevel level = ((ServerLevel) player.level());
         Vec3 center = PetalOrbit.center(player, player.getX(), player.getY(), player.getZ());

         for (int slot = 0; slot < 5; slot++) {
            if (swarm.petals[slot] != 0) {
               Vec3 at = PetalOrbit.blossom(center, slot, level.getGameTime());
               level.sendParticles(new DustParticleOptions(rgb(swarm.colors[slot]), 1.0F), at.x, at.y, at.z, 8, 0.3, 0.3, 0.3, 0.0);
               level.sendParticles(ParticleTypes.CHERRY_LEAVES, at.x, at.y, at.z, swarm.petals[slot], 0.3, 0.2, 0.3, 0.0);
               swarm.petals[slot] = 0;
               swarm.colors[slot] = 0;
            }
         }

         Sounds.play(level, center, SoundEvents.PINK_PETALS_BREAK, 0.8F, 0.9F);
         sync(player, swarm);
      }
   }

   private static void sync(ServerPlayer player, PetalSwarms.Swarm swarm) {
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, packet(player, swarm), new CustomPacketPayload[0]);
   }

   private static PetalSwarmPacket packet(ServerPlayer player, PetalSwarms.Swarm swarm) {
      return new PetalSwarmPacket(player.getId(), (int[])swarm.colors.clone(), (int[])swarm.petals.clone());
   }

   @SubscribeEvent
   public static void onStartTracking(StartTracking event) {
      if (event.getTarget() instanceof ServerPlayer wearer && event.getEntity() instanceof ServerPlayer watcher) {
         PetalSwarms.Swarm swarm = SWARMS.get(wearer.getUUID());
         if (swarm != null && swarm.blossoms() > 0) {
            PacketDistributor.sendToPlayer(watcher, packet(wearer, swarm), new CustomPacketPayload[0]);
         }
      }
   }

   @SubscribeEvent
   public static void onChangedDimension(PlayerChangedDimensionEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         PetalSwarms.Swarm swarm = SWARMS.get(player.getUUID());
         if (swarm != null) {
            PacketDistributor.sendToPlayer(player, packet(player, swarm), new CustomPacketPayload[0]);
         }
      }
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      SWARMS.clear();
   }

   private static final class Swarm {
      final int[] colors = new int[5];
      final int[] petals = new int[5];
      final Item[] flowers = new Item[5];
      double range;
      float damage;
      int lastWorn;
      int fireCooldown;
      int retarget;
      @Nullable
      LivingEntity target;
      final Int2IntOpenHashMap inFlight = new Int2IntOpenHashMap();

      int blossoms() {
         int count = 0;

         for (int petalCount : this.petals) {
            if (petalCount > 0) {
               count++;
            }
         }

         return count;
      }
   }
}
