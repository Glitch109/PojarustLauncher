package com.amuletmod.amulet.ability.librarian;

import com.amuletmod.registry.ModTags;
import com.amuletmod.util.Sounds;
import com.amuletmod.util.StackData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public final class Tome {
   public static final int VOLLEYS = 6;
   public static final int PAGES = 18;
   private static final String TORN = "amuletmod:torn_pages";

   private Tome() {
   }

   public static boolean isTome(ItemStack stack) {
      return stack.is(ModTags.TOMES);
   }

   public static boolean isWorn(ItemStack stack) {
      CompoundTag tag = StackData.get(stack);
      return tag != null && tag.getInt("amuletmod:torn_pages") > 0;
   }

   public static int pagesLeft(ItemStack stack) {
      CompoundTag tag = StackData.get(stack);
      return Math.max(0, 18 - (tag == null ? 0 : tag.getInt("amuletmod:torn_pages")));
   }

   @Nullable
   public static InteractionHand heldTome(LivingEntity holder) {
      for (InteractionHand hand : InteractionHand.values()) {
         if (isTome(holder.getItemInHand(hand))) {
            return hand;
         }
      }

      return null;
   }

   public static void tear(ServerPlayer player, InteractionHand hand, int pages) {
      ItemStack book = player.getItemInHand(hand);
      if (!player.getAbilities().instabuild) {
         int torn = 18 - pagesLeft(book) + pages;
         if (torn < 18) {
            StackData.update(book, tag -> tag.putInt("amuletmod:torn_pages", torn));
         } else {
            ItemStack spent = book.copyWithCount(1);
            book.shrink(1);
            StackData.remove(book, "amuletmod:torn_pages");
            ServerLevel level = ((ServerLevel) player.level());
            Vec3 at = player.getEyePosition().add(player.getLookAngle().scale(0.5)).add(0.0, -0.4, 0.0);
            level.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, spent), at.x, at.y, at.z, 16, 0.15, 0.15, 0.15, 0.08);
            Sounds.play(level, at, SoundEvents.ITEM_BREAK, 0.8F, 0.8F);
            Sounds.play(level, at, SoundEvents.BOOK_PAGE_TURN, 1.0F, 0.6F);
            player.displayClientMessage(
               Component.translatable("message.amuletmod.book_spent", new Object[]{spent.getHoverName()}).withStyle(ChatFormatting.GRAY), true
            );
         }
      }
   }
}
