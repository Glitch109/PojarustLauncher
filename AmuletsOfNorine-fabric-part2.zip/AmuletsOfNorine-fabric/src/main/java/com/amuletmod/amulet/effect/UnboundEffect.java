package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentUtils;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public record UnboundEffect(List<Holder<MobEffect>> shrugged) implements AmuletEffect {
   @Override
   public Component description() {
      return Component.translatable(
         "tooltip.amuletmod.effect.unbound",
         new Object[]{
            ComponentUtils.formatList(this.shrugged.stream().map(effect -> ((MobEffect)effect.value()).getDisplayName()).toList(), Component.literal(", "))
         }
      );
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      for (Holder<MobEffect> effect : this.shrugged) {
         if (wearer.hasEffect(effect)) {
            wearer.removeEffect(effect);
         }
      }
   }
}
