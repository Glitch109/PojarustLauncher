package com.amuletmod.amulet.ability.seal;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.AmuletItem;
import com.amuletmod.amulet.ability.sovereign.AuraSight;
import com.amuletmod.entity.SealCaptureEntity;
import com.amuletmod.seal.SealPrison;
import com.amuletmod.util.Aim;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public record CaptureSealAbility(double range, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.capture_seal", new Object[]{(int)this.range});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      LivingEntity target = Aim.lookedAt(player, this.range, living -> living.isAlive() && (living instanceof Mob || living instanceof Player));
      if (target == null) {
         return refuse(player, Component.translatable("message.amuletmod.capture_no_target"), false);
      } else if (!(target instanceof EnderDragon) && (target instanceof Player || target.getType().canSerialize())) {
         if (target instanceof Player other && !player.canHarmPlayer(other)) {
            return refuse(player, Component.translatable("message.amuletmod.capture_protected", new Object[]{target.getDisplayName()}), true);
         } else if (target instanceof Player && SealPrison.realm(player.server) == null) {
            return refuse(player, Component.translatable("message.amuletmod.capture_no_realm"), true);
         } else {
            float theirs = AuraSight.power(target);
            float yours = AuraSight.power(player);
            if (theirs > yours) {
               return refuse(
                  player,
                  Component.translatable("message.amuletmod.capture_too_strong", new Object[]{target.getDisplayName(), Math.round(theirs), Math.round(yours)}),
                  true
               );
            } else if (SealCaptureEntity.isTaking(level, target)) {
               return refuse(player, Component.translatable("message.amuletmod.capture_already", new Object[]{target.getDisplayName()}), false);
            } else {
               level.addFreshEntity(new SealCaptureEntity(level, player, target, ((AmuletItem)amulet.getItem()).originOf(amulet, this)));
               player.displayClientMessage(
                  Component.translatable("message.amuletmod.capture_closing", new Object[]{target.getDisplayName()}).withStyle(ChatFormatting.LIGHT_PURPLE),
                  true
               );
               return true;
            }
         }
      } else {
         return refuse(player, Component.translatable("message.amuletmod.capture_immune", new Object[]{target.getDisplayName()}), true);
      }
   }

   private static boolean refuse(ServerPlayer player, Component why, boolean rattle) {
      player.displayClientMessage(why.copy().withStyle(ChatFormatting.RED), true);
      if (rattle) {
         player.playNotifySound(SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 1.0F, 0.6F);
      }

      return false;
   }
}
