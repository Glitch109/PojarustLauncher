package com.amuletmod.amulet.ability.stealth;

import com.amuletmod.amulet.AbilityCooldowns;
import com.amuletmod.amulet.AbilityOrigin;
import com.amuletmod.network.FxPacket;
import com.amuletmod.network.ShadowMarkSyncPacket;
import com.amuletmod.util.PlayerData;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.PlayerEvent.PlayerChangedDimensionEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedInEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedOutEvent;
import com.amuletmod.neo.event.ServerStoppedEvent;
import com.amuletmod.neo.event.ServerTickEvent.Post;
import com.amuletmod.neo.PacketDistributor;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class ShadowMarks {
   private static final String KEY = "shadow_mark";
   private static final TicketType<ChunkPos> REACH_TICKET = TicketType.create("amuletmod:shadow_reach", Comparator.comparingLong(ChunkPos::toLong), 100);
   private static final int LOAD_TIMEOUT = 80;
   private static final Map<UUID, ShadowMarks.Channel> CHANNELS = new HashMap<>();
   private static final Map<UUID, Integer> SYNCED = new HashMap<>();

   private ShadowMarks() {
   }

   @Nullable
   public static ShadowMarks.Mark get(ServerPlayer player) {
      CompoundTag data = PlayerData.get(player);
      return data.contains("shadow_mark") ? ShadowMarks.Mark.load(data.getCompound("shadow_mark")) : null;
   }

   public static void set(ServerPlayer player, LivingEntity target) {
      PlayerData.get(player)
         .put("shadow_mark", new ShadowMarks.Mark(target.getUUID(), target.level().dimension(), target.position(), target instanceof ServerPlayer).save());
      sync(player, target);
   }

   public static void clear(ServerPlayer player) {
      PlayerData.get(player).remove("shadow_mark");
      sync(player, null);
   }

   public static boolean isSwapping(ServerPlayer player) {
      return CHANNELS.containsKey(player.getUUID());
   }

   @Nullable
   public static LivingEntity find(MinecraftServer server, ShadowMarks.Mark mark) {
      Entity found = null;
      if (mark.isPlayer()) {
         found = server.getPlayerList().getPlayer(mark.target());
      } else {
         ServerLevel home = server.getLevel(mark.dimension());
         if (home != null) {
            found = home.getEntity(mark.target());
         }

         if (found == null) {
            for (ServerLevel level : server.getAllLevels()) {
               if ((found = level.getEntity(mark.target())) != null) {
                  break;
               }
            }
         }
      }

      return found instanceof LivingEntity living && living.isAlive() ? living : null;
   }

   public static void track(ServerPlayer player) {
      ShadowMarks.Mark mark = get(player);
      if (mark != null) {
         LivingEntity target = find(player.server, mark);
         if (target != null) {
            PlayerData.get(player)
               .put("shadow_mark", new ShadowMarks.Mark(mark.target(), target.level().dimension(), target.position(), mark.isPlayer()).save());
            sync(player, target);
         }
      }
   }

   private static void sync(ServerPlayer player, @Nullable Entity target) {
      int id = target == null ? -1 : target.getId();
      Integer previous = SYNCED.put(player.getUUID(), id);
      if (previous == null || previous != id) {
         PacketDistributor.sendToPlayer(player, new ShadowMarkSyncPacket(id), new CustomPacketPayload[0]);
      }
   }

   public static boolean beginSwap(ServerPlayer player, ShadowMarks.Mark mark, int channelTicks, AbilityOrigin ability) {
      LivingEntity target = find(player.server, mark);
      if (target == null) {
         ServerLevel home = player.server.getLevel(mark.dimension());
         if (mark.isPlayer() || home == null) {
            player.displayClientMessage(Component.translatable("message.amuletmod.shadow_mark_gone").withStyle(ChatFormatting.RED), true);
            return false;
         }

         ChunkPos chunk = new ChunkPos(BlockPos.containing(mark.lastSeen()));
         home.getChunkSource().addRegionTicket(REACH_TICKET, chunk, 2, chunk);
      }

      CHANNELS.put(player.getUUID(), new ShadowMarks.Channel(mark, channelTicks, ability));
      ServerLevel level = ((ServerLevel) player.level());
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(
         player, new FxPacket(FxPacket.Kind.SHADOW_VANISH, player.position(), player.getBbHeight()), new CustomPacketPayload[0]
      );
      level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ILLUSIONER_PREPARE_MIRROR, SoundSource.PLAYERS, 0.5F, 0.7F);
      return true;
   }

   @SubscribeEvent
   public static void onServerTick(Post event) {
      if (!CHANNELS.isEmpty()) {
         MinecraftServer server = event.getServer();
         Iterator<Entry<UUID, ShadowMarks.Channel>> it = CHANNELS.entrySet().iterator();

         while (it.hasNext()) {
            Entry<UUID, ShadowMarks.Channel> entry = it.next();
            ShadowMarks.Channel channel = entry.getValue();
            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            if (player != null && player.isAlive()) {
               channel.ticks++;
               LivingEntity target = find(server, channel.mark);
               if (target != null && !channel.targetShown) {
                  channel.targetShown = true;
                  PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                     target, new FxPacket(FxPacket.Kind.SHADOW_VANISH, target.position(), target.getBbHeight()), new CustomPacketPayload[0]
                  );
               }

               if (target != null && channel.ticks >= channel.channelTicks) {
                  it.remove();
                  swap(player, target);
               } else if (channel.ticks >= channel.channelTicks + 80) {
                  it.remove();
                  AbilityCooldowns.clear(player, channel.ability);
                  clear(player);
                  player.displayClientMessage(Component.translatable("message.amuletmod.shadow_mark_gone").withStyle(ChatFormatting.RED), true);
               }
            } else {
               it.remove();
            }
         }
      }
   }

   private static void swap(ServerPlayer player, LivingEntity target) {
      ServerLevel playerLevel = ((ServerLevel) player.level());
      ServerLevel targetLevel = (ServerLevel)target.level();
      Vec3 playerAt = player.position();
      Vec3 targetAt = target.position();
      player.stopRiding();
      player.ejectPassengers();
      target.stopRiding();
      target.ejectPassengers();
      UUID targetId = target.getUUID();
      target.teleportTo(playerLevel, playerAt.x, playerAt.y, playerAt.z, Set.of(), target.getYRot(), target.getXRot());
      player.teleportTo(targetLevel, targetAt.x, targetAt.y, targetAt.z, player.getYRot(), player.getXRot());
      player.fallDistance = 0.0F;
      Entity moved = playerLevel.getEntity(targetId);
      if (moved instanceof LivingEntity living) {
         living.fallDistance = 0.0F;
         if (living instanceof Mob mob) {
            mob.getNavigation().stop();
         }

         arrive(living);
      }

      arrive(player);
      PacketDistributor.sendToPlayer(player, new FxPacket(FxPacket.Kind.SHADOW_VIGNETTE, targetAt, 1.0F), new CustomPacketPayload[0]);
      if (moved instanceof ServerPlayer other) {
         PacketDistributor.sendToPlayer(other, new FxPacket(FxPacket.Kind.SHADOW_VIGNETTE, playerAt, 1.0F), new CustomPacketPayload[0]);
         other.displayClientMessage(Component.translatable("message.amuletmod.shadow_swapped_victim").withStyle(ChatFormatting.DARK_PURPLE), true);
      }

      player.displayClientMessage(
         Component.translatable("message.amuletmod.shadow_swapped", new Object[]{moved == null ? target.getDisplayName() : moved.getDisplayName()})
            .withStyle(ChatFormatting.DARK_PURPLE),
         true
      );
      clear(player);
   }

   private static void arrive(LivingEntity entity) {
      ServerLevel level = (ServerLevel)entity.level();
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(
         entity, new FxPacket(FxPacket.Kind.SHADOW_REVEAL, entity.position(), entity.getBbHeight()), new CustomPacketPayload[0]
      );
      level.sendParticles(ParticleTypes.REVERSE_PORTAL, entity.getX(), entity.getY() + entity.getBbHeight() * 0.5, entity.getZ(), 30, 0.3, 0.5, 0.3, 0.05);
      level.playSound(null, entity.getX(), entity.getY(), entity.getZ(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.5F, 0.5F);
      level.playSound(null, entity.getX(), entity.getY(), entity.getZ(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.PLAYERS, 0.5F, 1.2F);
   }

   @SubscribeEvent
   public static void onLogin(PlayerLoggedInEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         SYNCED.remove(player.getUUID());
         track(player);
      }
   }

   @SubscribeEvent
   public static void onLogout(PlayerLoggedOutEvent event) {
      SYNCED.remove(event.getEntity().getUUID());
      CHANNELS.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onChangedDimension(PlayerChangedDimensionEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         SYNCED.remove(player.getUUID());
         track(player);
      }
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      CHANNELS.clear();
      SYNCED.clear();
   }

   private static final class Channel {
      final ShadowMarks.Mark mark;
      final int channelTicks;
      final AbilityOrigin ability;
      int ticks;
      boolean targetShown;

      Channel(ShadowMarks.Mark mark, int channelTicks, AbilityOrigin ability) {
         this.mark = mark;
         this.channelTicks = channelTicks;
         this.ability = ability;
      }
   }

   public record Mark(UUID target, ResourceKey<Level> dimension, Vec3 lastSeen, boolean isPlayer) {
      CompoundTag save() {
         CompoundTag tag = new CompoundTag();
         tag.putUUID("target", this.target);
         tag.putString("dimension", this.dimension.location().toString());
         tag.putDouble("x", this.lastSeen.x);
         tag.putDouble("y", this.lastSeen.y);
         tag.putDouble("z", this.lastSeen.z);
         tag.putBoolean("player", this.isPlayer);
         return tag;
      }

      @Nullable
      static ShadowMarks.Mark load(CompoundTag tag) {
         Identifier dimension = Identifier.tryParse(tag.getString("dimension"));
         return tag.hasUUID("target") && dimension != null
            ? new ShadowMarks.Mark(
               tag.getUUID("target"),
               ResourceKey.create(Registries.DIMENSION, dimension),
               new Vec3(tag.getDouble("x"), tag.getDouble("y"), tag.getDouble("z")),
               tag.getBoolean("player")
            )
            : null;
      }
   }
}
