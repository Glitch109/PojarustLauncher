package com.amuletmod.amulet.ability.chrono;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.entity.TimeFieldEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public record TimeStopAbility(float radius, int durationTicks, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.time_stop", new Object[]{(int)this.radius, this.durationTicks / 20});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      level.addFreshEntity(new TimeFieldEntity(level, player, this.radius, this.durationTicks));
      player.displayClientMessage(Component.translatable("message.amuletmod.time_stop").withStyle(ChatFormatting.GOLD), true);
      return true;
   }
}
