package com.amuletmod.amulet.ability.sovereign;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.network.FxPacket;
import com.amuletmod.util.ServerScheduler;
import com.amuletmod.util.Sounds;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.PacketDistributor;

public record AriseAbility(int budget, int lifetimeTicks, int cooldownTicks) implements ActiveAbility {
   private static final float WAVE_RADIUS = 9.0F;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.arise", new Object[]{this.budget, this.lifetimeTicks / 20, 5});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      int strength = ShadowArmy.strength(ShadowArmy.roster(player));
      int raised = strength <= 0 ? 0 : ShadowArmy.raise(player, this.lifetimeTicks);
      if (raised == 0) {
         player.displayClientMessage(Component.translatable("message.amuletmod.arise_empty").withStyle(ChatFormatting.RED), true);
         return false;
      } else {
         ServerLevel level = ((ServerLevel) player.level());
         Vec3 at = player.position();
         player.connection.send(new ClientboundSetTitlesAnimationPacket(4, 26, 14));
         player.connection
            .send(
               new ClientboundSetTitleTextPacket(
                  Component.translatable("title.amuletmod.arise").withStyle(new ChatFormatting[]{ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD})
               )
            );
         PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new FxPacket(FxPacket.Kind.ARISE, at, 9.0F), new CustomPacketPayload[0]);
         PacketDistributor.sendToPlayer(player, new FxPacket(FxPacket.Kind.SHADOW_VIGNETTE, at, 1.0F), new CustomPacketPayload[0]);
         Sounds.play(level, at, SoundEvents.EVOKER_PREPARE_SUMMON, 1.2F, 0.5F);
         Sounds.play(level, at, (SoundEvent)SoundEvents.RESPAWN_ANCHOR_DEPLETE.value(), 1.0F, 0.5F);
         Sounds.play(level, at, SoundEvents.BELL_RESONATE, 0.8F, 0.5F);
         ServerScheduler.schedule(6, () -> Sounds.play(level, at, SoundEvents.WARDEN_EMERGE, 0.6F, 1.3F));
         player.displayClientMessage(
            Component.translatable("message.amuletmod.arise", new Object[]{raised, strength}).withStyle(ChatFormatting.DARK_PURPLE), true
         );
         return true;
      }
   }
}
