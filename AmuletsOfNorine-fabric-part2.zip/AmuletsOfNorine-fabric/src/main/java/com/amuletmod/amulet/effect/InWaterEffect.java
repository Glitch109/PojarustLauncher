package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import com.amuletmod.util.Sounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public record InWaterEffect(AmuletEffect inner) implements AmuletEffect {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.effect.in_water", new Object[]{this.inner.description()});
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (!wearer.isInWaterOrBubble()) {
         this.inner.onUnequip(wearer, amulet);
      } else {
         this.inner.onWearerTick(wearer, amulet);
         if (wearer.tickCount % 8 == 0 && wearer.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.CLOUD, wearer.getX(), wearer.getY() + wearer.getBbHeight() * 0.6, wearer.getZ(), 2, 0.3, 0.3, 0.3, 0.02);
            level.sendParticles(ParticleTypes.BUBBLE_COLUMN_UP, wearer.getX(), wearer.getY() + 0.4, wearer.getZ(), 3, 0.3, 0.4, 0.3, 0.05);
         }

         if (wearer.tickCount % 50 == 0) {
            Sounds.play(wearer.level(), wearer.position(), SoundEvents.FIRE_EXTINGUISH, 0.35F, 1.4F);
         }
      }
   }

   @Override
   public void onUnequip(LivingEntity wearer, ItemStack amulet) {
      this.inner.onUnequip(wearer, amulet);
   }

   @Override
   public boolean isDrawback() {
      return this.inner.isDrawback();
   }
}
