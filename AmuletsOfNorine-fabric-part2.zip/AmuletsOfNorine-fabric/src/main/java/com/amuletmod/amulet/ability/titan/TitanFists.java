package com.amuletmod.amulet.ability.titan;

import com.amuletmod.amulet.AbilityCooldowns;
import com.amuletmod.amulet.Amulets;
import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.amulet.ability.sovereign.AuraSight;
import com.amuletmod.entity.TitanFistEntity;
import com.amuletmod.seal.SealPrison;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.minecraft.world.phys.shapes.CollisionContext;
import com.amuletmod.neo.EventPriority;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.EntityTeleportEvent;
import com.amuletmod.neo.event.LivingFallEvent;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;
import com.amuletmod.neo.event.PlayerFlyableFallEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerChangeGameModeEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerChangedDimensionEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedOutEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerRespawnEvent;
import com.amuletmod.neo.event.ServerStoppedEvent;
import com.amuletmod.neo.event.PlayerTickEvent.Pre;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class TitanFists {
   public static final float BASE_POWER = 31.5F;
   public static final float BASE_DAMAGE = 5.0F;
   private static final float POWER_CURVE = 1.1F;
   private static final double SLACK = 0.4;
   private static final double MIN_CLEARANCE = 3.0;
   private static final double CRUSH_HEIGHT = 7.0;
   private static final int LAUNCH_GRACE = 20;
   private static final double LAUNCH_RISE = 0.1;
   private static final int SETTLE_TICKS = 10;
   private static final int LAUNCH_LIMIT = 1200;
   private static final int COMBO_TICKS = 50;
   private static final Map<UUID, TitanFists.Combo> COMBOS = new HashMap<>();
   private static final Map<UUID, TitanFists.Launch> LAUNCHED = new HashMap<>();

   private TitanFists() {
   }

   public static float might(LivingEntity puncher) {
      return Math.max(0.5F, AuraSight.power(puncher) / 31.5F);
   }

   public static float damage(float might) {
      return 5.0F * (float)Math.pow(might, 1.1F);
   }

   public static boolean canStrike(Player puncher, LivingEntity target) {
      return target != puncher
            && target.isAlive()
            && !target.isSpectator()
            && target.isAttackable()
            && !(target instanceof ArmorStand)
            && !Summons.isSummonedBy(target, puncher)
            && !target.isAlliedTo(puncher)
            && !puncher.isAlliedTo(target)
            && !target.isPassengerOfSameVehicle(puncher)
            && !(target instanceof OwnableEntity pet && puncher.getUUID().equals(pet.getOwnerUUID()))
         ? !(target instanceof Player other && (other.isCreative() || !puncher.canHarmPlayer(other)))
         : false;
   }

   public static void punch(ServerPlayer player, float yaw, float pitch) {
      if (player.isAlive() && !player.isSpectator() && player.getMainHandItem().isEmpty() && !SealPrison.isImprisoned(player)) {
         Amulets.Found<TitanFistsAbility> found = Amulets.find(player, TitanFistsAbility.class);
         if (found != null) {
            TitanFistsAbility fists = found.ability();
            Stance stance = Stance.of(player);
            if (stance != null) {
               long remaining = AbilityCooldowns.remainingTicks(player, found.origin(), stance.id());
               if (remaining > 0L) {
                  if (stance != Stance.JAB) {
                     player.displayClientMessage(
                        Component.translatable("message.amuletmod.titan_recharging", new Object[]{stance.title(), (remaining + 19L) / 20L})
                           .withStyle(ChatFormatting.RED),
                        true
                     );
                  }
               } else {
                  Vec3 look = Vec3.directionFromRotation(Mth.clamp(pitch, -90.0F, 90.0F), yaw);
                  float might = might(player);

                  boolean thrown = switch (stance) {
                     case JAB -> jab(player, fists, look, might);
                     case CRUSH -> crush(player, fists, look, might);
                     case UPPERCUT -> uppercut(player, fists, look, might);
                  };
                  if (thrown) {
                     AbilityCooldowns.start(player, found.origin(), stance.id(), fists.cooldown(stance, player.getRandom()));
                     TitanSync.hud(player, -1);
                  }
               }
            }
         }
      }
   }

   private static boolean jab(ServerPlayer player, TitanFistsAbility fists, Vec3 look, float might) {
      TitanFists.Strike strike = aim(player, look, fists.jabRange());
      int shoulder = nextShoulder(player);
      Vec3 from = TitanFistEntity.shoulder(player.getEyePosition(), look, shoulder);
      Vec3 at = strike.point();
      if (strike.target() == null && strike.blocked()) {
         at = at.subtract(at.subtract(from).normalize().scale(0.15));
      }

      ServerLevel level = ((ServerLevel) player.level());
      level.addFreshEntity(new TitanFistEntity(level, player, Stance.JAB, at, from, strike.target(), might, shoulder, 0.0F));
      return true;
   }

   private static boolean crush(ServerPlayer player, TitanFistsAbility fists, Vec3 look, float might) {
      TitanFists.Strike strike = aim(player, look, fists.remoteRange());
      Vec3 spot = strike.target() != null ? groundUnder(player.level(), strike.target()) : landing(player.level(), strike.point(), look);
      if (spot == null) {
         return noGround(player);
      } else if (clearance(player.level(), spot, 7.0) < 3.0) {
         player.displayClientMessage(Component.translatable("message.amuletmod.titan_no_room").withStyle(ChatFormatting.GRAY), true);
         return false;
      } else {
         ServerLevel level = ((ServerLevel) player.level());
         level.addFreshEntity(new TitanFistEntity(level, player, Stance.CRUSH, spot, player.position(), strike.target(), might, 0, fists.shockwave()));
         return true;
      }
   }

   private static boolean uppercut(ServerPlayer player, TitanFistsAbility fists, Vec3 look, float might) {
      TitanFists.Strike strike = aim(player, look, fists.remoteRange());
      Vec3 spot = strike.target() != null ? groundUnder(player.level(), strike.target()) : landing(player.level(), strike.point(), look);
      if (spot == null) {
         return noGround(player);
      } else {
         ServerLevel level = ((ServerLevel) player.level());
         level.addFreshEntity(new TitanFistEntity(level, player, Stance.UPPERCUT, spot, player.position(), strike.target(), might, 0, 0.0F));
         return true;
      }
   }

   private static boolean noGround(ServerPlayer player) {
      player.displayClientMessage(Component.translatable("message.amuletmod.titan_no_ground").withStyle(ChatFormatting.GRAY), true);
      return false;
   }

   private static int nextShoulder(ServerPlayer player) {
      TitanFists.Combo combo = COMBOS.get(player.getUUID());
      int shoulder = combo != null && player.tickCount - combo.at() <= 50 && player.tickCount >= combo.at() ? combo.next() : 0;
      COMBOS.put(player.getUUID(), new TitanFists.Combo(player.tickCount, (shoulder + 1) % 3));
      return shoulder;
   }

   private static TitanFists.Strike aim(ServerPlayer player, Vec3 look, double range) {
      Level level = player.level();
      Vec3 eye = player.getEyePosition();
      BlockHitResult wall = level.clip(new ClipContext(eye, eye.add(look.scale(range)), Block.COLLIDER, Fluid.NONE, player));
      boolean blocked = wall.getType() != Type.MISS;
      Vec3 end = blocked ? wall.getLocation() : eye.add(look.scale(range));
      LivingEntity best = null;
      double bestDistance = Double.MAX_VALUE;

      for (Entity entity : level.getEntities(
         player, new AABB(eye, end).inflate(1.4), entityx -> entityx instanceof LivingEntity living && canStrike(player, living)
      )) {
         AABB box = entity.getBoundingBox().inflate(0.4 + entity.getPickRadius());
         Optional<Vec3> hit = box.contains(eye) ? Optional.of(eye) : box.clip(eye, end);
         if (hit.isPresent() && hit.get().distanceToSqr(eye) < bestDistance) {
            bestDistance = hit.get().distanceToSqr(eye);
            best = (LivingEntity)entity;
         }
      }

      return best != null ? new TitanFists.Strike(best.getBoundingBox().getCenter(), best, false) : new TitanFists.Strike(end, null, blocked);
   }

   @Nullable
   private static Vec3 landing(Level level, Vec3 point, Vec3 look) {
      return groundBelow(level, point.subtract(look.scale(0.3)).add(0.0, 0.05, 0.0), null);
   }

   @Nullable
   public static Vec3 groundUnder(Level level, LivingEntity target) {
      return groundBelow(level, target.position().add(0.0, 0.05, 0.0), target);
   }

   @Nullable
   private static Vec3 groundBelow(Level level, Vec3 from, @Nullable Entity ignoring) {
      Vec3 bottom = new Vec3(from.x, level.getMinBuildHeight() - 1.0, from.z);
      BlockHitResult ground = level.clip(
         new ClipContext(from, bottom, Block.COLLIDER, Fluid.NONE, ignoring == null ? CollisionContext.empty() : CollisionContext.of(ignoring))
      );
      return ground.getType() == Type.MISS ? null : ground.getLocation();
   }

   public static double clearance(Level level, Vec3 spot, double most) {
      Vec3 from = spot.add(0.0, 0.1, 0.0);
      BlockHitResult roof = level.clip(new ClipContext(from, from.add(0.0, most, 0.0), Block.COLLIDER, Fluid.NONE, CollisionContext.empty()));
      return roof.getType() == Type.MISS ? most : roof.getLocation().y - spot.y;
   }

   public static void launch(ServerPlayer player, Vec3 push) {
      player.setDeltaMovement(player.getDeltaMovement().scale(0.25).add(push));
      player.hurtMarked = true;
      player.resetFallDistance();
      LAUNCHED.put(player.getUUID(), new TitanFists.Launch(player.level().getGameTime(), player.getY()));
   }

   @SubscribeEvent
   public static void onFall(LivingFallEvent event) {
      if (event.getEntity() instanceof ServerPlayer player && LAUNCHED.remove(player.getUUID()) != null) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGH
   )
   public static void onFallDamage(LivingIncomingDamageEvent event) {
      if (event.getEntity() instanceof ServerPlayer player && event.getSource().is(DamageTypeTags.IS_FALL) && LAUNCHED.remove(player.getUUID()) != null) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void onPlayerTick(Pre event) {
      Player player = event.getEntity();
      if (!player.level().isClientSide() && !LAUNCHED.isEmpty()) {
         TitanFists.Launch launch = LAUNCHED.get(player.getUUID());
         if (launch != null) {
            double y = player.getY();
            if (y > launch.fromY + 0.1) {
               launch.airborne = true;
            }

            boolean descending = launch.airborne && y < launch.lastY;
            launch.still = Math.abs(y - launch.lastY) < 1.0E-4 ? launch.still + 1 : 0;
            launch.lastY = y;
            long age = player.level().getGameTime() - launch.at;
            boolean changed = player.isPassenger()
               || player.isFallFlying()
               || player.getAbilities().mayfly
               || player.isSpectator()
               || player.isSleeping()
               || descending && (player.isInWater() || player.isInLava() || player.onClimbable());
            boolean settled = launch.airborne && launch.still >= 10 && player.onGround();
            if (changed || settled || !launch.airborne && age > 20L || age > 1200L) {
               LAUNCHED.remove(player.getUUID());
            }
         }
      }
   }

   @SubscribeEvent
   public static void onFlyableFall(PlayerFlyableFallEvent event) {
      LAUNCHED.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onGameModeChange(PlayerChangeGameModeEvent event) {
      LAUNCHED.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onTeleport(EntityTeleportEvent event) {
      if (event.getEntity() instanceof Player player) {
         LAUNCHED.remove(player.getUUID());
      }
   }

   @SubscribeEvent
   public static void onChangedDimension(PlayerChangedDimensionEvent event) {
      LAUNCHED.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onLogout(PlayerLoggedOutEvent event) {
      COMBOS.remove(event.getEntity().getUUID());
      LAUNCHED.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onRespawn(PlayerRespawnEvent event) {
      LAUNCHED.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      COMBOS.clear();
      LAUNCHED.clear();
   }

   private record Combo(int at, int next) {
   }

   private static final class Launch {
      final long at;
      final double fromY;
      double lastY;
      boolean airborne;
      int still;

      Launch(long at, double fromY) {
         this.at = at;
         this.fromY = fromY;
         this.lastY = fromY;
      }
   }

   private record Strike(Vec3 point, @Nullable LivingEntity target, boolean blocked) {
   }
}
