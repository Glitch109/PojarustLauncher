package com.amuletmod.amulet.ability.strike;

import com.amuletmod.entity.BarrierEntity;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.NeoForge;
import com.amuletmod.neo.event.BlockEvent.BreakEvent;
import org.jetbrains.annotations.Nullable;

final class Crater {
   private static final int BUDGET = 6000;
   private static final double RIM_END = 1.32;
   private static final double SCORCH_END = 1.85;
   private static final int MAX_DEBRIS = 70;
   private static final double PILLAR_BASE = 0.66;
   private static final int FLAGS = 18;
   private final ServerLevel level;
   private final double centerX;
   private final double centerY;
   private final double centerZ;
   private final double radius;
   private final double depth;
   private final double rimHeight;
   private final RandomSource random;
   private final int seed;
   private final double[] rimPhases;
   private final List<Crater.Shelter> shelters = new ArrayList<>();
   private final List<int[]> columns = new ArrayList<>();
   private final MutableBlockPos cursor = new MutableBlockPos();
   private int next;
   private int changes;
   private int debris;

   static double extent(double radius) {
      return radius * 1.85 * 1.15;
   }

   Crater(ServerLevel level, Vec3 center, double radius, List<BarrierEntity> domes) {
      this.level = level;
      this.centerX = center.x;
      this.centerY = center.y;
      this.centerZ = center.z;
      this.radius = radius;
      this.depth = radius * 0.36;
      this.rimHeight = radius * 0.12;
      this.random = level.random;
      this.seed = this.random.nextInt();
      this.rimPhases = new double[]{
         this.random.nextDouble() * (float) (Math.PI * 2), this.random.nextDouble() * (float) (Math.PI * 2), this.random.nextDouble() * (float) (Math.PI * 2)
      };

      for (BarrierEntity dome : domes) {
         this.shelters.add(new Crater.Shelter(dome.center(), (double)dome.radius()));
      }

      int reach = Mth.ceil(extent(radius));

      for (int dx = -reach; dx <= reach; dx++) {
         for (int dz = -reach; dz <= reach; dz++) {
            if (dx * dx + dz * dz <= reach * reach) {
               this.columns.add(new int[]{dx, dz});
            }
         }
      }

      this.columns.sort(Comparator.comparingInt(c -> c[0] * c[0] + c[1] * c[1]));
   }

   boolean isDone() {
      return this.next >= this.columns.size();
   }

   void carve(@Nullable ServerPlayer owner) {
      this.changes = 0;

      while (this.next < this.columns.size() && this.changes < 6000) {
         int[] column = this.columns.get(this.next++);
         this.column(Mth.floor(this.centerX) + column[0], Mth.floor(this.centerZ) + column[1], column[0], column[1], owner);
      }
   }

   private void column(int x, int z, int dx, int dz, @Nullable ServerPlayer owner) {
      double angle = Math.atan2(dz, dx);
      double wobble = 1.0
         + 0.08 * Math.sin(3.0 * angle + this.rimPhases[0])
         + 0.05 * Math.sin(7.0 * angle + this.rimPhases[1])
         + 0.03 * Math.sin(13.0 * angle + this.rimPhases[2])
         + 0.08 * (this.noise(x * 0.07, z * 0.07, 1) - 0.5);
      double d = Math.sqrt(dx * dx + dz * dz) / (this.radius * wobble);
      if (!(d >= 1.85)) {
         int top = this.level.getChunk(x >> 4, z >> 4).getHeight(Types.WORLD_SURFACE, x & 15, z & 15);
         if (top > this.level.getMinBuildHeight()) {
            int ground = this.groundBelow(x, top, z);
            double rough = this.noise(x * 0.16, z * 0.16, 2) - 0.5;
            if (d < 1.0) {
               this.bowl(x, z, d, top, ground, rough, owner);
            } else if (d < 1.32) {
               this.rim(x, z, d, top, ground, rough, owner);
            } else {
               this.scorch(x, z, d, top, ground, owner);
            }
         }
      }
   }

   private void bowl(int x, int z, double d, int top, int ground, double rough, @Nullable ServerPlayer owner) {
      double bowl = this.depth * Math.pow(1.0 - d * d, 0.8);
      double peak = this.depth * 0.28 * Math.exp(-(d / 0.13) * (d / 0.13));
      int floor = Mth.floor(Math.min((double)ground, this.centerY - bowl + peak + rough * 3.0));
      floor = Math.max(floor, this.level.getMinBuildHeight() + 1);

      for (int y = top; y > floor; y--) {
         this.remove(x, y, z, floor, owner);
      }

      double cluster = this.noise(x * 0.21, z * 0.21, 3);
      BlockState lining = lining(d, cluster);
      boolean lava = lining.is(Blocks.LAVA);
      this.set(x, floor, z, lining, owner);
      this.set(x, floor - 1, z, lava ? Blocks.OBSIDIAN.defaultBlockState() : lining(d, this.noise(x * 0.3, z * 0.3, 4)), owner);
      if (!lava && this.random.nextDouble() < (d < 0.55 ? 0.3 : 0.16)) {
         this.ignite(x, floor + 1, z);
      }
   }

   private static BlockState lining(double d, double n) {
      if (d < 0.3 && d > 0.1 && n < 0.34) {
         return Blocks.LAVA.defaultBlockState();
      } else if (d < 0.3) {
         return (n < 0.55 ? Blocks.MAGMA_BLOCK : (n < 0.87 ? Blocks.OBSIDIAN : Blocks.CRYING_OBSIDIAN)).defaultBlockState();
      } else {
         return d < 0.6
            ? (n < 0.22 ? Blocks.OBSIDIAN : (n < 0.4 ? Blocks.MAGMA_BLOCK : (n < 0.7 ? Blocks.BLACKSTONE : (n < 0.88 ? Blocks.BASALT : Blocks.NETHERRACK))))
               .defaultBlockState()
            : (n < 0.14
                  ? Blocks.OBSIDIAN
                  : (
                     n < 0.36
                        ? Blocks.BLACKSTONE
                        : (n < 0.58 ? Blocks.COBBLESTONE : (n < 0.78 ? Blocks.TUFF : (n < 0.93 ? Blocks.COBBLED_DEEPSLATE : Blocks.MAGMA_BLOCK)))
                  ))
               .defaultBlockState();
      }
   }

   private void rim(int x, int z, double d, int top, int ground, double rough, @Nullable ServerPlayer owner) {
      double fromLip = (d - 1.02) / 0.11;
      int height = (int)Math.round(this.rimHeight * Math.exp(-fromLip * fromLip) + rough * 1.6);
      BlockState surface = this.level.getBlockState(this.cursor.set(x, ground, z));
      BlockState local = surface.isCollisionShapeFullBlock(this.level, this.cursor) && !surface.hasBlockEntity() && !surface.is(Blocks.GRASS_BLOCK)
         ? surface
         : Blocks.DIRT.defaultBlockState();

      for (int i = 1; i <= height; i++) {
         this.place(x, ground + i, z, i == height ? scorched(this.noise(x * 0.4, z * 0.4, 5)) : ejecta(this.noise(x * 0.25, z * 0.25 + i, 6), local));
      }

      this.clearPlants(x, ground + height + 1, top, z);
      if (this.random.nextDouble() < 0.14) {
         this.ignite(x, ground + Math.max(height, 0) + 1, z);
      }

      if (top > ground + height && this.random.nextDouble() < 0.2) {
         this.ignite(x, top + 1, z);
      }
   }

   private static BlockState ejecta(double n, BlockState local) {
      if (n < 0.2) {
         return Blocks.COBBLESTONE.defaultBlockState();
      } else if (n < 0.34) {
         return Blocks.GRAVEL.defaultBlockState();
      } else if (n < 0.48) {
         return Blocks.TUFF.defaultBlockState();
      } else if (n < 0.6) {
         return Blocks.BLACKSTONE.defaultBlockState();
      } else if (n < 0.76) {
         return Blocks.COARSE_DIRT.defaultBlockState();
      } else {
         return n < 0.93 ? local : Blocks.OBSIDIAN.defaultBlockState();
      }
   }

   private static BlockState scorched(double n) {
      return (n < 0.45 ? Blocks.COARSE_DIRT : (n < 0.8 ? Blocks.BLACKSTONE : (n < 0.92 ? Blocks.MAGMA_BLOCK : Blocks.OBSIDIAN))).defaultBlockState();
   }

   private void scorch(int x, int z, double d, int top, int ground, @Nullable ServerPlayer owner) {
      double heat = 1.0 - (d - 1.32) / 0.53;
      BlockState surface = this.level.getBlockState(this.cursor.set(x, ground, z));
      BlockState burnt = this.burnt(surface, heat);
      if (this.random.nextDouble() < heat * 0.035) {
         burnt = Blocks.OBSIDIAN.defaultBlockState();
      } else if (this.random.nextDouble() < heat * 0.02) {
         burnt = Blocks.MAGMA_BLOCK.defaultBlockState();
      }

      if (burnt != surface && this.random.nextDouble() < heat * 0.95) {
         this.set(x, ground, z, burnt, owner);
      }

      if (this.random.nextDouble() < heat) {
         this.clearPlants(x, ground + 1, Math.min(top, ground + 2), z);
      }

      if (this.random.nextDouble() < heat * 0.12) {
         this.ignite(x, ground + 1, z);
      }

      if (top > ground + 2 && this.random.nextDouble() < heat * 0.25) {
         this.ignite(x, top + 1, z);
      }
   }

   private BlockState burnt(BlockState surface, double heat) {
      if (!surface.is(Blocks.GRASS_BLOCK)
         && !surface.is(Blocks.PODZOL)
         && !surface.is(Blocks.MYCELIUM)
         && !surface.is(Blocks.MOSS_BLOCK)
         && !surface.is(Blocks.DIRT_PATH)) {
         if (surface.is(Blocks.SAND) && this.random.nextDouble() < heat * 0.4) {
            return Blocks.GLASS.defaultBlockState();
         } else if (surface.is(Blocks.RED_SAND) && this.random.nextDouble() < heat * 0.4) {
            return Blocks.ORANGE_STAINED_GLASS.defaultBlockState();
         } else {
            return surface.is(Blocks.SNOW_BLOCK) ? Blocks.DIRT.defaultBlockState() : surface;
         }
      } else {
         return this.random.nextDouble() < 0.7 ? Blocks.COARSE_DIRT.defaultBlockState() : Blocks.DIRT.defaultBlockState();
      }
   }

   private int groundBelow(int x, int top, int z) {
      this.cursor.set(x, top, z);
      int i = 0;

      while (i < 48 && this.cursor.getY() > this.level.getMinBuildHeight()) {
         BlockState state = this.level.getBlockState(this.cursor);
         if (!state.is(BlockTags.LOGS) && !state.is(BlockTags.LEAVES) && !state.canBeReplaced()) {
            return this.cursor.getY();
         }

         i++;
         this.cursor.move(Direction.DOWN);
      }

      return top;
   }

   private void remove(int x, int y, int z, int floor, @Nullable ServerPlayer owner) {
      BlockPos pos = this.cursor.set(x, y, z);
      BlockState state = this.level.getBlockState(pos);
      if (!state.isAir() && !this.sheltered(x, y, z) && this.mayChange(pos, state, owner)) {
         if (this.debris < 70
            && y > floor + 3
            && !state.hasBlockEntity()
            && state.getFluidState().isEmpty()
            && state.isCollisionShapeFullBlock(this.level, pos)
            && this.random.nextInt(140) == 0) {
            this.debris++;
            FallingBlockEntity chunk = FallingBlockEntity.fall(this.level, pos.immutable(), state);
            Vec3 away = new Vec3(x - this.centerX, 0.0, z - this.centerZ);
            away = away.lengthSqr() < 1.0E-4 ? new Vec3(1.0, 0.0, 0.0) : away.normalize();
            double speed = 0.8 + this.random.nextDouble() * 1.0;
            chunk.setDeltaMovement(away.x * speed, 0.9 + this.random.nextDouble() * 0.7, away.z * speed);
            chunk.dropItem = false;
            chunk.hasImpulse = true;
         } else {
            this.level.setBlock(pos, Blocks.AIR.defaultBlockState(), 18);
         }

         this.changes++;
      }
   }

   private void set(int x, int y, int z, BlockState state, @Nullable ServerPlayer owner) {
      BlockPos pos = this.cursor.set(x, y, z);
      if (this.level.isInWorldBounds(pos)) {
         BlockState current = this.level.getBlockState(pos);
         if (current != state && !this.sheltered(x, y, z) && this.mayChange(pos, current, owner)) {
            this.level.setBlock(pos, state, 18);
            this.changes++;
         }
      }
   }

   private void place(int x, int y, int z, BlockState state) {
      BlockPos pos = this.cursor.set(x, y, z);
      if (this.level.isInWorldBounds(pos) && this.level.getBlockState(pos).canBeReplaced() && !this.sheltered(x, y, z)) {
         this.level.setBlock(pos, state, 18);
         this.changes++;
      }
   }

   private void clearPlants(int x, int from, int to, int z) {
      for (int y = from; y <= to; y++) {
         BlockState state = this.level.getBlockState(this.cursor.set(x, y, z));
         if (!state.isAir() && state.canBeReplaced() && state.getFluidState().isEmpty() && !this.sheltered(x, y, z)) {
            this.level.setBlock(this.cursor, Blocks.AIR.defaultBlockState(), 18);
            this.changes++;
         }
      }
   }

   private void ignite(int x, int y, int z) {
      BlockPos pos = this.cursor.set(x, y, z);
      if (this.level.isInWorldBounds(pos) && this.level.getBlockState(pos).isAir() && !this.sheltered(x, y, z)) {
         BlockState fire = BaseFireBlock.getState(this.level, pos);
         if (fire.canSurvive(this.level, pos)) {
            this.level.setBlock(pos, fire, 18);
            this.changes++;
         }
      }
   }

   private boolean mayChange(BlockPos pos, BlockState state, @Nullable ServerPlayer owner) {
      return state.getDestroySpeed(this.level, pos) < 0.0F
         ? false
         : owner == null || !((BreakEvent)NeoForge.EVENT_BUS.post(new BreakEvent(this.level, pos.immutable(), state, owner))).isCanceled();
   }

   private boolean sheltered(int x, int y, int z) {
      for (Crater.Shelter shelter : this.shelters) {
         double dx = x + 0.5 - shelter.center.x;
         double dy = y + 0.5 - shelter.center.y;
         double dz = z + 0.5 - shelter.center.z;
         double across = dx * dx + dz * dz;
         double reach = shelter.radius + 2.0;
         if (!(across >= reach * reach)) {
            if (across + dy * dy < shelter.radius * shelter.radius) {
               return true;
            }

            if (dy < 0.0) {
               double pillar = this.pillarRadius(shelter, -dy, x, y, z);
               if (pillar > 0.0 && across < pillar * pillar) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private double pillarRadius(Crater.Shelter shelter, double below, int x, int y, int z) {
      double t = Math.min(below / this.depth, 1.0);
      double width = shelter.radius * (1.0 - 0.33999999999999997 * t);
      double chips = (this.noise3(x * 0.35, y * 0.35, z * 0.35, 7) - 0.5) * (1.0 + 1.6 * t);
      double gouges = Math.max(0.0, this.noise3(x * 0.13, y * 0.2, z * 0.13, 8) - 0.62) * 7.0;
      return width + chips - gouges;
   }

   private double noise3(double x, double y, double z, int channel) {
      int y0 = Mth.floor(y);
      double ty = y - y0;
      ty = ty * ty * (3.0 - 2.0 * ty);
      return Mth.lerp(ty, this.noise(x, z, channel * 1031 + y0), this.noise(x, z, channel * 1031 + y0 + 1));
   }

   private double noise(double x, double z, int channel) {
      int x0 = Mth.floor(x);
      int z0 = Mth.floor(z);
      double tx = x - x0;
      double tz = z - z0;
      tx = tx * tx * (3.0 - 2.0 * tx);
      tz = tz * tz * (3.0 - 2.0 * tz);
      double a = this.hash(x0, z0, channel);
      double b = this.hash(x0 + 1, z0, channel);
      double c = this.hash(x0, z0 + 1, channel);
      double e = this.hash(x0 + 1, z0 + 1, channel);
      return Mth.lerp(tz, Mth.lerp(tx, a, b), Mth.lerp(tx, c, e));
   }

   private double hash(int x, int z, int channel) {
      int h = x * 374761393 + z * 668265263 + channel * 1274126177 + this.seed;
      h = (h ^ h >>> 13) * 1274126177;
      h ^= h >>> 16;
      return (h & 16777215) / 1.6777216E7;
   }

   private record Shelter(Vec3 center, double radius) {
   }
}
