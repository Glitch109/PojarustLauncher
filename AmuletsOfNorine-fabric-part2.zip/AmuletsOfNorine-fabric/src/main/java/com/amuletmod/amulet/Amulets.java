package com.amuletmod.amulet;

import com.amuletmod.seal.SealPrison;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public final class Amulets {
   private Amulets() {
   }

   public static List<SlotResult> equipped(LivingEntity entity) {
      return AmuletSlots.equipped(entity);
   }

   @Nullable
   public static <T extends ActiveAbility> Amulets.Found<T> find(LivingEntity entity, Class<T> type) {
      for (SlotResult result : equipped(entity)) {
         ItemStack stack = result.stack();

         for (AbilityOrigin origin : ((AmuletItem)stack.getItem()).abilities(stack)) {
            if (type.isInstance(origin.ability())) {
               return new Amulets.Found<>(type.cast(origin.ability()), origin, stack);
            }
         }
      }

      return null;
   }

   public static void tryActivateAbility(ServerPlayer player, int slot) {
      if (SealPrison.isImprisoned(player)) {
         player.displayClientMessage(Component.translatable("message.amuletmod.sealed_powers").withStyle(ChatFormatting.RED), true);
      } else {
         for (SlotResult result : equipped(player)) {
            ItemStack stack = result.stack();
            AmuletItem amulet = (AmuletItem)stack.getItem();
            AbilityOrigin origin = amulet.abilityAt(stack, slot);
            if (origin != null) {
               AbilityOrigin sneak = player.isShiftKeyDown() ? amulet.sneakAbilityAt(stack, slot) : null;
               if (sneak != null) {
                  origin = sneak;
               }

               ActiveAbility ability = origin.ability();
               long remaining = AbilityCooldowns.remainingTicks(player, origin);
               if (remaining > 0L) {
                  player.displayClientMessage(
                     Component.translatable("message.amuletmod.ability_recharging", new Object[]{stack.getHoverName(), (remaining + 19L) / 20L})
                        .withStyle(ChatFormatting.RED),
                     true
                  );
                  return;
               }

               if (!ability.activate(player, stack)) {
                  return;
               }

               if (ability.cooldownTicks() > 0) {
                  AbilityCooldowns.start(player, origin, ability.cooldownTicks());
               }

               if (ability.consumesCharge() && amulet.definition(stack).charges() > 0) {
                  amulet.consumeCharge(player, result);
               }

               return;
            }
         }

         player.displayClientMessage(Component.translatable("message.amuletmod.no_ability", new Object[]{slot + 1}).withStyle(ChatFormatting.GRAY), true);
      }
   }

   public record Found<T extends ActiveAbility>(T ability, AbilityOrigin origin, ItemStack stack) {
   }
}
