package com.amuletmod.amulet.ability.recall;

import com.amuletmod.network.ReturnPointSyncPacket;
import com.amuletmod.util.PlayerData;
import java.util.Optional;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedInEvent;
import com.amuletmod.neo.PacketDistributor;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class ReturnPoints {
   private static final String KEY = "return_point";

   private ReturnPoints() {
   }

   public static Optional<ReturnPoint> get(ServerPlayer player) {
      CompoundTag data = PlayerData.get(player);
      return data.contains("return_point") ? Optional.ofNullable(ReturnPoint.load(data.getCompound("return_point"))) : Optional.empty();
   }

   public static void set(ServerPlayer player, ReturnPoint point) {
      PlayerData.get(player).put("return_point", point.save());
      sync(player, true);
   }

   public static void clear(ServerPlayer player) {
      PlayerData.get(player).remove("return_point");
      sync(player, false);
   }

   private static void sync(ServerPlayer player, boolean justSet) {
      PacketDistributor.sendToPlayer(player, new ReturnPointSyncPacket(get(player).orElse(null), justSet), new CustomPacketPayload[0]);
   }

   @SubscribeEvent
   public static void onLogin(PlayerLoggedInEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         sync(player, false);
      }
   }
}
