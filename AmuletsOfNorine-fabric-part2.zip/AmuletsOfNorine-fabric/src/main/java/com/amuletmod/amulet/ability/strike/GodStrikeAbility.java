package com.amuletmod.amulet.ability.strike;

import com.amuletmod.amulet.ActiveAbility;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public record GodStrikeAbility(float radius, double maxDistance, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.god_strike", new Object[]{(int)this.radius * 2});
   }

   @Override
   public boolean consumesCharge() {
      return true;
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      Optional<StrikeTarget> mark = StrikeTargets.get(player);
      if (mark.isEmpty()) {
         return fail(player, Component.translatable("message.amuletmod.no_target"));
      } else {
         StrikeTarget target = mark.get();
         if (target.dimension() != player.level().dimension()) {
            return fail(player, Component.translatable("message.amuletmod.target_other_dimension"));
         } else {
            double distance = player.position().distanceTo(target.position());
            if (distance > this.maxDistance) {
               return fail(player, Component.translatable("message.amuletmod.target_too_far", new Object[]{(int)distance, (int)this.maxDistance}));
            } else if (GodStrikes.isCharging(player)) {
               return fail(player, Component.translatable("message.amuletmod.strike_underway"));
            } else {
               GodStrikes.launch(player, target.position(), StrikeTimeline.lineOfFire(player.getYRot(), player.getRandom().nextBoolean()), this.radius);
               StrikeTargets.clear(player);
               player.displayClientMessage(Component.translatable("message.amuletmod.god_strike").withStyle(ChatFormatting.DARK_PURPLE), true);
               return true;
            }
         }
      }
   }

   private static boolean fail(ServerPlayer player, Component message) {
      player.displayClientMessage(message.copy().withStyle(ChatFormatting.RED), true);
      return false;
   }
}
