package com.amuletmod.amulet;

import dev.emi.trinkets.api.TrinketComponent;
import dev.emi.trinkets.api.TrinketsApi;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/**
 * The amulet slot. The NeoForge version used one Curios "necklace" slot; here the amulet lives in the Trinkets Updated
 * slot {@code chest/necklace} (enabled for players by {@code data/trinkets/entities/amuletmod.json}, amulets are allowed
 * there by {@code data/trinkets/tags/item/chest/necklace.json}).
 * <ul>
 *   <li>Right-click with an amulet: equip it into a free necklace slot (works in addition to the Trinkets inventory screen).</li>
 *   <li>Wear/tick/unequip hooks are driven from a server tick (see {@link #init()}), so it works with whatever way the amulet got into the slot.</li>
 * </ul>
 */
public final class AmuletSlots {
	private static final String GROUP = "chest";
	private static final String SLOT = "necklace";

	/** Last amulet seen per player; used to fire the unequip hooks. */
	private static final Map<UUID, ItemStack> LAST = new HashMap<>();

	private AmuletSlots() {}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				ItemStack now = get(player);
				ItemStack before = LAST.getOrDefault(player.getUUID(), ItemStack.EMPTY);
				if (!before.isEmpty() && before.getItem() instanceof AmuletItem old
					&& (now.isEmpty() || before.getItem() != now.getItem())) {
					old.wearerUnequipped(player, now, before);
				}
				if (now.isEmpty()) LAST.remove(player.getUUID());
				else LAST.put(player.getUUID(), now.copy());
				if (!now.isEmpty() && now.getItem() instanceof AmuletItem amulet) amulet.wearerTick(player, now);
			}
		});
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> LAST.remove(handler.getPlayer().getUUID()));
		UseItemCallback.EVENT.register((player, level, hand) -> {
			if (hand != InteractionHand.MAIN_HAND || level.isClientSide()) return InteractionResult.PASS;
			ItemStack held = player.getItemInHand(hand);
			if (!(held.getItem() instanceof AmuletItem)) return InteractionResult.PASS;
			Container inv = necklaceContainer(player);
			if (inv == null) return InteractionResult.PASS;
			for (int i = 0; i < inv.getContainerSize(); i++) {
				if (inv.getItem(i).isEmpty()) {
					inv.setItem(i, held.copyWithCount(1));
					held.shrink(1);
					return InteractionResult.SUCCESS;
				}
			}
			return InteractionResult.PASS;
		});
	}

	private static Container necklaceContainer(LivingEntity entity) {
		Optional<TrinketComponent> component = TrinketsApi.getTrinketComponent(entity);
		if (component.isEmpty()) return null;
		var groups = component.get().getInventory();
		var group = groups.get(GROUP);
		if (group == null) return null;
		return group.get(SLOT);
	}

	/** The first worn amulet, or {@link ItemStack#EMPTY}. */
	public static ItemStack get(LivingEntity entity) {
		List<SlotResult> all = equipped(entity);
		return all.isEmpty() ? ItemStack.EMPTY : all.get(0).stack();
	}

	/** Only used to clear the slot (an amulet that ran out of charges). Server side only. */
	public static void set(LivingEntity entity, ItemStack stack) {
		Container inv = necklaceContainer(entity);
		if (inv == null) return;
		for (int i = 0; i < inv.getContainerSize(); i++) {
			if (inv.getItem(i).getItem() instanceof AmuletItem) {
				inv.setItem(i, stack);
				return;
			}
		}
	}

	public static List<SlotResult> equipped(LivingEntity entity) {
		List<SlotResult> result = new ArrayList<>();
		Container inv = necklaceContainer(entity);
		if (inv == null) return result;
		for (int i = 0; i < inv.getContainerSize(); i++) {
			ItemStack stack = inv.getItem(i);
			if (!stack.isEmpty() && stack.getItem() instanceof AmuletItem) result.add(new SlotResult(stack, i));
		}
		return result;
	}
}
