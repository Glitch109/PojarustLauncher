package com.amuletmod.amulet.ability.librarian;

import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.amulet.ability.glacial.Frost;
import com.amuletmod.util.Aim;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import org.jetbrains.annotations.Nullable;

public record PageAim(@Nullable LivingEntity target, Vec3 point) {
   private static final double CONE = Math.toRadians(8.0);
   private static final double NEAR_SLACK = 1.5;
   private static final int SIGHT_CHECKS = 4;

   public static PageAim of(ServerPlayer thrower, double range) {
      Vec3 eye = thrower.getEyePosition();
      Vec3 look = thrower.getViewVector(1.0F);
      HitResult wall = thrower.pick(range, 1.0F, false);
      boolean open = wall.getType() == Type.MISS;
      double reach = open ? range : wall.getLocation().distanceTo(eye);
      LivingEntity target = Aim.lookedAt(thrower, range, living -> canTarget(thrower, living));
      if (target == null) {
         target = sticky(thrower, eye, look, reach);
      }

      return target != null ? new PageAim(target, middle(target)) : new PageAim(null, open ? eye.add(look.scale(range)) : wall.getLocation());
   }

   @Nullable
   private static LivingEntity sticky(ServerPlayer thrower, Vec3 eye, Vec3 look, double reach) {
      AABB sweep = new AABB(eye, eye.add(look.scale(reach))).inflate(reach * Math.tan(CONE) + 1.5 + 1.0);

      record Candidate(LivingEntity living, double angle) {
      }

      List<Candidate> candidates = new ArrayList<>();

      for (LivingEntity living : thrower.level().getEntitiesOfClass(LivingEntity.class, sweep, livingx -> canTarget(thrower, livingx))) {
         Vec3 to = middle(living).subtract(eye);
         double distance = to.length();
         if (!(distance < 0.5) && !(distance > reach + living.getBbWidth() + 0.5)) {
            double angle = Math.acos(Mth.clamp(look.dot(to.scale(1.0 / distance)), -1.0, 1.0));
            if (angle <= Math.max(CONE, Math.atan(1.5 / distance))) {
               candidates.add(new Candidate(living, angle));
            }
         }
      }

      candidates.sort(Comparator.comparingDouble(Candidate::angle));

      for (int i = 0; i < candidates.size() && i < 4; i++) {
         if (thrower.hasLineOfSight(candidates.get(i).living())) {
            return candidates.get(i).living();
         }
      }

      return null;
   }

   private static boolean canTarget(ServerPlayer thrower, LivingEntity living) {
      return Frost.canHarm(living, thrower) && !Summons.isSummonedBy(living, thrower) && !living.isInvisibleTo(thrower)
         ? !(living instanceof Player other && (other.isCreative() || !thrower.canHarmPlayer(other)))
         : false;
   }

   private static Vec3 middle(LivingEntity living) {
      return living.position().add(0.0, living.getBbHeight() * 0.5, 0.0);
   }
}
