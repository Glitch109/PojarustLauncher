package com.amuletmod.amulet.ability.titan;

import com.amuletmod.util.PlayerData;
import java.util.Locale;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Nullable;

public enum Stance {
   JAB,
   CRUSH,
   UPPERCUT;

   private static final String KEY = "TitanStance";
   private static final Stance[] VALUES = values();

   @Nullable
   public static Stance after(@Nullable Stance stance) {
      if (stance == null) {
         return VALUES[0];
      } else {
         return stance.ordinal() + 1 < VALUES.length ? VALUES[stance.ordinal() + 1] : null;
      }
   }

   public static Stance byId(int id) {
      return VALUES[Math.floorMod(id, VALUES.length)];
   }

   public static int code(@Nullable Stance stance) {
      return stance == null ? -1 : stance.ordinal();
   }

   @Nullable
   public static Stance fromCode(int code) {
      return code >= 0 && code < VALUES.length ? VALUES[code] : null;
   }

   public String id() {
      return this.name().toLowerCase(Locale.ROOT);
   }

   public Component title() {
      return Component.translatable("tooltip.amuletmod.titan_stance." + this.id());
   }

   @Nullable
   public static Stance of(Player player) {
      return fromCode(PlayerData.get(player).getByteOr("TitanStance", (byte)0) - 1);
   }

   public static void set(Player player, @Nullable Stance stance) {
      PlayerData.get(player).putByte("TitanStance", (byte)(code(stance) + 1));
   }
}
