package com.amuletmod.amulet.ability.librarian;

import com.amuletmod.entity.PageEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public record PageStrike(
   ServerLevel level, PageEntity page, @Nullable LivingEntity thrower, LivingEntity target, DamageSource source, float damage, Vec3 direction
) {
}
