package com.amuletmod.amulet;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

public record FusionChoice(AbilityOrigin ability, @Nullable AbilityOrigin sneak) {
   public boolean consumesCharge() {
      return this.ability.ability().consumesCharge() || this.sneak != null && this.sneak.ability().consumesCharge();
   }

   public boolean overlaps(FusionChoice other) {
      return this.ability.equals(other.ability)
         || this.sneak != null && (this.sneak.equals(other.ability) || this.sneak.equals(other.sneak))
         || other.sneak != null && other.sneak.equals(this.ability);
   }

   public static Component name(ActiveAbility ability) {
      String text = ability.description().getString();
      int colon = text.indexOf(58);
      return Component.literal(colon > 0 ? text.substring(0, colon) : text);
   }

   public CompoundTag save() {
      CompoundTag tag = this.ability.save();
      if (this.sneak != null) {
         tag.put("Sneak", this.sneak.save());
      }

      return tag;
   }

   @Nullable
   public static FusionChoice load(CompoundTag tag) {
      AbilityOrigin ability = AbilityOrigin.load(tag);
      return ability == null ? null : new FusionChoice(ability, tag.contains("Sneak") ? AbilityOrigin.load(tag.getCompound("Sneak")) : null);
   }
}
