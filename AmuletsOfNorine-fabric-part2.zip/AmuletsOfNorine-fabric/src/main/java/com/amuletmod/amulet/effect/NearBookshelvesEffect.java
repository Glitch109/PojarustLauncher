package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import com.amuletmod.amulet.ability.librarian.Bookshelves;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import com.amuletmod.neo.event.ProjectileImpactEvent;
import com.amuletmod.neo.event.EnderManAngerEvent;
import com.amuletmod.neo.event.LivingDeathEvent;
import com.amuletmod.neo.event.LivingFallEvent;
import com.amuletmod.neo.event.LivingHealEvent;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;

public record NearBookshelvesEffect(int radius, AmuletEffect inner) implements AmuletEffect {
   private static final Map<LivingEntity, Boolean> NEAR = new WeakHashMap<>();

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.effect.near_bookshelves", new Object[]{this.radius, this.inner.description()});
   }

   private boolean isNear(LivingEntity wearer) {
      return NEAR.getOrDefault(wearer, false);
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (wearer.tickCount % 20 == 0 || !NEAR.containsKey(wearer)) {
         NEAR.put(wearer, Bookshelves.anyNear(wearer.level(), wearer.blockPosition(), this.radius));
      }

      if (this.isNear(wearer)) {
         this.inner.onWearerTick(wearer, amulet);
      } else {
         this.inner.onUnequip(wearer, amulet);
      }
   }

   @Override
   public void onUnequip(LivingEntity wearer, ItemStack amulet) {
      NEAR.remove(wearer);
      this.inner.onUnequip(wearer, amulet);
   }

   @Override
   public void onWearerFall(LivingFallEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isNear(wearer)) {
         this.inner.onWearerFall(event, wearer, amulet);
      }
   }

   @Override
   public void onWearerHurt(LivingIncomingDamageEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isNear(wearer)) {
         this.inner.onWearerHurt(event, wearer, amulet);
      }
   }

   @Override
   public void onWearerHitByProjectile(ProjectileImpactEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isNear(wearer)) {
         this.inner.onWearerHitByProjectile(event, wearer, amulet);
      }
   }

   @Override
   public void onWearerDeath(LivingDeathEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isNear(wearer)) {
         this.inner.onWearerDeath(event, wearer, amulet);
      }
   }

   @Override
   public void onWearerHeal(LivingHealEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isNear(wearer)) {
         this.inner.onWearerHeal(event, wearer, amulet);
      }
   }

   @Override
   public void onEndermanStare(EnderManAngerEvent event, Player wearer, ItemStack amulet) {
      if (this.isNear(wearer)) {
         this.inner.onEndermanStare(event, wearer, amulet);
      }
   }

   @Override
   public boolean isDrawback() {
      return this.inner.isDrawback();
   }
}
