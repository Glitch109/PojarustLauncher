package com.amuletmod.amulet.ability.librarian;

import java.util.Locale;
import net.minecraft.core.Holder;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffect;
import com.amuletmod.util.VanillaEffects;

public enum Kanji {
   HEAL('癒', VanillaEffects.REGENERATION, 8188570),
   STRENGTH('力', VanillaEffects.DAMAGE_BOOST, 16734780),
   WARD('守', VanillaEffects.DAMAGE_RESISTANCE, 16765514),
   SWIFT('速', VanillaEffects.MOVEMENT_SPEED, 7333119);

   public static final int AMPLIFIER = 1;
   private final char glyph;
   private final Holder<MobEffect> effect;
   private final int color;

   private Kanji(char glyph, Holder<MobEffect> effect, int color) {
      this.glyph = glyph;
      this.effect = effect;
      this.color = color;
   }

   public char glyph() {
      return this.glyph;
   }

   public Holder<MobEffect> effect() {
      return this.effect;
   }

   public float r() {
      return (this.color >> 16 & 0xFF) / 255.0F;
   }

   public float g() {
      return (this.color >> 8 & 0xFF) / 255.0F;
   }

   public float b() {
      return (this.color & 0xFF) / 255.0F;
   }

   public int rgb() {
      return this.color;
   }

   public String translationKey() {
      return "kanji.amuletmod." + this.name().toLowerCase(Locale.ROOT);
   }

   public static Kanji byId(int id) {
      Kanji[] all = values();
      return all[Math.floorMod(id, all.length)];
   }

   public static Kanji random(RandomSource random) {
      return byId(random.nextInt(values().length));
   }

   public static Kanji other(RandomSource random, Kanji... not) {
      Kanji[] all = values();

      for (int tries = 0; tries < 32; tries++) {
         Kanji pick = all[random.nextInt(all.length)];
         boolean taken = false;

         for (Kanji excluded : not) {
            taken |= pick == excluded;
         }

         if (!taken) {
            return pick;
         }
      }

      return all[0];
   }
}
