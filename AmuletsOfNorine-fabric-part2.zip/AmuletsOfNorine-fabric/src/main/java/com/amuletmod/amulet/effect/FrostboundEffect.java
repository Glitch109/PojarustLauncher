package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import com.amuletmod.amulet.ability.glacial.Frost;
import com.amuletmod.util.Sounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;

public record FrostboundEffect(int chillTicks) implements AmuletEffect {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.effect.frostbound");
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (wearer.getTicksFrozen() > 0) {
         wearer.setTicksFrozen(0);
      }
   }

   @Override
   public void onWearerHurt(LivingIncomingDamageEvent event, LivingEntity wearer, ItemStack amulet) {
      DamageSource source = event.getSource();
      if (source.getDirectEntity() instanceof LivingEntity attacker && attacker == source.getEntity() && attacker != wearer && attacker.isAlive()) {
         Frost.chill(attacker, this.chillTicks);
         ServerLevel level = (ServerLevel)wearer.level();
         level.sendParticles(ParticleTypes.SNOWFLAKE, attacker.getX(), attacker.getY() + attacker.getBbHeight() * 0.5, attacker.getZ(), 16, 0.3, 0.4, 0.3, 0.05);
         Sounds.play(level, attacker.position(), SoundEvents.PLAYER_HURT_FREEZE, 0.8F, 1.2F);
      }
   }
}
