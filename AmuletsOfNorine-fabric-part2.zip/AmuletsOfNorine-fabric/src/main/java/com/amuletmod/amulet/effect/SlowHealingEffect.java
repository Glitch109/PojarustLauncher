package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import com.amuletmod.neo.event.LivingHealEvent;

public record SlowHealingEffect(float share) implements AmuletEffect {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.effect.slow_healing", new Object[]{Math.round((1.0F - this.share) * 100.0F)})
         .withStyle(ChatFormatting.RED);
   }

   @Override
   public void onWearerHeal(LivingHealEvent event, LivingEntity wearer, ItemStack amulet) {
      event.setAmount(event.getAmount() * this.share);
   }

   @Override
   public boolean isDrawback() {
      return true;
   }
}
