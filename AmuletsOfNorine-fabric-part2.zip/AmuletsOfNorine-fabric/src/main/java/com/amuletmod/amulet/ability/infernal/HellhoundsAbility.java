package com.amuletmod.amulet.ability.infernal;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.ability.glacial.Frost;
import com.amuletmod.entity.HellhoundEntity;
import com.amuletmod.network.FxPacket;
import com.amuletmod.util.ServerScheduler;
import com.amuletmod.util.Sounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.PacketDistributor;

public record HellhoundsAbility(int count, int lifetimeTicks, int cooldownTicks) implements ActiveAbility {
   private static final double SPAWN_DISTANCE = 2.6;
   private static final int STAGGER_TICKS = 5;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.hellhounds", new Object[]{this.count, this.lifetimeTicks / 20});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      Vec3 center = player.position();
      Sounds.play(level, center, SoundEvents.WOLF_HOWL, 1.6F, 0.55F);
      ServerScheduler.schedule(8, () -> Sounds.play(level, center, SoundEvents.WOLF_HOWL, 1.2F, 0.7F));
      Sounds.play(level, center, SoundEvents.BLAZE_SHOOT, 1.0F, 0.5F);
      float yaw = player.getYRot() * (float) (Math.PI / 180.0);

      for (int i = 0; i < this.count; i++) {
         double angle = yaw + (i + 0.5) * (float) (Math.PI * 2) / this.count - Math.PI / this.count;
         double x = center.x - Math.sin(angle) * 2.6;
         double z = center.z + Math.cos(angle) * 2.6;
         Double ground = Frost.groundY(level, x, center.y, z, 2, 4);
         Vec3 at = ground == null ? center : new Vec3(x, ground, z);
         ServerScheduler.schedule(i * 5, () -> this.rise(level, player, at));
      }

      player.displayClientMessage(Component.translatable("message.amuletmod.hellhounds").withStyle(ChatFormatting.GOLD), true);
      return true;
   }

   private void rise(ServerLevel level, ServerPlayer owner, Vec3 at) {
      if (!owner.isRemoved() && owner.level() == level) {
         HellhoundEntity.summon(level, owner, at, this.lifetimeTicks + level.random.nextInt(10));
         PacketDistributor.sendToPlayersTrackingEntityAndSelf(owner, new FxPacket(FxPacket.Kind.HOUND_SUMMON, at, 1.0F), new CustomPacketPayload[0]);
         level.sendParticles(ParticleTypes.FLAME, at.x, at.y + 0.1, at.z, 30, 0.6, 0.05, 0.6, 0.05);
         level.sendParticles(ParticleTypes.LAVA, at.x, at.y + 0.2, at.z, 5, 0.4, 0.1, 0.4, 0.0);
         level.sendParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y + 0.5, at.z, 8, 0.4, 0.4, 0.4, 0.02);
         Sounds.play(level, at, SoundEvents.FIRECHARGE_USE, 1.0F, 0.7F);
         Sounds.play(level, at, SoundEvents.LAVA_POP, 1.0F, 0.8F);
         Sounds.play(level, at, SoundEvents.WOLF_GROWL, 1.0F, 0.6F);
      }
   }
}
