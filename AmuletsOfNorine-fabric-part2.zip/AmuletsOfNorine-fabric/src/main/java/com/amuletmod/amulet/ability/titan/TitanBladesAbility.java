package com.amuletmod.amulet.ability.titan;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.client.TitanHud;
import com.amuletmod.registry.ModSounds;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Sounds;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public record TitanBladesAbility(
   double slashReach,
   double volleyRange,
   int cutTicks,
   int comboTicks,
   int volleyCooldown,
   int stormWindow,
   int stormBlades,
   double stormRange,
   int stormCooldown
) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.titan_blades");
   }

   @Override
   public List<Component> details(ItemStack amulet) {
      BladeMode current = ClientSide.call(() -> TitanHud::blades);
      return List.of(
         modeLine(BladeMode.SLASH, current, (int)this.slashReach, TitanFistsAbility.format(this.volleyCooldown)),
         modeLine(BladeMode.STORM, current, TitanFistsAbility.format(this.stormWindow), this.stormBlades, TitanFistsAbility.format(this.stormCooldown))
      );
   }

   private static Component modeLine(BladeMode mode, @Nullable BladeMode current, Object... args) {
      return Component.literal("    ")
         .append(Component.translatable("tooltip.amuletmod.ability.titan_blades." + mode.id(), args))
         .withStyle(mode == current ? ChatFormatting.AQUA : ChatFormatting.GRAY);
   }

   @Override
   public int cooldownTicks() {
      return 0;
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      BladeMode mode = BladeMode.of(player);
      if (mode == null && !TitanBlades.isSword(player.getMainHandItem())) {
         player.displayClientMessage(Component.translatable("message.amuletmod.titan_needs_sword").withStyle(ChatFormatting.GRAY), true);
         return false;
      } else {
         BladeMode next = BladeMode.after(mode);
         BladeMode.set(player, next);
         TitanBlades.endCombo(player);
         if (next == null) {
            player.playNotifySound((SoundEvent)ModSounds.TITAN_POWER_CANCEL.get(), SoundSource.PLAYERS, 0.9F, 1.06F);
            Sounds.play(player.level(), player.position().add(0.0, 1.0, 0.0), SoundEvents.FIRE_EXTINGUISH, 0.35F, 1.8F);
         } else {
            player.playNotifySound((SoundEvent)ModSounds.TITAN_POWER_SELECT.get(), SoundSource.PLAYERS, 0.9F, 1.0F + 0.08F * next.ordinal());
            if (next == BladeMode.SLASH) {
               Sounds.play(player.level(), player.position().add(0.0, 1.0, 0.0), SoundEvents.FIRECHARGE_USE, 0.3F, 1.9F);
            }
         }

         TitanSync.hud(player, TitanSync.glyph(next));
         TitanSync.hands(player);
         return true;
      }
   }

   @Override
   public void onUnequip(LivingEntity wearer, ItemStack amulet) {
      if (wearer instanceof ServerPlayer player && BladeMode.of(player) != null) {
         BladeMode.set(player, null);
         TitanBlades.endCombo(player);
         TitanSync.hud(player, -1);
         TitanSync.hands(player);
      }
   }
}
