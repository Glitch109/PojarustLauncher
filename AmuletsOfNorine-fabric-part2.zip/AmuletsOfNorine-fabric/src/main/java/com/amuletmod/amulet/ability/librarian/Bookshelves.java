package com.amuletmod.amulet.ability.librarian;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import com.amuletmod.neo.Tags.Blocks;

public final class Bookshelves {
   private Bookshelves() {
   }

   public static boolean isBookshelf(Level level, BlockPos pos, BlockState state) {
      return !state.isAir() && (state.is(Blocks.BOOKSHELVES) || state.getEnchantPowerBonus(level, pos) > 0.0F);
   }

   public static boolean anyNear(Level level, BlockPos center, int radius) {
      for (BlockPos pos : BlockPos.betweenClosed(center.offset(-radius, -radius, -radius), center.offset(radius, radius, radius))) {
         if (isBookshelf(level, pos, level.getBlockState(pos))) {
            return true;
         }
      }

      return false;
   }

   public static List<BlockPos> within(Level level, BlockPos center, int radius) {
      List<BlockPos> found = new ArrayList<>();
      long radiusSqr = (long)radius * radius;

      for (BlockPos pos : BlockPos.betweenClosed(center.offset(-radius, -radius, -radius), center.offset(radius, radius, radius))) {
         if (pos.distSqr(center) <= radiusSqr && isBookshelf(level, pos, level.getBlockState(pos))) {
            found.add(pos.immutable());
         }
      }

      found.sort(Comparator.comparingDouble(posx -> posx.distSqr(center)));
      return found;
   }
}
