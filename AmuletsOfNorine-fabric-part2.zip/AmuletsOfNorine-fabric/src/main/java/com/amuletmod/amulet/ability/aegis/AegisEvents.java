package com.amuletmod.amulet.ability.aegis;

import com.amuletmod.entity.BarrierEntity;
import com.amuletmod.util.Sounds;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.EventPriority;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.ProjectileImpactEvent;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;
import com.amuletmod.neo.event.ExplosionEvent.Detonate;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class AegisEvents {
   private AegisEvents() {
   }

   @SubscribeEvent(
      priority = EventPriority.HIGH
   )
   public static void onProjectileImpact(ProjectileImpactEvent event) {
      Projectile projectile = event.getProjectile();
      if (!projectile.level().isClientSide()
         && event.getRayTraceResult() instanceof EntityHitResult hit
         && hit.getEntity() instanceof Player player
         && projectile.getOwner() != player) {
         BarrierEntity ward = BarrierEntity.wardOf(player);
         if (ward != null) {
            event.setCanceled(true);
            Vec3 at = projectile.position();
            Deflection.returnToSender(projectile, player, projectile.getDeltaMovement().reverse());
            ward.impact(at);
            Deflection.sparks((ServerLevel)player.level(), at);
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public static void onLivingAttack(LivingIncomingDamageEvent event) {
      if (event.getEntity() instanceof Player player && !player.level().isClientSide()) {
         BarrierEntity ward = BarrierEntity.wardOf(player);
         if (ward != null) {
            DamageSource source = event.getSource();
            Entity attacker = source.getEntity();
            boolean explosion = source.is(DamageTypeTags.IS_EXPLOSION);
            if (attacker != null && attacker != player || explosion) {
               event.setCanceled(true);
               Vec3 from = source.getSourcePosition() != null ? source.getSourcePosition() : (attacker != null ? attacker.position() : player.position());
               ward.impact(from);
               if (attacker instanceof LivingEntity living && living.isAlive() && source.getDirectEntity() == attacker && !source.is(DamageTypes.THORNS)) {
                  living.hurt(player.damageSources().thorns(player), event.getAmount());
                  living.knockback(0.8, player.getX() - living.getX(), player.getZ() - living.getZ());
                  Sounds.play(player.level(), living.position(), SoundEvents.SHIELD_BLOCK, 1.0F, 0.8F);
                  Deflection.sparks((ServerLevel)player.level(), living.position().add(0.0, living.getBbHeight() * 0.5, 0.0));
               }
            }
         }
      }
   }

   @SubscribeEvent
   public static void onExplosion(Detonate event) {
      Level level = event.getLevel();
      if (!level.isClientSide()) {
         Vec3 blast = event.getExplosion().center();
         event.getAffectedEntities().removeIf(entity -> {
            BarrierEntity ward = entity instanceof Player player ? BarrierEntity.wardOf(player) : null;
            if (ward != null) {
               ward.impact(blast);
            }

            return ward != null;
         });

         for (BarrierEntity dome : level.getEntitiesOfClass(
            BarrierEntity.class,
            new AABB(blast, blast).inflate(28.0),
            barrier -> barrier.mode() == BarrierEntity.Mode.DOME && barrier.isShielding() && !barrier.contains(blast)
         )) {
            int before = event.getAffectedEntities().size() + event.getAffectedBlocks().size();
            event.getAffectedEntities().removeIf(entity -> dome.contains(entity.position()));
            event.getAffectedBlocks().removeIf(pos -> dome.contains(Vec3.atCenterOf(pos)));
            if (event.getAffectedEntities().size() + event.getAffectedBlocks().size() < before) {
               dome.impact(blast);
            }
         }
      }
   }
}
