package com.amuletmod.amulet.ability.sovereign;

import com.amuletmod.amulet.ActiveAbility;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public record AuraSightAbility(double range) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.aura_sight", new Object[]{(int)this.range});
   }

   @Override
   public int cooldownTicks() {
      return 0;
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      boolean on = AuraSight.toggle(player, this.range);
      player.displayClientMessage(
         Component.translatable(on ? "message.amuletmod.aura_sight_on" : "message.amuletmod.aura_sight_off")
            .withStyle(on ? ChatFormatting.AQUA : ChatFormatting.GRAY),
         true
      );
      return true;
   }
}
