package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public record ShortCircuitEffect(float damage, int intervalTicks) implements AmuletEffect {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.effect.short_circuit", new Object[]{trim(this.damage / 2.0F), trim(this.intervalTicks / 20.0F)})
         .withStyle(ChatFormatting.RED);
   }

   private static String trim(float value) {
      return value == (int)value ? String.valueOf((int)value) : String.valueOf(value);
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (wearer.isInWaterOrBubble() && wearer.level() instanceof ServerLevel level) {
         double var6 = wearer.getY() + wearer.getBbHeight() * 0.5;
         if (wearer.tickCount % 5 == 0) {
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, wearer.getX(), var6, wearer.getZ(), 3, 0.3, 0.4, 0.3, 0.1);
         }

         if (wearer.tickCount % this.intervalTicks == 0) {
            wearer.hurt(ModDamage.source(level, ModDamage.SHORT_CIRCUIT, null, null), this.damage);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, wearer.getX(), var6, wearer.getZ(), 24, 0.4, 0.6, 0.4, 0.4);
            Sounds.play(level, wearer.position(), SoundEvents.REDSTONE_TORCH_BURNOUT, 0.7F, 1.8F);
            Sounds.play(level, wearer.position(), SoundEvents.LIGHTNING_BOLT_IMPACT, 0.25F, 2.0F);
         }
      }
   }

   @Override
   public boolean isDrawback() {
      return true;
   }
}
