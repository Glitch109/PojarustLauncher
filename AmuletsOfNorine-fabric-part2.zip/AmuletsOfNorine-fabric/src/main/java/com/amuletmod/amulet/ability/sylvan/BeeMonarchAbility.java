package com.amuletmod.amulet.ability.sylvan;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.entity.MonarchBeeEntity;
import com.amuletmod.network.FxPacket;
import com.amuletmod.util.ServerScheduler;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder.Reference;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.PacketDistributor;

public record BeeMonarchAbility(int radius, int minBees, int maxBees, int lifetimeTicks, int cooldownTicks) implements ActiveAbility {
   private static final int SAMPLE = 48;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.bee_monarch", new Object[]{this.minBees, this.maxBees, this.lifetimeTicks / 20});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      RandomSource random = level.random;
      List<BlockPos> leaves = findLeaves(level, player.blockPosition(), this.radius, random);
      if (leaves.isEmpty()) {
         player.displayClientMessage(Component.translatable("message.amuletmod.bee_no_leaves", new Object[]{this.radius}).withStyle(ChatFormatting.RED), true);
         return false;
      } else {
         Vec3 center = player.position();
         Sounds.play(level, center, (SoundEvent)((Reference)SoundEvents.GOAT_HORN_SOUND_VARIANTS.get(5)).value(), 2.0F, 1.15F);
         Sounds.play(level, center, SoundEvents.BEE_LOOP_AGGRESSIVE, 1.2F, 0.8F);
         Sounds.play(level, center, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0F, 1.2F);
         PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new FxPacket(FxPacket.Kind.MONARCH_CALL, center, this.radius), new CustomPacketPayload[0]);
         int count = this.minBees + random.nextInt(this.maxBees - this.minBees + 1);

         for (int i = 0; i < count; i++) {
            BlockPos leaf = (BlockPos)Util.getRandom(leaves, random);
            ServerScheduler.schedule(3 + i / 2 + random.nextInt(3), () -> this.emerge(level, player, leaf));
         }

         player.displayClientMessage(Component.translatable("message.amuletmod.bee_monarch", new Object[]{count}).withStyle(ChatFormatting.GOLD), true);
         return true;
      }
   }

   private void emerge(ServerLevel level, ServerPlayer owner, BlockPos leaf) {
      if (!owner.isRemoved() && owner.level() == level) {
         RandomSource random = level.random;
         BlockState leafState = level.getBlockState(leaf);
         Direction exit = Direction.UP;

         for (Direction side : Direction.allShuffled(random)) {
            if (level.getBlockState(leaf.relative(side)).getCollisionShape(level, leaf.relative(side)).isEmpty()) {
               exit = side;
               break;
            }
         }

         Vec3 at = Vec3.atCenterOf(leaf).add(exit.getStepX() * 0.7, exit.getStepY() * 0.7 - 0.2, exit.getStepZ() * 0.7);
         Vec3 burst = new Vec3(exit.getStepX(), exit.getStepY(), exit.getStepZ()).scale(0.35).add(0.0, 0.15, 0.0);
         MonarchBeeEntity.summon(level, owner, at, burst, this.lifetimeTicks + random.nextInt(30));
         if (leafState.is(BlockTags.LEAVES)) {
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, leafState), at.x, at.y, at.z, 10, 0.3, 0.3, 0.3, 0.1);
         }

         level.sendParticles(ParticleTypes.CHERRY_LEAVES, at.x, at.y, at.z, 2, 0.3, 0.3, 0.3, 0.0);
         Sounds.play(level, at, leafState.getSoundType(level, leaf, null).getBreakSound(), 0.6F, 0.9F + random.nextFloat() * 0.3F);
         if (random.nextInt(3) == 0) {
            Sounds.play(level, at, SoundEvents.BEEHIVE_EXIT, 0.8F, 1.0F + random.nextFloat() * 0.2F);
         }
      }
   }

   private static List<BlockPos> findLeaves(ServerLevel level, BlockPos center, int radius, RandomSource random) {
      List<BlockPos> picked = new ArrayList<>();
      int seen = 0;
      int radiusSqr = radius * radius;
      int minY = Math.max(level.getMinBuildHeight(), center.getY() - radius);
      int maxY = Math.min(level.getMaxBuildHeight() - 1, center.getY() + radius);

      for (int chunkX = center.getX() - radius >> 4; chunkX <= center.getX() + radius >> 4; chunkX++) {
         for (int chunkZ = center.getZ() - radius >> 4; chunkZ <= center.getZ() + radius >> 4; chunkZ++) {
            LevelChunk chunk = level.getChunkSource().getChunkNow(chunkX, chunkZ);
            if (chunk != null) {
               for (int sectionY = minY >> 4; sectionY <= maxY >> 4; sectionY++) {
                  LevelChunkSection section = chunk.getSection(chunk.getSectionIndexFromSectionY(sectionY));
                  if (!section.hasOnlyAir() && section.maybeHas(state -> state.is(BlockTags.LEAVES))) {
                     for (int y = 0; y < 16; y++) {
                        for (int z = 0; z < 16; z++) {
                           for (int x = 0; x < 16; x++) {
                              int wx = (chunkX << 4) + x;
                              int wy = (sectionY << 4) + y;
                              int wz = (chunkZ << 4) + z;
                              int dx = wx - center.getX();
                              int dy = wy - center.getY();
                              int dz = wz - center.getZ();
                              if (dx * dx + dy * dy + dz * dz <= radiusSqr && section.getBlockState(x, y, z).is(BlockTags.LEAVES)) {
                                 seen++;
                                 if (picked.size() < 48) {
                                    picked.add(new BlockPos(wx, wy, wz));
                                 } else if (random.nextInt(seen) < 48) {
                                    picked.set(random.nextInt(48), new BlockPos(wx, wy, wz));
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return picked;
   }
}
