package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import com.amuletmod.neo.event.EnderManAngerEvent;

public record EndermanCalmEffect() implements AmuletEffect {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.effect.enderman_calm");
   }

   @Override
   public void onEndermanStare(EnderManAngerEvent event, Player wearer, ItemStack amulet) {
      event.setCanceled(true);
   }
}
