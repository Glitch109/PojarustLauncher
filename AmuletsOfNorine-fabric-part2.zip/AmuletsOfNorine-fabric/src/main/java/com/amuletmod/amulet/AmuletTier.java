package com.amuletmod.amulet;

public enum AmuletTier {
   SILVER("iron", 15265010, 0),
   GOLD("gold", 16767050, 2),
   SHULKER("shulker", 11045094, 4);

   private final String chain;
   private final int metalColor;
   private final int fusionCost;

   private AmuletTier(String chain, int metalColor, int fusionCost) {
      this.chain = chain;
      this.metalColor = metalColor;
      this.fusionCost = fusionCost;
   }

   public int fusionCost() {
      return this.fusionCost;
   }

   public String chain() {
      return this.chain;
   }

   public int metalColor() {
      return this.metalColor;
   }
}
