package com.amuletmod.amulet.ability.strike;

import com.amuletmod.amulet.ability.aegis.Deflection;
import com.amuletmod.entity.BarrierEntity;
import com.amuletmod.network.GodStrikePacket;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.PlayerEvent.PlayerChangedDimensionEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedInEvent;
import com.amuletmod.neo.event.ServerStoppedEvent;
import com.amuletmod.neo.event.ServerTickEvent.Post;
import com.amuletmod.neo.PacketDistributor;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class GodStrikes {
   private static final double PULL_RADIUS = 32.0;
   private static final double PULL_STRENGTH = 0.045;
   private static final double KILL_RADIUS = 45.0;
   private static final float MAX_DAMAGE = 100.0F;
   private static final float MIN_DAMAGE = 12.0F;
   private static final int SKY_SEARCH_RADIUS = 48;
   private static final int SKY_SEARCH_STEP = 8;
   private static final List<GodStrikes.Strike> ACTIVE = new ArrayList<>();
   private static int nextId;

   private GodStrikes() {
   }

   public static boolean isCharging(ServerPlayer player) {
      for (GodStrikes.Strike strike : ACTIVE) {
         if (strike.ownerId.equals(player.getUUID()) && strike.age < 304) {
            return true;
         }
      }

      return false;
   }

   public static void launch(ServerPlayer owner, Vec3 target, Vec3 lineOfFire, float radius) {
      ServerLevel level = ((ServerLevel) owner.level());
      Vec3 source = StrikeTimeline.source(target, lineOfFire, groundAround(level, target, lineOfFire));
      GodStrikes.Strike strike = new GodStrikes.Strike(nextId++, level, target, source, entry(level, source, target, owner), owner.getUUID(), radius);
      ACTIVE.add(strike);
      PacketDistributor.sendToPlayersInDimension(((ServerLevel) owner.level()), strike.packet(), new CustomPacketPayload[0]);
   }

   private static double groundAround(ServerLevel level, Vec3 target, Vec3 lineOfFire) {
      double ground = target.y;
      if (level.dimensionType().hasCeiling()) {
         return ground;
      } else {
         MutableBlockPos column = new MutableBlockPos();

         for (int dx = -48; dx <= 48; dx += 8) {
            for (int dz = -48; dz <= 48; dz += 8) {
               if (dx * dx + dz * dz <= 2304) {
                  ground = Math.max(ground, surface(level, column.set(target.x + dx, target.y, target.z + dz)));
               }
            }
         }

         Vec3 across = new Vec3(lineOfFire.x, 0.0, lineOfFire.z).scale(130.0);
         int steps = (int)Math.ceil(across.length() / 8.0);

         for (int i = 1; i <= steps; i++) {
            Vec3 under = target.add(across.scale((double)i / steps));
            ground = Math.max(ground, surface(level, column.set(under.x, under.y, under.z)));
         }

         return ground;
      }
   }

   @Nullable
   private static Vec3 entry(ServerLevel level, Vec3 source, Vec3 target, ServerPlayer owner) {
      BlockHitResult hit = level.clip(new ClipContext(source, target, Block.COLLIDER, Fluid.NONE, owner));
      return hit.getType() != Type.MISS && !(hit.getLocation().distanceTo(target) < 3.0) ? hit.getLocation() : null;
   }

   private static double surface(ServerLevel level, BlockPos column) {
      return !level.hasChunkAt(column) ? Double.NEGATIVE_INFINITY : level.getHeight(Types.MOTION_BLOCKING, column.getX(), column.getZ());
   }

   @SubscribeEvent
   public static void onServerTick(Post event) {
      if (!ACTIVE.isEmpty()) {
         MinecraftServer server = event.getServer();
         Iterator<GodStrikes.Strike> it = ACTIVE.iterator();

         while (it.hasNext()) {
            GodStrikes.Strike strike = it.next();
            ServerLevel level = server.getLevel(strike.dimension);
            if (level == null) {
               it.remove();
            } else {
               strike.age++;
               ServerPlayer owner = server.getPlayerList().getPlayer(strike.ownerId);
               if (strike.age >= 104 && !strike.tunnel.isDone()) {
                  strike.tunnel.bore(StrikeTimeline.beamReach(strike.age), owner, domesAlong(level, strike));
               }

               if (strike.age >= 240 && strike.age < 304) {
                  pull(level, strike);
               }

               if (strike.age == 304) {
                  impact(level, strike, owner);
               }

               if (strike.crater != null && !strike.crater.isDone()) {
                  strike.crater.carve(owner);
               }

               if (strike.age >= 420 && strike.tunnel.isDone() && (strike.crater == null || strike.crater.isDone())) {
                  it.remove();
               }
            }
         }
      }
   }

   private static void pull(ServerLevel level, GodStrikes.Strike strike) {
      float ramp = (strike.age - 240) / 64.0F;
      List<BarrierEntity> domes = domesAround(level, strike.target, 32.0);

      for (Entity entity : level.getEntities(
         (Entity)null,
         new AABB(strike.target, strike.target).inflate(32.0),
         entityx -> entityx.isAlive()
            && !entityx.isSpectator()
            && !entityx.getUUID().equals(strike.ownerId)
            && (entityx instanceof LivingEntity || entityx instanceof ItemEntity)
            && !sheltered(entityx, domes)
      )) {
         Vec3 toward = strike.target.subtract(entity.position());
         double distance = toward.length();
         if (!(distance > 32.0) && !(distance < 1.0)) {
            entity.setDeltaMovement(entity.getDeltaMovement().add(toward.scale(0.045 * ramp / distance)));
            entity.hurtMarked = true;
         }
      }
   }

   private static void impact(ServerLevel level, GodStrikes.Strike strike, @Nullable ServerPlayer owner) {
      Vec3 target = strike.target;
      double reach = strike.radius * 1.4;
      DamageSource blast = level.damageSources().explosion(owner, owner);
      DamageSource obliteration = owner == null ? blast : ModDamage.source(level, ModDamage.GOD_STRIKE, owner, owner);
      List<BarrierEntity> domes = domesAround(level, target, Math.max(reach, Crater.extent(strike.radius)));

      for (Entity entity : level.getEntities(
         (Entity)null,
         new AABB(target, target).inflate(reach, strike.radius, reach),
         entityx -> entityx.isAlive() && !entityx.getUUID().equals(strike.ownerId) && !sheltered(entityx, domes)
      )) {
         double distance = entity.position().distanceTo(target);
         if (!(distance > reach)) {
            double closeness = 1.0 - distance / reach;
            if (!(entity instanceof ItemEntity) && !(entity instanceof ExperienceOrb)) {
               if (entity instanceof LivingEntity living) {
                  if (distance <= 45.0) {
                     living.invulnerableTime = 0;
                     living.hurt(obliteration, Float.MAX_VALUE);
                  } else {
                     living.hurt(blast, (float)(12.0 + 88.0 * closeness * closeness));
                  }

                  living.igniteForSeconds(3 + (int)(10.0 * closeness));
               }

               Vec3 away = entity.position().subtract(target).multiply(1.0, 0.0, 1.0);
               away = away.lengthSqr() < 1.0E-4 ? new Vec3(1.0, 0.0, 0.0) : away.normalize();
               entity.setDeltaMovement(away.scale(0.6 + 2.2 * closeness).add(0.0, 0.5 + 1.3 * closeness, 0.0));
               entity.hurtMarked = true;
               entity.hasImpulse = true;
            } else if (distance < strike.radius) {
               entity.discard();
            }
         }
      }

      for (BarrierEntity dome : domes) {
         brace(level, dome, strike);
      }

      strike.crater = new Crater(level, target, strike.radius, domes);
   }

   private static List<BarrierEntity> domesAround(ServerLevel level, Vec3 target, double range) {
      return level.getEntitiesOfClass(
         BarrierEntity.class, new AABB(target, target).inflate(range + 12.0), barrier -> barrier.mode() == BarrierEntity.Mode.DOME && barrier.isShielding()
      );
   }

   private static List<BarrierEntity> domesAlong(ServerLevel level, GodStrikes.Strike strike) {
      return level.getEntitiesOfClass(
         BarrierEntity.class,
         new AABB(strike.source, strike.target).inflate(12.0),
         barrier -> barrier.mode() == BarrierEntity.Mode.DOME && barrier.isShielding()
      );
   }

   private static boolean sheltered(Entity entity, List<BarrierEntity> domes) {
      for (BarrierEntity dome : domes) {
         if (dome.contains(entity.position())) {
            return true;
         }
      }

      return false;
   }

   private static void brace(ServerLevel level, BarrierEntity dome, GodStrikes.Strike strike) {
      Vec3 center = dome.center();
      Vec3 across = strike.target.subtract(center).multiply(1.0, 0.0, 1.0);
      Vec3 toward = !dome.contains(strike.target) && !(across.lengthSqr() < 1.0E-4) ? across.normalize().add(0.0, 0.6, 0.0).normalize() : strike.lineOfFire;
      dome.impact(center.add(toward));

      for (int i = 0; i < 3; i++) {
         Vec3 spread = toward.add(level.random.nextGaussian() * 0.3, level.random.nextGaussian() * 0.3, level.random.nextGaussian() * 0.3);
         Deflection.sparks(level, center.add(spread.normalize().scale(dome.radius())));
      }

      Sounds.play(level, center, SoundEvents.BEACON_POWER_SELECT, 2.0F, 0.6F);
   }

   private static void sendActiveTo(ServerPlayer player) {
      for (GodStrikes.Strike strike : ACTIVE) {
         if (strike.dimension == player.level().dimension() && strike.age < 420) {
            PacketDistributor.sendToPlayer(player, strike.packet(), new CustomPacketPayload[0]);
         }
      }
   }

   @SubscribeEvent
   public static void onLogin(PlayerLoggedInEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         sendActiveTo(player);
      }
   }

   @SubscribeEvent
   public static void onChangedDimension(PlayerChangedDimensionEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         sendActiveTo(player);
      }
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      ACTIVE.clear();
   }

   private static final class Strike {
      final int id;
      final ResourceKey<Level> dimension;
      final Vec3 target;
      final Vec3 source;
      final Vec3 lineOfFire;
      @Nullable
      final Vec3 entry;
      final UUID ownerId;
      final float radius;
      final Tunnel tunnel;
      int age;
      @Nullable
      Crater crater;

      Strike(int id, ServerLevel level, Vec3 target, Vec3 source, @Nullable Vec3 entry, UUID ownerId, float radius) {
         this.id = id;
         this.dimension = level.dimension();
         this.target = target;
         this.source = source;
         this.lineOfFire = source.subtract(target).normalize();
         this.entry = entry;
         this.ownerId = ownerId;
         this.radius = radius;
         this.tunnel = new Tunnel(level, source, target);
      }

      GodStrikePacket packet() {
         return new GodStrikePacket(this.id, this.dimension, this.target, this.source, this.entry, this.radius, this.age);
      }
   }
}
