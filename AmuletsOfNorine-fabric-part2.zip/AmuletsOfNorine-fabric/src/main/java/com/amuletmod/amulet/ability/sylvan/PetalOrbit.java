package com.amuletmod.amulet.ability.sylvan;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public final class PetalOrbit {
   public static final int BLOSSOMS = 5;
   public static final int PETALS = 5;
   public static final double PETAL_REACH = 0.17;
   private static final double RADIUS = 1.25;
   private static final double BOB = 0.18;
   private static final double TILT = 0.6;
   private static final double ORBIT_SPEED = 0.045;
   private static final double SPIN_SPEED = 0.11;

   private PetalOrbit() {
   }

   public static Vec3 center(Entity owner, double x, double y, double z) {
      return new Vec3(x, y + owner.getBbHeight() * 0.55, z);
   }

   private static double angle(int slot, double time) {
      return time * 0.045 + slot * (float) (Math.PI * 2) / 5.0F;
   }

   public static Vec3 outward(int slot, double time) {
      double angle = angle(slot, time);
      return new Vec3(Math.cos(angle), 0.0, Math.sin(angle));
   }

   public static Vec3 blossom(Vec3 center, int slot, double time) {
      Vec3 out = outward(slot, time);
      double bob = 0.18 * Math.sin(time * 0.07 + slot * 1.7);
      return center.add(out.x * 1.25, bob, out.z * 1.25);
   }

   public static Vec3 normal(int slot, double time) {
      Vec3 out = outward(slot, time);
      return new Vec3(out.x * Math.cos(0.6), Math.sin(0.6), out.z * Math.cos(0.6));
   }

   public static Vec3 petalDirection(int slot, int petal, double time) {
      Vec3 out = outward(slot, time);
      Vec3 n = normal(slot, time);
      Vec3 tangent = new Vec3(-out.z, 0.0, out.x);
      Vec3 bitangent = n.cross(tangent);
      double spin = time * 0.11 * (slot % 2 == 0 ? 1.0 : -1.0) + slot;
      double psi = spin + petal * (float) (Math.PI * 2) / 5.0F;
      return tangent.scale(Math.cos(psi)).add(bitangent.scale(Math.sin(psi)));
   }

   public static Vec3 petal(Vec3 center, int slot, int petal, double time) {
      return blossom(center, slot, time).add(petalDirection(slot, petal, time).scale(0.17));
   }
}
