package com.amuletmod.amulet;

import com.amuletmod.amulet.effect.BlastWardEffect;
import com.amuletmod.util.Damage;
import java.util.function.BiConsumer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.ProjectileImpactEvent;
import com.amuletmod.neo.event.EnderManAngerEvent;
import com.amuletmod.neo.event.LivingDeathEvent;
import com.amuletmod.neo.event.LivingFallEvent;
import com.amuletmod.neo.event.LivingHealEvent;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;
import com.amuletmod.neo.event.ExplosionKnockbackEvent;
import com.amuletmod.amulet.SlotResult;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class AmuletEvents {
   private AmuletEvents() {
   }

   private static void forEachEffect(LivingEntity entity, BiConsumer<AmuletEffect, ItemStack> action) {
      if (!entity.level().isClientSide()) {
         for (SlotResult result : Amulets.equipped(entity)) {
            ItemStack stack = result.stack();

            for (AmuletEffect effect : ((AmuletItem)stack.getItem()).definition(stack).effects()) {
               action.accept(effect, stack);
            }
         }
      }
   }

   @SubscribeEvent
   public static void onLivingFall(LivingFallEvent event) {
      LivingEntity wearer = event.getEntity();
      forEachEffect(wearer, (effect, stack) -> effect.onWearerFall(event, wearer, stack));
   }

   @SubscribeEvent
   public static void onLivingHurt(LivingIncomingDamageEvent event) {
      LivingEntity wearer = event.getEntity();
      if (Damage.landing(event)) {
         forEachEffect(wearer, (effect, stack) -> effect.onWearerHurt(event, wearer, stack));
      }
   }

   @SubscribeEvent
   public static void onProjectileImpact(ProjectileImpactEvent event) {
      if (event.getRayTraceResult() instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity wearer) {
         forEachEffect(wearer, (effect, stack) -> effect.onWearerHitByProjectile(event, wearer, stack));
      }
   }

   @SubscribeEvent
   public static void onLivingDeath(LivingDeathEvent event) {
      LivingEntity wearer = event.getEntity();
      forEachEffect(wearer, (effect, stack) -> effect.onWearerDeath(event, wearer, stack));
   }

   @SubscribeEvent
   public static void onLivingHeal(LivingHealEvent event) {
      LivingEntity wearer = event.getEntity();
      forEachEffect(wearer, (effect, stack) -> effect.onWearerHeal(event, wearer, stack));
   }

   @SubscribeEvent
   public static void onExplosionKnockback(ExplosionKnockbackEvent event) {
      if (event.getAffectedEntity() instanceof LivingEntity wearer && !wearer.level().isClientSide()) {
         event.setKnockbackVelocity(event.getKnockbackVelocity().scale(BlastWardEffect.dampenKnockback(wearer, 1.0)));
      }
   }

   @SubscribeEvent
   public static void onEndermanAnger(EnderManAngerEvent event) {
      Player wearer = event.getPlayer();
      forEachEffect(wearer, (effect, stack) -> effect.onEndermanStare(event, wearer, stack));
   }
}
