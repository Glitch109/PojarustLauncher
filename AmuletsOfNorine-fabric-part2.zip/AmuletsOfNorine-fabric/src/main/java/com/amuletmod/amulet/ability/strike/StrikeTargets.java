package com.amuletmod.amulet.ability.strike;

import com.amuletmod.amulet.Amulets;
import com.amuletmod.network.StrikeTargetSyncPacket;
import com.amuletmod.util.PlayerData;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedInEvent;
import com.amuletmod.neo.event.PlayerTickEvent.Post;
import com.amuletmod.neo.PacketDistributor;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class StrikeTargets {
   public static final int LIFETIME_TICKS = 1200;
   private static final String KEY = "strike_target";
   private static final String MARKED_AT = "marked_at";
   private static final int CHECK_TICKS = 10;

   private StrikeTargets() {
   }

   public static Optional<StrikeTarget> get(ServerPlayer player) {
      CompoundTag data = PlayerData.get(player);
      return data.contains("strike_target") ? Optional.ofNullable(StrikeTarget.load(data.getCompound("strike_target"))) : Optional.empty();
   }

   public static void set(ServerPlayer player, StrikeTarget target) {
      CompoundTag mark = target.save();
      mark.putLong("marked_at", now(player));
      PlayerData.get(player).put("strike_target", mark);
      sync(player);
   }

   public static void clear(ServerPlayer player) {
      PlayerData.get(player).remove("strike_target");
      sync(player);
   }

   private static void sync(ServerPlayer player) {
      PacketDistributor.sendToPlayer(player, new StrikeTargetSyncPacket(get(player).orElse(null)), new CustomPacketPayload[0]);
   }

   private static long now(ServerPlayer player) {
      return player.server.overworld().getGameTime();
   }

   private static boolean canMark(ServerPlayer player) {
      return Amulets.<MarkTargetAbility>find(player, MarkTargetAbility.class) != null;
   }

   @SubscribeEvent
   public static void onPlayerTick(Post event) {
      if (event.getEntity() instanceof ServerPlayer player && player.tickCount % 10 == 0) {
         CompoundTag data = PlayerData.get(player);
         if (data.contains("strike_target")) {
            CompoundTag mark = data.getCompound("strike_target");
            boolean expired = !mark.contains("marked_at") || now(player) - mark.getLong("marked_at") >= 1200L;
            if (expired || !canMark(player)) {
               clear(player);
               player.playNotifySound(SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.6F, 1.4F);
               player.displayClientMessage(
                  Component.translatable(expired ? "message.amuletmod.target_expired" : "message.amuletmod.target_dropped").withStyle(ChatFormatting.GRAY),
                  true
               );
            }
         }
      }
   }

   @SubscribeEvent
   public static void onLogin(PlayerLoggedInEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         sync(player);
      }
   }
}
