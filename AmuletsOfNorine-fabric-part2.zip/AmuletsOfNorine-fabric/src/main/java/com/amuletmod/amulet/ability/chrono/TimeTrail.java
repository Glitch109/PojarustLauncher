package com.amuletmod.amulet.ability.chrono;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedOutEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerRespawnEvent;
import com.amuletmod.neo.event.ServerStoppedEvent;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class TimeTrail {
   public static final int MAX_TICKS = 200;
   private static final Map<UUID, TimeTrail.Trail> TRAILS = new HashMap<>();

   private TimeTrail() {
   }

   public static void record(ServerPlayer player) {
      long now = player.server.overworld().getGameTime();
      TimeTrail.Trail trail = TRAILS.computeIfAbsent(player.getUUID(), id -> new TimeTrail.Trail());
      TimeTrail.Snapshot last = trail.snapshots.peekLast();
      if (last == null || last.time() != now) {
         if (trail.dimension != player.level().dimension() || last != null && now - last.time() > 2L) {
            trail.snapshots.clear();
            trail.dimension = player.level().dimension();
         }

         trail.snapshots.addLast(new TimeTrail.Snapshot(now, player.position(), player.getYRot(), player.getXRot(), player.getHealth(), player.isOnFire()));

         while (trail.snapshots.size() > 200) {
            trail.snapshots.removeFirst();
         }
      }
   }

   public static List<TimeTrail.Snapshot> path(ServerPlayer player, int ticks) {
      TimeTrail.Trail trail = TRAILS.get(player.getUUID());
      if (trail != null && trail.dimension == player.level().dimension()) {
         List<TimeTrail.Snapshot> path = new ArrayList<>(Math.min(ticks, trail.snapshots.size()));
         Iterator<TimeTrail.Snapshot> newestFirst = trail.snapshots.descendingIterator();

         while (newestFirst.hasNext() && path.size() < ticks) {
            path.add(newestFirst.next());
         }

         Collections.reverse(path);
         return path;
      } else {
         return List.of();
      }
   }

   public static void clear(ServerPlayer player) {
      TRAILS.remove(player.getUUID());
   }

   @SubscribeEvent
   public static void onRespawn(PlayerRespawnEvent event) {
      TRAILS.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onLogout(PlayerLoggedOutEvent event) {
      TRAILS.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      TRAILS.clear();
   }

   public record Snapshot(long time, Vec3 position, float yRot, float xRot, float health, boolean burning) {
   }

   private static final class Trail {
      @Nullable
      ResourceKey<Level> dimension;
      final ArrayDeque<TimeTrail.Snapshot> snapshots = new ArrayDeque<>();
   }
}
