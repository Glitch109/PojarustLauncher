package com.amuletmod.amulet.ability.recall;

import com.amuletmod.amulet.ActiveAbility;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public record RecallAbility(double maxDistance, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.recall", new Object[]{(int)this.maxDistance});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      Optional<ReturnPoint> maybePoint = ReturnPoints.get(player);
      if (maybePoint.isEmpty()) {
         return fail(player, Component.translatable("message.amuletmod.no_return_point"));
      } else {
         ReturnPoint point = maybePoint.get();
         if (point.dimension() != player.level().dimension()) {
            return fail(player, Component.translatable("message.amuletmod.return_point_other_dimension"));
         } else {
            double distance = player.position().distanceTo(point.position());
            if (distance > this.maxDistance) {
               return fail(
                  player, Component.translatable("message.amuletmod.return_point_too_far", new Object[]{(int)Math.ceil(distance), (int)this.maxDistance})
               );
            } else {
               ServerLevel level = ((ServerLevel) player.level());
               teleportEffects(level, player.position());
               player.stopRiding();
               player.teleportTo(level, point.position().x, point.position().y, point.position().z, player.getYRot(), player.getXRot());
               player.resetFallDistance();
               teleportEffects(level, point.position());
               ReturnPoints.clear(player);
               player.displayClientMessage(Component.translatable("message.amuletmod.recalled").withStyle(ChatFormatting.GREEN), true);
               return true;
            }
         }
      }
   }

   private static boolean fail(ServerPlayer player, Component message) {
      player.displayClientMessage(message.copy().withStyle(ChatFormatting.RED), true);
      return false;
   }

   private static void teleportEffects(ServerLevel level, Vec3 pos) {
      level.sendParticles(ParticleTypes.PORTAL, pos.x, pos.y + 1.0, pos.z, 40, 0.3, 0.6, 0.3, 0.1);
      level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
   }
}
