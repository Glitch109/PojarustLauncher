package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public record InSunlightEffect(AmuletEffect inner) implements AmuletEffect {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.effect.in_sunlight", new Object[]{this.inner.description()});
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (!inSunlight(wearer)) {
         this.inner.onUnequip(wearer, amulet);
      } else {
         this.inner.onWearerTick(wearer, amulet);
         if (wearer.tickCount % 12 == 0 && wearer.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.SMOKE, wearer.getX(), wearer.getY() + wearer.getBbHeight() * 0.7, wearer.getZ(), 2, 0.25, 0.35, 0.25, 0.01);
         }
      }
   }

   private static boolean inSunlight(LivingEntity wearer) {
      Level level = wearer.level();
      BlockPos eyes = BlockPos.containing(wearer.getX(), wearer.getEyeY(), wearer.getZ());
      return level.isDay() && level.canSeeSky(eyes) && !level.isRainingAt(eyes);
   }

   @Override
   public void onUnequip(LivingEntity wearer, ItemStack amulet) {
      this.inner.onUnequip(wearer, amulet);
   }

   @Override
   public boolean isDrawback() {
      return this.inner.isDrawback();
   }
}
