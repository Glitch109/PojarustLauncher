package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import com.amuletmod.amulet.AmuletItem;
import com.amuletmod.amulet.Amulets;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;
import com.amuletmod.amulet.SlotResult;

public record BlastWardEffect(float damageMultiplier, float knockbackMultiplier) implements AmuletEffect {
   @Override
   public Component description() {
      return Component.translatable(
         "tooltip.amuletmod.effect.blast_ward",
         new Object[]{Math.round((1.0F - this.damageMultiplier) * 100.0F), Math.round((1.0F - this.knockbackMultiplier) * 100.0F)}
      );
   }

   @Override
   public void onWearerHurt(LivingIncomingDamageEvent event, LivingEntity wearer, ItemStack amulet) {
      if (event.getSource().is(DamageTypeTags.IS_EXPLOSION)) {
         event.setAmount(event.getAmount() * this.damageMultiplier);
      }
   }

   public static double dampenKnockback(LivingEntity entity, double knockback) {
      for (SlotResult result : Amulets.equipped(entity)) {
         for (AmuletEffect effect : ((AmuletItem)result.stack().getItem()).definition(result.stack()).effects()) {
            if (effect instanceof BlastWardEffect ward) {
               knockback *= ward.knockbackMultiplier();
            }
         }
      }

      return knockback;
   }
}
