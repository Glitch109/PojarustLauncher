package com.amuletmod.amulet.ability.sovereign;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.ability.glacial.Frost;
import com.amuletmod.entity.ChainBindEntity;
import com.amuletmod.util.Aim;
import com.amuletmod.util.Sounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public record ChainBindingAbility(double range, int durationTicks, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.chain_binding", new Object[]{this.durationTicks / 20, (int)this.range});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      LivingEntity target = Aim.lookedAt(player, this.range, living -> Frost.canHarm(living, player));
      if (target == null) {
         player.displayClientMessage(Component.translatable("message.amuletmod.chain_no_target").withStyle(ChatFormatting.RED), true);
         return false;
      } else if (target instanceof EnderDragon) {
         player.displayClientMessage(
            Component.translatable("message.amuletmod.chain_immune", new Object[]{target.getDisplayName()}).withStyle(ChatFormatting.RED), true
         );
         player.playNotifySound(SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 1.0F, 0.6F);
         return false;
      } else {
         float theirs = AuraSight.power(target);
         float yours = AuraSight.power(player);
         if (theirs > yours) {
            player.displayClientMessage(
               Component.translatable("message.amuletmod.chain_too_strong", new Object[]{target.getDisplayName(), Math.round(theirs), Math.round(yours)})
                  .withStyle(ChatFormatting.RED),
               true
            );
            player.playNotifySound(SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 1.0F, 0.6F);
            return false;
         } else if (ChainBindEntity.isBinding(level, target)) {
            player.displayClientMessage(
               Component.translatable("message.amuletmod.chain_already", new Object[]{target.getDisplayName()}).withStyle(ChatFormatting.RED), true
            );
            return false;
         } else {
            level.addFreshEntity(new ChainBindEntity(level, target, this.durationTicks));
            Vec3 eye = player.getEyePosition();
            Vec3 to = target.position().add(0.0, target.getBbHeight() * 0.5, 0.0);
            int steps = (int)Math.ceil(eye.distanceTo(to) / 0.6);

            for (int i = 1; i <= steps; i++) {
               Vec3 at = eye.lerp(to, (double)i / steps);
               level.sendParticles(ParticleTypes.WITCH, at.x, at.y, at.z, 1, 0.02, 0.02, 0.02, 0.0);
            }

            Sounds.play(level, eye, SoundEvents.ILLUSIONER_CAST_SPELL, 1.0F, 0.7F);
            player.displayClientMessage(
               Component.translatable("message.amuletmod.chain_binding", new Object[]{target.getDisplayName()}).withStyle(ChatFormatting.LIGHT_PURPLE), true
            );
            return true;
         }
      }
   }
}
