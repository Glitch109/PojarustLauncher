package com.amuletmod.amulet.ability.aegis;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.entity.BarrierEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public record MirrorWardAbility(int durationTicks, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.mirror_ward", new Object[]{this.durationTicks / 20});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      level.addFreshEntity(BarrierEntity.ward(level, player, this.durationTicks));
      player.displayClientMessage(Component.translatable("message.amuletmod.mirror_ward").withStyle(ChatFormatting.GOLD), true);
      return true;
   }
}
