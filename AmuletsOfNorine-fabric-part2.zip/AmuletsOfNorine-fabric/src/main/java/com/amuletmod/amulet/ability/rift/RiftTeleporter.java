package com.amuletmod.amulet.ability.rift;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.feature.EndPlatformFeature;
import net.minecraft.world.level.portal.DimensionTransition;
import net.minecraft.world.phys.Vec3;

public final class RiftTeleporter {
   private RiftTeleporter() {
   }

   public static DimensionTransition to(ServerLevel target, Vec3 destination, float yRot, Entity traveller) {
      if (target.dimension() == Level.END) {
         EndPlatformFeature.createEndPlatform(target, BlockPos.containing(destination).below(), true);
      }

      return new DimensionTransition(target, destination, Vec3.ZERO, yRot, traveller.getXRot(), DimensionTransition.DO_NOTHING);
   }
}
