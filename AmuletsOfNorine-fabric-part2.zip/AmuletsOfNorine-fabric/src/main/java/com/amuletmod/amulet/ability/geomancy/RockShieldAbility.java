package com.amuletmod.amulet.ability.geomancy;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.entity.RockShellEntity;
import com.amuletmod.util.ServerScheduler;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.Tags.Blocks;

public record RockShieldAbility(float healthMultiplier, int durationTicks, int cooldownTicks) implements ActiveAbility {
   private static final int SEARCH_RADIUS = 8;
   private static final int MAX_ROCKS = 24;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.rock_shield", new Object[]{this.durationTicks / 20});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      if (RockShellEntity.of(player) != null) {
         player.displayClientMessage(Component.translatable("message.amuletmod.rock_shield_up").withStyle(ChatFormatting.RED), true);
         return false;
      } else {
         ServerLevel level = ((ServerLevel) player.level());
         List<RockShellEntity.Source> rocks = findRocks(level, player.blockPosition(), level.random);
         float capacity = player.getMaxHealth() * this.healthMultiplier;
         level.addFreshEntity(new RockShellEntity(level, player, rocks, capacity, this.durationTicks));
         Vec3 at = player.position();
         Sounds.play(level, at, SoundEvents.DEEPSLATE_BREAK, 1.0F, 0.5F);

         for (int i = 0; i < 4; i++) {
            float pitch = 0.6F + i * 0.1F;
            ServerScheduler.schedule(2 + i * 4, () -> Sounds.play(level, player.position(), SoundEvents.GRAVEL_BREAK, 0.9F, pitch));
         }

         ServerScheduler.schedule(
            (int)RockShellEntity.formsAt(RockShellEntity.PIECES - 1) + 1, () -> Sounds.play(level, player.position(), SoundEvents.ANVIL_LAND, 0.4F, 0.5F)
         );
         player.displayClientMessage(Component.translatable("message.amuletmod.rock_shield", new Object[]{(int)capacity}).withStyle(ChatFormatting.GOLD), true);
         return true;
      }
   }

   private static List<RockShellEntity.Source> findRocks(ServerLevel level, BlockPos center, RandomSource random) {
      List<RockShellEntity.Source> picked = new ArrayList<>();
      int seen = 0;
      MutableBlockPos neighbour = new MutableBlockPos();

      for (BlockPos pos : BlockPos.betweenClosed(center.offset(-8, -8, -8), center.offset(8, 8, 8))) {
         BlockState state = level.getBlockState(pos);
         if (isRock(state)) {
            boolean exposed = false;

            for (Direction side : Direction.values()) {
               if (level.getBlockState(neighbour.setWithOffset(pos, side)).isAir()) {
                  exposed = true;
                  break;
               }
            }

            if (exposed) {
               seen++;
               if (picked.size() < 24) {
                  picked.add(new RockShellEntity.Source(pos.immutable(), state));
               } else if (random.nextInt(seen) < 24) {
                  picked.set(random.nextInt(24), new RockShellEntity.Source(pos.immutable(), state));
               }
            }
         }
      }

      return picked;
   }

   private static boolean isRock(BlockState state) {
      return !state.is(Blocks.ORES)
         && (
            state.is(BlockTags.BASE_STONE_OVERWORLD)
               || state.is(BlockTags.BASE_STONE_NETHER)
               || state.is(Blocks.STONES)
               || state.is(Blocks.COBBLESTONES)
               || state.is(Blocks.SANDSTONE_BLOCKS)
               || state.is(Blocks.END_STONES)
               || state.is(Blocks.GRAVELS)
         );
   }
}
