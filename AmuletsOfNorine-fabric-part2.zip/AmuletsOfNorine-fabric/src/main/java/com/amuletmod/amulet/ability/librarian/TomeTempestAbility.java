package com.amuletmod.amulet.ability.librarian;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.entity.PageStormEntity;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public record TomeTempestAbility(int shelfRadius, int maxPages, double range, float damage, int cooldownTicks) implements ActiveAbility {
   public static final int BOOKS_PER_SHELF = 3;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.tome_tempest", new Object[]{this.shelfRadius, 3, this.maxPages, 12, (int)this.range});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      int maxBooks = Math.max(1, this.maxPages / 5);
      List<BlockPos> shelfBooks = new ArrayList<>();

      for (BlockPos shelf : Bookshelves.within(level, player.blockPosition(), this.shelfRadius)) {
         for (int i = 0; i < 3 && shelfBooks.size() < maxBooks; i++) {
            shelfBooks.add(shelf);
         }
      }

      int fromPack = takeBooks(player, maxBooks - shelfBooks.size());
      if (shelfBooks.isEmpty() && fromPack == 0) {
         player.displayClientMessage(
            Component.translatable("message.amuletmod.tome_tempest_no_books", new Object[]{this.shelfRadius}).withStyle(ChatFormatting.RED), true
         );
         return false;
      } else {
         List<BlockPos> sources = new ArrayList<>();

         for (int i = 0; i < fromPack; i++) {
            sources.add(null);
         }

         sources.addAll(shelfBooks);
         level.addFreshEntity(new PageStormEntity(level, player, sources, this.range, this.damage));
         player.displayClientMessage(
            Component.translatable("message.amuletmod.tome_tempest", new Object[]{sources.size(), sources.size() * 5}).withStyle(ChatFormatting.LIGHT_PURPLE),
            true
         );
         return true;
      }
   }

   private static int takeBooks(ServerPlayer player, int wanted) {
      Inventory inventory = player.getInventory();
      int taken = 0;

      for (int slot = 0; slot < inventory.getContainerSize() && taken < wanted; slot++) {
         ItemStack stack = inventory.getItem(slot);
         if (stack.is(Items.BOOK)) {
            int take = Math.min(stack.getCount(), wanted - taken);
            taken += take;
            if (!player.getAbilities().instabuild) {
               stack.shrink(take);
            }
         }
      }

      if (taken > 0) {
         inventory.setChanged();
      }

      return taken;
   }
}
