package com.amuletmod.amulet.ability.rift;

import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

public enum RiftKind {
   NETHER(Level.NETHER, ChatFormatting.RED, 16730640, 16767120),
   END(Level.END, ChatFormatting.LIGHT_PURPLE, 10108159, 15916543),
   OVERWORLD(Level.OVERWORLD, ChatFormatting.GREEN, 3989642, 16056296);

   private final ResourceKey<Level> dimension;
   private final ChatFormatting chatColor;
   private final int glow;
   private final int core;

   private RiftKind(ResourceKey<Level> dimension, ChatFormatting chatColor, int glow, int core) {
      this.dimension = dimension;
      this.chatColor = chatColor;
      this.glow = glow;
      this.core = core;
   }

   public ResourceKey<Level> dimension() {
      return this.dimension;
   }

   public ChatFormatting chatColor() {
      return this.chatColor;
   }

   public int glow() {
      return this.glow;
   }

   public int core() {
      return this.core;
   }

   public Component displayName() {
      return Component.translatable("tooltip.amuletmod.rift." + this.name().toLowerCase(Locale.ROOT));
   }

   public static RiftKind byId(int id) {
      RiftKind[] kinds = values();
      return kinds[Math.floorMod(id, kinds.length)];
   }

   public static RiftKind of(ResourceKey<Level> dimension) {
      if (dimension == Level.NETHER) {
         return NETHER;
      } else {
         return dimension == Level.END ? END : OVERWORLD;
      }
   }
}
