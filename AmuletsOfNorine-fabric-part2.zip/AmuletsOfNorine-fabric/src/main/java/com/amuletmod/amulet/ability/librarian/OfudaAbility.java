package com.amuletmod.amulet.ability.librarian;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.entity.OfudaEntity;
import com.amuletmod.util.Aim;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.item.ItemStack;

public record OfudaAbility(double range, int minTicks, int maxTicks, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.ofuda", new Object[]{(int)this.range, this.minTicks / 20, this.maxTicks / 20});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      LivingEntity target = Aim.lookedAt(
         player, this.range, living -> living.isAlive() && !living.isSpectator() && !(living instanceof ArmorStand) && !living.isInvisibleTo(player)
      );
      if (target == null) {
         target = player;
      }

      RandomSource random = player.getRandom();
      Kanji chosen = Kanji.random(random);
      Kanji first = Kanji.other(random, chosen);
      Kanji second = Kanji.other(random, chosen, first);
      int ticks = this.minTicks + random.nextInt(Math.max(1, this.maxTicks - this.minTicks + 1));
      ServerLevel level = ((ServerLevel) player.level());
      level.addFreshEntity(new OfudaEntity(level, player, target, new Kanji[]{first, second, chosen}, ticks));
      return true;
   }
}
