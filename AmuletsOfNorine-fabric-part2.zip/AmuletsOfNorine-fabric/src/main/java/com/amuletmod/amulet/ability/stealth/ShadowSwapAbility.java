package com.amuletmod.amulet.ability.stealth;

import net.minecraft.server.level.ServerLevel;
import com.amuletmod.amulet.AbilityOrigin;
import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.AmuletItem;
import com.amuletmod.util.Aim;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import com.amuletmod.neo.Tags.EntityTypes;

public record ShadowSwapAbility(double markRange, int channelTicks, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.shadow_swap", new Object[]{(int)this.markRange});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      if (ShadowMarks.isSwapping(player)) {
         return false;
      } else {
         ShadowMarks.Mark mark = ShadowMarks.get(player);
         LivingEntity looked = Aim.lookedAt(player, this.markRange, living -> living.isAlive());
         if (looked == null || mark != null && looked.getUUID().equals(mark.target())) {
            if (mark == null) {
               player.displayClientMessage(Component.translatable("message.amuletmod.shadow_no_mark").withStyle(ChatFormatting.RED), true);
               return false;
            } else {
               AbilityOrigin origin = ((AmuletItem)amulet.getItem()).originOf(amulet, this);
               return origin != null && ShadowMarks.beginSwap(player, mark, this.channelTicks, origin);
            }
         } else if (looked.getType().is(EntityTypes.BOSSES)) {
            player.displayClientMessage(
               Component.translatable("message.amuletmod.shadow_mark_immune", new Object[]{looked.getDisplayName()}).withStyle(ChatFormatting.RED), true
            );
            return false;
         } else {
            ShadowMarks.set(player, looked);
            ((ServerLevel) player.level())
               .sendParticles(
                  player,
                  ParticleTypes.REVERSE_PORTAL,
                  true,
                  looked.getX(),
                  looked.getY() + looked.getBbHeight() * 0.5,
                  looked.getZ(),
                  30,
                  looked.getBbWidth() * 0.5,
                  looked.getBbHeight() * 0.4,
                  looked.getBbWidth() * 0.5,
                  0.02
               );
            player.playNotifySound(SoundEvents.ILLUSIONER_CAST_SPELL, SoundSource.PLAYERS, 0.6F, 1.4F);
            player.displayClientMessage(
               Component.translatable("message.amuletmod.shadow_marked", new Object[]{looked.getDisplayName()}).withStyle(ChatFormatting.DARK_PURPLE), true
            );
            return false;
         }
      }
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (wearer instanceof ServerPlayer player && wearer.tickCount % 20 == 0) {
         ShadowMarks.track(player);
      }
   }
}
