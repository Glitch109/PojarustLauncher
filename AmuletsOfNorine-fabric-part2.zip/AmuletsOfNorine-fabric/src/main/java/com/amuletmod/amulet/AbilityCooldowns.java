package com.amuletmod.amulet;

import com.amuletmod.util.PlayerData;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;

public final class AbilityCooldowns {
   private static final String KEY = "cooldowns";
   private static final String DISABLED_KEY = "cooldowns_disabled";

   private AbilityCooldowns() {
   }

   public static long remainingTicks(ServerPlayer player, AbilityOrigin ability) {
      return remainingTicks(player, key(ability));
   }

   public static long remainingTicks(ServerPlayer player, AbilityOrigin ability, String move) {
      return remainingTicks(player, key(ability) + "/" + move);
   }

   public static void start(ServerPlayer player, AbilityOrigin ability, int ticks) {
      start(player, key(ability), ticks);
   }

   public static void start(ServerPlayer player, AbilityOrigin ability, String move, int ticks) {
      start(player, key(ability) + "/" + move, ticks);
   }

   private static long remainingTicks(ServerPlayer player, String key) {
      if (disabled(player)) {
         return 0L;
      } else {
         long readyAt = cooldowns(player).getLong(key);
         return Math.max(0L, readyAt - now(player));
      }
   }

   private static void start(ServerPlayer player, String key, int ticks) {
      if (!disabled(player)) {
         CompoundTag cooldowns = cooldowns(player);
         long now = now(player);
         cooldowns.getAllKeys().removeIf(other -> cooldowns.getLong(other) <= now);
         cooldowns.putLong(key, now + ticks);
      }
   }

   public static void clear(ServerPlayer player, AbilityOrigin ability) {
      cooldowns(player).remove(key(ability));
   }

   public static int clearAll(ServerPlayer player) {
      CompoundTag cooldowns = cooldowns(player);
      long now = now(player);
      int running = (int)cooldowns.getAllKeys().stream().filter(key -> cooldowns.getLong(key) > now).count();
      PlayerData.get(player).remove("cooldowns");
      return running;
   }

   public static boolean disabled(ServerPlayer player) {
      return PlayerData.get(player).getBoolean("cooldowns_disabled");
   }

   public static void setDisabled(ServerPlayer player, boolean disabled) {
      clearAll(player);
      if (disabled) {
         PlayerData.get(player).putBoolean("cooldowns_disabled", true);
      } else {
         PlayerData.get(player).remove("cooldowns_disabled");
      }
   }

   private static CompoundTag cooldowns(ServerPlayer player) {
      CompoundTag data = PlayerData.get(player);
      if (!data.contains("cooldowns")) {
         data.put("cooldowns", new CompoundTag());
      }

      return data.getCompound("cooldowns");
   }

   private static String key(AbilityOrigin ability) {
      return BuiltInRegistries.ITEM.getKey(ability.amulet()) + "#" + ability.slot();
   }

   private static long now(ServerPlayer player) {
      return player.server.overworld().getGameTime();
   }
}
