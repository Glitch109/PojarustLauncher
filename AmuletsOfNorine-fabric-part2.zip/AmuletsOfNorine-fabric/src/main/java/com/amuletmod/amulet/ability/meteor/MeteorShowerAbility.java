package com.amuletmod.amulet.ability.meteor;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.entity.MeteorEntity;
import com.amuletmod.util.ServerScheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public record MeteorShowerAbility(int durationTicks, int intervalTicks, double radius, int cooldownTicks) implements ActiveAbility {
   private static final double MIN_RADIUS = 3.0;
   private static final double SPEED = 1.2;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.meteor_shower", new Object[]{this.durationTicks / 20, (int)this.radius});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.WITHER_SPAWN, SoundSource.PLAYERS, 0.6F, 1.6F);
      player.displayClientMessage(Component.translatable("message.amuletmod.meteor_shower").withStyle(ChatFormatting.GOLD), true);
      int t = 0;

      while (t < this.durationTicks) {
         ServerScheduler.schedule(t, () -> this.spawnMeteor(player, level));
         t += this.intervalTicks;
      }

      return true;
   }

   private void spawnMeteor(ServerPlayer player, ServerLevel level) {
      if (!player.isRemoved() && player.isAlive() && player.level() == level) {
         RandomSource random = player.getRandom();
         double angle = random.nextDouble() * Math.PI * 2.0;
         double distance = 3.0 + (this.radius - 3.0) * Math.sqrt(random.nextDouble());
         Vec3 target = player.position().add(Math.cos(angle) * distance, 0.0, Math.sin(angle) * distance);
         double approach = random.nextDouble() * Math.PI * 2.0;
         double sideways = 10.0 + random.nextDouble() * 10.0;
         Vec3 start = target.add(Math.cos(approach) * sideways, 30.0 + random.nextDouble() * 10.0, Math.sin(approach) * sideways);
         if (level.getBlockState(BlockPos.containing(start)).isAir()) {
            Vec3 velocity = target.subtract(start).normalize().scale(1.2);
            level.addFreshEntity(new MeteorEntity(level, player, start, velocity));
         }
      }
   }
}
