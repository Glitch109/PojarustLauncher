package com.amuletmod.amulet.ability.titan;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.client.TitanHud;
import com.amuletmod.registry.ModSounds;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Sounds;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public record TitanFistsAbility(double jabRange, double remoteRange, float shockwave, int jabMinTicks, int jabMaxTicks, int crushTicks, int uppercutTicks)
   implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.titan_fists");
   }

   @Override
   public List<Component> details(ItemStack amulet) {
      Stance current = ClientSide.call(() -> TitanHud::fists);
      return List.of(
         stanceLine(Stance.JAB, current, (int)this.jabRange, format(this.jabMinTicks), format(this.jabMaxTicks)),
         stanceLine(Stance.CRUSH, current, (int)this.remoteRange, (int)this.shockwave, format(this.crushTicks)),
         stanceLine(Stance.UPPERCUT, current, (int)this.remoteRange, format(this.uppercutTicks))
      );
   }

   private static Component stanceLine(Stance stance, @Nullable Stance current, Object... args) {
      return Component.literal("    ")
         .append(Component.translatable("tooltip.amuletmod.ability.titan_fists." + stance.id(), args))
         .withStyle(stance == current ? ChatFormatting.YELLOW : ChatFormatting.GRAY);
   }

   static String format(int ticks) {
      return ticks % 20 == 0 ? Integer.toString(ticks / 20) : Float.toString(ticks / 20.0F);
   }

   @Override
   public int cooldownTicks() {
      return 0;
   }

   public int cooldown(Stance stance, RandomSource random) {
      return switch (stance) {
         case JAB -> this.jabMinTicks + random.nextInt(this.jabMaxTicks - this.jabMinTicks + 1);
         case CRUSH -> this.crushTicks;
         case UPPERCUT -> this.uppercutTicks;
      };
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      Stance stance = Stance.after(Stance.of(player));
      Stance.set(player, stance);
      if (stance == null) {
         player.playNotifySound((SoundEvent)ModSounds.TITAN_POWER_CANCEL.get(), SoundSource.PLAYERS, 0.9F, 1.0F);
         Sounds.play(player.level(), player.position().add(0.0, 1.0, 0.0), SoundEvents.FIRE_EXTINGUISH, 0.35F, 1.6F);
      } else {
         player.playNotifySound((SoundEvent)ModSounds.TITAN_POWER_SELECT.get(), SoundSource.PLAYERS, 0.9F, 0.95F + 0.05F * stance.ordinal());
         if (stance == Stance.JAB) {
            Sounds.play(player.level(), player.position().add(0.0, 1.0, 0.0), SoundEvents.FIRECHARGE_USE, 0.3F, 1.4F);
         }
      }

      TitanSync.hud(player, TitanSync.glyph(stance));
      TitanSync.hands(player);
      return true;
   }

   @Override
   public void onUnequip(LivingEntity wearer, ItemStack amulet) {
      if (wearer instanceof ServerPlayer player && Stance.of(player) != null) {
         Stance.set(player, null);
         TitanSync.hud(player, -1);
         TitanSync.hands(player);
      }
   }
}
