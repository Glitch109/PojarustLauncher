package com.amuletmod.amulet.ability.geomancy;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.ability.glacial.Frost;
import com.amuletmod.entity.SeismicWaveEntity;
import com.amuletmod.util.Sounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public record SeismicSlamAbility(float radius, float damage, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.seismic_slam", new Object[]{(int)this.radius});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      Double ground = Frost.groundY(level, player.getX(), player.getY(), player.getZ(), 1, 3);
      if (ground == null) {
         player.displayClientMessage(Component.translatable("message.amuletmod.seismic_no_ground").withStyle(ChatFormatting.RED), true);
         return false;
      } else {
         Vec3 center = new Vec3(player.getX(), ground, player.getZ());
         level.addFreshEntity(new SeismicWaveEntity(level, player, center, this.radius, this.damage));
         player.swing(InteractionHand.MAIN_HAND, true);
         BlockState floor = level.getBlockState(BlockPos.containing(center.x, center.y - 0.5, center.z));
         if (!floor.isAir()) {
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, floor), center.x, center.y + 0.1, center.z, 50, 0.8, 0.1, 0.8, 0.25);
         }

         level.sendParticles(ParticleTypes.EXPLOSION, center.x, center.y + 0.3, center.z, 1, 0.0, 0.0, 0.0, 0.0);
         Sounds.play(level, center, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 0.9F, 0.55F);
         Sounds.play(level, center, SoundEvents.DEEPSLATE_BREAK, 1.4F, 0.5F);
         Sounds.play(level, center, SoundEvents.ANVIL_LAND, 0.5F, 0.5F);
         player.displayClientMessage(Component.translatable("message.amuletmod.seismic_slam").withStyle(ChatFormatting.GOLD), true);
         return true;
      }
   }
}
