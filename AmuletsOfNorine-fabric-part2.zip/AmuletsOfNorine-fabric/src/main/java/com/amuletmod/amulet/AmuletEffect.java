package com.amuletmod.amulet;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import com.amuletmod.neo.event.ProjectileImpactEvent;
import com.amuletmod.neo.event.EnderManAngerEvent;
import com.amuletmod.neo.event.LivingDeathEvent;
import com.amuletmod.neo.event.LivingFallEvent;
import com.amuletmod.neo.event.LivingHealEvent;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;

public interface AmuletEffect {
   Component description();

   default boolean isDrawback() {
      return false;
   }

   default void onWearerTick(LivingEntity wearer, ItemStack amulet) {
   }

   default void onUnequip(LivingEntity wearer, ItemStack amulet) {
   }

   default void onWearerFall(LivingFallEvent event, LivingEntity wearer, ItemStack amulet) {
   }

   default void onWearerHurt(LivingIncomingDamageEvent event, LivingEntity wearer, ItemStack amulet) {
   }

   default void onWearerHitByProjectile(ProjectileImpactEvent event, LivingEntity wearer, ItemStack amulet) {
   }

   default void onWearerDeath(LivingDeathEvent event, LivingEntity wearer, ItemStack amulet) {
   }

   default void onWearerHeal(LivingHealEvent event, LivingEntity wearer, ItemStack amulet) {
   }

   default void onEndermanStare(EnderManAngerEvent event, Player wearer, ItemStack amulet) {
   }
}
