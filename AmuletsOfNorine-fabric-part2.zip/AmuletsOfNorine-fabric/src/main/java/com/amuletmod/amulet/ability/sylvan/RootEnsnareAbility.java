package com.amuletmod.amulet.ability.sylvan;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.ability.glacial.Frost;
import com.amuletmod.entity.RootsEntity;
import com.amuletmod.registry.ModTags;
import com.amuletmod.util.Aim;
import com.amuletmod.util.Sounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.Tags.EntityTypes;

public record RootEnsnareAbility(double range, int durationTicks, int cooldownTicks) implements ActiveAbility {
   private static final int MAX_DROP = 10;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.root_ensnare", new Object[]{this.durationTicks / 20, (int)this.range});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      LivingEntity target = Aim.lookedAt(player, this.range, living -> Frost.canHarm(living, player));
      if (target == null) {
         player.displayClientMessage(Component.translatable("message.amuletmod.root_no_target").withStyle(ChatFormatting.RED), true);
         return false;
      } else if (target.getType().is(EntityTypes.BOSSES)) {
         player.displayClientMessage(
            Component.translatable("message.amuletmod.root_immune", new Object[]{target.getDisplayName()}).withStyle(ChatFormatting.RED), true
         );
         return false;
      } else if (RootsEntity.isHolding(level, target)) {
         player.displayClientMessage(
            Component.translatable("message.amuletmod.root_already", new Object[]{target.getDisplayName()}).withStyle(ChatFormatting.RED), true
         );
         return false;
      } else {
         Double ground = Frost.groundY(level, target.getX(), target.getY(), target.getZ(), 1, 10);
         if (ground != null && !(target.getY() - ground > 10.0)) {
            BlockState soil = level.getBlockState(BlockPos.containing(target.getX(), ground - 0.01, target.getZ()));
            if (!soil.is(ModTags.ROOT_SOIL)) {
               player.displayClientMessage(
                  Component.translatable("message.amuletmod.root_bad_ground", new Object[]{soil.getBlock().getName()}).withStyle(ChatFormatting.RED), true
               );
               return false;
            } else {
               level.addFreshEntity(new RootsEntity(level, target, new Vec3(target.getX(), ground, target.getZ()), this.durationTicks));
               Vec3 eye = player.getEyePosition();
               Vec3 to = target.position().add(0.0, target.getBbHeight() * 0.5, 0.0);
               int steps = (int)Math.ceil(eye.distanceTo(to) / 0.7);

               for (int i = 1; i <= steps; i++) {
                  Vec3 at = eye.lerp(to, (double)i / steps);
                  level.sendParticles(ParticleTypes.COMPOSTER, at.x, at.y, at.z, 1, 0.03, 0.03, 0.03, 0.0);
               }

               Sounds.play(level, eye, SoundEvents.BIG_DRIPLEAF_TILT_DOWN, 1.0F, 0.7F);
               Sounds.play(level, eye, SoundEvents.AZALEA_LEAVES_PLACE, 1.0F, 0.6F);
               player.displayClientMessage(
                  Component.translatable("message.amuletmod.root_ensnare", new Object[]{target.getDisplayName()}).withStyle(ChatFormatting.GREEN), true
               );
               return true;
            }
         } else {
            player.displayClientMessage(Component.translatable("message.amuletmod.root_no_ground", new Object[]{10}).withStyle(ChatFormatting.RED), true);
            return false;
         }
      }
   }
}
