package com.amuletmod.amulet.ability.infernal;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.ability.glacial.Frost;
import com.amuletmod.entity.UnderworldHandEntity;
import com.amuletmod.network.FxPacket;
import com.amuletmod.util.ServerScheduler;
import com.amuletmod.util.Sounds;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.Tags.EntityTypes;
import com.amuletmod.neo.PacketDistributor;

public record UnderworldExpressAbility(double radius, int maxVictims, int cooldownTicks) implements ActiveAbility {
   private static final int STAGGER_TICKS = 14;
   private static final int MAX_DROP = 24;
   private static final double ESCAPE_MARGIN = 8.0;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.underworld_express", new Object[]{this.maxVictims, (int)this.radius});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      Vec3 center = player.position();
      List<Mob> monsters = level.getEntitiesOfClass(
         Mob.class,
         player.getBoundingBox().inflate(this.radius),
         mob -> mob instanceof Enemy
            && mob.distanceToSqr(player) <= this.radius * this.radius
            && Frost.canHarm(mob, player)
            && !mob.getType().is(EntityTypes.BOSSES)
            && !UnderworldHandEntity.isSeized(mob)
      );
      if (monsters.isEmpty()) {
         player.displayClientMessage(
            Component.translatable("message.amuletmod.underworld_none", new Object[]{(int)this.radius}).withStyle(ChatFormatting.RED), true
         );
         return false;
      } else {
         float hearts = player.getMaxHealth() + player.getAbsorptionAmount();
         List<Mob> victims = monsters.stream()
            .filter(mob -> mob.getMaxHealth() <= hearts)
            .sorted((a, b) -> Double.compare(a.distanceToSqr(player), b.distanceToSqr(player)))
            .filter(mob -> ground(level, mob) != null)
            .limit(this.maxVictims)
            .toList();
         if (victims.isEmpty()) {
            boolean anyWeakEnough = monsters.stream().anyMatch(mob -> mob.getMaxHealth() <= hearts);
            player.displayClientMessage(
               Component.translatable(
                     anyWeakEnough ? "message.amuletmod.underworld_none" : "message.amuletmod.underworld_too_strong", new Object[]{(int)this.radius}
                  )
                  .withStyle(ChatFormatting.RED),
               true
            );
            return false;
         } else {
            Sounds.play(level, center, SoundEvents.BELL_BLOCK, 2.0F, 0.5F);
            ServerScheduler.schedule(10, () -> Sounds.play(level, center, SoundEvents.BELL_BLOCK, 1.6F, 0.47F));
            Sounds.play(level, center, SoundEvents.BELL_RESONATE, 1.0F, 0.6F);
            Sounds.play(level, center, (SoundEvent)SoundEvents.SOUL_ESCAPE.value(), 1.5F, 0.5F);
            PacketDistributor.sendToPlayersTrackingEntityAndSelf(
               player, new FxPacket(FxPacket.Kind.KNELL, center, (float)this.radius), new CustomPacketPayload[0]
            );
            PacketDistributor.sendToPlayer(player, new FxPacket(FxPacket.Kind.HELL_VIGNETTE, center, 1.0F), new CustomPacketPayload[0]);
            double reachSqr = (this.radius + 8.0) * (this.radius + 8.0);

            for (int i = 0; i < victims.size(); i++) {
               Mob victim = victims.get(i);
               ServerScheduler.schedule(4 + i * 14, () -> {
                  if (victim.isAlive() && victim.level() == level && !UnderworldHandEntity.isSeized(victim) && !(victim.distanceToSqr(center) > reachSqr)) {
                     Double ground = ground(level, victim);
                     if (ground != null) {
                        level.addFreshEntity(new UnderworldHandEntity(level, victim, new Vec3(victim.getX(), ground, victim.getZ()), player));
                     }
                  }
               });
            }

            player.displayClientMessage(
               Component.translatable("message.amuletmod.underworld_express", new Object[]{victims.size()}).withStyle(ChatFormatting.DARK_RED), true
            );
            return true;
         }
      }
   }

   private static Double ground(ServerLevel level, Mob mob) {
      return Frost.groundY(level, mob.getX(), mob.getY(), mob.getZ(), 1, 24);
   }
}
