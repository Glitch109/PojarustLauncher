package com.amuletmod.amulet.ability.lightning;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.entity.StormCloudEntity;
import com.amuletmod.util.Sounds;
import java.util.Comparator;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public record StormCallAbility(double radius, int maxTargets, int strikes, float damage, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.storm_call", new Object[]{this.maxTargets, (int)this.radius, this.strikes});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      double radiusSqr = this.radius * this.radius;
      List<LivingEntity> targets = level.getEntitiesOfClass(
            LivingEntity.class,
            player.getBoundingBox().inflate(this.radius),
            target -> target.distanceToSqr(player) <= radiusSqr && Summons.isFoe(player, target)
         )
         .stream()
         .sorted(Comparator.comparingDouble(target -> target.distanceToSqr(player)))
         .limit(this.maxTargets)
         .toList();
      if (targets.isEmpty()) {
         player.displayClientMessage(
            Component.translatable("message.amuletmod.storm_no_targets", new Object[]{(int)this.radius}).withStyle(ChatFormatting.GRAY), true
         );
         return false;
      } else {
         level.addFreshEntity(new StormCloudEntity(level, player, targets, this.strikes, this.damage));
         Sounds.play(level, player.position(), SoundEvents.EVOKER_PREPARE_SUMMON, 0.6F, 1.4F);
         player.displayClientMessage(Component.translatable("message.amuletmod.storm_call", new Object[]{targets.size()}).withStyle(ChatFormatting.AQUA), true);
         return true;
      }
   }
}
