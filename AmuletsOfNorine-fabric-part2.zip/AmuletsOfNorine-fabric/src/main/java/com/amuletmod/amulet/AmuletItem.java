package com.amuletmod.amulet;

import com.amuletmod.util.StackData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.component.TooltipDisplay;
import org.jetbrains.annotations.Nullable;

public class AmuletItem extends Item {
   private static final String CHARGES_KEY = "Charges";
   private static final int CHARGE_BAR_COLOR = 11558143;
   private final AmuletItem.Definition definition;

   public AmuletItem(Properties properties, AmuletItem.Definition definition) {
      super(properties);
      this.definition = definition;
   }

   public AmuletItem.Definition definition() {
      return this.definition;
   }

   public AmuletItem.Definition definition(ItemStack stack) {
      return this.definition;
   }

   @Nullable
   public AbilityOrigin abilityAt(ItemStack stack, int slot) {
      return this.definition.ability(slot) == null ? null : new AbilityOrigin(this, slot);
   }

   @Nullable
   public AbilityOrigin sneakAbilityAt(ItemStack stack, int slot) {
      return null;
   }

   public List<AbilityOrigin> abilities(ItemStack stack) {
      List<AbilityOrigin> abilities = new ArrayList<>();

      for (int slot = 0; slot < 3; slot++) {
         AbilityOrigin ability = this.abilityAt(stack, slot);
         if (ability != null) {
            abilities.add(ability);
         }

         AbilityOrigin sneak = this.sneakAbilityAt(stack, slot);
         if (sneak != null) {
            abilities.add(sneak);
         }
      }

      return abilities;
   }

   @Nullable
   public AbilityOrigin originOf(ItemStack stack, ActiveAbility ability) {
      for (AbilityOrigin origin : this.abilities(stack)) {
         if (origin.ability() == ability) {
            return origin;
         }
      }

      return null;
   }

   public List<FusionChoice> fusionChoices(ItemStack stack) {
      List<FusionChoice> choices = new ArrayList<>();

      for (int slot = 0; slot < this.definition.abilities().size(); slot++) {
         if (!this.definition.fusionPairs().containsValue(slot)) {
            Integer sneak = this.definition.fusionPairs().get(slot);
            choices.add(new FusionChoice(new AbilityOrigin(this, slot), sneak == null ? null : new AbilityOrigin(this, sneak)));
         }
      }

      return choices;
   }

   public List<EffectOrigin> fusionPassives(ItemStack stack) {
      List<EffectOrigin> passives = new ArrayList<>();

      for (int i = 0; i < this.definition.effects().size(); i++) {
         passives.add(new EffectOrigin(this, i));
      }

      return passives;
   }

   public int charges(ItemStack stack) {
      CompoundTag tag = StackData.get(stack);
      return tag != null && tag.contains("Charges") ? tag.getIntOr("Charges", this.definition(stack).charges()) : this.definition(stack).charges();
   }

   public static void setCharges(ItemStack stack, int charges) {
      StackData.update(stack, tag -> tag.putInt("Charges", charges));
   }

   public void consumeCharge(ServerPlayer player, SlotResult slot) {
      ItemStack stack = slot.stack();
      int left = this.charges(stack) - 1;
      if (left > 0) {
         StackData.update(stack, tag -> tag.putInt("Charges", left));
      } else {
         ItemStack spent = stack.copy();
         AmuletSlots.set(player, ItemStack.EMPTY);
         ServerLevel level = player.level();
         level.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, spent), player.getX(), player.getY() + 1.2, player.getZ(), 24, 0.25, 0.25, 0.25, 0.08);
         level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ITEM_BREAK, SoundSource.PLAYERS, 1.0F, 0.7F);
         level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.AMETHYST_CLUSTER_BREAK, SoundSource.PLAYERS, 1.0F, 0.6F);
         player.displayClientMessage(
            Component.translatable("message.amuletmod.amulet_spent", new Object[]{spent.getHoverName()}).withStyle(ChatFormatting.DARK_PURPLE), false
         );
      }
   }

   @Override
   public boolean isBarVisible(ItemStack stack) {
      return this.definition(stack).charges() > 0;
   }

   @Override
   public int getBarWidth(ItemStack stack) {
      return Math.round(13.0F * this.charges(stack) / Math.max(1, this.definition(stack).charges()));
   }

   @Override
   public int getBarColor(ItemStack stack) {
      return 11558143;
   }

   public void wearerTick(LivingEntity wearer, ItemStack stack) {
      if (!wearer.level().isClientSide()) {
         for (AmuletEffect effect : this.definition(stack).effects()) {
            effect.onWearerTick(wearer, stack);
         }

         for (AbilityOrigin ability : this.abilities(stack)) {
            ability.ability().onWearerTick(wearer, stack);
         }
      }
   }

   public void wearerUnequipped(LivingEntity wearer, ItemStack newStack, ItemStack stack) {
      if (!wearer.level().isClientSide()) {
         for (AmuletEffect effect : this.definition(stack).effects()) {
            effect.onUnequip(wearer, stack);
         }

         if (newStack.getItem() != stack.getItem()) {
            for (AbilityOrigin ability : this.abilities(stack)) {
               ability.ability().onUnequip(wearer, stack);
            }
         }
      }
   }

   @Override
   public void appendHoverText(ItemStack stack, Item.TooltipContext context, TooltipDisplay display, Consumer<Component> out, TooltipFlag flag) {
      List<Component> tooltip = new ArrayList<>();
      AmuletItem.Definition definition = this.definition(stack);

      for (AmuletEffect effect : definition.effects()) {
         tooltip.add(Component.literal(" • ").append(effect.description()).withStyle(ChatFormatting.BLUE));
      }

      for (int slot = 0; slot < 3; slot++) {
         AbilityOrigin ability = this.abilityAt(stack, slot);
         if (ability != null) {
            Component key = Component.keybind(ActiveAbility.keyMappingName(slot));
            abilityLine(tooltip, Component.literal("[").append(key).append("] "), ability.ability(), stack);
            AbilityOrigin sneak = this.sneakAbilityAt(stack, slot);
            if (sneak != null) {
               abilityLine(tooltip, Component.translatable("tooltip.amuletmod.sneak_key", new Object[]{key}), sneak.ability(), stack);
            }
         }
      }

      if (definition.charges() > 0) {
         tooltip.add(
            Component.translatable("tooltip.amuletmod.charges", new Object[]{this.charges(stack), definition.charges()}).withStyle(ChatFormatting.LIGHT_PURPLE)
         );
         tooltip.add(Component.translatable("tooltip.amuletmod.unrepairable").withStyle(new ChatFormatting[]{ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC}));
      }
      tooltip.forEach(out);
   }

   private static void abilityLine(List<Component> tooltip, Component key, ActiveAbility ability, ItemStack stack) {
      tooltip.add(key.copy().withStyle(ChatFormatting.GOLD).append(ability.description().copy().withStyle(ChatFormatting.YELLOW)));
      tooltip.addAll(ability.details(stack));
      if (ability.cooldownTicks() > 0) {
         tooltip.add(Component.translatable("tooltip.amuletmod.cooldown", new Object[]{ability.cooldownTicks() / 20}).withStyle(ChatFormatting.DARK_GRAY));
      }
   }

   public record Definition(AmuletTier tier, List<AmuletEffect> effects, List<ActiveAbility> abilities, int charges, Map<Integer, Integer> fusionPairs) {
      public static AmuletItem.Definition.Builder builder(AmuletTier tier) {
         return new AmuletItem.Definition.Builder(tier);
      }

      @Nullable
      public ActiveAbility ability(int slot) {
         return slot >= 0 && slot < this.abilities.size() ? this.abilities.get(slot) : null;
      }

      public static final class Builder {
         private final AmuletTier tier;
         private final List<AmuletEffect> effects = new ArrayList<>();
         private final List<ActiveAbility> abilities = new ArrayList<>();
         private final Map<Integer, Integer> fusionPairs = new HashMap<>();
         private int charges;

         private Builder(AmuletTier tier) {
            this.tier = tier;
         }

         public AmuletItem.Definition.Builder charges(int charges) {
            this.charges = charges;
            return this;
         }

         public AmuletItem.Definition.Builder effect(AmuletEffect effect) {
            this.effects.add(effect);
            return this;
         }

         public AmuletItem.Definition.Builder ability(ActiveAbility ability) {
            if (this.abilities.size() >= 3) {
               throw new IllegalStateException("An amulet can have at most 3 active abilities");
            } else {
               this.abilities.add(ability);
               return this;
            }
         }

         public AmuletItem.Definition.Builder fusionPair(int slot, int sneakSlot) {
            this.fusionPairs.put(slot, sneakSlot);
            return this;
         }

         public AmuletItem.Definition build() {
            this.fusionPairs.forEach((slot, sneak) -> {
               if (slot.equals(sneak) || slot >= this.abilities.size() || sneak >= this.abilities.size() || this.fusionPairs.containsKey(sneak)) {
                  throw new IllegalStateException("Bad fusion pair " + slot + " -> " + sneak);
               }
            });
            return new AmuletItem.Definition(this.tier, List.copyOf(this.effects), List.copyOf(this.abilities), this.charges, Map.copyOf(this.fusionPairs));
         }
      }
   }
}
