package com.amuletmod.amulet.ability.chrono;

import com.amuletmod.network.RewindEffectPacket;
import com.amuletmod.util.Easing;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.EventPriority;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerChangedDimensionEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedOutEvent;
import com.amuletmod.neo.event.ServerStoppedEvent;
import com.amuletmod.neo.event.ServerTickEvent.Post;
import com.amuletmod.neo.PacketDistributor;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class Rewinds {
   public static final int DURATION_TICKS = 16;
   private static final Map<UUID, Rewinds.Rewind> ACTIVE = new HashMap<>();

   private Rewinds() {
   }

   public static boolean isRewinding(Player player) {
      return ACTIVE.containsKey(player.getUUID());
   }

   public static void start(ServerPlayer player, List<TimeTrail.Snapshot> path, float minHealth) {
      List<TimeTrail.Snapshot> newestFirst = new ArrayList<>(path);
      Collections.reverse(newestFirst);
      ACTIVE.put(player.getUUID(), new Rewinds.Rewind(newestFirst, minHealth));
      player.stopRiding();
      TimeTrail.clear(player);
      ServerLevel level = ((ServerLevel) player.level());
      Vec3 at = player.position();
      Sounds.play(level, at, SoundEvents.ILLUSIONER_MIRROR_MOVE, 1.0F, 0.6F);
      Sounds.play(level, at, SoundEvents.BELL_RESONATE, 0.8F, 1.6F);
      Sounds.play(level, at, SoundEvents.BEACON_POWER_SELECT, 0.8F, 0.6F);
      PacketDistributor.sendToPlayer(player, new RewindEffectPacket(20), new CustomPacketPayload[0]);
   }

   @SubscribeEvent
   public static void onServerTick(Post event) {
      if (!ACTIVE.isEmpty()) {
         MinecraftServer server = event.getServer();
         Iterator<Entry<UUID, Rewinds.Rewind>> it = ACTIVE.entrySet().iterator();

         while (it.hasNext()) {
            Entry<UUID, Rewinds.Rewind> entry = it.next();
            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            if (player != null && player.isAlive()) {
               Rewinds.Rewind rewind = entry.getValue();
               List<TimeTrail.Snapshot> path = rewind.newestFirst;
               rewind.step++;
               float progress = Math.min(1.0F, rewind.step / 16.0F);
               TimeTrail.Snapshot snapshot = path.get(Math.round(Easing.smoothstep(0.0F, 1.0F, progress) * (path.size() - 1)));
               ServerLevel level = ((ServerLevel) player.level());
               Vec3 from = player.position();
               Vec3 to = snapshot.position();
               player.connection.teleport(to.x, to.y, to.z, snapshot.yRot(), snapshot.xRot());
               player.setDeltaMovement(Vec3.ZERO);
               player.resetFallDistance();
               wake(level, from, to);
               if (rewind.step % 4 == 0) {
                  Sounds.play(level, to, SoundEvents.AMETHYST_BLOCK_CHIME, 0.8F, 0.6F + progress * 1.2F);
               }

               if (rewind.step >= 16) {
                  it.remove();
                  arrive(player, path.get(path.size() - 1), rewind.minHealth);
               }
            } else {
               it.remove();
            }
         }
      }
   }

   private static void wake(ServerLevel level, Vec3 from, Vec3 to) {
      double distance = from.distanceTo(to);
      int points = Math.max(1, (int)(distance / 0.5));

      for (int i = 0; i <= points; i++) {
         Vec3 at = from.lerp(to, (double)i / points);
         level.sendParticles(ParticleTypes.REVERSE_PORTAL, at.x, at.y + 1.0, at.z, 2, 0.15, 0.4, 0.15, 0.0);
         level.sendParticles(ParticleTypes.END_ROD, at.x, at.y + 1.0, at.z, 1, 0.1, 0.3, 0.1, 0.0);
      }
   }

   private static void arrive(ServerPlayer player, TimeTrail.Snapshot origin, float minHealth) {
      player.setHealth(Math.max(player.getHealth(), Math.max(origin.health(), minHealth)));
      if (!origin.burning()) {
         player.clearFire();
      }

      player.resetFallDistance();
      player.setDeltaMovement(Vec3.ZERO);
      player.hurtMarked = true;
      ServerLevel level = ((ServerLevel) player.level());
      Vec3 at = player.position();
      level.sendParticles(ParticleTypes.REVERSE_PORTAL, at.x, at.y + 1.0, at.z, 50, 0.4, 0.8, 0.4, 0.1);
      level.sendParticles(ParticleTypes.END_ROD, at.x, at.y + 1.0, at.z, 20, 0.3, 0.6, 0.3, 0.08);
      Sounds.play(level, at, SoundEvents.BELL_BLOCK, 1.0F, 1.5F);
      Sounds.play(level, at, SoundEvents.ENDERMAN_TELEPORT, 0.8F, 0.5F);
      player.displayClientMessage(Component.translatable("message.amuletmod.rewound").withStyle(ChatFormatting.AQUA), true);
   }

   @SubscribeEvent(
      priority = EventPriority.HIGH
   )
   public static void onLivingAttack(LivingIncomingDamageEvent event) {
      if (event.getEntity() instanceof ServerPlayer player && isRewinding(player) && !event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void onChangedDimension(PlayerChangedDimensionEvent event) {
      ACTIVE.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onLogout(PlayerLoggedOutEvent event) {
      ACTIVE.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      ACTIVE.clear();
   }

   private static final class Rewind {
      final List<TimeTrail.Snapshot> newestFirst;
      final float minHealth;
      int step;

      Rewind(List<TimeTrail.Snapshot> newestFirst, float minHealth) {
         this.newestFirst = newestFirst;
         this.minHealth = minHealth;
      }
   }
}
