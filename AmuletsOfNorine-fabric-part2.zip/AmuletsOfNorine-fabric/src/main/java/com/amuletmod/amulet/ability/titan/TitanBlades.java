package com.amuletmod.amulet.ability.titan;

import com.amuletmod.amulet.AbilityCooldowns;
import com.amuletmod.amulet.AbilityOrigin;
import com.amuletmod.amulet.Amulets;
import com.amuletmod.amulet.ability.sovereign.AuraSight;
import com.amuletmod.entity.TitanBladeEntity;
import com.amuletmod.entity.TitanSlashEntity;
import com.amuletmod.registry.ModSounds;
import com.amuletmod.seal.SealPrison;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.minecraft.world.phys.shapes.CollisionContext;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedOutEvent;
import com.amuletmod.neo.event.ServerStoppedEvent;
import com.amuletmod.neo.event.ServerTickEvent.Post;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class TitanBlades {
   public static final double CUT_DISTANCE = 3.5;
   private static final double MIN_CUT_DISTANCE = 1.2;
   private static final double CUT_SPREAD = Math.cos(Math.toRadians(65.0));
   private static final float[] VOLLEY_FAN = new float[]{-12.0F, 12.0F, 0.0F};
   public static final int STORM_PAUSE = 8;
   public static final int STORM_TURN = 10;
   private static final int STORM_BEAT = 4;
   private static final double STORM_SPREAD = 0.5;
   private static final double SEGMENT = 8.0;
   private static final float[][] FORMATION = new float[][]{
      {1.0F, -26.0F},
      {1.0F, 26.0F},
      {2.0F, -19.0F},
      {2.0F, 19.0F},
      {0.0F, -19.0F},
      {0.0F, 19.0F},
      {1.0F, -35.0F},
      {1.0F, 35.0F},
      {2.0F, -28.0F},
      {2.0F, 28.0F},
      {0.0F, -28.0F},
      {0.0F, 28.0F},
      {1.0F, -44.0F},
      {1.0F, 44.0F},
      {2.0F, -37.0F},
      {2.0F, 37.0F},
      {0.0F, -37.0F},
      {0.0F, 37.0F},
      {2.0F, -46.0F},
      {2.0F, 46.0F}
   };
   private static final double[] ROW_DISTANCE = new double[]{2.8, 3.1, 3.5};
   private static final double[] ROW_HEIGHT = new double[]{0.7, 1.65, 2.85};
   private static final Map<UUID, TitanBlades.Combo> COMBOS = new HashMap<>();
   private static final Map<UUID, TitanBlades.Storm> STORMS = new HashMap<>();

   private TitanBlades() {
   }

   public static boolean isSword(ItemStack stack) {
      return !stack.isEmpty() && (stack.getItem() instanceof SwordItem || stack.is(ItemTags.SWORDS));
   }

   public static float multiplier(LivingEntity wielder) {
      return (float)Math.max(1.0, Math.sqrt(AuraSight.power(wielder) / 31.5F));
   }

   public static float attack(ServerPlayer wielder) {
      return (float)wielder.getAttributeValue(Attributes.ATTACK_DAMAGE);
   }

   public static boolean strike(
      ServerPlayer wielder, ItemStack weapon, float attack, float multiplier, LivingEntity victim, DamageSource source, Vec3 push, boolean wear
   ) {
      ServerLevel server = ((ServerLevel) wielder.level());
      float amount = EnchantmentHelper.modifyDamage(server, weapon, victim, source, attack) * multiplier;
      if (!victim.hurt(source, amount)) {
         return false;
      } else {
         float knockback = EnchantmentHelper.modifyKnockback(server, weapon, victim, source, 0.0F);
         double level = Math.sqrt(push.x * push.x + push.z * push.z);
         if (knockback > 0.0F && level > 1.0E-4) {
            victim.knockback(knockback * 0.5, -push.x / level, -push.z / level);
         }

         EnchantmentHelper.doPostAttackEffectsWithItemSource(server, victim, source, weapon);
         ItemStack hitting = wear ? weapon : weapon.copy();
         if (!wear) {
            hitting.setDamageValue(0);
         }

         if (hitting.hurtEnemy(victim, wielder)) {
            hitting.postHurtEnemy(victim, wielder);
         }

         wielder.setLastHurtMob(victim);
         return true;
      }
   }

   public static void click(ServerPlayer player, float yaw, float pitch) {
      if (player.isAlive() && !player.isSpectator() && !SealPrison.isImprisoned(player)) {
         ItemStack weapon = player.getMainHandItem();
         Amulets.Found<TitanBladesAbility> found = Amulets.find(player, TitanBladesAbility.class);
         BladeMode mode = BladeMode.of(player);
         if (isSword(weapon) && found != null && mode != null) {
            switch (mode) {
               case SLASH:
                  slash(player, found, weapon, Mth.clamp(pitch, -90.0F, 90.0F), yaw);
                  break;
               case STORM:
                  summon(player, found, weapon);
            }
         }
      }
   }

   private static void slash(ServerPlayer player, Amulets.Found<TitanBladesAbility> found, ItemStack weapon, float pitch, float yaw) {
      TitanBladesAbility blades = found.ability();
      if (AbilityCooldowns.remainingTicks(player, found.origin(), BladeMode.SLASH.id()) <= 0L) {
         ServerLevel level = ((ServerLevel) player.level());
         long now = level.getGameTime();
         TitanBlades.Combo combo = COMBOS.computeIfAbsent(player.getUUID(), id -> new TitanBlades.Combo());
         if (now - combo.lastCut >= blades.cutTicks()) {
            if (now - combo.lastCut > blades.comboTicks()) {
               combo.cuts = 0;
               combo.slashes.clear();
            }

            int cut = combo.cuts;
            Vec3 eye = player.getEyePosition();
            Vec3 look = Vec3.directionFromRotation(pitch, yaw);
            double distance = cutDistance(player, eye, look);
            TitanSlashEntity slash = new TitanSlashEntity(
               level, player, cut, eye, yaw, pitch, distance, weapon, attack(player), multiplier(player), blades.slashReach(), blades.volleyRange()
            );
            level.addFreshEntity(slash);
            Sounds.play(level, eye.add(look.scale(distance)), (SoundEvent)ModSounds.TITAN_SLASH.get(), 1.0F, 0.95F + player.getRandom().nextFloat() * 0.1F);
            combo.slashes.add(slash.getId());
            combo.cuts = cut + 1;
            combo.lastCut = now;
            combo.comboTicks = blades.comboTicks();
            if (combo.cuts >= 3) {
               for (int i = 0; i < combo.slashes.size(); i++) {
                  if (level.getEntity(combo.slashes.get(i)) instanceof TitanSlashEntity each && each.isAlive()) {
                     int which = each.cut();
                     each.launch(Vec3.directionFromRotation(pitch, yaw + VOLLEY_FAN[which]), 3);
                  }
               }

               combo.cuts = 0;
               combo.slashes.clear();
               AbilityCooldowns.start(player, found.origin(), BladeMode.SLASH.id(), blades.volleyCooldown());
            }

            TitanSync.hud(player, -1);
         }
      }
   }

   private static double cutDistance(ServerPlayer player, Vec3 eye, Vec3 look) {
      Level level = player.level();
      Vec3 far = eye.add(look.scale(3.5));
      BlockHitResult wall = level.clip(new ClipContext(eye, far, Block.COLLIDER, Fluid.NONE, player));
      double most = wall.getType() == Type.MISS ? 3.5 : wall.getLocation().distanceTo(eye) - 0.3;

      for (Entity entity : level.getEntities(
         player, new AABB(eye, far).inflate(1.0), entityx -> entityx instanceof LivingEntity living && TitanFists.canStrike(player, living)
      )) {
         Optional<Vec3> hit = entity.getBoundingBox().inflate(0.3).clip(eye, far);
         if (hit.isPresent()) {
            most = Math.min(most, hit.get().distanceTo(eye) + entity.getBbWidth() * 0.5);
         }
      }

      return Mth.clamp(most, 1.2, 3.5);
   }

   public static List<LivingEntity> cutVictims(ServerPlayer player, Vec3 eye, Vec3 look, double reach) {
      Level level = player.level();
      List<LivingEntity> victims = new ArrayList<>();

      for (LivingEntity victim : level.getEntitiesOfClass(
         LivingEntity.class, new AABB(eye, eye).inflate(reach + 1.0), victimx -> TitanFists.canStrike(player, victimx)
      )) {
         AABB box = victim.getBoundingBox();
         Vec3 nearest = new Vec3(Mth.clamp(eye.x, box.minX, box.maxX), Mth.clamp(eye.y, box.minY, box.maxY), Mth.clamp(eye.z, box.minZ, box.maxZ));
         double distance = nearest.distanceTo(eye);
         if (!(distance > reach)) {
            Vec3 centre = box.getCenter();
            if ((!(distance > 0.6) || !(centre.subtract(eye).normalize().dot(look) < CUT_SPREAD))
               && level.clip(new ClipContext(eye, centre, Block.COLLIDER, Fluid.NONE, player)).getType() == Type.MISS) {
               victims.add(victim);
            }
         }
      }

      return victims;
   }

   public static void endCombo(ServerPlayer player) {
      COMBOS.remove(player.getUUID());
   }

   private static void summon(ServerPlayer player, Amulets.Found<TitanBladesAbility> found, ItemStack weapon) {
      TitanBladesAbility blades = found.ability();
      ServerLevel level = ((ServerLevel) player.level());
      long now = level.getGameTime();
      TitanBlades.Storm storm = STORMS.get(player.getUUID());
      if (storm == null) {
         long remaining = AbilityCooldowns.remainingTicks(player, found.origin(), BladeMode.STORM.id());
         if (remaining > 0L) {
            player.displayClientMessage(
               Component.translatable("message.amuletmod.titan_recharging", new Object[]{BladeMode.STORM.title(), (remaining + 19L) / 20L})
                  .withStyle(ChatFormatting.RED),
               true
            );
            return;
         }

         storm = new TitanBlades.Storm(found.origin(), blades, now);
         STORMS.put(player.getUUID(), storm);
      }

      if (storm.open() && storm.swords.size() < blades.stormBlades() && storm.lastSummon != now) {
         int slot = storm.swords.size();
         Vec3 offset = formation(slot, player.getRandom());
         TitanBladeEntity sword = new TitanBladeEntity(level, player, weapon, offset, attack(player), slot);
         level.addFreshEntity(sword);
         storm.swords.add(sword.getId());
         storm.lastSummon = now;
         Vec3 at = TitanBladeEntity.place(player.position(), player.getYRot(), offset);
         Sounds.play(level, at, (SoundEvent)ModSounds.TITAN_STORM_SUMMON.get(), 1.0F, 0.94F + player.getRandom().nextFloat() * 0.12F + slot * 0.004F);
         if (storm.swords.size() >= blades.stormBlades()) {
            storm.closedAt = now;
         }

         TitanSync.hud(player, -1);
      }
   }

   private static Vec3 formation(int slot, RandomSource random) {
      float[] place = FORMATION[slot % FORMATION.length];
      int row = (int)place[0];
      double angle = Math.toRadians(place[1] + (random.nextDouble() - 0.5) * 4.0);
      double distance = ROW_DISTANCE[row] + 0.6 * (slot / FORMATION.length) + random.nextDouble() * 0.15;
      double height = ROW_HEIGHT[row] + (random.nextDouble() - 0.5) * 0.2;
      return new Vec3(Math.sin(angle) * distance, height, Math.cos(angle) * distance);
   }

   @SubscribeEvent
   public static void onServerTick(Post event) {
      if (!STORMS.isEmpty()) {
         MinecraftServer server = event.getServer();
         Iterator<Entry<UUID, TitanBlades.Storm>> storms = STORMS.entrySet().iterator();

         while (true) {
            TitanBlades.Storm storm;
            ServerPlayer player;
            long now;
            while (true) {
               if (!storms.hasNext()) {
                  return;
               }

               Entry<UUID, TitanBlades.Storm> entry = storms.next();
               storm = entry.getValue();
               player = server.getPlayerList().getPlayer(entry.getKey());
               if (player != null && player.isAlive()) {
                  now = ((ServerLevel) player.level()).getGameTime();
                  if (!storm.open()) {
                     break;
                  }

                  if (now - storm.start >= storm.blades.stormWindow()) {
                     storm.closedAt = now;
                     TitanSync.hud(player, -1);
                     break;
                  }
               } else {
                  storms.remove();
               }
            }

            if (now == storm.turnAt()) {
               turn(player, storm);
            }

            if (now >= storm.fireAt()) {
               int due = (int)Math.min((long)storm.swords.size(), now - storm.fireAt() + 1L);

               while (storm.fired < due) {
                  fire(player, storm, storm.swords.get(storm.fired++));
               }

               if (storm.fired >= storm.swords.size()) {
                  storms.remove();
                  AbilityCooldowns.start(player, storm.origin, BladeMode.STORM.id(), storm.blades.stormCooldown());
                  TitanSync.hud(player, -1);
               }
            }
         }
      }
   }

   private static void turn(ServerPlayer player, TitanBlades.Storm storm) {
      ServerLevel level = ((ServerLevel) player.level());

      for (int id : storm.swords) {
         if (level.getEntity(id) instanceof TitanBladeEntity sword && sword.isAlive()) {
            sword.turn();
         }
      }

      Sounds.play(level, player.position(), SoundEvents.ILLUSIONER_PREPARE_MIRROR, 1.0F, 1.5F);
      Sounds.play(level, player.position(), (SoundEvent)SoundEvents.TRIDENT_RIPTIDE_1.value(), 0.6F, 1.6F);
   }

   private static void fire(ServerPlayer player, TitanBlades.Storm storm, int id) {
      ServerLevel level = ((ServerLevel) player.level());
      if (level.getEntity(id) instanceof TitanBladeEntity sword && sword.isAlive() && !sword.fired()) {
         double range = storm.blades.stormRange();
         Vec3 eye = player.getEyePosition();
         Vec3 look = player.getLookAngle();
         RandomSource random = player.getRandom();
         TitanBlades.Trace sight = trace(level, eye, look, range);
         LivingEntity marked = first(level, player, eye, sight.end());
         Vec3 aim;
         if (marked != null) {
            AABB box = marked.getBoundingBox();
            aim = new Vec3(
               Mth.lerp(0.25 + random.nextDouble() * 0.5, box.minX, box.maxX),
               Mth.lerp(0.25 + random.nextDouble() * 0.5, box.minY, box.maxY),
               Mth.lerp(0.25 + random.nextDouble() * 0.5, box.minZ, box.maxZ)
            );
         } else {
            double spread = 0.5 * Math.min(1.0, sight.end().distanceTo(eye) / 8.0);
            aim = sight.end()
               .add((random.nextDouble() - 0.5) * 2.0 * spread, (random.nextDouble() - 0.5) * 2.0 * spread, (random.nextDouble() - 0.5) * 2.0 * spread);
         }

         Vec3 from = sword.position();
         Vec3 heading = aim.subtract(from);
         heading = heading.lengthSqr() < 1.0 ? look : heading.normalize();
         TitanBlades.Trace flight = trace(level, from, heading, range + from.distanceTo(eye));
         DamageSource source = ModDamage.source(level, ModDamage.TITAN_BLADE, sword, player);
         boolean hit = false;

         for (LivingEntity victim : along(level, player, from, flight.end())) {
            hit |= strike(player, sword.weapon(), sword.attack(), 1.0F, victim, source, heading, false);
         }

         sword.fire(from, flight.end(), flight.face());
         Sounds.play(level, from, (SoundEvent)SoundEvents.TRIDENT_THROW.value(), 1.0F, 1.5F + random.nextFloat() * 0.4F);
         if (flight.face() != null) {
            Sounds.play(level, flight.end(), SoundEvents.TRIDENT_HIT_GROUND, 1.2F, 0.7F + random.nextFloat() * 0.2F);
         }

         if (hit) {
            Sounds.play(level, marked != null ? marked.position() : flight.end(), SoundEvents.PLAYER_ATTACK_STRONG, 0.8F, 1.3F);
         }
      }
   }

   private static TitanBlades.Trace trace(Level level, Vec3 from, Vec3 heading, double range) {
      Vec3 to = from.add(heading.scale(range));
      ClipContext context = new ClipContext(from, to, Block.COLLIDER, Fluid.NONE, CollisionContext.empty());
      BlockHitResult hit = (BlockHitResult)BlockGetter.traverseBlocks(from, to, context, (ctx, pos) -> {
         if (!level.isLoaded(pos)) {
            return BlockHitResult.miss(nearestOnLine(from, heading, pos), Direction.UP, pos);
         } else {
            BlockState state = level.getBlockState(pos);
            return level.clipWithInteractionOverride(from, to, pos, ctx.getBlockShape(state, level, pos), state);
         }
      }, ctx -> null);
      return hit == null ? new TitanBlades.Trace(to, null) : new TitanBlades.Trace(hit.getLocation(), hit.getType() == Type.BLOCK ? hit.getDirection() : null);
   }

   private static Vec3 nearestOnLine(Vec3 from, Vec3 heading, BlockPos pos) {
      return from.add(heading.scale(Math.max(0.0, Vec3.atCenterOf(pos).subtract(from).dot(heading))));
   }

   private static Set<LivingEntity> along(Level level, ServerPlayer player, Vec3 from, Vec3 to) {
      Set<LivingEntity> victims = new LinkedHashSet<>();
      double length = from.distanceTo(to);
      Vec3 step = length < 1.0E-4 ? Vec3.ZERO : to.subtract(from).scale(1.0 / length);

      for (double done = 0.0; done < length; done += 8.0) {
         Vec3 a = from.add(step.scale(done));
         Vec3 b = from.add(step.scale(Math.min(length, done + 8.0)));

         for (Entity entity : level.getEntities(
            player, new AABB(a, b).inflate(1.0), entityx -> entityx instanceof LivingEntity living && TitanFists.canStrike(player, living)
         )) {
            if (entity.getBoundingBox().inflate(0.3).clip(from, to).isPresent()) {
               victims.add((LivingEntity)entity);
            }
         }
      }

      return victims;
   }

   @Nullable
   private static LivingEntity first(Level level, ServerPlayer player, Vec3 from, Vec3 to) {
      LivingEntity best = null;
      double bestDistance = Double.MAX_VALUE;

      for (LivingEntity victim : along(level, player, from, to)) {
         Optional<Vec3> hit = victim.getBoundingBox().inflate(0.3).clip(from, to);
         double distance = hit.<Double>map(at -> at.distanceToSqr(from)).orElse(Double.MAX_VALUE);
         if (distance < bestDistance) {
            bestDistance = distance;
            best = victim;
         }
      }

      return best;
   }

   public static TitanBlades.Status status(ServerPlayer player) {
      long now = player.level().getGameTime();
      int cuts = 0;
      int comboLeft = 0;
      int swords = 0;
      int windowLeft = 0;
      TitanBlades.Combo combo = COMBOS.get(player.getUUID());
      if (combo != null && combo.cuts > 0 && combo.lastCut + combo.comboTicks > now) {
         cuts = combo.cuts;
         comboLeft = (int)(combo.lastCut + combo.comboTicks - now);
      }

      TitanBlades.Storm storm = STORMS.get(player.getUUID());
      if (storm != null) {
         swords = storm.swords.size() - storm.fired;
         if (storm.open()) {
            windowLeft = (int)Math.max(0L, storm.start + storm.blades.stormWindow() - now);
         }
      }

      return new TitanBlades.Status(cuts, comboLeft, swords, windowLeft);
   }

   @SubscribeEvent
   public static void onLogout(PlayerLoggedOutEvent event) {
      COMBOS.remove(event.getEntity().getUUID());
      STORMS.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      COMBOS.clear();
      STORMS.clear();
   }

   private static final class Combo {
      long lastCut = -4611686018427387904L;
      int cuts;
      int comboTicks;
      final List<Integer> slashes = new ArrayList<>();
   }

   public record Status(int cuts, int comboLeft, int swords, int windowLeft) {
   }

   private static final class Storm {
      final AbilityOrigin origin;
      final TitanBladesAbility blades;
      final long start;
      final List<Integer> swords = new ArrayList<>();
      long lastSummon = Long.MIN_VALUE;
      long closedAt = -1L;
      int fired;

      Storm(AbilityOrigin origin, TitanBladesAbility blades, long start) {
         this.origin = origin;
         this.blades = blades;
         this.start = start;
      }

      boolean open() {
         return this.closedAt < 0L;
      }

      long turnAt() {
         return this.closedAt + 8L;
      }

      long fireAt() {
         return this.turnAt() + 10L + 4L;
      }
   }

   private record Trace(Vec3 end, @Nullable Direction face) {
   }
}
