package com.amuletmod.amulet.ability.seal;

import com.amuletmod.amulet.ability.sovereign.AuraSight;
import net.minecraft.util.Mth;

public final class SealRank {
   private static final int RANK_A = 4;
   private static final int RANK_S = 5;

   private SealRank() {
   }

   public static int sealTicks(float power, int shortest, int longest) {
      float from = AuraSight.rankThreshold(4);
      float to = AuraSight.rankThreshold(5);
      return Math.round(Mth.lerp(Mth.clamp((power - from) / (to - from), 0.0F, 1.0F), shortest, longest));
   }

   public static float containReach(float power, float most) {
      return most * Math.min(AuraSight.rank(power) + 1, 5) / 5.0F;
   }
}
