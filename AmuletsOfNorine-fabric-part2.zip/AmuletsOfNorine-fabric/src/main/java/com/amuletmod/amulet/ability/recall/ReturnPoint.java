package com.amuletmod.amulet.ability.recall;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public record ReturnPoint(ResourceKey<Level> dimension, Vec3 position) {
   public BlockPos markerPos() {
      return BlockPos.containing(this.position);
   }

   public CompoundTag save() {
      CompoundTag tag = new CompoundTag();
      tag.putString("dim", this.dimension.location().toString());
      tag.putDouble("x", this.position.x);
      tag.putDouble("y", this.position.y);
      tag.putDouble("z", this.position.z);
      return tag;
   }

   @Nullable
   public static ReturnPoint load(CompoundTag tag) {
      Identifier dim = Identifier.tryParse(tag.getString("dim"));
      return dim == null
         ? null
         : new ReturnPoint(ResourceKey.create(Registries.DIMENSION, dim), new Vec3(tag.getDouble("x"), tag.getDouble("y"), tag.getDouble("z")));
   }

   public void write(FriendlyByteBuf buf) {
      buf.writeResourceKey(this.dimension);
      buf.writeDouble(this.position.x);
      buf.writeDouble(this.position.y);
      buf.writeDouble(this.position.z);
   }

   public static ReturnPoint read(FriendlyByteBuf buf) {
      return new ReturnPoint(buf.readResourceKey(Registries.DIMENSION), new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()));
   }
}
