package com.amuletmod.amulet;

import net.minecraft.world.item.ItemStack;

/** One equipped amulet. Replaces Curios' SlotResult (the mod only ever used the single "necklace" slot). */
public record SlotResult(ItemStack stack, int index) {
}
