package com.amuletmod.amulet.ability.librarian;

public enum PageLook {
   PLAIN(0.95F, 0.92F, 0.82F),
   ENCHANTED(0.68F, 0.42F, 1.0F),
   FROSTY(0.55F, 0.85F, 1.0F),
   FIERY(1.0F, 0.5F, 0.12F),
   WINDY(0.78F, 0.95F, 0.92F),
   STORMY(0.62F, 0.72F, 1.0F),
   CURSED(0.95F, 0.12F, 0.2F);

   private final float r;
   private final float g;
   private final float b;

   private PageLook(float r, float g, float b) {
      this.r = r;
      this.g = g;
      this.b = b;
   }

   public float r() {
      return this.r;
   }

   public float g() {
      return this.g;
   }

   public float b() {
      return this.b;
   }

   public boolean glints() {
      return this != PLAIN;
   }

   public static PageLook byId(int id) {
      PageLook[] looks = values();
      return id >= 0 && id < looks.length ? looks[id] : PLAIN;
   }
}
