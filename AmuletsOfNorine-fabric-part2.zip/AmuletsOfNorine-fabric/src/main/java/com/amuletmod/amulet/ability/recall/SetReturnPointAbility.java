package com.amuletmod.amulet.ability.recall;

import com.amuletmod.amulet.ActiveAbility;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;

public record SetReturnPointAbility(int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.set_return_point");
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ReturnPoint point = new ReturnPoint(player.level().dimension(), player.position());
      ReturnPoints.set(player, point);
      player.playNotifySound(SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.4F);
      player.displayClientMessage(
         Component.translatable(
               "message.amuletmod.return_point_set", new Object[]{point.markerPos().getX(), point.markerPos().getY(), point.markerPos().getZ()}
            )
            .withStyle(ChatFormatting.GREEN),
         true
      );
      return true;
   }
}
