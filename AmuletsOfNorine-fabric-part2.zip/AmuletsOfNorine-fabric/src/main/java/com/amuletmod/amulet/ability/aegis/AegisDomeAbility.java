package com.amuletmod.amulet.ability.aegis;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.entity.BarrierEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public record AegisDomeAbility(float radius, int durationTicks, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.aegis_dome", new Object[]{(int)this.radius, this.durationTicks / 20});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      level.addFreshEntity(BarrierEntity.dome(level, player, this.radius, this.durationTicks));
      player.displayClientMessage(Component.translatable("message.amuletmod.aegis_dome").withStyle(ChatFormatting.GOLD), true);
      return true;
   }
}
