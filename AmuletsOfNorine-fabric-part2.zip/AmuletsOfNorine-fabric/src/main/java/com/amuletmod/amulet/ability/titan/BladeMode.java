package com.amuletmod.amulet.ability.titan;

import com.amuletmod.util.PlayerData;
import java.util.Locale;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Nullable;

public enum BladeMode {
   SLASH,
   STORM;

   private static final String KEY = "TitanBlades";
   private static final BladeMode[] VALUES = values();

   @Nullable
   public static BladeMode after(@Nullable BladeMode mode) {
      if (mode == null) {
         return VALUES[0];
      } else {
         return mode.ordinal() + 1 < VALUES.length ? VALUES[mode.ordinal() + 1] : null;
      }
   }

   public static int code(@Nullable BladeMode mode) {
      return mode == null ? -1 : mode.ordinal();
   }

   @Nullable
   public static BladeMode fromCode(int code) {
      return code >= 0 && code < VALUES.length ? VALUES[code] : null;
   }

   public String id() {
      return this.name().toLowerCase(Locale.ROOT);
   }

   public Component title() {
      return Component.translatable("tooltip.amuletmod.titan_blade_mode." + this.id());
   }

   @Nullable
   public static BladeMode of(Player player) {
      return fromCode(PlayerData.get(player).getByteOr("TitanBlades", (byte)0) - 1);
   }

   public static void set(Player player, @Nullable BladeMode mode) {
      PlayerData.get(player).putByte("TitanBlades", (byte)(code(mode) + 1));
   }
}
