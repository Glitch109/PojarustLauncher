package com.amuletmod.amulet.ability.seal;

import com.amuletmod.seal.SealBarrierBlock;
import java.util.Arrays;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.Direction.AxisDirection;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import org.jetbrains.annotations.Nullable;

public final class Openings {
   public static final int MAX_CELLS = 1024;
   public static final int MAX_REACH = 32;
   private static final int SPAN = 65;

   private Openings() {
   }

   public static Axis uAxis(Axis normal) {
      return normal == Axis.X ? Axis.Z : Axis.X;
   }

   public static Axis vAxis(Axis normal) {
      return normal == Axis.Y ? Axis.Z : Axis.Y;
   }

   public static BlockPos cell(BlockPos anchor, Axis normal, int u, int v) {
      return anchor.relative(uAxis(normal), u).relative(vAxis(normal), v);
   }

   @Nullable
   public static Openings.Opening find(ServerLevel level, ServerPlayer player, double range) {
      Vec3 eye = player.getEyePosition();
      Vec3 look = player.getViewVector(1.0F);
      HitResult hit = level.clip(new ClipContext(eye, eye.add(look.scale(range)), Block.COLLIDER, Fluid.NONE, player));
      double reach = hit.getType() == Type.MISS ? range : hit.getLocation().distanceTo(eye);
      Axis axis = Direction.getNearest(look.x, look.y, look.z).getAxis();
      double along = look.get(axis);
      if (Math.abs(along) < 1.0E-4) {
         return null;
      } else {
         int step = along > 0.0 ? 1 : -1;
         Direction facing = Direction.fromAxisAndDirection(axis, step > 0 ? AxisDirection.NEGATIVE : AxisDirection.POSITIVE);
         AABB body = player.getBoundingBox();
         int slice = step > 0 ? Mth.floor(body.max(axis) - 1.0E-4) + 1 : Mth.floor(body.min(axis) + 1.0E-4) - 1;
         boolean[] seen = new boolean[4225];
         MutableBlockPos pos = new MutableBlockPos();

         while (true) {
            double enters = ((step > 0 ? slice : slice + 1) - eye.get(axis)) / along;
            if (enters >= reach) {
               return null;
            }

            double middle = (slice + 0.5 - eye.get(axis)) / along;
            Vec3 at = eye.add(look.scale(Mth.clamp(middle, Math.max(0.0, enters) + 0.001, reach - 0.001)));
            BlockPos anchor = withAxis(BlockPos.containing(at), axis, slice);
            Openings.Opening opening = fill(level, anchor, axis, facing, seen, pos);
            if (opening != null) {
               return opening;
            }

            slice += step;
         }
      }
   }

   private static BlockPos withAxis(BlockPos pos, Axis axis, int value) {
      return switch (axis) {
         case X -> new BlockPos(value, pos.getY(), pos.getZ());
         case Y -> new BlockPos(pos.getX(), value, pos.getZ());
         case Z -> new BlockPos(pos.getX(), pos.getY(), value);
         default -> throw new MatchException(null, null);
      };
   }

   @Nullable
   private static Boolean open(ServerLevel level, BlockPos pos) {
      if (!level.isOutsideBuildHeight(pos) && level.isLoaded(pos)) {
         BlockState state = level.getBlockState(pos);
         return !state.is(SealBarrierBlock.block()) && state.getCollisionShape(level, pos).isEmpty();
      } else {
         return null;
      }
   }

   @Nullable
   private static Openings.Opening fill(ServerLevel level, BlockPos anchor, Axis axis, Direction facing, boolean[] seen, MutableBlockPos pos) {
      if (open(level, anchor) != Boolean.TRUE) {
         return null;
      } else {
         Axis uAxis = uAxis(axis);
         Axis vAxis = vAxis(axis);
         int ax = anchor.getX();
         int ay = anchor.getY();
         int az = anchor.getZ();
         int ux = uAxis == Axis.X ? 1 : 0;
         int uy = uAxis == Axis.Y ? 1 : 0;
         int uz = uAxis == Axis.Z ? 1 : 0;
         int vx = vAxis == Axis.X ? 1 : 0;
         int vy = vAxis == Axis.Y ? 1 : 0;
         int vz = vAxis == Axis.Z ? 1 : 0;
         int[][] ways = new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

         for (int[] way : ways) {
            int reached;
            for (reached = 1; reached <= 33; reached++) {
               int u = way[0] * reached;
               int v = way[1] * reached;
               Boolean open = open(level, pos.set(ax + ux * u + vx * v, ay + uy * u + vy * v, az + uz * u + vz * v));
               if (open == null) {
                  return null;
               }

               if (!open) {
                  break;
               }
            }

            if (reached > 33) {
               return null;
            }
         }

         Arrays.fill(seen, false);
         int[] us = new int[1024];
         int[] vs = new int[1024];
         int[] depths = new int[1024];
         int count = 1;
         seen[2112] = true;

         for (int next = 0; next < count; next++) {
            for (int[] way : ways) {
               int uxx = us[next] + way[0];
               int vxx = vs[next] + way[1];
               if (Math.abs(uxx) > 32 || Math.abs(vxx) > 32) {
                  return null;
               }

               int index = (vxx + 32) * 65 + uxx + 32;
               if (!seen[index]) {
                  seen[index] = true;
                  Boolean openx = open(level, pos.set(ax + ux * uxx + vx * vxx, ay + uy * uxx + vy * vxx, az + uz * uxx + vz * vxx));
                  if (openx == null) {
                     return null;
                  }

                  if (openx) {
                     if (count >= 1024) {
                        return null;
                     }

                     us[count] = uxx;
                     vs[count] = vxx;
                     depths[count] = depths[next] + 1;
                     count++;
                  }
               }
            }
         }

         return new Openings.Opening(facing, anchor, Arrays.copyOf(us, count), Arrays.copyOf(vs, count), Arrays.copyOf(depths, count));
      }
   }

   public record Opening(Direction facing, BlockPos anchor, int[] us, int[] vs, int[] depths) {
      public int size() {
         return this.us.length;
      }
   }
}
