package com.amuletmod.amulet.ability;

import com.amuletmod.amulet.ability.sovereign.ShadowArmy;
import com.amuletmod.util.Damage;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TraceableEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.EventPriority;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.LivingDeathEvent;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedOutEvent;
import com.amuletmod.neo.event.ServerStoppedEvent;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class Summons {
   public static final int FEUD_TICKS = 600;
   private static final int GRUDGE_TICKS = 200;
   private static final int SIGHT_CHECKS = 6;
   private static final Map<UUID, Summons.Scan> SCANS = new HashMap<>();
   private static final Map<UUID, Map<UUID, Long>> FEUDS = new ConcurrentHashMap<>();

   private Summons() {
   }

   public static boolean isSummonedBy(Entity entity, LivingEntity owner) {
      return entity instanceof Summons.Owned owned && owner.getUUID().equals(owned.summonerId()) || owner.getUUID().equals(ShadowArmy.ownerOf(entity));
   }

   public static boolean isFoe(LivingEntity owner, LivingEntity candidate) {
      if (candidate != owner
         && candidate.isAlive()
         && !candidate.isSpectator()
         && candidate.isAttackable()
         && !(candidate instanceof ArmorStand)
         && !isSummonedBy(candidate, owner)
         && !candidate.isAlliedTo(owner)
         && !owner.isAlliedTo(candidate)) {
         UUID side = sideOf(candidate);
         if (side != null) {
            Player rival = owner.level().getPlayerByUUID(side);
            return owner instanceof Player ownerPlayer
               && rival != null
               && rival != ownerPlayer
               && !rival.isCreative()
               && ownerPlayer.canHarmPlayer(rival)
               && feuding(ownerPlayer, rival);
         } else {
            return !(candidate instanceof Enemy) && !(candidate instanceof Mob mob && mob.getTarget() == owner)
               ? candidate == owner.getLastHurtByMob() || candidate == owner.getLastHurtMob() && owner.tickCount - owner.getLastHurtMobTimestamp() < 200
               : true;
         }
      } else {
         return false;
      }
   }

   @Nullable
   public static UUID sideOf(@Nullable Entity entity) {
      for (int depth = 0; entity != null && depth < 4; depth++) {
         if (entity instanceof Player) {
            return entity.getUUID();
         }

         if (entity instanceof Summons.Owned owned && owned.summonerId() != null) {
            return owned.summonerId();
         }

         UUID master = ShadowArmy.ownerOf(entity);
         if (master != null) {
            return master;
         }

         entity = entity instanceof TraceableEntity traceable ? traceable.getOwner() : null;
      }

      return null;
   }

   @Nullable
   private static UUID sideOf(DamageSource source) {
      UUID side = sideOf(source.getEntity());
      return side != null ? side : sideOf(source.getDirectEntity());
   }

   public static boolean feuding(Player player, Player rival) {
      Map<UUID, Long> feuds = FEUDS.get(player.getUUID());
      Long endsAt = feuds == null ? null : feuds.get(rival.getUUID());
      return endsAt != null && player.level().getGameTime() < endsAt;
   }

   private static void feud(UUID player, UUID rival, long endsAt) {
      Map<UUID, Long> feuds = FEUDS.computeIfAbsent(player, id -> new ConcurrentHashMap<>());
      feuds.values().removeIf(end -> end < endsAt - 600L);
      feuds.put(rival, endsAt);
   }

   private static void endFeuds(UUID player) {
      FEUDS.remove(player);
      FEUDS.values().forEach(feuds -> feuds.remove(player));
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public static void onLivingHurt(LivingIncomingDamageEvent event) {
      LivingEntity victim = event.getEntity();
      if (!victim.level().isClientSide() && !(event.getAmount() <= 0.0F) && Damage.landing(event)) {
         UUID defender = sideOf(victim);
         if (defender != null) {
            UUID attacker = sideOf(event.getSource());
            if (attacker != null && !attacker.equals(defender)) {
               long endsAt = victim.level().getGameTime() + 600L;
               feud(defender, attacker, endsAt);
               feud(attacker, defender, endsAt);
            }
         }
      }
   }

   @SubscribeEvent
   public static void onLivingDeath(LivingDeathEvent event) {
      if (event.getEntity() instanceof Player player && !player.level().isClientSide()) {
         endFeuds(player.getUUID());
      }
   }

   @SubscribeEvent
   public static void onLogout(PlayerLoggedOutEvent event) {
      endFeuds(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      FEUDS.clear();
   }

   @Nullable
   public static LivingEntity findTarget(LivingEntity owner, Vec3 around, double radius, @Nullable LivingEntity viewer) {
      double radiusSqr = radius * radius;

      for (LivingEntity grudge : new LivingEntity[]{owner.getLastHurtByMob(), owner.getLastHurtMob()}) {
         if (grudge != null
            && grudge.level() == owner.level()
            && grudge.distanceToSqr(around) <= radiusSqr
            && isFoe(owner, grudge)
            && (viewer == null || viewer.hasLineOfSight(grudge))) {
            return grudge;
         }
      }

      List<LivingEntity> candidates = owner.level()
         .getEntitiesOfClass(
            LivingEntity.class, new AABB(around, around).inflate(radius), candidate -> candidate.distanceToSqr(around) <= radiusSqr && isFoe(owner, candidate)
         );
      candidates.sort(Comparator.comparingDouble(candidate -> candidate.distanceToSqr(around)));

      for (int i = 0; i < candidates.size() && i < 6; i++) {
         if (viewer == null || viewer.hasLineOfSight((Entity)candidates.get(i))) {
            return candidates.get(i);
         }
      }

      return null;
   }

   public static List<LivingEntity> foesAround(LivingEntity owner, double radius) {
      long tick = owner.level().getGameTime();
      Summons.Scan scan = SCANS.get(owner.getUUID());
      if (scan != null && scan.tick() == tick && scan.radius() == radius) {
         return scan.foes();
      } else {
         double radiusSqr = radius * radius;
         List<LivingEntity> foes = owner.level()
            .getEntitiesOfClass(
               LivingEntity.class, owner.getBoundingBox().inflate(radius), candidate -> candidate.distanceToSqr(owner) <= radiusSqr && isFoe(owner, candidate)
            );
         foes.sort(Comparator.comparingDouble(candidate -> candidate.distanceToSqr(owner)));
         if (SCANS.size() > 64) {
            SCANS.clear();
         }

         SCANS.put(owner.getUUID(), new Summons.Scan(tick, radius, foes));
         return foes;
      }
   }

   public interface Owned {
      @Nullable
      UUID summonerId();
   }

   private record Scan(long tick, double radius, List<LivingEntity> foes) {
   }
}
