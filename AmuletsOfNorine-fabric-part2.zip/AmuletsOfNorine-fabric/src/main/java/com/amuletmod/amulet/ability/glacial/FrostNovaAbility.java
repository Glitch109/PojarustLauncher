package com.amuletmod.amulet.ability.glacial;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.util.ServerScheduler;
import com.amuletmod.util.Sounds;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public record FrostNovaAbility(float radius, float damage, int cooldownTicks) implements ActiveAbility {
   private static final int RINGS = 3;
   private static final int RING_DELAY_TICKS = 4;
   private static final double SPIKE_SPACING = 1.35;
   private static final int CHILL_TICKS = 80;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.frost_nova", new Object[]{(int)this.radius});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      Vec3 center = player.position();
      RandomSource random = level.random;
      Sounds.play(level, center, SoundEvents.GLASS_BREAK, 1.0F, 0.5F);
      Sounds.play(level, center, SoundEvents.POWDER_SNOW_BREAK, 1.0F, 0.5F);
      Sounds.play(level, center, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0F, 0.5F);
      Sounds.play(level, center, SoundEvents.PLAYER_HURT_FREEZE, 1.0F, 0.6F);

      for (int i = 0; i < 72; i++) {
         double angle = i * (float) (Math.PI * 2) / 72.0;
         level.sendParticles(ParticleTypes.SNOWFLAKE, center.x, center.y + 0.3, center.z, 0, Math.cos(angle), 0.04, Math.sin(angle), 0.55);
      }

      level.sendParticles(ParticleTypes.CLOUD, center.x, center.y + 0.2, center.z, 20, 0.8, 0.1, 0.8, 0.05);
      double reach = this.radius + 1.0;

      for (LivingEntity target : level.getEntitiesOfClass(
         LivingEntity.class,
         player.getBoundingBox().inflate(reach),
         targetx -> targetx instanceof Enemy && targetx.isAlive() && targetx.distanceToSqr(player) < reach * reach
      )) {
         Frost.chill(target, 80);
      }

      Set<UUID> hits = new HashSet<>();

      for (int ring = 0; ring < 3; ring++) {
         int index = ring;
         float ringRadius = this.radius * (ring + 1) / 3.0F;
         ServerScheduler.schedule(ring * 4, () -> this.raiseRing(level, player, center, index, ringRadius, hits, random));
      }

      player.displayClientMessage(Component.translatable("message.amuletmod.frost_nova").withStyle(ChatFormatting.AQUA), true);
      return true;
   }

   private void raiseRing(ServerLevel level, ServerPlayer owner, Vec3 center, int ring, float ringRadius, Set<UUID> hits, RandomSource random) {
      int count = Math.max(6, (int)Math.round((float) (Math.PI * 2) * ringRadius / 1.35));
      double offset = random.nextDouble() * (float) (Math.PI * 2);

      for (int i = 0; i < count; i++) {
         double angle = offset + i * (float) (Math.PI * 2) / count;
         double x = center.x + Math.cos(angle) * ringRadius;
         double z = center.z + Math.sin(angle) * ringRadius;
         Double y = Frost.groundY(level, x, center.y, z, 2, 3);
         if (y != null) {
            float outward = (float)(angle * 180.0F / (float)Math.PI) - 90.0F;
            Frost.erupt(
               level,
               new Vec3(x, y, z),
               1.5F + ring * 0.55F + random.nextFloat() * 0.5F,
               outward + (random.nextFloat() - 0.5F) * 16.0F,
               18.0F + random.nextFloat() * 12.0F,
               50 + ring * 6 + random.nextInt(12),
               owner,
               this.damage,
               hits
            );
         }
      }

      Sounds.play(level, center, SoundEvents.AMETHYST_CLUSTER_BREAK, 1.0F, 0.6F + ring * 0.15F);
      Sounds.play(level, center, SoundEvents.GLASS_BREAK, 0.8F, 0.6F + ring * 0.1F);
   }
}
