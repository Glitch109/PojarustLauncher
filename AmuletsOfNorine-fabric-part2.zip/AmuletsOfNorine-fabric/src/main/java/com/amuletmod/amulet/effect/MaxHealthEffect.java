package com.amuletmod.amulet.effect;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.AmuletEffect;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.item.ItemStack;

public record MaxHealthEffect(float share) implements AmuletEffect {
   private static final Identifier MODIFIER = AmuletMod.id("amulet_max_health");

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.effect.max_health", new Object[]{Math.round(this.share * 100.0F)});
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      AttributeInstance health = wearer.getAttribute(Attributes.MAX_HEALTH);
      if (health != null && health.getModifier(MODIFIER) == null) {
         health.addTransientModifier(new AttributeModifier(MODIFIER, this.share, Operation.ADD_MULTIPLIED_TOTAL));
      }
   }

   @Override
   public void onUnequip(LivingEntity wearer, ItemStack amulet) {
      AttributeInstance health = wearer.getAttribute(Attributes.MAX_HEALTH);
      if (health != null && health.getModifier(MODIFIER) != null) {
         health.removeModifier(MODIFIER);
         if (wearer.getHealth() > wearer.getMaxHealth()) {
            wearer.setHealth(wearer.getMaxHealth());
         }
      }
   }
}
