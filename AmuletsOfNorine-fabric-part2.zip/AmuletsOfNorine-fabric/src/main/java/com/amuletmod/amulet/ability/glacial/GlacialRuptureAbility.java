package com.amuletmod.amulet.ability.glacial;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.util.ServerScheduler;
import com.amuletmod.util.Sounds;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public record GlacialRuptureAbility(float length, float damage, int cooldownTicks) implements ActiveAbility {
   private static final double SPACING = 1.1;
   private static final int SPIKES_PER_TICK = 2;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.glacial_rupture", new Object[]{(int)this.length});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      float yaw = player.getYRot();
      Vec3 forward = Vec3.directionFromRotation(0.0F, yaw);
      Vec3 start = player.position().add(forward.scale(1.8));
      Double ground = Frost.groundY(level, start.x, player.getY(), start.z, 2, 3);
      if (ground == null) {
         player.displayClientMessage(Component.translatable("message.amuletmod.glacial_no_ground").withStyle(ChatFormatting.RED), true);
         return false;
      } else {
         Vec3 at = player.position();
         Sounds.play(level, at, SoundEvents.POWDER_SNOW_BREAK, 1.0F, 0.6F);
         Sounds.play(level, at, SoundEvents.PLAYER_HURT_FREEZE, 0.8F, 0.7F);
         Sounds.play(level, at, SoundEvents.EVOKER_CAST_SPELL, 0.7F, 1.5F);
         new GlacialRuptureAbility.Wave(level, player, yaw, forward, start, ground, (int)(this.length / 1.1), this.damage).run();
         return true;
      }
   }

   private static final class Wave implements Runnable {
      private final ServerLevel level;
      private final ServerPlayer owner;
      private final float yaw;
      private final Vec3 forward;
      private final Vec3 side;
      private final Vec3 start;
      private final int count;
      private final float damage;
      private final Set<UUID> hits = new HashSet<>();
      private final RandomSource random;
      private double groundY;
      private int step;

      Wave(ServerLevel level, ServerPlayer owner, float yaw, Vec3 forward, Vec3 start, double groundY, int count, float damage) {
         this.level = level;
         this.owner = owner;
         this.yaw = yaw;
         this.forward = forward;
         this.side = new Vec3(-forward.z, 0.0, forward.x);
         this.start = start;
         this.groundY = groundY;
         this.count = count;
         this.damage = damage;
         this.random = level.random;
      }

      @Override
      public void run() {
         int n = 0;

         while (n < 2 && this.step < this.count) {
            float progress = (float)this.step / this.count;
            Vec3 at = this.start.add(this.forward.scale(this.step * 1.1)).add(this.side.scale((this.random.nextDouble() - 0.5) * 0.7));
            Double y = Frost.groundY(this.level, at.x, this.groundY, at.z, 2, 3);
            if (y == null) {
               return;
            }

            this.groundY = y;
            float height = 1.4F + 1.8F * progress + this.random.nextFloat() * 0.5F;
            Frost.erupt(
               this.level,
               new Vec3(at.x, y, at.z),
               height,
               this.yaw + (this.random.nextFloat() - 0.5F) * 40.0F,
               10.0F + this.random.nextFloat() * 12.0F,
               40 + this.random.nextInt(14),
               this.owner,
               this.damage,
               this.hits
            );
            if (this.step % 2 == 1) {
               for (int s = -1; s <= 1; s += 2) {
                  Vec3 flank = at.add(this.side.scale(s * (0.9 + this.random.nextDouble() * 0.4)));
                  Double flankY = Frost.groundY(this.level, flank.x, this.groundY, flank.z, 2, 3);
                  if (flankY != null) {
                     Frost.erupt(
                        this.level,
                        new Vec3(flank.x, flankY, flank.z),
                        height * (0.4F + this.random.nextFloat() * 0.2F),
                        this.yaw + s * 90.0F + (this.random.nextFloat() - 0.5F) * 30.0F,
                        30.0F + this.random.nextFloat() * 12.0F,
                        34 + this.random.nextInt(10),
                        this.owner,
                        this.damage,
                        this.hits
                     );
                  }
               }
            }

            Sounds.play(this.level, at, SoundEvents.AMETHYST_CLUSTER_BREAK, 0.9F, 0.5F + progress * 0.3F + this.random.nextFloat() * 0.1F);
            if (this.step % 2 == 0) {
               Sounds.play(this.level, at, SoundEvents.GLASS_BREAK, 0.5F, 0.5F + this.random.nextFloat() * 0.1F);
            }

            n++;
            this.step++;
         }

         if (this.step < this.count) {
            ServerScheduler.schedule(1, this);
         }
      }
   }
}
