package com.amuletmod.amulet.ability.sovereign;

import net.minecraft.server.level.ServerLevel;
import com.amuletmod.amulet.Amulets;
import com.amuletmod.network.AuraSyncPacket;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.Holder;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedOutEvent;
import com.amuletmod.neo.event.ServerStoppedEvent;
import com.amuletmod.neo.event.ServerTickEvent.Post;
import com.amuletmod.neo.PacketDistributor;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class AuraSight {
   private static final int SYNC_TICKS = 10;
   private static final int MAX_AURAS = 96;
   private static final float[] RANK_THRESHOLDS = new float[]{25.0F, 50.0F, 90.0F, 150.0F, 250.0F, 400.0F, 650.0F};
   private static final String[] RANK_NAMES = new String[]{"E", "D", "C", "B", "A", "S", "SS", "SSS"};
   private static final Map<UUID, Double> VIEWERS = new HashMap<>();
   private static int clock;

   private AuraSight() {
   }

   public static boolean toggle(ServerPlayer player, double range) {
      if (VIEWERS.remove(player.getUUID()) != null) {
         PacketDistributor.sendToPlayer(player, AuraSyncPacket.off(), new CustomPacketPayload[0]);
         return false;
      } else {
         VIEWERS.put(player.getUUID(), range);
         sync(player, range);
         return true;
      }
   }

   public static int rank(float power) {
      int rank = 0;

      while (rank < RANK_THRESHOLDS.length && power >= RANK_THRESHOLDS[rank]) {
         rank++;
      }

      return rank;
   }

   public static String rankName(int rank) {
      return RANK_NAMES[Math.max(0, Math.min(rank, RANK_NAMES.length - 1))];
   }

   public static float rankThreshold(int rank) {
      return rank <= 0 ? 0.0F : RANK_THRESHOLDS[Math.min(rank, RANK_THRESHOLDS.length) - 1];
   }

   public static float power(LivingEntity entity) {
      float vitality = entity.getMaxHealth() * 0.6F + entity.getHealth() * 0.4F + entity.getAbsorptionAmount();
      AttributeInstance toughness = entity.getAttribute(Attributes.ARMOR_TOUGHNESS);
      float armour = entity.getArmorValue() + (toughness == null ? 0.0F : (float)toughness.getValue() * 0.5F);
      AttributeInstance attack = entity.getAttribute(Attributes.ATTACK_DAMAGE);
      float might = attack == null ? 0.0F : (float)attack.getValue() * 1.5F;
      float blessings = 0.0F;

      for (MobEffectInstance effect : entity.getActiveEffects()) {
         if (((MobEffect)effect.getEffect().value()).isBeneficial()) {
            blessings += (effect.getAmplifier() + 1) * 4.0F;
         }
      }

      float enchantments = 0.0F;

      for (EquipmentSlot slot : EquipmentSlot.values()) {
         ItemStack stack = entity.getItemBySlot(slot);
         if (!stack.isEmpty()) {
            for (Entry<Holder<Enchantment>> enchantment : stack.getEnchantments().entrySet()) {
               enchantments += enchantment.getIntValue() * 0.8F;
            }
         }
      }

      float amulets = entity instanceof Player ? Amulets.equipped(entity).size() * 6.0F : 0.0F;
      return vitality + armour + might + blessings + enchantments + amulets;
   }

   private static void sync(ServerPlayer player, double range) {
      double rangeSqr = range * range;
      List<LivingEntity> seen = ((ServerLevel) player.level())
         .getEntitiesOfClass(
            LivingEntity.class,
            player.getBoundingBox().inflate(range),
            entity -> entity.isAlive() && !entity.isSpectator() && entity.distanceToSqr(player) <= rangeSqr
         );
      seen.sort(Comparator.comparingDouble(entity -> entity.distanceToSqr(player)));
      int count = Math.min(seen.size(), 96);
      int[] ids = new int[count];
      float[] powers = new float[count];

      for (int i = 0; i < count; i++) {
         ids[i] = seen.get(i).getId();
         powers[i] = power(seen.get(i));
      }

      PacketDistributor.sendToPlayer(player, new AuraSyncPacket(true, ids, powers), new CustomPacketPayload[0]);
   }

   private static boolean hasSight(ServerPlayer player) {
      return Amulets.<AuraSightAbility>find(player, AuraSightAbility.class) != null;
   }

   @SubscribeEvent
   public static void onServerTick(Post event) {
      if (!VIEWERS.isEmpty() && ++clock % 10 == 0) {
         MinecraftServer server = event.getServer();

         for (java.util.Map.Entry<UUID, Double> viewer : List.copyOf(VIEWERS.entrySet())) {
            ServerPlayer player = server.getPlayerList().getPlayer(viewer.getKey());
            if (player == null) {
               VIEWERS.remove(viewer.getKey());
            } else if (!hasSight(player)) {
               toggle(player, viewer.getValue());
            } else {
               sync(player, viewer.getValue());
            }
         }
      }
   }

   @SubscribeEvent
   public static void onLogout(PlayerLoggedOutEvent event) {
      VIEWERS.remove(event.getEntity().getUUID());
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      VIEWERS.clear();
   }
}
