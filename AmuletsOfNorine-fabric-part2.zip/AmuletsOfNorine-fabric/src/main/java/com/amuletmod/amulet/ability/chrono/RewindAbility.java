package com.amuletmod.amulet.ability.chrono;

import com.amuletmod.amulet.ActiveAbility;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public record RewindAbility(int rewindTicks, int cooldownTicks) implements ActiveAbility {
   private static final int MIN_TRAIL_TICKS = 20;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.rewind", new Object[]{this.rewindTicks / 20});
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (wearer instanceof ServerPlayer player && !Rewinds.isRewinding(player)) {
         TimeTrail.record(player);
      }
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      if (Rewinds.isRewinding(player)) {
         return false;
      } else {
         List<TimeTrail.Snapshot> path = TimeTrail.path(player, this.rewindTicks);
         if (path.size() < 20) {
            player.displayClientMessage(Component.translatable("message.amuletmod.rewind_no_trail").withStyle(ChatFormatting.RED), true);
            return false;
         } else {
            Rewinds.start(player, path, 0.0F);
            return true;
         }
      }
   }
}
