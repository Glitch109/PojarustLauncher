package com.amuletmod.amulet.ability.meteor;

import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.amulet.ability.glacial.Frost;
import com.amuletmod.amulet.effect.BlastWardEffect;
import com.amuletmod.network.FxPacket;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Explosion.BlockInteraction;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.event.EventHooks;
import com.amuletmod.neo.PacketDistributor;
import org.jetbrains.annotations.Nullable;

public final class MeteorBlast {
   private static final double KNOCKBACK = 0.9;
   private static final double FX_RANGE = 96.0;

   private MeteorBlast() {
   }

   public static void explode(ServerLevel level, Entity meteor, @Nullable Entity owner, Vec3 at, @Nullable Entity struck, float damage, double radius) {
      DamageSource source = ModDamage.source(level, ModDamage.METEOR, meteor, owner);
      Explosion explosion = new Explosion(
         level,
         meteor,
         source,
         null,
         at.x,
         at.y,
         at.z,
         (float)radius,
         false,
         BlockInteraction.KEEP,
         ParticleTypes.EXPLOSION,
         ParticleTypes.EXPLOSION_EMITTER,
         SoundEvents.GENERIC_EXPLODE
      );
      List<Entity> caught = level.getEntities(
         meteor,
         new AABB(at, at).inflate(radius + 1.0),
         entityx -> entityx instanceof LivingEntity livingx
            && Frost.canHarm(livingx, owner)
            && !(owner instanceof LivingEntity summoner && Summons.isSummonedBy(livingx, summoner))
      );
      EventHooks.onExplosionDetonate(level, explosion, caught, radius * 2.0);
      float bestHit = 0.0F;

      for (Entity entity : caught) {
         LivingEntity living = (LivingEntity)entity;
         boolean direct = living == struck;
         double distance = direct ? 0.0 : distanceTo(at, living.getBoundingBox());
         if (!(distance >= radius)) {
            double closeness = 1.0 - distance / radius;
            float falloff = (float)(closeness * closeness * (direct ? 1.0 : Explosion.getSeenPercent(at, living)));
            if (!(falloff < 0.05F) && living.hurt(source, damage * falloff)) {
               Vec3 away = living.position().add(0.0, living.getBbHeight() * 0.5, 0.0).subtract(at);
               away = away.lengthSqr() < 1.0E-4 ? new Vec3(0.0, 1.0, 0.0) : away.normalize();
               double push = BlastWardEffect.dampenKnockback(
                  living, 0.9 * falloff * (1.0 - living.getAttributeValue(Attributes.EXPLOSION_KNOCKBACK_RESISTANCE))
               );
               living.setDeltaMovement(living.getDeltaMovement().add(away.x * push, Math.max(away.y, 0.3) * push * 0.6, away.z * push));
               living.hurtMarked = true;
               if (living instanceof ServerPlayer victim) {
                  PacketDistributor.sendToPlayer(victim, new FxPacket(FxPacket.Kind.METEOR_IMPACT, at, falloff), new CustomPacketPayload[0]);
               }

               bestHit = Math.max(bestHit, falloff);
            }
         }
      }

      PacketDistributor.sendToPlayersNear(
         level, null, at.x, at.y, at.z, 96.0, new FxPacket(FxPacket.Kind.METEOR_BLAST, at, (float)radius), new CustomPacketPayload[0]
      );
      if (bestHit > 0.3F && owner instanceof ServerPlayer caster) {
         PacketDistributor.sendToPlayer(caster, new FxPacket(FxPacket.Kind.METEOR_HIT, at, bestHit), new CustomPacketPayload[0]);
      }

      float pitch = 0.85F + level.random.nextFloat() * 0.25F;
      Sounds.play(level, at, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 2.0F, pitch);
      Sounds.play(level, at, SoundEvents.FIRECHARGE_USE, 1.4F, 0.55F);
      Sounds.play(level, at, SoundEvents.BASALT_BREAK, 1.6F, 0.5F);
      Sounds.play(level, at, SoundEvents.LAVA_POP, 1.2F, 0.7F + level.random.nextFloat() * 0.3F);
   }

   private static double distanceTo(Vec3 point, AABB box) {
      double x = Mth.clamp(point.x, box.minX, box.maxX);
      double y = Mth.clamp(point.y, box.minY, box.maxY);
      double z = Mth.clamp(point.z, box.minZ, box.maxZ);
      return point.distanceTo(new Vec3(x, y, z));
   }
}
