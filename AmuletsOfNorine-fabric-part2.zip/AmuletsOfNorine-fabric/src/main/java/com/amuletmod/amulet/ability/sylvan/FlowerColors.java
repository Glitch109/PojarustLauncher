package com.amuletmod.amulet.ability.sylvan;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.Mth;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

public final class FlowerColors {
   private static final Map<Item, Integer> KNOWN = new HashMap<>();
   private static final Map<Item, Integer> CACHE = new HashMap<>();

   private FlowerColors() {
   }

   public static int of(Item flower, Level level) {
      Integer known = KNOWN.get(flower);
      return known != null ? known : CACHE.computeIfAbsent(flower, item -> lookUp(item, level));
   }

   private static int lookUp(Item flower, Level level) {
      ItemStack stack = new ItemStack(flower);

      for (RecipeHolder<CraftingRecipe> holder : level.getRecipeManager().getAllRecipesFor(RecipeType.CRAFTING)) {
         CraftingRecipe recipe = (CraftingRecipe)holder.value();
         List<Ingredient> ingredients = recipe.getIngredients().stream().filter(ingredient -> !ingredient.isEmpty()).toList();
         if (ingredients.size() == 1 && ingredients.get(0).test(stack) && recipe.getResultItem(level.registryAccess()).getItem() instanceof DyeItem dye) {
            return dye.getDyeColor().getTextColor();
         }
      }

      float hue = (BuiltInRegistries.ITEM.getKey(flower).hashCode() & 65535) / 65536.0F;
      return Mth.hsvToRgb(hue, 0.5F, 1.0F);
   }

   static {
      KNOWN.put(Items.DANDELION, 16767034);
      KNOWN.put(Items.POPPY, 15217196);
      KNOWN.put(Items.BLUE_ORCHID, 3129584);
      KNOWN.put(Items.ALLIUM, 12610800);
      KNOWN.put(Items.AZURE_BLUET, 15266047);
      KNOWN.put(Items.RED_TULIP, 15743536);
      KNOWN.put(Items.ORANGE_TULIP, 16747562);
      KNOWN.put(Items.WHITE_TULIP, 16054004);
      KNOWN.put(Items.PINK_TULIP, 16754384);
      KNOWN.put(Items.OXEYE_DAISY, 16776168);
      KNOWN.put(Items.CORNFLOWER, 5008624);
      KNOWN.put(Items.LILY_OF_THE_VALLEY, 16187378);
      KNOWN.put(Items.WITHER_ROSE, 4857674);
      KNOWN.put(Items.TORCHFLOWER, 16747040);
      KNOWN.put(Items.SUNFLOWER, 16763936);
      KNOWN.put(Items.LILAC, 14192872);
      KNOWN.put(Items.ROSE_BUSH, 14166576);
      KNOWN.put(Items.PEONY, 15902424);
      KNOWN.put(Items.PITCHER_PLANT, 7250160);
      KNOWN.put(Items.PINK_PETALS, 16754892);
      KNOWN.put(Items.CHERRY_LEAVES, 16757970);
      KNOWN.put(Items.FLOWERING_AZALEA, 14708952);
      KNOWN.put(Items.FLOWERING_AZALEA_LEAVES, 14708952);
      KNOWN.put(Items.SPORE_BLOSSOM, 15757488);
      KNOWN.put(Items.MANGROVE_PROPAGULE, 9227088);
   }
}
