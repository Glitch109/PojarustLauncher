package com.amuletmod.amulet;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.Identifier;
import org.jetbrains.annotations.Nullable;

public record EffectOrigin(AmuletItem amulet, int index) {
   public AmuletEffect effect() {
      return this.amulet.definition().effects().get(this.index);
   }

   public CompoundTag save() {
      CompoundTag tag = new CompoundTag();
      tag.putString("Amulet", String.valueOf(BuiltInRegistries.ITEM.getKey(this.amulet)));
      tag.putInt("Index", this.index);
      return tag;
   }

   @Nullable
   public static EffectOrigin load(CompoundTag tag) {
      Identifier id = Identifier.tryParse(tag.getString("Amulet"));
      int index = tag.getInt("Index");
      return id != null && BuiltInRegistries.ITEM.get(id) instanceof AmuletItem amulet && index >= 0 && index < amulet.definition().effects().size()
         ? new EffectOrigin(amulet, index)
         : null;
   }
}
