package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AbilityCooldowns;
import com.amuletmod.amulet.AmuletEffect;
import com.amuletmod.amulet.ability.chrono.Rewinds;
import com.amuletmod.amulet.ability.chrono.TimeTrail;
import com.amuletmod.registry.ModCriteria;
import com.amuletmod.util.PlayerData;
import com.amuletmod.util.Sounds;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import com.amuletmod.neo.event.LivingDeathEvent;

public record BorrowedTimeEffect(int rewindTicks, int cooldownTicks) implements AmuletEffect {
   private static final String READY_KEY = "borrowed_time_ready_at";
   private static final float MIN_HEALTH = 6.0F;
   private static final int MIN_TRAIL_TICKS = 10;

   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.effect.borrowed_time", new Object[]{this.rewindTicks / 20, this.cooldownTicks / 1200});
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (wearer instanceof ServerPlayer player && !Rewinds.isRewinding(player)) {
         TimeTrail.record(player);
      }
   }

   @Override
   public void onWearerDeath(LivingDeathEvent event, LivingEntity wearer, ItemStack amulet) {
      if (!event.isCanceled()
         && wearer instanceof ServerPlayer player
         && !Rewinds.isRewinding(player)
         && !event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
         CompoundTag data = PlayerData.get(player);
         long now = player.server.overworld().getGameTime();
         boolean recharges = !AbilityCooldowns.disabled(player);
         if (!recharges || data.getLong("borrowed_time_ready_at") <= now) {
            List<TimeTrail.Snapshot> path = TimeTrail.path(player, this.rewindTicks);
            if (path.size() >= 10) {
               event.setCanceled(true);
               player.setHealth(1.0F);
               if (recharges) {
                  data.putLong("borrowed_time_ready_at", now + this.cooldownTicks);
               }

               Rewinds.start(player, path, 6.0F);
               Sounds.play(player.level(), player.position(), SoundEvents.TOTEM_USE, 0.6F, 1.4F);
               player.displayClientMessage(Component.translatable("message.amuletmod.borrowed_time").withStyle(ChatFormatting.GOLD), true);
               ModCriteria.FEAT.trigger(player, "borrowed_time");
            }
         }
      }
   }
}
