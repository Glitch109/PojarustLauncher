package com.amuletmod.amulet.ability.seal;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.ability.sovereign.AuraSight;
import com.amuletmod.entity.SealEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public record SealOpeningAbility(double range, int shortestTicks, int longestTicks, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.seal", new Object[]{(int)this.range, this.shortestTicks / 20, this.longestTicks / 20});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      ServerLevel level = ((ServerLevel) player.level());
      Openings.Opening opening = Openings.find(level, player, this.range);
      if (opening == null) {
         player.displayClientMessage(Component.translatable("message.amuletmod.seal_no_opening").withStyle(ChatFormatting.RED), true);
         return false;
      } else {
         int ticks = SealRank.sealTicks(AuraSight.power(player), this.shortestTicks, this.longestTicks);
         level.addFreshEntity(new SealEntity(level, player, opening, ticks));
         Vec3 eye = player.getEyePosition();
         Vec3 to = Vec3.atCenterOf(opening.anchor());
         int steps = (int)Math.ceil(eye.distanceTo(to) / 0.6);

         for (int i = 1; i <= steps; i++) {
            Vec3 at = eye.lerp(to, (double)i / steps);
            level.sendParticles(ParticleTypes.END_ROD, at.x, at.y, at.z, 1, 0.02, 0.02, 0.02, 0.0);
         }

         player.displayClientMessage(
            Component.translatable("message.amuletmod.seal_cast", new Object[]{opening.size(), ticks / 20}).withStyle(ChatFormatting.LIGHT_PURPLE), true
         );
         return true;
      }
   }
}
