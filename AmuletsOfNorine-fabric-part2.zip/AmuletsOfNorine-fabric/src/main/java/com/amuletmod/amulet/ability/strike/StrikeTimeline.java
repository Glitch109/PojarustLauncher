package com.amuletmod.amulet.ability.strike;

import com.amuletmod.util.Easing;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public final class StrikeTimeline {
   public static final int CIRCLES_START = 10;
   public static final int CIRCLE_STAGGER = 20;
   public static final int CIRCLE_OPEN_TICKS = 34;
   public static final int RIFT_SEAM = 82;
   public static final int RIFT_TEAR = 94;
   public static final int RIFT_OPEN_TICKS = 16;
   public static final int BEAM_START = 104;
   public static final int BEAM_REACH_TICKS = 8;
   public static final int PULL_START = 240;
   public static final int IMPACT = 304;
   public static final int BEAM_FADE_START = 350;
   public static final int BEAM_FADE_TICKS = 18;
   public static final int RIFT_CLOSE = 362;
   public static final int RIFT_CLOSE_TICKS = 16;
   public static final int CIRCLES_CLOSE_START = 372;
   public static final int CIRCLE_CLOSE_TICKS = 18;
   public static final int SHATTER_SPREAD_TICKS = 14;
   public static final int SHATTER_MEND_START = 358;
   public static final int SHATTER_MEND_TICKS = 48;
   public static final int END = 420;
   public static final int AFTERMATH_END = 700;
   public static final double SOURCE_DISTANCE = 130.0;
   public static final float ELEVATION_DEGREES = 60.0F;
   public static final double SKY_CLEARANCE = 130.0 * Math.sin(Math.toRadians(60.0));
   public static final float[] CIRCLE_RADII = new float[]{30.0F, 20.0F, 12.5F};
   public static final float[] CIRCLE_OFFSETS = new float[]{-1.5F, 11.0F, 20.0F};

   private StrikeTimeline() {
   }

   public static Vec3 lineOfFire(float casterYaw, boolean fromRight) {
      Vec3 facing = Vec3.directionFromRotation(0.0F, casterYaw);
      Vec3 side = new Vec3(-facing.z, 0.0, facing.x).scale(fromRight ? -1.0 : 1.0);
      float elevation = (float) (Math.PI / 3);
      return side.scale(Mth.cos(elevation)).add(0.0, Mth.sin(elevation), 0.0).normalize();
   }

   public static Vec3 source(Vec3 target, Vec3 lineOfFire, double ground) {
      Vec3 open = target.add(lineOfFire.scale(130.0));
      return new Vec3(open.x, Math.max(open.y, ground + SKY_CLEARANCE), open.z);
   }

   public static float circleOpen(int index, float age) {
      float opening = (age - 10.0F - index * 20) / 34.0F;
      if (opening <= 0.0F) {
         return 0.0F;
      } else {
         float open = Easing.cubicBezier(0.7F, 0.0F, 0.25F, 1.25F, opening);
         float closing = (age - 372.0F - (CIRCLE_RADII.length - 1 - index) * 6) / 18.0F;
         if (closing > 0.0F) {
            open *= 1.0F - Easing.cubicBezier(0.6F, 0.0F, 0.9F, 0.6F, closing);
         }

         return Math.max(0.0F, open);
      }
   }

   public static float beamReach(float age) {
      return Mth.clamp((age - 104.0F) / 8.0F, 0.0F, 1.0F);
   }

   public static float charge(float age) {
      return Mth.clamp((age - 104.0F) / 200.0F, 0.0F, 1.0F);
   }
}
