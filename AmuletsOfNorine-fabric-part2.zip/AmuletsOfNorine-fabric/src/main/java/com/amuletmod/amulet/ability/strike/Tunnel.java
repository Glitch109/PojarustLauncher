package com.amuletmod.amulet.ability.strike;

import com.amuletmod.entity.BarrierEntity;
import java.util.List;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.NeoForge;
import com.amuletmod.neo.event.BlockEvent.BreakEvent;
import org.jetbrains.annotations.Nullable;

final class Tunnel {
   static final double RADIUS = 3.0;
   private static final double SEARED = 4.0;
   private static final int SPAN = Mth.ceil(Math.sqrt(17.0)) + 1;
   private static final int BUDGET = 4000;
   private static final int FLAGS = 18;
   private final ServerLevel level;
   private final Vec3 from;
   private final Vec3 down;
   private final double length;
   private final RandomSource random;
   private final MutableBlockPos cursor = new MutableBlockPos();
   private int bored;
   private int changes;

   Tunnel(ServerLevel level, Vec3 from, Vec3 to) {
      this.level = level;
      this.from = from;
      Vec3 path = to.subtract(from);
      this.length = path.length();
      this.down = path.normalize();
      this.random = level.random;
   }

   boolean isDone() {
      return this.bored >= this.length;
   }

   void bore(float reach, @Nullable ServerPlayer owner, List<BarrierEntity> domes) {
      this.changes = 0;
      double until = reach * this.length;

      while (this.bored < until && this.changes < 4000) {
         this.slice(this.bored++, owner, domes);
      }
   }

   private void slice(int step, @Nullable ServerPlayer owner, List<BarrierEntity> domes) {
      Vec3 point = this.from.add(this.down.scale(step));
      if (!(point.y - SPAN >= this.level.getMaxBuildHeight()) && !(point.y + SPAN < this.level.getMinBuildHeight())) {
         int px = Mth.floor(point.x);
         int py = Mth.floor(point.y);
         int pz = Mth.floor(point.z);

         for (int x = px - SPAN; x <= px + SPAN; x++) {
            for (int y = py - SPAN; y <= py + SPAN; y++) {
               for (int z = pz - SPAN; z <= pz + SPAN; z++) {
                  double dx = x + 0.5 - this.from.x;
                  double dy = y + 0.5 - this.from.y;
                  double dz = z + 0.5 - this.from.z;
                  double along = dx * this.down.x + dy * this.down.y + dz * this.down.z;
                  if (!(along < step) && !(along >= step + 1) && !(along > this.length)) {
                     double ox = dx - this.down.x * along;
                     double oy = dy - this.down.y * along;
                     double oz = dz - this.down.z * along;
                     double off = ox * ox + oy * oy + oz * oz;
                     if (!(off > 16.0) && this.level.isInWorldBounds(this.cursor.set(x, y, z))) {
                        if (off <= 9.0) {
                           this.burn(owner, domes);
                        } else {
                           this.sear(owner, domes);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void burn(@Nullable ServerPlayer owner, List<BarrierEntity> domes) {
      BlockState state = this.level.getBlockState(this.cursor);
      if (!state.isAir() && !this.sheltered(domes) && this.mayChange(state, owner)) {
         this.level.setBlock(this.cursor, Blocks.AIR.defaultBlockState(), 18);
         this.changes++;
      }
   }

   private void sear(@Nullable ServerPlayer owner, List<BarrierEntity> domes) {
      if (!(this.random.nextFloat() > 0.45F)) {
         BlockState state = this.level.getBlockState(this.cursor);
         if (!state.isAir()
            && state.isCollisionShapeFullBlock(this.level, this.cursor)
            && !state.hasBlockEntity()
            && !state.is(BlockTags.LOGS)
            && !state.is(BlockTags.LEAVES)
            && !this.sheltered(domes)
            && this.mayChange(state, owner)) {
            float n = this.random.nextFloat();
            Block seared = n < 0.35F ? Blocks.MAGMA_BLOCK : (n < 0.6F ? Blocks.BLACKSTONE : (n < 0.8F ? Blocks.BASALT : Blocks.OBSIDIAN));
            this.level.setBlock(this.cursor, seared.defaultBlockState(), 18);
            this.changes++;
         }
      }
   }

   private boolean sheltered(List<BarrierEntity> domes) {
      Vec3 middle = Vec3.atCenterOf(this.cursor);

      for (BarrierEntity dome : domes) {
         if (dome.contains(middle)) {
            return true;
         }
      }

      return false;
   }

   private boolean mayChange(BlockState state, @Nullable ServerPlayer owner) {
      return state.getDestroySpeed(this.level, this.cursor) < 0.0F
         ? false
         : owner == null || !((BreakEvent)NeoForge.EVENT_BUS.post(new BreakEvent(this.level, this.cursor.immutable(), state, owner))).isCanceled();
   }
}
