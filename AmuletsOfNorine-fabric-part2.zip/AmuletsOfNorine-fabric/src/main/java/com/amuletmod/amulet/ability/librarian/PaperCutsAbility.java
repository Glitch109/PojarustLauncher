package com.amuletmod.amulet.ability.librarian;

import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.entity.PageEntity;
import com.amuletmod.util.Sounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public record PaperCutsAbility(double range, float damage, int cooldownTicks) implements ActiveAbility {
   @Override
   public Component description() {
      return Component.translatable("tooltip.amuletmod.ability.paper_cuts", new Object[]{3, 18});
   }

   @Override
   public boolean activate(ServerPlayer player, ItemStack amulet) {
      InteractionHand hand = Tome.heldTome(player);
      if (hand == null) {
         player.displayClientMessage(Component.translatable("message.amuletmod.paper_cuts_no_book").withStyle(ChatFormatting.RED), true);
         return false;
      } else {
         ItemStack book = player.getItemInHand(hand);
         PageLoad load = PageLoad.of(book);
         int volley = Math.min(load.volley(), Tome.pagesLeft(book));
         ServerLevel level = ((ServerLevel) player.level());

         for (int slot = 0; slot < volley; slot++) {
            level.addFreshEntity(new PageEntity(level, player, slot, volley, load, this.damage, this.range));
         }

         Tome.tear(player, hand, volley);
         player.swing(hand, true);
         Vec3 at = player.getEyePosition().add(player.getLookAngle().scale(0.6)).add(0.0, -0.3, 0.0);
         level.sendParticles(PageEntity.scraps(), at.x, at.y, at.z, 5, 0.15, 0.15, 0.15, 0.05);
         if (load.isEnchanted()) {
            level.sendParticles(ParticleTypes.ENCHANT, at.x, at.y, at.z, 12, 0.3, 0.3, 0.3, 0.6);
         }

         Sounds.play(level, at, SoundEvents.BOOK_PAGE_TURN, 1.2F, 0.8F);
         Sounds.play(level, at, SoundEvents.BOOK_PAGE_TURN, 1.0F, 1.3F);
         if (load.isEnchanted()) {
            Sounds.play(level, at, SoundEvents.ENCHANTMENT_TABLE_USE, 0.7F, 1.5F);
         }

         return true;
      }
   }
}
