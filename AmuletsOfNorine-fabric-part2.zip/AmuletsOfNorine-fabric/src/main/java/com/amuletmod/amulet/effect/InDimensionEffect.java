package com.amuletmod.amulet.effect;

import com.amuletmod.amulet.AmuletEffect;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import com.amuletmod.neo.event.ProjectileImpactEvent;
import com.amuletmod.neo.event.EnderManAngerEvent;
import com.amuletmod.neo.event.LivingDeathEvent;
import com.amuletmod.neo.event.LivingFallEvent;
import com.amuletmod.neo.event.LivingHealEvent;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;

public record InDimensionEffect(ResourceKey<Level> dimension, AmuletEffect inner) implements AmuletEffect {
   @Override
   public Component description() {
      Identifier id = this.dimension.location();
      return Component.translatable(
         "tooltip.amuletmod.effect.in_dimension",
         new Object[]{Component.translatable("tooltip.amuletmod.dimension." + id.getNamespace() + "." + id.getPath()), this.inner.description()}
      );
   }

   private boolean isIn(LivingEntity wearer) {
      return wearer.level().dimension() == this.dimension;
   }

   @Override
   public void onWearerTick(LivingEntity wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onWearerTick(wearer, amulet);
      } else {
         this.inner.onUnequip(wearer, amulet);
      }
   }

   @Override
   public void onUnequip(LivingEntity wearer, ItemStack amulet) {
      this.inner.onUnequip(wearer, amulet);
   }

   @Override
   public void onWearerFall(LivingFallEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onWearerFall(event, wearer, amulet);
      }
   }

   @Override
   public void onWearerHurt(LivingIncomingDamageEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onWearerHurt(event, wearer, amulet);
      }
   }

   @Override
   public void onWearerHitByProjectile(ProjectileImpactEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onWearerHitByProjectile(event, wearer, amulet);
      }
   }

   @Override
   public void onWearerDeath(LivingDeathEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onWearerDeath(event, wearer, amulet);
      }
   }

   @Override
   public void onWearerHeal(LivingHealEvent event, LivingEntity wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onWearerHeal(event, wearer, amulet);
      }
   }

   @Override
   public void onEndermanStare(EnderManAngerEvent event, Player wearer, ItemStack amulet) {
      if (this.isIn(wearer)) {
         this.inner.onEndermanStare(event, wearer, amulet);
      }
   }

   @Override
   public boolean isDrawback() {
      return this.inner.isDrawback();
   }
}
