package com.amuletmod.amulet;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public interface ActiveAbility {
   int MAX_SLOTS = 3;

   static String keyMappingName(int slot) {
      return "key.amuletmod.ability_" + (slot + 1);
   }

   Component description();

   default List<Component> details(ItemStack amulet) {
      return List.of();
   }

   int cooldownTicks();

   boolean activate(ServerPlayer var1, ItemStack var2);

   default boolean consumesCharge() {
      return false;
   }

   default void onWearerTick(LivingEntity wearer, ItemStack amulet) {
   }

   default void onUnequip(LivingEntity wearer, ItemStack amulet) {
   }
}
