package com.amuletmod;

import com.amuletmod.amulet.AmuletSlots;
import com.amuletmod.neo.Handlers;
import com.amuletmod.neo.hooks.FabricHooks;
import com.amuletmod.network.ModNetwork;
import com.amuletmod.registry.LegacyIds;
import com.amuletmod.registry.ModBlockEntities;
import com.amuletmod.registry.ModBlocks;
import com.amuletmod.registry.ModCreativeTabs;
import com.amuletmod.registry.ModCriteria;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.registry.ModItems;
import com.amuletmod.registry.ModSounds;
import com.mojang.logging.LogUtils;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;

public class AmuletMod implements ModInitializer {
   public static final String MODID = "amuletmod";
   public static final Logger LOGGER = LogUtils.getLogger();

   @Override
   public void onInitialize() {
      // Order matters: blocks before items (block items), items before the creative tab.
      ModBlocks.BLOCKS.registerAll();
      ModItems.ITEMS.registerAll();
      ModBlockEntities.BLOCK_ENTITY_TYPES.registerAll();
      ModEntities.ENTITY_TYPES.registerAll();
      ModSounds.SOUND_EVENTS.registerAll();
      ModCreativeTabs.CREATIVE_MODE_TABS.registerAll();
      ModCriteria.TRIGGER_TYPES.registerAll();
      ModEntities.registerAttributes();
      LegacyIds.register();

      ModNetwork.registerPayloads();
      AmuletSlots.init();
      Handlers.registerCommon();
      FabricHooks.init();
   }

   public static Identifier id(String path) {
      return Identifier.fromNamespaceAndPath("amuletmod", path);
   }
}
