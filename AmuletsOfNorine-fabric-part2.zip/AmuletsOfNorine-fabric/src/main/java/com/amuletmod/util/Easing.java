package com.amuletmod.util;

import net.minecraft.util.Mth;

public final class Easing {
   private Easing() {
   }

   public static float outBack(float x) {
      float c1 = 1.70158F;
      float c3 = c1 + 1.0F;
      float y = Mth.clamp(x, 0.0F, 1.0F) - 1.0F;
      return 1.0F + c3 * y * y * y + c1 * y * y;
   }

   public static float outCubic(float x) {
      float y = 1.0F - Mth.clamp(x, 0.0F, 1.0F);
      return 1.0F - y * y * y;
   }

   public static float cubicBezier(float x1, float y1, float x2, float y2, float x) {
      x = Mth.clamp(x, 0.0F, 1.0F);
      float t = x;

      for (int i = 0; i < 8; i++) {
         float error = bezier(x1, x2, t) - x;
         float slope = bezierSlope(x1, x2, t);
         if (Math.abs(error) < 1.0E-5F || Math.abs(slope) < 1.0E-6F) {
            break;
         }

         t = Mth.clamp(t - error / slope, 0.0F, 1.0F);
      }

      return bezier(y1, y2, t);
   }

   private static float bezier(float p1, float p2, float t) {
      float u = 1.0F - t;
      return 3.0F * u * u * t * p1 + 3.0F * u * t * t * p2 + t * t * t;
   }

   private static float bezierSlope(float p1, float p2, float t) {
      float u = 1.0F - t;
      return 3.0F * u * u * p1 + 6.0F * u * t * (p2 - p1) + 3.0F * t * t * (1.0F - p2);
   }

   public static float smoothstep(float edge0, float edge1, float x) {
      float t = Mth.clamp((x - edge0) / (edge1 - edge0), 0.0F, 1.0F);
      return t * t * (3.0F - 2.0F * t);
   }
}
