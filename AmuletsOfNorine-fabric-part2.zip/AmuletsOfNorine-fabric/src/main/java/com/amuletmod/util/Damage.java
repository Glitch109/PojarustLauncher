package com.amuletmod.util;

import com.amuletmod.mixin.LivingEntityAccessor;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.LivingEntity;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;

public final class Damage {
   private Damage() {
   }

   public static boolean landing(LivingIncomingDamageEvent event) {
      LivingEntity victim = event.getEntity();
      return victim.invulnerableTime <= 10
         || event.getSource().is(DamageTypeTags.BYPASSES_COOLDOWN)
         || event.getAmount() > ((LivingEntityAccessor)victim).amuletmod$lastHurt();
   }
}
