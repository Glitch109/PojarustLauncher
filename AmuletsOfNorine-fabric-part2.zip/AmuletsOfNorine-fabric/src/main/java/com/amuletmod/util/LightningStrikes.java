package com.amuletmod.util;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import com.amuletmod.neo.event.EventHooks;
import org.jetbrains.annotations.Nullable;

public final class LightningStrikes {
   private LightningStrikes() {
   }

   public static void strike(ServerLevel level, LivingEntity target, @Nullable ServerPlayer cause) {
      LightningBolt bolt = (LightningBolt)EntityType.LIGHTNING_BOLT.create(level);
      if (bolt != null) {
         bolt.moveTo(target.getX(), target.getY(), target.getZ());
         bolt.setVisualOnly(true);
         bolt.setCause(cause);
         level.addFreshEntity(bolt);
         if (!EventHooks.onEntityStruckByLightning(target, bolt)) {
            target.invulnerableTime = 0;
            target.thunderHit(level, bolt);
         }
      }
   }
}
