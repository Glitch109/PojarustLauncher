package com.amuletmod.util;

import java.util.ArrayList;
import java.util.List;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.ServerStoppedEvent;
import com.amuletmod.neo.event.ServerTickEvent.Post;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class ServerScheduler {
   private static final List<ServerScheduler.Task> TASKS = new ArrayList<>();
   private static long currentTick;

   private ServerScheduler() {
   }

   public static void schedule(int delayTicks, Runnable action) {
      if (delayTicks <= 0) {
         action.run();
      } else {
         TASKS.add(new ServerScheduler.Task(currentTick + delayTicks, action));
      }
   }

   @SubscribeEvent
   public static void onServerTick(Post event) {
      currentTick++;
      if (!TASKS.isEmpty()) {
         List<ServerScheduler.Task> due = new ArrayList<>();
         TASKS.removeIf(task -> task.dueTick() <= currentTick && due.add(task));
         due.forEach(task -> task.action().run());
      }
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      TASKS.clear();
   }

   private record Task(long dueTick, Runnable action) {
   }
}
