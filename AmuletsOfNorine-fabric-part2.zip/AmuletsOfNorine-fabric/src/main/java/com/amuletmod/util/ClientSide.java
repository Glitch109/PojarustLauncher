package com.amuletmod.util;

import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;

public final class ClientSide {
   private static final boolean CLIENT = FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;

   private ClientSide() {
   }

   public static void run(Supplier<Runnable> action) {
      if (CLIENT) {
         action.get().run();
      }
   }

   public static <T> T call(Supplier<Supplier<T>> action) {
      return CLIENT ? action.get().get() : null;
   }
}
