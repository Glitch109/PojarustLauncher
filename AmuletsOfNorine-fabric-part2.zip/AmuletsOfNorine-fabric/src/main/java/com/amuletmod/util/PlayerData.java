package com.amuletmod.util;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

public final class PlayerData {
   private PlayerData() {
   }

   public static CompoundTag get(Player player) {
      CompoundTag persistent = player.getPersistentData();
      if (!persistent.contains("PlayerPersisted")) {
         persistent.put("PlayerPersisted", new CompoundTag());
      }

      CompoundTag persisted = persistent.getCompound("PlayerPersisted");
      if (!persisted.contains("amuletmod")) {
         persisted.put("amuletmod", new CompoundTag());
      }

      return persisted.getCompound("amuletmod");
   }
}
