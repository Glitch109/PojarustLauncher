package com.amuletmod.util;

import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import org.jetbrains.annotations.Nullable;

public final class Aim {
   private static final double SLACK = 0.4;

   private Aim() {
   }

   @Nullable
   public static LivingEntity lookedAt(ServerPlayer player, double range, Predicate<LivingEntity> filter) {
      Vec3 eye = player.getEyePosition();
      Vec3 look = player.getViewVector(1.0F);
      HitResult wall = player.pick(range, 1.0F, false);
      double reach = wall.getType() == Type.MISS ? range : wall.getLocation().distanceTo(eye);
      Vec3 end = eye.add(look.scale(reach));
      LivingEntity best = null;
      double bestDistance = Double.MAX_VALUE;
      AABB sweep = new AABB(eye, end).inflate(1.4);

      for (Entity entity : player.level()
         .getEntities(player, sweep, entityx -> entityx instanceof LivingEntity living && !entityx.isSpectator() && filter.test(living))) {
         AABB box = entity.getBoundingBox().inflate(0.4 + entity.getPickRadius());
         Optional<Vec3> hit = box.contains(eye) ? Optional.of(eye) : box.clip(eye, end);
         if (hit.isPresent() && hit.get().distanceToSqr(eye) < bestDistance) {
            bestDistance = hit.get().distanceToSqr(eye);
            best = (LivingEntity)entity;
         }
      }

      return best;
   }
}
