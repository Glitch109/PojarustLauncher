package com.amuletmod.util;

import com.amuletmod.AmuletMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public final class ModDamage {
   public static final ResourceKey<DamageType> GOD_STRIKE = key("god_strike");
   public static final ResourceKey<DamageType> PETAL = key("petal");
   public static final ResourceKey<DamageType> MONARCH_STING = key("monarch_sting");
   public static final ResourceKey<DamageType> HELLHOUND = key("hellhound");
   public static final ResourceKey<DamageType> UNDERWORLD = key("underworld");
   public static final ResourceKey<DamageType> STORM = key("storm");
   public static final ResourceKey<DamageType> SHOCK = key("shock");
   public static final ResourceKey<DamageType> SHORT_CIRCUIT = key("short_circuit");
   public static final ResourceKey<DamageType> SEISMIC = key("seismic");
   public static final ResourceKey<DamageType> METEOR = key("meteor");
   public static final ResourceKey<DamageType> PAGE = key("page");
   public static final ResourceKey<DamageType> PIERCING_PAGE = key("piercing_page");
   public static final ResourceKey<DamageType> TITAN_FIST = key("titan_fist");
   public static final ResourceKey<DamageType> TITAN_BLADE = key("titan_blade");

   private ModDamage() {
   }

   private static ResourceKey<DamageType> key(String name) {
      return ResourceKey.create(Registries.DAMAGE_TYPE, AmuletMod.id(name));
   }

   public static DamageSource source(Level level, ResourceKey<DamageType> type, @Nullable Entity direct, @Nullable Entity causing) {
      return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(type), direct, causing);
   }
}
