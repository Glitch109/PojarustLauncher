package com.amuletmod.util;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.effect.MobEffect;

/** Vanilla mob effects looked up by registry id, so the Java field names of Mojang's MobEffects (renamed several times) don't matter. */
public final class VanillaEffects {
	public static final Holder<MobEffect> CONDUIT_POWER = get("conduit_power");
	public static final Holder<MobEffect> DAMAGE_BOOST = get("strength");
	public static final Holder<MobEffect> DAMAGE_RESISTANCE = get("resistance");
	public static final Holder<MobEffect> DIG_SLOWDOWN = get("mining_fatigue");
	public static final Holder<MobEffect> DIG_SPEED = get("haste");
	public static final Holder<MobEffect> DOLPHINS_GRACE = get("dolphins_grace");
	public static final Holder<MobEffect> FIRE_RESISTANCE = get("fire_resistance");
	public static final Holder<MobEffect> HUNGER = get("hunger");
	public static final Holder<MobEffect> INVISIBILITY = get("invisibility");
	public static final Holder<MobEffect> LEVITATION = get("levitation");
	public static final Holder<MobEffect> MOVEMENT_SLOWDOWN = get("slowness");
	public static final Holder<MobEffect> MOVEMENT_SPEED = get("speed");
	public static final Holder<MobEffect> NIGHT_VISION = get("night_vision");
	public static final Holder<MobEffect> POISON = get("poison");
	public static final Holder<MobEffect> REGENERATION = get("regeneration");
	public static final Holder<MobEffect> SLOW_FALLING = get("slow_falling");
	public static final Holder<MobEffect> WATER_BREATHING = get("water_breathing");
	public static final Holder<MobEffect> WEAKNESS = get("weakness");
	public static final Holder<MobEffect> WITHER = get("wither");

	private static Holder<MobEffect> get(String id) {
		return BuiltInRegistries.MOB_EFFECT.getOrThrow(ResourceKey.create(Registries.MOB_EFFECT, Identifier.withDefaultNamespace(id)));
	}

	private VanillaEffects() {}
}
