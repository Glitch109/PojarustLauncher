package com.amuletmod.util;

import java.util.function.Consumer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import org.jetbrains.annotations.Nullable;

/** Helpers for the amulet's data inside the CUSTOM_DATA component. NOTE: CompoundTag getters return Optionals since 1.21.5. */
public final class StackData {
   private StackData() {
   }

   @Nullable
   public static CompoundTag get(ItemStack stack) {
      CustomData data = stack.get(DataComponents.CUSTOM_DATA);
      return data == null ? null : data.copyTag();
   }

   @Nullable
   public static CompoundTag getElement(ItemStack stack, String key) {
      CompoundTag tag = get(stack);
      return tag != null && tag.contains(key) ? tag.getCompound(key).orElse(null) : null;
   }

   public static void update(ItemStack stack, Consumer<CompoundTag> edit) {
      CustomData.update(DataComponents.CUSTOM_DATA, stack, edit);
   }

   public static void putElement(ItemStack stack, String key, CompoundTag element) {
      update(stack, tag -> tag.put(key, element));
   }

   public static void remove(ItemStack stack, String key) {
      CustomData data = stack.get(DataComponents.CUSTOM_DATA);
      if (data != null && data.contains(key)) {
         CompoundTag tag = data.copyTag();
         tag.remove(key);
         if (tag.isEmpty()) {
            stack.remove(DataComponents.CUSTOM_DATA);
         } else {
            stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
         }
      }
   }
}
