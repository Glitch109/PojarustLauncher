package com.amuletmod.neo;

import com.amuletmod.neo.event.ExplosionEvent;
import com.amuletmod.neo.event.ProjectileImpactEvent;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;

public final class EventHooks {
	private EventHooks() {}

	/** @return true when a handler canceled the impact. */
	public static boolean onProjectileImpact(Projectile projectile, HitResult hit) {
		return NeoBus.EVENT_BUS.post(new ProjectileImpactEvent(projectile, hit)).isCanceled();
	}

	/** Fires Detonate with a mutable copy of {@code entities}; the removals done by handlers are applied back to the given list. */
	public static void onExplosionDetonate(Level level, Explosion explosion, List<Entity> entities, double diameter) {
		List<Entity> copy = new ArrayList<>(entities);
		NeoBus.EVENT_BUS.post(new ExplosionEvent.Detonate(level, explosion, copy, new ArrayList<>()));
		entities.retainAll(copy);
	}
}
