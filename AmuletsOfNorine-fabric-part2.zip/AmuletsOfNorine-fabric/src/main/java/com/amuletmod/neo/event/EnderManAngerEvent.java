package com.amuletmod.neo.event;

import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.player.Player;

public class EnderManAngerEvent extends Event {
	private final EnderMan enderman;
	private final Player player;
	public EnderManAngerEvent(EnderMan enderman, Player player) { this.enderman = enderman; this.player = player; }
	public EnderMan getEntity() { return enderman; }
	public Player getPlayer() { return player; }
}
