package com.amuletmod.neo.event;

import net.minecraft.world.entity.LivingEntity;

public class LivingExperienceDropEvent extends LivingEntityEvent {
	private int droppedExperience;
	public LivingExperienceDropEvent(LivingEntity entity, int xp) { super(entity); this.droppedExperience = xp; }
	public int getDroppedExperience() { return droppedExperience; }
	public void setDroppedExperience(int xp) { this.droppedExperience = xp; }
}
