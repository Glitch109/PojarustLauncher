package com.amuletmod.neo;

import net.minecraft.world.entity.player.Player;

/** Shim for NeoForge's IPayloadContext. Fabric already runs receivers on the main thread, so enqueueWork runs immediately. */
@FunctionalInterface
public interface IPayloadContext {
	Player player();

	default void enqueueWork(Runnable work) { work.run(); }
}
