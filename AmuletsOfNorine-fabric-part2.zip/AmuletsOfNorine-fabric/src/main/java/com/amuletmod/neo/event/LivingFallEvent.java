package com.amuletmod.neo.event;

import net.minecraft.world.entity.LivingEntity;

public class LivingFallEvent extends LivingEntityEvent {
	private double distance;
	private float damageMultiplier;
	public LivingFallEvent(LivingEntity entity, double distance, float damageMultiplier) { super(entity); this.distance = distance; this.damageMultiplier = damageMultiplier; }
	public double getDistance() { return distance; }
	public void setDistance(double distance) { this.distance = distance; }
	public float getDamageMultiplier() { return damageMultiplier; }
	public void setDamageMultiplier(float m) { this.damageMultiplier = m; }
}
