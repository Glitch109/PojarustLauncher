package com.amuletmod.neo.event;

import net.minecraft.world.entity.LivingEntity;

public class LivingChangeTargetEvent extends LivingEntityEvent {
	private LivingEntity newTarget;
	public LivingChangeTargetEvent(LivingEntity entity, LivingEntity newTarget) { super(entity); this.newTarget = newTarget; }
	public LivingEntity getNewAboutToBeSetTarget() { return newTarget; }
	public void setNewAboutToBeSetTarget(LivingEntity t) { this.newTarget = t; }
}
