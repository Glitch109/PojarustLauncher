package com.amuletmod.neo.event;

import net.minecraft.world.entity.LivingEntity;

public class LivingEntityEvent extends Event {
	private final LivingEntity entity;
	public LivingEntityEvent(LivingEntity entity) { this.entity = entity; }
	public LivingEntity getEntity() { return entity; }
}
