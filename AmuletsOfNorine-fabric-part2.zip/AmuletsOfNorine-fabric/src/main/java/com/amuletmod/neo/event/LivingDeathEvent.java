package com.amuletmod.neo.event;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;

public class LivingDeathEvent extends LivingEntityEvent {
	private final DamageSource source;
	public LivingDeathEvent(LivingEntity entity, DamageSource source) { super(entity); this.source = source; }
	public DamageSource getSource() { return source; }
}
