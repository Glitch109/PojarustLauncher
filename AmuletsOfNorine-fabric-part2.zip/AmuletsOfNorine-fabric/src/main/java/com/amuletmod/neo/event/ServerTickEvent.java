package com.amuletmod.neo.event;

import net.minecraft.server.MinecraftServer;

public class ServerTickEvent {
	public static class Post extends Event {
		private final MinecraftServer server;
		public Post(MinecraftServer server) { this.server = server; }
		public MinecraftServer getServer() { return server; }
	}
}
