package com.amuletmod.neo;

import java.lang.annotation.*;

/** Marker only. Classes carrying it must be listed in {@link Handlers}. */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface EventBusSubscriber {
	String modid() default "";
	Dist[] value() default {};
}
