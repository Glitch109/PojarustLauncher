package com.amuletmod.neo.event;

import net.minecraft.world.entity.LivingEntity;

public class LivingConversionEvent {
	public static class Pre extends LivingEntityEvent {
		public Pre(LivingEntity entity) { super(entity); }
	}
}
