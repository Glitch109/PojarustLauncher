package com.amuletmod.neo;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.Nullable;

/** Shim for NeoForge's PacketDistributor on top of Fabric networking. The varargs "more payloads" parameter is kept for source compatibility. */
public final class PacketDistributor {
	private PacketDistributor() {}

	public static void sendToPlayer(ServerPlayer player, CustomPacketPayload payload, CustomPacketPayload... more) {
		ServerPlayNetworking.send(player, payload);
		for (CustomPacketPayload p : more) ServerPlayNetworking.send(player, p);
	}

	public static void sendToPlayersTrackingEntity(Entity entity, CustomPacketPayload payload, CustomPacketPayload... more) {
		for (ServerPlayer p : PlayerLookup.tracking(entity)) sendToPlayer(p, payload, more);
	}

	public static void sendToPlayersTrackingEntityAndSelf(Entity entity, CustomPacketPayload payload, CustomPacketPayload... more) {
		for (ServerPlayer p : PlayerLookup.tracking(entity)) sendToPlayer(p, payload, more);
		if (entity instanceof ServerPlayer self) sendToPlayer(self, payload, more);
	}

	public static void sendToPlayersNear(ServerLevel level, @Nullable ServerPlayer except, double x, double y, double z, double radius, CustomPacketPayload payload, CustomPacketPayload... more) {
		double r2 = radius * radius;
		for (ServerPlayer p : level.players()) {
			if (p == except) continue;
			if (p.distanceToSqr(x, y, z) <= r2) sendToPlayer(p, payload, more);
		}
	}

	public static void sendToPlayersInDimension(ServerLevel level, CustomPacketPayload payload, CustomPacketPayload... more) {
		for (ServerPlayer p : level.players()) sendToPlayer(p, payload, more);
	}

	public static void sendToAllPlayers(net.minecraft.server.MinecraftServer server, CustomPacketPayload payload, CustomPacketPayload... more) {
		for (ServerPlayer p : server.getPlayerList().getPlayers()) sendToPlayer(p, payload, more);
	}

	public static void sendToServer(CustomPacketPayload payload, CustomPacketPayload... more) {
		ClientPlayNetworking.send(payload);
		for (CustomPacketPayload p : more) ClientPlayNetworking.send(p);
	}
}
