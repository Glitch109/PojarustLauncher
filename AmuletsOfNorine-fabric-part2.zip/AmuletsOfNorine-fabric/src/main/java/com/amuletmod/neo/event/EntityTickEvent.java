package com.amuletmod.neo.event;

import net.minecraft.world.entity.Entity;

public class EntityTickEvent {
	public static class Pre extends Event { private final Entity e; public Pre(Entity e) { this.e = e; } public Entity getEntity() { return e; } }
}
