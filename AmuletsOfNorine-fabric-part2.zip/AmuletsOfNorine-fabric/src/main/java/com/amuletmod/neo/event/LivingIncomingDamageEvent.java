package com.amuletmod.neo.event;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;

public class LivingIncomingDamageEvent extends LivingEntityEvent {
	private final DamageSource source;
	private float amount;
	public LivingIncomingDamageEvent(LivingEntity entity, DamageSource source, float amount) { super(entity); this.source = source; this.amount = amount; }
	public DamageSource getSource() { return source; }
	public float getAmount() { return amount; }
	public void setAmount(float amount) { this.amount = amount; }
}
