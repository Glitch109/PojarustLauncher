package com.amuletmod.neo.event;

import net.minecraft.world.level.LevelAccessor;

public class LevelEvent {
	public static class Unload extends Event {
		private final LevelAccessor level;
		public Unload(LevelAccessor level) { this.level = level; }
		public LevelAccessor getLevel() { return level; }
	}
}
