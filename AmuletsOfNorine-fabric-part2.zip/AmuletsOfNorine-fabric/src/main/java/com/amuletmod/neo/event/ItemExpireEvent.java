package com.amuletmod.neo.event;

import net.minecraft.world.entity.item.ItemEntity;

public class ItemExpireEvent extends Event {
	private final ItemEntity entity;
	public ItemExpireEvent(ItemEntity entity) { this.entity = entity; }
	public ItemEntity getEntity() { return entity; }
}
