package com.amuletmod.neo.event;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public class ExplosionKnockbackEvent extends Event {
	private final Entity affected;
	private Vec3 knockback;
	public ExplosionKnockbackEvent(Entity affected, Vec3 knockback) { this.affected = affected; this.knockback = knockback; }
	public Entity getAffectedEntity() { return affected; }
	public Vec3 getKnockbackVelocity() { return knockback; }
	public void setKnockbackVelocity(Vec3 v) { this.knockback = v; }
}
