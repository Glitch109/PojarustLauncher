package com.amuletmod.neo.registry;

import java.util.function.Supplier;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;

/** Shim for NeoForge's DeferredHolder. Resolves to a value once {@link DeferredRegister#registerAll()} has run. */
public class DeferredHolder<R, T extends R> implements Supplier<T> {
	private final ResourceKey<R> key;
	private final Registry<R> registry;
	private T value;

	DeferredHolder(Registry<R> registry, ResourceKey<R> key) {
		this.registry = registry;
		this.key = key;
	}

	void bind(T value) { this.value = value; }

	@Override
	@SuppressWarnings("unchecked")
	public T get() {
		if (value == null) {
			Object v = registry.getValue(key);
			if (v == null) throw new IllegalStateException("Registry object not present yet: " + key);
			value = (T) v;
		}
		return value;
	}

	public T value() { return get(); }
	public boolean isBound() { return value != null || registry.containsKey(key); }
	public ResourceKey<R> getKey() { return key; }
	public Identifier getId() { return key.identifier(); }
	public boolean is(ResourceKey<R> other) { return key.equals(other); }
	public boolean is(Identifier id) { return key.identifier().equals(id); }

	/** The vanilla Holder for this entry (needed wherever vanilla wants a Holder, e.g. mob effects). */
	public Holder<R> holder() { return registry.getOrThrow(key); }
}
