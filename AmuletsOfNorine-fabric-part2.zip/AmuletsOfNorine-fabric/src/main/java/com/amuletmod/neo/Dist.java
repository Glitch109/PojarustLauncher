package com.amuletmod.neo;

/** Shim for net.neoforged.api.distmarker.Dist. */
public enum Dist { CLIENT, DEDICATED_SERVER }
