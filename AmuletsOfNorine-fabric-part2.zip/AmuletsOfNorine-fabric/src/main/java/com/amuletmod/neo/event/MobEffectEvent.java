package com.amuletmod.neo.event;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;

public class MobEffectEvent {
	public static class Added extends LivingEntityEvent {
		private final MobEffectInstance effect;
		private final Entity source;
		public Added(LivingEntity entity, MobEffectInstance effect, Entity source) { super(entity); this.effect = effect; this.source = source; }
		public MobEffectInstance getEffectInstance() { return effect; }
		public Entity getEffectSource() { return source; }
	}
}
