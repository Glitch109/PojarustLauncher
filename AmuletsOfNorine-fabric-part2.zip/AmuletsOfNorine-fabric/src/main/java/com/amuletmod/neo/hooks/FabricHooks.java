package com.amuletmod.neo.hooks;

import com.amuletmod.neo.NeoBus;
import com.amuletmod.neo.event.*;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.networking.v1.EntityTrackingEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;

/** Translates Fabric callbacks into the NeoForge-style events the ported handlers listen to. Mixin-based events live in com.amuletmod.mixin. */
public final class FabricHooks {
	private FabricHooks() {}

	public static void init() {
		ServerTickEvents.START_SERVER_TICK.register(server -> {
			for (ServerPlayer p : server.getPlayerList().getPlayers()) NeoBus.EVENT_BUS.post(new PlayerTickEvent.Pre(p));
		});
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer p : server.getPlayerList().getPlayers()) NeoBus.EVENT_BUS.post(new PlayerTickEvent.Post(p));
			NeoBus.EVENT_BUS.post(new ServerTickEvent.Post(server));
		});
		ServerLifecycleEvents.SERVER_STARTED.register(server -> NeoBus.EVENT_BUS.post(new ServerStartedEvent(server)));
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> NeoBus.EVENT_BUS.post(new ServerStoppedEvent(server)));
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> NeoBus.EVENT_BUS.post(new PlayerEvent.PlayerLoggedInEvent(handler.getPlayer())));
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> NeoBus.EVENT_BUS.post(new PlayerEvent.PlayerLoggedOutEvent(handler.getPlayer())));
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> NeoBus.EVENT_BUS.post(new PlayerEvent.PlayerRespawnEvent(newPlayer)));
		ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) ->
			NeoBus.EVENT_BUS.post(new PlayerEvent.PlayerChangedDimensionEvent(player, origin.dimension(), destination.dimension())));
		ServerEntityEvents.ENTITY_LOAD.register((entity, level) -> NeoBus.EVENT_BUS.post(new EntityJoinLevelEvent(entity, level, false)));
		ServerEntityEvents.ENTITY_UNLOAD.register((entity, level) -> NeoBus.EVENT_BUS.post(new EntityLeaveLevelEvent(entity, level)));
		EntityTrackingEvents.START_TRACKING.register((tracked, player) -> NeoBus.EVENT_BUS.post(new PlayerEvent.StartTracking(player, tracked)));
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> NeoBus.EVENT_BUS.post(new RegisterCommandsEvent(dispatcher)));
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> !NeoBus.EVENT_BUS.post(new LivingDeathEvent(entity, source)).isCanceled());
		AttackBlockCallback.EVENT.register((player, level, hand, pos, direction) -> {
			boolean canceled = NeoBus.EVENT_BUS.post(new PlayerInteractEvent.LeftClickBlock(player, level, pos)).isCanceled();
			return canceled ? InteractionResult.FAIL : InteractionResult.PASS;
		});
	}
}
