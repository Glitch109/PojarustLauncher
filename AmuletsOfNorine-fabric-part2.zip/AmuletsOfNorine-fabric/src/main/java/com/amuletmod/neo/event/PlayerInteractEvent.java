package com.amuletmod.neo.event;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class PlayerInteractEvent {
	public static class LeftClickBlock extends Event {
		private final Player entity; private final Level level; private final BlockPos pos;
		public LeftClickBlock(Player entity, Level level, BlockPos pos) { this.entity = entity; this.level = level; this.pos = pos; }
		public Player getEntity() { return entity; }
		public Level getLevel() { return level; }
		public BlockPos getPos() { return pos; }
	}
}
