package com.amuletmod.neo.registry;

import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class DeferredBlock<T extends Block> extends DeferredHolder<Block, T> implements ItemLike {
	DeferredBlock(Registry<Block> registry, ResourceKey<Block> key) { super(registry, key); }

	@Override
	public Item asItem() { return get().asItem(); }

	public BlockState defaultBlockState() { return get().defaultBlockState(); }
}
