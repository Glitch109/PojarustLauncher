package com.amuletmod.neo;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Block;

/** Shim for NeoForge's Tags: the same "c:" convention tag ids (also used by Fabric). */
public final class Tags {
	private Tags() {}

	public static final class EntityTypes {
		public static final TagKey<EntityType<?>> BOSSES = TagKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("c", "bosses"));
		private EntityTypes() {}
	}

	public static final class Blocks {
		public static final TagKey<Block> BOOKSHELVES = block("bookshelves");
		public static final TagKey<Block> ORES = block("ores");
		public static final TagKey<Block> STONES = block("stones");
		public static final TagKey<Block> COBBLESTONES = block("cobblestones");
		public static final TagKey<Block> SANDSTONE_BLOCKS = block("sandstone/blocks");
		public static final TagKey<Block> END_STONES = block("end_stones");
		public static final TagKey<Block> GRAVELS = block("gravels");

		private static TagKey<Block> block(String path) {
			return TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("c", path));
		}
		private Blocks() {}
	}
}
