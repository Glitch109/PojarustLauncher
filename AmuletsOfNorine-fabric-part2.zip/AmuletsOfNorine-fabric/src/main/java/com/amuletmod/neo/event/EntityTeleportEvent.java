package com.amuletmod.neo.event;

import net.minecraft.world.entity.Entity;

public class EntityTeleportEvent extends Event {
	private final Entity entity; private double targetX, targetY, targetZ;
	public EntityTeleportEvent(Entity entity, double x, double y, double z) { this.entity = entity; this.targetX = x; this.targetY = y; this.targetZ = z; }
	public Entity getEntity() { return entity; }
	public double getTargetX() { return targetX; }
	public double getTargetY() { return targetY; }
	public double getTargetZ() { return targetZ; }
}
