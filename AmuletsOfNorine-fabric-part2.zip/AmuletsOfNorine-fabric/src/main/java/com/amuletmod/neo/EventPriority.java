package com.amuletmod.neo;

public enum EventPriority { HIGHEST, HIGH, NORMAL, LOW, LOWEST }
