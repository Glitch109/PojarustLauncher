package com.amuletmod.neo;

import net.minecraft.network.RegistryFriendlyByteBuf;

/**
 * Shim for NeoForge's IEntityWithComplexSpawn. Fabric has no direct equivalent, so entities implementing this
 * are given their spawn data through {@link com.amuletmod.network.SpawnDataPacket} (see ModNetwork).
 */
public interface IEntityWithComplexSpawn {
	void writeSpawnData(RegistryFriendlyByteBuf buffer);
	void readSpawnData(RegistryFriendlyByteBuf additionalData);
}
