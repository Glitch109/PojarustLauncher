package com.amuletmod.neo.event;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;

public class ExplosionEvent {
	public static class Detonate extends Event {
		private final Level level;
		private final Explosion explosion;
		private final List<Entity> affectedEntities;
		private final List<BlockPos> affectedBlocks;
		public Detonate(Level level, Explosion explosion, List<Entity> entities, List<BlockPos> blocks) { this.level = level; this.explosion = explosion; this.affectedEntities = entities; this.affectedBlocks = blocks; }
		public Level getLevel() { return level; }
		public Explosion getExplosion() { return explosion; }
		public List<Entity> getAffectedEntities() { return affectedEntities; }
		public List<BlockPos> getAffectedBlocks() { return affectedBlocks; }
	}
}
