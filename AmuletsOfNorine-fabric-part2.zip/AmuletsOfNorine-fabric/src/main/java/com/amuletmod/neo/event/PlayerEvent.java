package com.amuletmod.neo.event;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;

public class PlayerEvent {
	public static class PlayerEventBase extends Event {
		private final Player entity;
		public PlayerEventBase(Player entity) { this.entity = entity; }
		public Player getEntity() { return entity; }
	}
	public static class PlayerLoggedInEvent extends PlayerEventBase { public PlayerLoggedInEvent(Player p) { super(p); } }
	public static class PlayerLoggedOutEvent extends PlayerEventBase { public PlayerLoggedOutEvent(Player p) { super(p); } }
	public static class PlayerRespawnEvent extends PlayerEventBase { public PlayerRespawnEvent(Player p) { super(p); } }
	public static class PlayerChangedDimensionEvent extends PlayerEventBase {
		private final ResourceKey<Level> from, to;
		public PlayerChangedDimensionEvent(Player p, ResourceKey<Level> from, ResourceKey<Level> to) { super(p); this.from = from; this.to = to; }
		public ResourceKey<Level> getFrom() { return from; }
		public ResourceKey<Level> getTo() { return to; }
	}
	public static class StartTracking extends PlayerEventBase {
		private final Entity target;
		public StartTracking(Player p, Entity target) { super(p); this.target = target; }
		public Entity getTarget() { return target; }
	}
	public static class PlayerChangeGameModeEvent extends PlayerEventBase {
		private final GameType current, newMode;
		public PlayerChangeGameModeEvent(Player p, GameType current, GameType newMode) { super(p); this.current = current; this.newMode = newMode; }
		public GameType getCurrentGameMode() { return current; }
		public GameType getNewGameMode() { return newMode; }
	}
}
