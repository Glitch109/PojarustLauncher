package com.amuletmod.neo;

import java.lang.annotation.*;

/** Shim for NeoForge's @SubscribeEvent. Handlers are dispatched by {@link NeoBus}. */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface SubscribeEvent {
	EventPriority priority() default EventPriority.NORMAL;
	boolean receiveCanceled() default false;
}
