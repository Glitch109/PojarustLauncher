package com.amuletmod.neo;

/** Central list of all classes with static @SubscribeEvent methods (replaces @EventBusSubscriber auto-scan). */
public final class Handlers {
	private Handlers() {}

	public static void registerCommon() {
		for (Class<?> c : COMMON) NeoBus.EVENT_BUS.register(c);
	}

	private static final Class<?>[] COMMON = {
		com.amuletmod.amulet.AmuletEvents.class,
		com.amuletmod.amulet.ability.Summons.class,
		com.amuletmod.amulet.ability.aegis.AegisEvents.class,
		com.amuletmod.amulet.ability.chrono.Rewinds.class,
		com.amuletmod.amulet.ability.chrono.TimeTrail.class,
		com.amuletmod.amulet.ability.recall.ReturnPoints.class,
		com.amuletmod.amulet.ability.sovereign.AuraSight.class,
		com.amuletmod.amulet.ability.sovereign.ShadowArmy.class,
		com.amuletmod.amulet.ability.stealth.ShadowMarks.class,
		com.amuletmod.amulet.ability.stealth.Stealth.class,
		com.amuletmod.amulet.ability.strike.GodStrikes.class,
		com.amuletmod.amulet.ability.strike.StrikeTargets.class,
		com.amuletmod.amulet.ability.sylvan.PetalSwarms.class,
		com.amuletmod.amulet.ability.titan.TitanBlades.class,
		com.amuletmod.amulet.ability.titan.TitanFists.class,
		com.amuletmod.amulet.ability.titan.TitanSync.class,
		com.amuletmod.command.ModCommands.class,
		com.amuletmod.entity.ChainBindEntity.ChainBindEvents.class,
		com.amuletmod.entity.MeteorEntity.MeteorEvents.class,
		com.amuletmod.entity.PageEntity.PageEvents.class,
		com.amuletmod.entity.RockShellEntity.RockShellEvents.class,
		com.amuletmod.entity.SealEntity.SealEvents.class,
		com.amuletmod.entity.TimeFieldEntity.TimeFieldEvents.class,
		com.amuletmod.entity.UnderworldHandEntity.UnderworldHandEvents.class,
		com.amuletmod.seal.SealCubeItem.SealCubeEvents.class,
		com.amuletmod.seal.SealPrison.class,
		com.amuletmod.util.ServerScheduler.class,
	};
}
