package com.amuletmod.neo.event;

import net.minecraft.world.entity.Entity;

public class EntityMobGriefingEvent extends Event {
	private final Entity entity; private boolean canGrief;
	public EntityMobGriefingEvent(Entity entity, boolean canGrief) { this.entity = entity; this.canGrief = canGrief; }
	public Entity getEntity() { return entity; }
	public boolean canGrief() { return canGrief; }
	public void setCanGrief(boolean b) { this.canGrief = b; }
}
