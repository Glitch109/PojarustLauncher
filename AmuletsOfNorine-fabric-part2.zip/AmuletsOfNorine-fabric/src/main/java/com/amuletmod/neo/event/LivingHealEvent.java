package com.amuletmod.neo.event;

import net.minecraft.world.entity.LivingEntity;

public class LivingHealEvent extends LivingEntityEvent {
	private float amount;
	public LivingHealEvent(LivingEntity entity, float amount) { super(entity); this.amount = amount; }
	public float getAmount() { return amount; }
	public void setAmount(float amount) { this.amount = amount; }
}
