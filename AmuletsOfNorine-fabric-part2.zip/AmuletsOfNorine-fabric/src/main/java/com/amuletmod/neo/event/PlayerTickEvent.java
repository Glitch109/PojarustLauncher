package com.amuletmod.neo.event;

import net.minecraft.world.entity.player.Player;

public class PlayerTickEvent {
	public static class Pre extends Event { private final Player p; public Pre(Player p) { this.p = p; } public Player getEntity() { return p; } }
	public static class Post extends Event { private final Player p; public Post(Player p) { this.p = p; } public Player getEntity() { return p; } }
}
