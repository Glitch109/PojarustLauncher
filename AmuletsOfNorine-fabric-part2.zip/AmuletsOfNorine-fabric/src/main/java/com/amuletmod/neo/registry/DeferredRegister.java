package com.amuletmod.neo.registry;

import com.amuletmod.AmuletMod;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;

/**
 * Shim for NeoForge's DeferredRegister on top of plain Registry.register.
 * <p>
 * Suppliers run inside {@link #registerAll()} (called from the mod initializer, in order). While a supplier runs,
 * {@link #currentKey()} returns the ResourceKey of the object being created, because since 1.21.2 Item/Block
 * properties and EntityType builders need their id up front (use {@code new Item.Properties().setId(DeferredRegister.currentKey())}).
 */
public class DeferredRegister<T> {
	private static ResourceKey<?> current;

	protected final Registry<T> registry;
	private final ResourceKey<? extends Registry<T>> registryKey;
	private final String namespace;
	private final List<Runnable> pending = new ArrayList<>();
	private final List<DeferredHolder<T, ? extends T>> entries = new ArrayList<>();

	public java.util.Collection<DeferredHolder<T, ? extends T>> getEntries() { return java.util.Collections.unmodifiableList(entries); }

	protected DeferredRegister(ResourceKey<? extends Registry<T>> registryKey, String namespace) {
		this.registryKey = registryKey;
		this.namespace = namespace;
		this.registry = lookup(registryKey);
	}

	@SuppressWarnings("unchecked")
	private static <T> Registry<T> lookup(ResourceKey<? extends Registry<T>> key) {
		Object r = BuiltInRegistries.REGISTRY.getValue(key.identifier());
		if (r == null) throw new IllegalStateException("Unknown registry " + key);
		return (Registry<T>) r;
	}

	public static <T> DeferredRegister<T> create(ResourceKey<? extends Registry<T>> key, String namespace) {
		return new DeferredRegister<>(key, namespace);
	}

	public static Items createItems(String namespace) { return new Items(namespace); }

	public static Blocks createBlocks(String namespace) { return new Blocks(namespace); }

	/** Key of the object whose supplier is currently running. */
	@SuppressWarnings("unchecked")
	public static <K> ResourceKey<K> currentKey() {
		if (current == null) throw new IllegalStateException("currentKey() used outside of a DeferredRegister supplier");
		return (ResourceKey<K>) current;
	}

	protected ResourceKey<T> keyOf(String name) {
		return ResourceKey.create(registryKey, Identifier.fromNamespaceAndPath(namespace, name));
	}

	protected <I extends T> void enqueue(ResourceKey<T> key, Supplier<? extends I> supplier, DeferredHolder<T, I> holder) {
		entries.add(holder);
		pending.add(() -> {
			current = key;
			try {
				I value = supplier.get();
				Registry.register(registry, key, value);
				holder.bind(value);
			} finally {
				current = null;
			}
		});
	}

	public <I extends T> DeferredHolder<T, I> register(String name, Supplier<? extends I> supplier) {
		ResourceKey<T> key = keyOf(name);
		DeferredHolder<T, I> holder = new DeferredHolder<>(registry, key);
		enqueue(key, supplier, holder);
		return holder;
	}

	/** Legacy id support (renamed objects keep loading from old saves). */
	public void addAlias(Identifier from, Identifier to) {
		if (registry instanceof net.minecraft.core.MappedRegistry<T> mapped) mapped.addAlias(from, to);
	}

	/** Runs every queued registration. Call once, from the mod initializer. */
	public void registerAll() {
		List<Runnable> work = new ArrayList<>(pending);
		pending.clear();
		work.forEach(Runnable::run);
		AmuletMod.LOGGER.debug("Registered {} entries in {}", work.size(), registryKey.identifier());
	}

	public static final class Items extends DeferredRegister<Item> {
		private Items(String ns) { super(Registries.ITEM, ns); }

		@Override
		public <I extends Item> DeferredItem<I> register(String name, Supplier<? extends I> supplier) {
			ResourceKey<Item> key = keyOf(name);
			DeferredItem<I> holder = new DeferredItem<>(this.registry, key);
			enqueue(key, supplier, holder);
			return holder;
		}
	}

	public static final class Blocks extends DeferredRegister<Block> {
		private Blocks(String ns) { super(Registries.BLOCK, ns); }

		@Override
		public <B extends Block> DeferredBlock<B> register(String name, Supplier<? extends B> supplier) {
			ResourceKey<Block> key = keyOf(name);
			DeferredBlock<B> holder = new DeferredBlock<>(this.registry, key);
			enqueue(key, supplier, holder);
			return holder;
		}
	}
}
