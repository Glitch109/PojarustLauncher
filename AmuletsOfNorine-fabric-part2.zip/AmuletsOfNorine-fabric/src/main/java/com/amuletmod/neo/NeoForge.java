package com.amuletmod.neo;

/** Shim so that {@code NeoForge.EVENT_BUS.post(...)} call sites keep compiling. */
public final class NeoForge {
	public static final NeoBus EVENT_BUS = NeoBus.EVENT_BUS;
	private NeoForge() {}
}
