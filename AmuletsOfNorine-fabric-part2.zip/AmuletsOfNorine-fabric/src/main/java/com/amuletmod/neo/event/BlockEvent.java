package com.amuletmod.neo.event;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;

public class BlockEvent {
	public static class BreakEvent extends Event {
		private final LevelAccessor level; private final BlockPos pos; private final BlockState state; private final Player player;
		public BreakEvent(LevelAccessor level, BlockPos pos, BlockState state, Player player) { this.level = level; this.pos = pos; this.state = state; this.player = player; }
		public LevelAccessor getLevel() { return level; }
		public BlockPos getPos() { return pos; }
		public BlockState getState() { return state; }
		public Player getPlayer() { return player; }
	}
}
