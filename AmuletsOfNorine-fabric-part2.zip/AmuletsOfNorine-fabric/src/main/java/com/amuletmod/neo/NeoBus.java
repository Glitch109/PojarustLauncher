package com.amuletmod.neo;

import com.amuletmod.neo.event.Event;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Tiny replacement for NeoForge's event bus. Only static @SubscribeEvent methods are supported. */
public final class NeoBus {
	public static final NeoBus EVENT_BUS = new NeoBus();

	private record Listener(Class<?> type, Method method, EventPriority priority, boolean receiveCanceled) {}

	private final List<Listener> listeners = new CopyOnWriteArrayList<>();

	private NeoBus() {}

	public void register(Class<?> owner) {
		List<Listener> found = new ArrayList<>();
		for (Method m : owner.getDeclaredMethods()) {
			SubscribeEvent sub = m.getAnnotation(SubscribeEvent.class);
			if (sub == null || !Modifier.isStatic(m.getModifiers()) || m.getParameterCount() != 1) continue;
			m.setAccessible(true);
			found.add(new Listener(m.getParameterTypes()[0], m, sub.priority(), sub.receiveCanceled()));
		}
		listeners.addAll(found);
		List<Listener> sorted = new ArrayList<>(listeners);
		sorted.sort(Comparator.comparingInt(l -> l.priority.ordinal()));
		listeners.clear();
		listeners.addAll(sorted);
	}

	public <T extends Event> T post(T event) {
		for (Listener l : listeners) {
			if (!l.type.isInstance(event)) continue;
			if (event.isCanceled() && !l.receiveCanceled) continue;
			try {
				l.method.invoke(null, event);
			} catch (Throwable t) {
				Throwable cause = t.getCause() != null ? t.getCause() : t;
				com.amuletmod.AmuletMod.LOGGER.error("Event handler {}#{} failed", l.method.getDeclaringClass().getSimpleName(), l.method.getName(), cause);
			}
		}
		return event;
	}

	public boolean hasListeners(Class<?> type) {
		for (Listener l : listeners) if (l.type.isAssignableFrom(type) || type.isAssignableFrom(l.type)) return true;
		return false;
	}
}
