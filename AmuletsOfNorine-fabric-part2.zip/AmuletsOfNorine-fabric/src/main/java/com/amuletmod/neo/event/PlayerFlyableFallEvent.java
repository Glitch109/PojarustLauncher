package com.amuletmod.neo.event;

import net.minecraft.world.entity.player.Player;

public class PlayerFlyableFallEvent extends Event {
	private final Player entity; private double distance;
	public PlayerFlyableFallEvent(Player entity, double distance) { this.entity = entity; this.distance = distance; }
	public Player getEntity() { return entity; }
	public double getDistance() { return distance; }
}
