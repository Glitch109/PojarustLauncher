package com.amuletmod.client;

import com.amuletmod.entity.BarrierEntity;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/BarrierHum.java and is ported in the client phase. */
public final class BarrierHum {
   public static void start(BarrierEntity barrier) {  }
}
