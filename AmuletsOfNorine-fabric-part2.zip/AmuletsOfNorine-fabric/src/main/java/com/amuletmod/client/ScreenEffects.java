package com.amuletmod.client;



/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ScreenEffects.java and is ported in the client phase. */
public final class ScreenEffects {
   public static void startRewind(int durationTicks) {  }
}
