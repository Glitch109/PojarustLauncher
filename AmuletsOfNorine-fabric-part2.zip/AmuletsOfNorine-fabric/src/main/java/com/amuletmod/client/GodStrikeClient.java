package com.amuletmod.client;

import com.amuletmod.network.GodStrikePacket;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/GodStrikeClient.java and is ported in the client phase. */
public final class GodStrikeClient {
   public static void start(GodStrikePacket packet) {  }
}
