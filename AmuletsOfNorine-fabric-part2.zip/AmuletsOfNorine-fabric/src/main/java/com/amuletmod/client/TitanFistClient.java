package com.amuletmod.client;

import com.amuletmod.entity.TitanFistEntity;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/TitanFistClient.java and is ported in the client phase. */
public final class TitanFistClient {
   public static void tick(TitanFistEntity fist) {  }
}
