package com.amuletmod.client;



/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/PaperCutsClient.java and is ported in the client phase. */
public final class PaperCutsClient {
   public static void flung(int throwerId) {  }
   public static void impactFrame(int throwerId) {  }
}
