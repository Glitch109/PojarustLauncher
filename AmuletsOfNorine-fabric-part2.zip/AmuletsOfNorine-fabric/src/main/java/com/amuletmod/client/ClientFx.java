package com.amuletmod.client;

import com.amuletmod.network.FxPacket;
import net.minecraft.world.phys.Vec3;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ClientFx.java and is ported in the client phase. */
public final class ClientFx {
   public static void play(FxPacket.Kind kind, Vec3 at, Vec3 to, float size) {  }
}
