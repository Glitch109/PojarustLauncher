package com.amuletmod.client;



/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/PetalOrbitClient.java and is ported in the client phase. */
public final class PetalOrbitClient {
   public static void update(int entityId, int[] colors, int[] petals) {  }
}
