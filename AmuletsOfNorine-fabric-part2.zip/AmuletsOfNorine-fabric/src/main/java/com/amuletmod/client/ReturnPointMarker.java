package com.amuletmod.client;

import com.amuletmod.amulet.ability.recall.ReturnPoint;
import org.jetbrains.annotations.Nullable;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ReturnPointMarker.java and is ported in the client phase. */
public final class ReturnPointMarker {
   public static void update(@Nullable ReturnPoint newPoint, boolean justSet) {  }
}
