package com.amuletmod.client;

import com.amuletmod.network.TitanHudPacket;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/TitanHud.java and is ported in the client phase. */
public final class TitanHud {
   public static void state(TitanHudPacket packet) {  }
}
