package com.amuletmod.client;



/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ShadowMarkClient.java and is ported in the client phase. */
public final class ShadowMarkClient {
   public static void update(int entityId) {  }
}
