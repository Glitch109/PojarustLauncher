package com.amuletmod.client;



/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ShadowSoldierClient.java and is ported in the client phase. */
public final class ShadowSoldierClient {
   public static void add(int entityId, int age) {  }
}
