package com.amuletmod.client;



/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/SealCaptureClient.java and is ported in the client phase. */
public final class SealCaptureClient {
   public static void shrink(int entityId, float scale, float height) {  }
}
