package com.amuletmod.client;



/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/AuraVisionClient.java and is ported in the client phase. */
public final class AuraVisionClient {
   public static void update(boolean on, int[] ids, float[] powers) {  }
}
