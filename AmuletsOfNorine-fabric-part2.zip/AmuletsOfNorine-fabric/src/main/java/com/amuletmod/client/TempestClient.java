package com.amuletmod.client;

import com.amuletmod.entity.PageStormEntity;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/TempestClient.java and is ported in the client phase. */
public final class TempestClient {
   public static void broke(int casterId) {  }
   public static void building(int casterId, float build) {  }
   public static void started(PageStormEntity storm) {  }
}
