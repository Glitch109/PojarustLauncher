package com.amuletmod.client;

import com.amuletmod.entity.OfudaEntity;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/OfudaClient.java and is ported in the client phase. */
public final class OfudaClient {
   public static void strike(int writerId, int k) {  }
   public static void writing(OfudaEntity ofuda) {  }
}
