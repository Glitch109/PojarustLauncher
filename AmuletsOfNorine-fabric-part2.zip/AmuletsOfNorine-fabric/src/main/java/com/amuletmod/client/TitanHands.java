package com.amuletmod.client;

import java.util.UUID;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/TitanHands.java and is ported in the client phase. */
public final class TitanHands {
   public static void state(UUID player, int fists, int blades) {  }
}
