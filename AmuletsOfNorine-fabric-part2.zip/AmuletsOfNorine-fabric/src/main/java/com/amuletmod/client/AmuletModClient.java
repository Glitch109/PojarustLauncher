package com.amuletmod.client;

import com.amuletmod.network.ModNetwork;
import net.fabricmc.api.ClientModInitializer;

/**
 * Client entrypoint. The original client code (renderers, HUD, shaders, key mappings, screens) is still in
 * porting_pending/ and is ported in the client phase (see PORTING_STATUS.md).
 */
public class AmuletModClient implements ClientModInitializer {
   @Override
   public void onInitializeClient() {
      ModNetwork.registerClientReceivers();
   }
}
