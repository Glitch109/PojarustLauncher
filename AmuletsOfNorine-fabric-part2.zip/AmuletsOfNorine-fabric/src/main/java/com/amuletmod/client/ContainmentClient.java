package com.amuletmod.client;

import com.amuletmod.entity.ContainmentEntity;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ContainmentClient.java and is ported in the client phase. */
public final class ContainmentClient {
   public static void tick(ContainmentEntity walls) {  }
}
