package com.amuletmod.client;

import com.amuletmod.entity.TitanBladeEntity;
import com.amuletmod.entity.TitanSlashEntity;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/TitanBladeClient.java and is ported in the client phase. */
public final class TitanBladeClient {
   public static void fired(TitanBladeEntity blade) {  }
   public static void tickBlade(TitanBladeEntity blade) {  }
   public static void tickSlash(TitanSlashEntity slash) {  }
}
