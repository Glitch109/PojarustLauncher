package com.amuletmod.client;

import com.amuletmod.amulet.ability.strike.StrikeTarget;
import org.jetbrains.annotations.Nullable;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/StrikeTargetMarker.java and is ported in the client phase. */
public final class StrikeTargetMarker {
   public static void update(@Nullable StrikeTarget newTarget) {  }
}
