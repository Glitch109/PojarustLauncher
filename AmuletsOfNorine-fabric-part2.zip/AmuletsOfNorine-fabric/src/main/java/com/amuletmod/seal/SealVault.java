package com.amuletmod.seal;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedData.Factory;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public final class SealVault extends SavedData {
   private static final String NAME = "amuletmod_seals";
   private final Map<UUID, SealVault.Seal> seals = new HashMap<>();
   private final Map<UUID, SealVault.Seal> byPrisoner = new HashMap<>();

   private SealVault() {
   }

   public static SealVault get(MinecraftServer server) {
      return (SealVault)server.overworld().getDataStorage().computeIfAbsent(new Factory(SealVault::new, SealVault::load, null), "amuletmod_seals");
   }

   @Nullable
   public SealVault.Seal seal(UUID id) {
      return this.seals.get(id);
   }

   @Nullable
   public SealVault.Seal ofPrisoner(UUID prisoner) {
      return this.byPrisoner.get(prisoner);
   }

   public Collection<SealVault.Seal> seals() {
      return this.seals.values();
   }

   public SealVault.Seal create(UUID prisoner, String prisonerName, UUID captor, String captorName, float coreHealth) {
      int cell = 0;

      while (this.occupied(cell)) {
         cell++;
      }

      SealVault.Seal seal = new SealVault.Seal(UUID.randomUUID(), prisoner, prisonerName, captor, captorName, cell, coreHealth);
      this.seals.put(seal.id, seal);
      this.byPrisoner.put(prisoner, seal);
      this.setDirty();
      return seal;
   }

   private boolean occupied(int cell) {
      for (SealVault.Seal seal : this.seals.values()) {
         if (seal.cell == cell) {
            return true;
         }
      }

      return false;
   }

   public void remove(SealVault.Seal seal) {
      this.seals.remove(seal.id);
      this.byPrisoner.remove(seal.prisoner, seal);
      this.setDirty();
   }

   public CompoundTag save(CompoundTag tag, Provider registries) {
      ListTag list = new ListTag();
      this.seals.values().forEach(seal -> list.add(seal.save()));
      tag.put("Seals", list);
      return tag;
   }

   private static SealVault load(CompoundTag tag, Provider registries) {
      SealVault vault = new SealVault();
      ListTag list = tag.getList("Seals", 10);

      for (int i = 0; i < list.size(); i++) {
         CompoundTag saved = list.getCompound(i);
         if (saved.hasUUID("Id") && saved.hasUUID("Prisoner") && saved.hasUUID("Captor")) {
            SealVault.Seal seal = SealVault.Seal.load(saved);
            vault.seals.put(seal.id, seal);
            vault.byPrisoner.put(seal.prisoner, seal);
         }
      }

      return vault;
   }

   private static CompoundTag place(ResourceKey<Level> dimension, Vec3 pos) {
      CompoundTag tag = new CompoundTag();
      tag.putString("dimension", dimension.location().toString());
      tag.putDouble("x", pos.x);
      tag.putDouble("y", pos.y);
      tag.putDouble("z", pos.z);
      return tag;
   }

   private static ResourceKey<Level> dimension(CompoundTag tag) {
      Identifier id = Identifier.tryParse(tag.getString("dimension"));
      return id == null ? Level.OVERWORLD : ResourceKey.create(Registries.DIMENSION, id);
   }

   private static Vec3 pos(CompoundTag tag) {
      return new Vec3(tag.getDouble("x"), tag.getDouble("y"), tag.getDouble("z"));
   }

   public static final class Seal {
      public final UUID id;
      public final UUID prisoner;
      public final String prisonerName;
      public final UUID captor;
      public final String captorName;
      public final int cell;
      public final float coreHealth;
      public ResourceKey<Level> originDimension = Level.OVERWORLD;
      public Vec3 origin = Vec3.ZERO;
      public int previousMode;
      public boolean arrived;
      public boolean cubeDropped;
      @Nullable
      public UUID cubeHolder;
      public ResourceKey<Level> cubeDimension = Level.OVERWORLD;
      public Vec3 cubeAt = Vec3.ZERO;
      public boolean releasing;
      public boolean toSpawn;
      public ResourceKey<Level> releaseDimension = Level.OVERWORLD;
      public Vec3 releaseAt = Vec3.ZERO;
      public String reason = "";

      Seal(UUID id, UUID prisoner, String prisonerName, UUID captor, String captorName, int cell, float coreHealth) {
         this.id = id;
         this.prisoner = prisoner;
         this.prisonerName = prisonerName;
         this.captor = captor;
         this.captorName = captorName;
         this.cell = cell;
         this.coreHealth = coreHealth;
      }

      public void sight(Entity holder) {
         this.cubeDropped = holder instanceof ItemEntity;
         this.cubeHolder = holder.getUUID();
         this.cubeDimension = holder.level().dimension();
         this.cubeAt = holder.position();
      }

      CompoundTag save() {
         CompoundTag tag = new CompoundTag();
         tag.putUUID("Id", this.id);
         tag.putUUID("Prisoner", this.prisoner);
         tag.putString("PrisonerName", this.prisonerName);
         tag.putUUID("Captor", this.captor);
         tag.putString("CaptorName", this.captorName);
         tag.putInt("Cell", this.cell);
         tag.putFloat("CoreHealth", this.coreHealth);
         tag.put("Origin", SealVault.place(this.originDimension, this.origin));
         tag.putInt("PreviousMode", this.previousMode);
         tag.putBoolean("Arrived", this.arrived);
         tag.putBoolean("CubeDropped", this.cubeDropped);
         if (this.cubeHolder != null) {
            tag.putUUID("CubeHolder", this.cubeHolder);
         }

         tag.put("Cube", SealVault.place(this.cubeDimension, this.cubeAt));
         tag.putBoolean("Releasing", this.releasing);
         tag.putBoolean("ToSpawn", this.toSpawn);
         tag.put("Release", SealVault.place(this.releaseDimension, this.releaseAt));
         tag.putString("Reason", this.reason);
         return tag;
      }

      static SealVault.Seal load(CompoundTag tag) {
         SealVault.Seal seal = new SealVault.Seal(
            tag.getUUID("Id"),
            tag.getUUID("Prisoner"),
            tag.getString("PrisonerName"),
            tag.getUUID("Captor"),
            tag.getString("CaptorName"),
            tag.getInt("Cell"),
            tag.getFloat("CoreHealth")
         );
         seal.originDimension = SealVault.dimension(tag.getCompound("Origin"));
         seal.origin = SealVault.pos(tag.getCompound("Origin"));
         seal.previousMode = tag.getInt("PreviousMode");
         seal.arrived = tag.getBoolean("Arrived");
         seal.cubeDropped = tag.getBoolean("CubeDropped");
         seal.cubeHolder = tag.hasUUID("CubeHolder") ? tag.getUUID("CubeHolder") : null;
         seal.cubeDimension = SealVault.dimension(tag.getCompound("Cube"));
         seal.cubeAt = SealVault.pos(tag.getCompound("Cube"));
         seal.releasing = tag.getBoolean("Releasing");
         seal.toSpawn = tag.getBoolean("ToSpawn");
         seal.releaseDimension = SealVault.dimension(tag.getCompound("Release"));
         seal.releaseAt = SealVault.pos(tag.getCompound("Release"));
         seal.reason = tag.getString("Reason");
         return seal;
      }
   }
}
