package com.amuletmod.seal;

import com.amuletmod.registry.ModBlocks;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

public class SealBarrierBlock extends Block implements EntityBlock, SimpleWaterloggedBlock {
   public static final DirectionProperty FACING = BlockStateProperties.FACING;
   public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;
   private static final Map<Direction, VoxelShape> SHAPES = new EnumMap<>(Direction.class);

   public SealBarrierBlock(Properties properties) {
      super(properties);
      this.registerDefaultState((BlockState)((BlockState)((BlockState)this.stateDefinition.any()).setValue(FACING, Direction.UP)).setValue(WATERLOGGED, false));
   }

   public static Block block() {
      return (Block)ModBlocks.SEAL_BARRIER.get();
   }

   public static boolean canSeal(BlockGetter level, BlockPos pos, BlockState state) {
      return !state.hasBlockEntity() && !state.is(block()) && state.getCollisionShape(level, pos).isEmpty();
   }

   public static boolean seal(ServerLevel level, BlockPos pos, Direction facing, int ticks) {
      BlockState old = level.getBlockState(pos);
      if (!canSeal(level, pos, old)) {
         return false;
      } else {
         boolean water = old.getFluidState().isSourceOfType(Fluids.WATER);
         BlockState pane = (BlockState)((BlockState)block().defaultBlockState().setValue(FACING, facing)).setValue(WATERLOGGED, water);
         if (!level.setBlock(pos, pane, 18)) {
            return false;
         } else {
            if (!old.isAir() && (!water || !old.is(Blocks.WATER))) {
               level.setBlockEntity(new SealBarrierBlockEntity(pos, pane, old));
            }

            level.scheduleTick(pos, pane.getBlock(), ticks);
            return true;
         }
      }
   }

   public static void dissolve(ServerLevel level, BlockPos pos) {
      BlockState state = level.getBlockState(pos);
      if (state.is(block())) {
         BlockState restored = state.getValue(WATERLOGGED) ? Blocks.WATER.defaultBlockState() : Blocks.AIR.defaultBlockState();
         if (level.getBlockEntity(pos) instanceof SealBarrierBlockEntity held) {
            restored = held.replaced();
         }

         level.setBlock(pos, restored, 3);
      }
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{FACING, WATERLOGGED});
   }

   public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
      dissolve(level, pos);
   }

   public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      return SHAPES.get(state.getValue(FACING));
   }

   public VoxelShape getVisualShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      return Shapes.empty();
   }

   public RenderShape getRenderShape(BlockState state) {
      return RenderShape.INVISIBLE;
   }

   public boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
      return !(Boolean)state.getValue(WATERLOGGED);
   }

   public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
      return 1.0F;
   }

   protected boolean isPathfindable(BlockState state, PathComputationType type) {
      return false;
   }

   public FluidState getFluidState(BlockState state) {
      return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
   }

   public ItemStack getCloneItemStack(LevelReader level, BlockPos pos, BlockState state) {
      return ItemStack.EMPTY;
   }

   @Nullable
   public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      return null;
   }

   static {
      SHAPES.put(Direction.DOWN, box(0.0, 0.0, 0.0, 16.0, 2.0, 16.0));
      SHAPES.put(Direction.UP, box(0.0, 14.0, 0.0, 16.0, 16.0, 16.0));
      SHAPES.put(Direction.NORTH, box(0.0, 0.0, 0.0, 16.0, 16.0, 2.0));
      SHAPES.put(Direction.SOUTH, box(0.0, 0.0, 14.0, 16.0, 16.0, 16.0));
      SHAPES.put(Direction.WEST, box(0.0, 0.0, 0.0, 2.0, 16.0, 16.0));
      SHAPES.put(Direction.EAST, box(14.0, 0.0, 0.0, 16.0, 16.0, 16.0));
   }
}
