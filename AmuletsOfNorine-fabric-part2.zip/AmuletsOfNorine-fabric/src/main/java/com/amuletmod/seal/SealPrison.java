package com.amuletmod.seal;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.SealCoreEntity;
import com.amuletmod.network.FxPacket;
import com.amuletmod.util.ServerScheduler;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.Container;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.EndRodBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.level.portal.DimensionTransition;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.EventPriority;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.LivingDeathEvent;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;
import com.amuletmod.neo.event.PlayerEvent.PlayerLoggedInEvent;
import com.amuletmod.neo.event.ExplosionEvent.Detonate;
import com.amuletmod.neo.event.ServerStoppedEvent;
import com.amuletmod.neo.event.ServerTickEvent.Post;
import com.amuletmod.neo.PacketDistributor;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod"
)
public final class SealPrison {
   public static final ResourceKey<Level> REALM = ResourceKey.create(Registries.DIMENSION, AmuletMod.id("sealed_realm"));
   public static final float CORE_HEALTH_FACTOR = 4.0F;
   public static final int SHATTER_TICKS = 18;
   private static final int SPACING = 512;
   private static final int ROW = 64;
   private static final int FLOOR_Y = 64;
   private static final int WIDTH = 9;
   private static final int HEIGHT = 7;
   private static final int CHECK_TICKS = 10;
   private static final Set<UUID> CLOSING = new HashSet<>();
   private static int clock;

   private SealPrison() {
   }

   @Nullable
   public static ServerLevel realm(MinecraftServer server) {
      return server.getLevel(REALM);
   }

   public static boolean isImprisoned(ServerPlayer player) {
      return player.level().dimension() == REALM && SealVault.get(player.server).ofPrisoner(player.getUUID()) != null;
   }

   private static BlockPos corner(int cell) {
      return new BlockPos(Math.floorMod(cell, 64) * 512 + 3, 64, Math.floorDiv(cell, 64) * 512 + 3);
   }

   private static AABB room(int cell) {
      BlockPos corner = corner(cell);
      return new AABB(corner.getX() + 1, corner.getY() + 1, corner.getZ() + 1, corner.getX() + 9 - 1, corner.getY() + 7 - 1, corner.getZ() + 9 - 1);
   }

   private static Vec3 arrival(int cell) {
      return Vec3.atLowerCornerOf(corner(cell)).add(4.5, 1.0, 6.5);
   }

   public static Vec3 coreAt(int cell) {
      return Vec3.atLowerCornerOf(corner(cell)).add(4.5, 1.55, 4.5);
   }

   private static void build(ServerLevel realm, SealVault.Seal seal) {
      BlockPos corner = corner(seal.cell);
      realm.getChunk(corner.getX() >> 4, corner.getZ() >> 4);
      empty(realm, seal.cell);
      int last = 8;
      int top = 6;
      int middle = 4;

      for (int x = 0; x <= last; x++) {
         for (int y = 0; y <= top; y++) {
            for (int z = 0; z <= last; z++) {
               boolean edgeX = x == 0 || x == last;
               boolean edgeZ = z == 0 || z == last;
               boolean heart = Math.abs(x - middle) <= 1 && Math.abs(z - middle) <= 1;
               BlockState state;
               if (edgeX && edgeZ) {
                  state = Blocks.PURPUR_PILLAR.defaultBlockState();
               } else if (edgeX || edgeZ) {
                  state = y != top / 2 || x != middle && z != middle ? Blocks.PURPUR_BLOCK.defaultBlockState() : Blocks.CRYING_OBSIDIAN.defaultBlockState();
               } else if (y == 0) {
                  state = x == middle && z == middle
                     ? Blocks.CRYING_OBSIDIAN.defaultBlockState()
                     : (heart ? Blocks.OBSIDIAN.defaultBlockState() : Blocks.END_STONE_BRICKS.defaultBlockState());
               } else {
                  if (y != top) {
                     continue;
                  }

                  state = heart ? Blocks.PURPLE_STAINED_GLASS.defaultBlockState() : Blocks.PURPUR_BLOCK.defaultBlockState();
               }

               realm.setBlock(corner.offset(x, y, z), state, 2);
            }
         }
      }

      BlockState lamp = (BlockState)Blocks.END_ROD.defaultBlockState().setValue(EndRodBlock.FACING, Direction.DOWN);

      for (int x : new int[]{2, last - 2}) {
         for (int z : new int[]{2, last - 2}) {
            realm.setBlock(corner.offset(x, top - 1, z), lamp, 2);
         }
      }

      BlockState bed = (BlockState)Blocks.PURPLE_BED.defaultBlockState().setValue(BedBlock.FACING, Direction.NORTH);
      realm.setBlock(corner.offset(1, 1, 2), (BlockState)bed.setValue(BedBlock.PART, BedPart.FOOT), 2);
      realm.setBlock(corner.offset(1, 1, 1), (BlockState)bed.setValue(BedBlock.PART, BedPart.HEAD), 2);
      realm.setBlock(corner.offset(last - 1, 1, 1), (BlockState)Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.SOUTH), 2);
      realm.addFreshEntity(
         new SealCoreEntity(
            realm, seal.id, coreAt(seal.cell), seal.coreHealth, Component.translatable("entity.amuletmod.seal_core.of", new Object[]{seal.captorName})
         )
      );
   }

   private static List<ItemStack> empty(ServerLevel realm, int cell) {
      BlockPos corner = corner(cell);
      realm.getChunk(corner.getX() >> 4, corner.getZ() >> 4);
      List<ItemStack> loot = new ArrayList<>();
      AABB shell = new AABB(Vec3.atLowerCornerOf(corner), Vec3.atLowerCornerOf(corner.offset(9, 7, 9)));

      for (Entity entity : realm.getEntities((Entity)null, shell, entityx -> !(entityx instanceof Player))) {
         if (entity instanceof ItemEntity item && !item.getItem().isEmpty()) {
            loot.add(item.getItem().copy());
         }

         entity.discard();
      }

      for (BlockPos pos : BlockPos.betweenClosed(corner, corner.offset(8, 6, 8))) {
         if (!realm.getBlockState(pos).isAir()) {
            if (realm.getBlockEntity(pos) instanceof Container container) {
               for (int slot = 0; slot < container.getContainerSize(); slot++) {
                  ItemStack stack = container.removeItemNoUpdate(slot);
                  if (!stack.isEmpty()) {
                     loot.add(stack);
                  }
               }
            }

            realm.setBlock(pos, Blocks.AIR.defaultBlockState(), 2);
         }
      }

      return loot;
   }

   @Nullable
   public static UUID imprison(ServerPlayer captor, ServerPlayer victim) {
      MinecraftServer server = victim.server;
      SealVault vault = SealVault.get(server);
      if (realm(server) != null && vault.ofPrisoner(victim.getUUID()) == null) {
         SealVault.Seal seal = vault.create(
            victim.getUUID(), victim.getGameProfile().getName(), captor.getUUID(), captor.getGameProfile().getName(), captor.getMaxHealth() * 4.0F
         );
         seal.originDimension = victim.level().dimension();
         seal.origin = victim.position();
         seal.sight(captor);
         UUID id = seal.id;
         CLOSING.add(id);
         ServerScheduler.schedule(1, () -> carryOff(server, id));
         return id;
      } else {
         return null;
      }
   }

   private static void carryOff(MinecraftServer server, UUID id) {
      CLOSING.remove(id);
      SealVault vault = SealVault.get(server);
      SealVault.Seal seal = vault.seal(id);
      ServerLevel realm = realm(server);
      if (seal != null) {
         ServerPlayer victim = server.getPlayerList().getPlayer(seal.prisoner);
         if (realm != null && victim != null && victim.isAlive() && !seal.releasing) {
            build(realm, seal);
            victim.stopRiding();
            victim.ejectPassengers();
            if (victim.isSleeping()) {
               victim.stopSleepInBed(true, true);
            }

            victim.closeContainer();
            Vec3 to = arrival(seal.cell);
            victim.teleportTo(realm, to.x, to.y, to.z, 180.0F, 0.0F);
            victim.setDeltaMovement(Vec3.ZERO);
            victim.resetFallDistance();
            seal.previousMode = victim.gameMode.getGameModeForPlayer().getId();
            victim.setGameMode(GameType.ADVENTURE);
            seal.arrived = true;
            vault.setDirty();
            PacketDistributor.sendToPlayer(victim, new FxPacket(FxPacket.Kind.SEAL_VIGNETTE, to, 1.0F), new CustomPacketPayload[0]);
            Sounds.play(realm, to, SoundEvents.SHULKER_BOX_CLOSE, 1.0F, 0.5F);
            Sounds.play(realm, to, SoundEvents.IRON_DOOR_CLOSE, 1.0F, 0.5F);
            Sounds.play(realm, to, SoundEvents.BELL_RESONATE, 0.6F, 0.6F);
            victim.displayClientMessage(
               Component.translatable("message.amuletmod.sealed_in", new Object[]{seal.captorName}).withStyle(ChatFormatting.LIGHT_PURPLE), false
            );
         } else {
            vault.remove(seal);
         }
      }
   }

   public static boolean sighting(MinecraftServer server, UUID id, Entity holder) {
      SealVault vault = SealVault.get(server);
      SealVault.Seal seal = vault.seal(id);
      if (seal != null && !seal.releasing) {
         seal.sight(holder);
         vault.setDirty();
         return true;
      } else {
         return false;
      }
   }

   @Nullable
   public static String prisonerName(MinecraftServer server, UUID id) {
      SealVault.Seal seal = SealVault.get(server).seal(id);
      return seal != null && !seal.releasing ? seal.prisonerName : null;
   }

   public static boolean open(MinecraftServer server, UUID id, ServerLevel level, Vec3 at) {
      SealVault.Seal seal = SealVault.get(server).seal(id);
      if (seal != null && !seal.releasing) {
         release(server, seal, new SealPrison.Place(level.dimension(), at), SealPrison.Reason.OPENED);
         return true;
      } else {
         return false;
      }
   }

   public static void cubeDestroyed(MinecraftServer server, UUID id) {
      SealVault.Seal seal = SealVault.get(server).seal(id);
      if (seal != null && !seal.releasing) {
         release(server, seal, null, SealPrison.Reason.DESTROYED);
      }
   }

   public static boolean pardon(ServerPlayer prisoner) {
      SealVault.Seal seal = SealVault.get(prisoner.server).ofPrisoner(prisoner.getUUID());
      if (seal != null && !seal.releasing) {
         release(prisoner.server, seal, new SealPrison.Place(seal.originDimension, seal.origin), SealPrison.Reason.PARDONED);
         return true;
      } else {
         return false;
      }
   }

   public static void coreBroken(MinecraftServer server, UUID id) {
      SealVault.Seal seal = SealVault.get(server).seal(id);
      if (seal != null && !seal.releasing) {
         ServerLevel last = server.getLevel(seal.cubeDimension);
         SealPrison.Place place = new SealPrison.Place(seal.cubeDimension, seal.cubeAt);
         if (seal.cubeHolder != null && !seal.cubeDropped) {
            ServerPlayer holder = server.getPlayerList().getPlayer(seal.cubeHolder);
            if (holder != null && SealCubeItem.take(holder, id)) {
               place = new SealPrison.Place(holder.level().dimension(), holder.position());
               holder.displayClientMessage(
                  Component.translatable("message.amuletmod.seal_broke_out", new Object[]{seal.prisonerName}).withStyle(ChatFormatting.RED), false
               );
            }
         } else if (seal.cubeHolder != null
            && last != null
            && last.getEntity(seal.cubeHolder) instanceof ItemEntity item
            && id.equals(SealCubeItem.sealOf(item.getItem()))) {
            place = new SealPrison.Place(last.dimension(), item.position());
            item.discard();
         }

         release(server, seal, place, SealPrison.Reason.ESCAPED);
         ServerPlayer prisoner = server.getPlayerList().getPlayer(seal.prisoner);
         if (prisoner != null) {
            PacketDistributor.sendToPlayer(prisoner, new FxPacket(FxPacket.Kind.SEAL_FLASH, prisoner.position(), 1.0F), new CustomPacketPayload[0]);
         }
      }
   }

   private static void release(MinecraftServer server, SealVault.Seal seal, @Nullable SealPrison.Place place, SealPrison.Reason reason) {
      seal.releasing = true;
      seal.toSpawn = place == null;
      if (place != null) {
         seal.releaseDimension = place.dimension();
         seal.releaseAt = place.pos();
      }

      seal.reason = reason.name();
      SealVault.get(server).setDirty();
      UUID id = seal.id;
      if (server.getPlayerList().getPlayer(seal.prisoner) != null) {
         ServerScheduler.schedule(reason == SealPrison.Reason.ESCAPED ? 18 : 1, () -> finish(server, id));
      }
   }

   private static void finish(MinecraftServer server, UUID id) {
      SealVault vault = SealVault.get(server);
      SealVault.Seal seal = vault.seal(id);
      if (seal != null) {
         ServerPlayer prisoner = server.getPlayerList().getPlayer(seal.prisoner);
         if (prisoner != null) {
            vault.remove(seal);
            if (seal.arrived) {
               ServerLevel realm = realm(server);
               List<ItemStack> loot = realm == null ? List.of() : empty(realm, seal.cell);
               GameType mode = GameType.byId(seal.previousMode);
               if (prisoner.gameMode.getGameModeForPlayer() == GameType.ADVENTURE && mode != GameType.ADVENTURE) {
                  prisoner.setGameMode(mode);
               }

               SealPrison.Place place = seal.toSpawn ? spawnOf(prisoner) : new SealPrison.Place(seal.releaseDimension, seal.releaseAt);
               ServerLevel to = server.getLevel(place.dimension());
               if (to == null) {
                  place = spawnOf(prisoner);
                  to = server.overworld();
               }

               Vec3 at = seal.toSpawn ? place.pos() : settle(to, place.pos(), prisoner);
               if (prisoner.isAlive()) {
                  prisoner.stopRiding();
                  prisoner.teleportTo(to, at.x, at.y, at.z, prisoner.getYRot(), 0.0F);
                  prisoner.setDeltaMovement(Vec3.ZERO);
                  prisoner.resetFallDistance();
                  arrive(to, at, prisoner.getBbHeight());
               }

               for (ItemStack stack : loot) {
                  ItemEntity item = new ItemEntity(to, at.x, at.y + 0.5, at.z, stack);
                  item.setDefaultPickUpDelay();
                  to.addFreshEntity(item);
               }
               String told = switch (SealPrison.Reason.valueOf(seal.reason)) {
                  case ESCAPED -> "message.amuletmod.seal_escaped";
                  case OPENED -> "message.amuletmod.seal_opened";
                  case DESTROYED -> "message.amuletmod.seal_destroyed";
                  case DIED -> null;
                  case PARDONED -> "message.amuletmod.seal_pardoned";
               };
               if (told != null) {
                  prisoner.displayClientMessage(Component.translatable(told).withStyle(ChatFormatting.LIGHT_PURPLE), false);
               }
            }
         }
      }
   }

   public static void arrive(ServerLevel level, Vec3 feet, float height) {
      PacketDistributor.sendToPlayersNear(
         level, null, feet.x, feet.y, feet.z, 64.0, new FxPacket(FxPacket.Kind.SEAL_RELEASE, feet, height), new CustomPacketPayload[0]
      );
      level.sendParticles(ParticleTypes.END_ROD, feet.x, feet.y + height * 0.5, feet.z, 24, 0.3, height * 0.3, 0.3, 0.08);
      level.sendParticles(ParticleTypes.REVERSE_PORTAL, feet.x, feet.y + height * 0.5, feet.z, 40, 0.3, height * 0.3, 0.3, 0.06);
      Sounds.play(level, feet, SoundEvents.SHULKER_BOX_OPEN, 1.0F, 0.6F);
      Sounds.play(level, feet, SoundEvents.ENDER_CHEST_OPEN, 0.8F, 1.4F);
      Sounds.play(level, feet, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0F, 1.2F);
      Sounds.play(level, feet, SoundEvents.GLASS_BREAK, 0.6F, 1.4F);
      Sounds.play(level, feet, SoundEvents.ENDERMAN_TELEPORT, 0.5F, 0.6F);
   }

   private static SealPrison.Place spawnOf(ServerPlayer player) {
      MinecraftServer server = player.server;
      BlockPos respawn = player.getRespawnPosition();
      ServerLevel level = respawn == null ? null : server.getLevel(player.getRespawnDimension());
      if (respawn != null && level != null) {
         DimensionTransition spot = player.findRespawnPositionAndUseSpawnBlock(true, DimensionTransition.DO_NOTHING);
         if (!spot.missingRespawnBlock()) {
            return new SealPrison.Place(spot.newLevel().dimension(), spot.pos());
         }
      }

      ServerLevel overworld = server.overworld();
      BlockPos spawn = overworld.getSharedSpawnPos();
      int y = overworld.getChunk(spawn.getX() >> 4, spawn.getZ() >> 4).getHeight(Types.MOTION_BLOCKING_NO_LEAVES, spawn.getX() & 15, spawn.getZ() & 15) + 1;
      return new SealPrison.Place(Level.OVERWORLD, new Vec3(spawn.getX() + 0.5, y, spawn.getZ() + 0.5));
   }

   private static Vec3 settle(ServerLevel level, Vec3 at, ServerPlayer player) {
      for (int up = 0; up <= 8; up++) {
         Vec3 spot = at.add(0.0, up, 0.0);
         if (level.noCollision(player.getDimensions(player.getPose()).makeBoundingBox(spot))) {
            return spot;
         }
      }

      return at;
   }

   @SubscribeEvent
   public static void onServerTick(Post event) {
      if (++clock % 10 == 0) {
         MinecraftServer server = event.getServer();
         ServerLevel realm = realm(server);
         if (realm != null) {
            SealVault vault = SealVault.get(server);
            if (!vault.seals().isEmpty() || !realm.players().isEmpty()) {
               for (SealVault.Seal seal : List.copyOf(vault.seals())) {
                  if (!seal.arrived && !CLOSING.contains(seal.id)) {
                     vault.remove(seal);
                  }
               }

               for (SealVault.Seal sealx : vault.seals()) {
                  if (sealx.arrived && !sealx.releasing) {
                     ServerPlayer prisoner = server.getPlayerList().getPlayer(sealx.prisoner);
                     if (prisoner != null && prisoner.isAlive() && (prisoner.level() != realm || !room(sealx.cell).inflate(0.5).contains(prisoner.position()))) {
                        Vec3 to = arrival(sealx.cell);
                        prisoner.stopRiding();
                        prisoner.teleportTo(realm, to.x, to.y, to.z, 180.0F, 0.0F);
                        prisoner.setDeltaMovement(Vec3.ZERO);
                        prisoner.resetFallDistance();
                        Sounds.play(realm, to, SoundEvents.SHULKER_BOX_CLOSE, 1.0F, 0.5F);
                     }
                  }
               }

               for (ServerPlayer stray : List.copyOf(realm.players())) {
                  if (!stray.isCreative() && !stray.isSpectator() && stray.isAlive() && vault.ofPrisoner(stray.getUUID()) == null) {
                     SealPrison.Place place = spawnOf(stray);
                     ServerLevel to = server.getLevel(place.dimension());
                     if (to != null) {
                        stray.teleportTo(to, place.pos().x, place.pos().y, place.pos().z, stray.getYRot(), 0.0F);
                        stray.resetFallDistance();
                        if (stray.gameMode.getGameModeForPlayer() == GameType.ADVENTURE) {
                           stray.setGameMode(server.getDefaultGameType());
                        }

                        stray.displayClientMessage(Component.translatable("message.amuletmod.seal_stray").withStyle(ChatFormatting.LIGHT_PURPLE), false);
                     }
                  }
               }
            }
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGH
   )
   public static void onLivingAttack(LivingIncomingDamageEvent event) {
      if (event.getEntity() instanceof ServerPlayer player && !event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY) && isImprisoned(player)) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public static void onLivingDeath(LivingDeathEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         SealVault.Seal seal = SealVault.get(player.server).ofPrisoner(player.getUUID());
         if (seal != null && !seal.releasing) {
            release(player.server, seal, null, SealPrison.Reason.DIED);
         }
      }
   }

   @SubscribeEvent
   public static void onLogin(PlayerLoggedInEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         MinecraftServer server = player.server;
         SealVault.Seal seal = SealVault.get(server).ofPrisoner(player.getUUID());
         if (seal != null && seal.releasing) {
            UUID id = seal.id;
            ServerScheduler.schedule(10, () -> finish(server, id));
         }
      }
   }

   @SubscribeEvent
   public static void onExplosion(Detonate event) {
      if (!event.getLevel().isClientSide() && event.getLevel().dimension() == REALM) {
         event.getAffectedBlocks().clear();
      }
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      CLOSING.clear();
   }

   public record Place(ResourceKey<Level> dimension, Vec3 pos) {
   }

   public static enum Reason {
      ESCAPED,
      OPENED,
      DESTROYED,
      DIED,
      PARDONED;
   }
}
