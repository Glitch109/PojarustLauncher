package com.amuletmod.seal;

import com.amuletmod.amulet.ability.sovereign.AuraSight;
import com.amuletmod.registry.ModItems;
import com.amuletmod.util.ServerScheduler;
import com.amuletmod.util.Sounds;
import com.amuletmod.util.StackData;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.EntityLeaveLevelEvent;
import com.amuletmod.neo.event.ItemExpireEvent;
import org.jetbrains.annotations.Nullable;

public class SealCubeItem extends Item {
   private static final String CAPTIVE_KEY = "Captive";
   private static final String SEAL_KEY = "Seal";
   private static final String ENTITY_KEY = "Entity";
   private static final int MAX_BYTES = 262144;
   private static final int SIGHT_TICKS = 10;
   private static final double VOID_DEPTH = 32.0;

   public SealCubeItem(Properties properties) {
      super(properties);
   }

   @Nullable
   public static ItemStack ofCreature(Mob mob, ServerPlayer captor) {
      if (!mob.getType().canSerialize()) {
         return null;
      } else {
         CompoundTag saved = new CompoundTag();
         mob.saveWithoutId(saved);
         saved.putString("id", String.valueOf(EntityType.getKey(mob.getType())));
         if (size(saved) > 262144) {
            return null;
         } else {
            CompoundTag captive = describe(mob, captor);
            captive.put("Entity", saved);
            ItemStack stack = new ItemStack((ItemLike)ModItems.SEAL_CUBE.get());
            StackData.putElement(stack, "Captive", captive);
            return stack;
         }
      }
   }

   public static ItemStack ofPlayer(UUID id, ServerPlayer victim, ServerPlayer captor) {
      CompoundTag captive = describe(victim, captor);
      captive.putUUID("Seal", id);
      ItemStack stack = new ItemStack((ItemLike)ModItems.SEAL_CUBE.get());
      StackData.putElement(stack, "Captive", captive);
      return stack;
   }

   private static CompoundTag describe(LivingEntity captive, ServerPlayer captor) {
      CompoundTag tag = new CompoundTag();
      tag.putString("Name", captive.getName().getString());
      tag.putString("Type", String.valueOf(EntityType.getKey(captive.getType())));
      tag.putFloat("Health", captive.getHealth());
      tag.putFloat("MaxHealth", captive.getMaxHealth());
      tag.putInt("Rank", AuraSight.rank(AuraSight.power(captive)));
      tag.putString("Captor", captor.getGameProfile().getName());
      return tag;
   }

   private static int size(CompoundTag tag) {
      ByteArrayOutputStream bytes = new ByteArrayOutputStream();

      try (DataOutputStream out = new DataOutputStream(bytes)) {
         NbtIo.write(tag, out);
      } catch (IOException var7) {
         return Integer.MAX_VALUE;
      }

      return bytes.size();
   }

   @Nullable
   private static CompoundTag captive(ItemStack stack) {
      return stack.getItem() instanceof SealCubeItem ? StackData.getElement(stack, "Captive") : null;
   }

   @Nullable
   public static UUID sealOf(ItemStack stack) {
      CompoundTag captive = captive(stack);
      return captive != null && captive.hasUUID("Seal") ? captive.getUUID("Seal") : null;
   }

   public static boolean take(ServerPlayer holder, UUID id) {
      for (int slot = 0; slot < holder.getInventory().getContainerSize(); slot++) {
         if (id.equals(sealOf(holder.getInventory().getItem(slot)))) {
            holder.getInventory().setItem(slot, ItemStack.EMPTY);
            return true;
         }
      }

      if (id.equals(sealOf(holder.containerMenu.getCarried()))) {
         holder.containerMenu.setCarried(ItemStack.EMPTY);
         return true;
      } else {
         return false;
      }
   }

   public InteractionResult useOn(UseOnContext context) {
      if (captive(context.getItemInHand()) == null) {
         return InteractionResult.PASS;
      } else {
         if (context.getLevel() instanceof ServerLevel level && context.getPlayer() instanceof ServerPlayer player) {
            BlockPos clicked = context.getClickedPos();
            BlockPos into = level.getBlockState(clicked).getCollisionShape(level, clicked).isEmpty() ? clicked : clicked.relative(context.getClickedFace());
            open(level, player, context.getItemInHand(), Vec3.atBottomCenterOf(into));
         }

         return InteractionResult.SUCCESS;
      }
   }

   public InteractionResult use(Level world, Player user, InteractionHand hand) {
      ItemStack stack = user.getItemInHand(hand);
      if (captive(stack) == null) {
         return InteractionResult.PASS;
      } else {
         if (world instanceof ServerLevel level && user instanceof ServerPlayer player) {
            Vec3 ahead = player.getEyePosition().add(player.getLookAngle().scale(3.0));
            MutableBlockPos pos = BlockPos.containing(ahead).mutable();
            Vec3 at = ahead;
            int down = 0;

            while (down < 5) {
               if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) {
                  at = new Vec3(ahead.x, pos.getY() + 1.0, ahead.z);
                  break;
               }

               down++;
               pos.move(0, -1, 0);
            }

            open(level, player, stack, at);
         }

         return InteractionResult.SUCCESS;
      }
   }

   private static void open(ServerLevel level, ServerPlayer player, ItemStack stack, Vec3 at) {
      CompoundTag captive = captive(stack);
      if (captive != null) {
         UUID seal = sealOf(stack);
         String name = captive.getString("Name");
         if (seal != null) {
            if (!SealPrison.open(level.getServer(), seal, level, at)) {
               crumble(level, player.position().add(0.0, 1.0, 0.0), stack);
               player.displayClientMessage(Component.translatable("message.amuletmod.seal_cube_empty").withStyle(ChatFormatting.GRAY), true);
            } else if (level.getServer().getPlayerList().getPlayerByName(name) == null) {
               player.displayClientMessage(
                  Component.translatable("message.amuletmod.seal_cube_opened_away", new Object[]{name}).withStyle(ChatFormatting.LIGHT_PURPLE), true
               );
            } else {
               player.displayClientMessage(
                  Component.translatable("message.amuletmod.seal_cube_opened", new Object[]{name}).withStyle(ChatFormatting.LIGHT_PURPLE), true
               );
            }

            stack.shrink(1);
         } else {
            Entity freed = revive(level, captive.getCompound("Entity"), at, player.getYRot() + 180.0F);
            if (freed == null) {
               player.displayClientMessage(Component.translatable("message.amuletmod.seal_cube_stuck").withStyle(ChatFormatting.RED), true);
            } else {
               SealPrison.arrive(level, at, freed.getBbHeight());
               player.displayClientMessage(
                  Component.translatable("message.amuletmod.seal_cube_opened", new Object[]{freed.getDisplayName()}).withStyle(ChatFormatting.LIGHT_PURPLE),
                  true
               );
               stack.shrink(1);
            }
         }
      }
   }

   @Nullable
   private static Entity revive(ServerLevel level, CompoundTag saved, Vec3 at, float yaw) {
      if (saved.isEmpty()) {
         return null;
      } else {
         Entity entity = EntityType.loadEntityRecursive(saved.copy(), level, loaded -> {
            loaded.moveTo(at.x, at.y, at.z, yaw, 0.0F);
            return loaded;
         });
         if (entity == null) {
            return null;
         } else {
            if (level.getEntity(entity.getUUID()) != null) {
               entity.setUUID(Mth.createInsecureUUID(level.random));
            }

            entity.setDeltaMovement(Vec3.ZERO);
            entity.resetFallDistance();
            if (entity instanceof LivingEntity living) {
               living.yHeadRot = yaw;
               living.yBodyRot = yaw;
            }

            return level.tryAddFreshEntityWithPassengers(entity) ? entity : null;
         }
      }
   }

   private static void crumble(ServerLevel level, Vec3 at, ItemStack stack) {
      level.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, stack.copy()), at.x, at.y, at.z, 16, 0.15, 0.15, 0.15, 0.06);
      Sounds.play(level, at, SoundEvents.AMETHYST_CLUSTER_BREAK, 0.8F, 1.3F);
      Sounds.play(level, at, SoundEvents.ITEM_BREAK, 0.6F, 1.2F);
   }

   public void inventoryTick(ItemStack stack, Level level, Entity holder, int slot, boolean selected) {
      if (holder instanceof ServerPlayer player && (player.tickCount + slot) % 10 == 0) {
         UUID seal = sealOf(stack);
         if (seal != null && !SealPrison.sighting(player.server, seal, player)) {
            crumble(((ServerLevel) player.level()), player.position().add(0.0, 1.0, 0.0), stack);
            stack.shrink(1);
            player.displayClientMessage(Component.translatable("message.amuletmod.seal_cube_empty").withStyle(ChatFormatting.GRAY), true);
         }
      }
   }

   public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
      if (entity.level() instanceof ServerLevel level) {
         if (entity.getY() < level.getMinBuildHeight() - 32.0 && captive(stack) != null) {
            destroyed(entity);
            entity.discard();
            return true;
         } else {
            UUID seal = sealOf(stack);
            if (seal != null && entity.tickCount % 10 == 0 && !SealPrison.sighting(level.getServer(), seal, entity)) {
               crumble(level, entity.position(), stack);
               entity.discard();
               return true;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   public void onDestroyed(ItemEntity entity) {
      destroyed(entity);
   }

   private static void destroyed(ItemEntity entity) {
      ItemStack stack = entity.getItem();
      if (captive(stack) != null && entity.level() instanceof ServerLevel level) {
         spill(level, stack.copy(), entity.position(), entity.getYRot());
         StackData.remove(stack, "Captive");
      }
   }

   private static void spill(ServerLevel level, ItemStack stack, Vec3 at, float yaw) {
      CompoundTag captive = captive(stack);
      if (captive != null) {
         UUID seal = sealOf(stack);
         if (seal != null) {
            SealPrison.cubeDestroyed(level.getServer(), seal);
         } else {
            Entity freed = revive(level, captive.getCompound("Entity"), at, yaw);
            if (freed != null) {
               SealPrison.arrive(level, at, freed.getBbHeight());
            }
         }
      }
   }

   public boolean canFitInsideContainerItems() {
      return false;
   }

   public Component getName(ItemStack stack) {
      CompoundTag captive = captive(stack);
      return (Component)(captive == null
         ? super.getName(stack)
         : Component.translatable("item.amuletmod.seal_cube.holding", new Object[]{captive.getString("Name")}));
   }

   public boolean isFoil(ItemStack stack) {
      return captive(stack) != null;
   }

   public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
      CompoundTag captive = captive(stack);
      if (captive == null) {
         tooltip.add(Component.translatable("tooltip.amuletmod.seal_cube.empty").withStyle(new ChatFormatting[]{ChatFormatting.GRAY, ChatFormatting.ITALIC}));
      } else {
         boolean player = captive.hasUUID("Seal");
         Identifier type = Identifier.tryParse(captive.getString("Type"));
         EntityType<?> kind = type != null && BuiltInRegistries.ENTITY_TYPE.containsKey(type) ? (EntityType)BuiltInRegistries.ENTITY_TYPE.get(type) : null;
         if (!player && kind != null) {
            tooltip.add(Component.literal(" • ").append(kind.getDescription()).withStyle(ChatFormatting.BLUE));
         }

         tooltip.add(
            Component.literal(" • ")
               .append(
                  Component.translatable(
                     "tooltip.amuletmod.seal_cube.health",
                     new Object[]{
                        Math.round(captive.getFloat("Health")),
                        Math.round(captive.getFloat("MaxHealth")),
                        Component.translatable("aura.amuletmod.rank", new Object[]{AuraSight.rankName(captive.getInt("Rank"))})
                     }
                  )
               )
               .withStyle(ChatFormatting.BLUE)
         );
         tooltip.add(
            Component.literal(" • ")
               .append(Component.translatable("tooltip.amuletmod.seal_cube.captor", new Object[]{captive.getString("Captor")}))
               .withStyle(ChatFormatting.BLUE)
         );
         tooltip.add(Component.translatable("tooltip.amuletmod.seal_cube.open").withStyle(ChatFormatting.YELLOW));
         tooltip.add(
            Component.translatable(player ? "tooltip.amuletmod.seal_cube.player" : "tooltip.amuletmod.seal_cube.creature")
               .withStyle(new ChatFormatting[]{ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC})
         );
      }
   }

   @EventBusSubscriber(
      modid = "amuletmod"
   )
   public static final class SealCubeEvents {
      private SealCubeEvents() {
      }

      @SubscribeEvent
      public static void onItemExpire(ItemExpireEvent event) {
         SealCubeItem.destroyed(event.getEntity());
      }

      @SubscribeEvent
      public static void onEntityLeave(EntityLeaveLevelEvent event) {
         if (event.getEntity() instanceof ItemEntity item
            && item.getRemovalReason() == RemovalReason.KILLED
            && SealCubeItem.captive(item.getItem()) != null
            && item.level() instanceof ServerLevel level) {
            ItemStack var7 = item.getItem().copy();
            Vec3 at = item.position();
            float yaw = item.getYRot();
            ServerScheduler.schedule(1, () -> SealCubeItem.spill(level, var7, at, yaw));
         }
      }
   }
}
