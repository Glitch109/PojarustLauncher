package com.amuletmod.seal;

import com.amuletmod.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

public class SealBarrierBlockEntity extends BlockEntity {
   private static final String REPLACED_KEY = "Replaced";
   private BlockState replaced = Blocks.AIR.defaultBlockState();

   public SealBarrierBlockEntity(BlockPos pos, BlockState state) {
      super((BlockEntityType)ModBlockEntities.SEAL_BARRIER.get(), pos, state);
   }

   public SealBarrierBlockEntity(BlockPos pos, BlockState state, BlockState replaced) {
      this(pos, state);
      this.replaced = replaced;
   }

   public BlockState replaced() {
      return this.replaced;
   }

   protected void saveAdditional(CompoundTag tag, Provider registries) {
      super.saveAdditional(tag, registries);
      tag.put("Replaced", NbtUtils.writeBlockState(this.replaced));
   }

   protected void loadAdditional(CompoundTag tag, Provider registries) {
      super.loadAdditional(tag, registries);
      this.replaced = NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), tag.getCompound("Replaced"));
   }
}
