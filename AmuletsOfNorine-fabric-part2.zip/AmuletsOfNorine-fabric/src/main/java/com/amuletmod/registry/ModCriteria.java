package com.amuletmod.registry;

import com.amuletmod.advancement.FeatTrigger;
import net.minecraft.advancements.CriterionTrigger;
import net.minecraft.core.registries.Registries;
import com.amuletmod.neo.registry.DeferredRegister;

public final class ModCriteria {
   public static final DeferredRegister<CriterionTrigger<?>> TRIGGER_TYPES = DeferredRegister.create(Registries.TRIGGER_TYPE, "amuletmod");
   public static final FeatTrigger FEAT = new FeatTrigger();

   private ModCriteria() {
   }

   static {
      TRIGGER_TYPES.register("feat", () -> FEAT);
   }
}
