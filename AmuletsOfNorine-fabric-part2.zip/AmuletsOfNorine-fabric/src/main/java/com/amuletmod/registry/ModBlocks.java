package com.amuletmod.registry;

import com.amuletmod.seal.SealBarrierBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import com.amuletmod.neo.registry.DeferredBlock;
import com.amuletmod.neo.registry.DeferredRegister;
import com.amuletmod.neo.registry.DeferredRegister.Blocks;

public final class ModBlocks {
   public static final Blocks BLOCKS = DeferredRegister.createBlocks("amuletmod");
   public static final DeferredBlock<SealBarrierBlock> SEAL_BARRIER = BLOCKS.register(
      "seal_barrier",
      () -> new SealBarrierBlock(
         Properties.of().setId(DeferredRegister.currentKey())
            .mapColor(MapColor.NONE)
            .strength(-1.0F, 3600000.0F)
            .sound(SoundType.AMETHYST)
            .noLootTable()
            .noOcclusion()
            .forceSolidOn()
            .pushReaction(PushReaction.BLOCK)
            .isValidSpawn((state, level, pos, type) -> false)
            .isSuffocating((state, level, pos) -> false)
            .isViewBlocking((state, level, pos) -> false)
            .noTerrainParticles()
      )
   );

   private ModBlocks() {
   }
}
