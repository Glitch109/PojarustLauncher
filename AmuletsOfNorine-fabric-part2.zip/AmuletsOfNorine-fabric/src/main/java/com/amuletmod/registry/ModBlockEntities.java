package com.amuletmod.registry;

import com.amuletmod.seal.SealBarrierBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import com.amuletmod.neo.registry.DeferredHolder;
import com.amuletmod.neo.registry.DeferredRegister;

public final class ModBlockEntities {
   public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, "amuletmod");
   public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SealBarrierBlockEntity>> SEAL_BARRIER = BLOCK_ENTITY_TYPES.register(
      "seal_barrier", () -> new BlockEntityType<>(SealBarrierBlockEntity::new, ModBlocks.SEAL_BARRIER.get())
   );

   private ModBlockEntities() {
   }
}
