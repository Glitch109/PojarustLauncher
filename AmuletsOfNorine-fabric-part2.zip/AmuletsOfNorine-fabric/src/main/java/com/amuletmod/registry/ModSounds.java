package com.amuletmod.registry;

import com.amuletmod.AmuletMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import com.amuletmod.neo.registry.DeferredHolder;
import com.amuletmod.neo.registry.DeferredRegister;

public final class ModSounds {
   public static final DeferredRegister<SoundEvent> SOUND_EVENTS = DeferredRegister.create(Registries.SOUND_EVENT, "amuletmod");
   public static final DeferredHolder<SoundEvent, SoundEvent> TITAN_JAB_SUMMON = register("titan.jab_summon");
   public static final DeferredHolder<SoundEvent, SoundEvent> TITAN_CRUSH_SUMMON = register("titan.crush_summon");
   public static final DeferredHolder<SoundEvent, SoundEvent> TITAN_CRUSH_IMPACT = register("titan.crush_impact");
   public static final DeferredHolder<SoundEvent, SoundEvent> TITAN_UPPERCUT_SUMMON = register("titan.uppercut_summon");
   public static final DeferredHolder<SoundEvent, SoundEvent> TITAN_POWER_SELECT = register("titan.power_select");
   public static final DeferredHolder<SoundEvent, SoundEvent> TITAN_POWER_CANCEL = register("titan.power_cancel");
   public static final DeferredHolder<SoundEvent, SoundEvent> TITAN_SLASH = register("titan.slash");
   public static final DeferredHolder<SoundEvent, SoundEvent> TITAN_SLASH_VOLLEY = register("titan.slash_volley");
   public static final DeferredHolder<SoundEvent, SoundEvent> TITAN_STORM_SUMMON = register("titan.storm_summon");
   public static final DeferredHolder<SoundEvent, SoundEvent> AEGIS_SHIELD_SPAWN = register("aegis.shield_spawn");
   public static final DeferredHolder<SoundEvent, SoundEvent> AEGIS_SHIELD_LOOP = register("aegis.shield_loop");

   private ModSounds() {
   }

   private static DeferredHolder<SoundEvent, SoundEvent> register(String name) {
      return SOUND_EVENTS.register(name, () -> SoundEvent.createVariableRangeEvent(AmuletMod.id(name)));
   }
}
