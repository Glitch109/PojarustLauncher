package com.amuletmod.registry;

import com.amuletmod.AmuletMod;

public final class LegacyIds {
   private LegacyIds() {
   }

   public static void register() {
      ModItems.ITEMS.addAlias(AmuletMod.id("storm_amulet"), AmuletMod.id("lightning_amulet"));
      ModItems.ITEMS.addAlias(AmuletMod.id("block_hole_amulet"), AmuletMod.id("geomancy_amulet"));
   }
}
