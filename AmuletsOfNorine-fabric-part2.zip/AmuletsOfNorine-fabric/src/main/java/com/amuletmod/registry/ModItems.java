package com.amuletmod.registry;

import com.amuletmod.amulet.AmuletItem;
import com.amuletmod.amulet.AmuletTier;
import com.amuletmod.amulet.ParagonAmuletItem;
import com.amuletmod.amulet.ability.aegis.AegisDomeAbility;
import com.amuletmod.amulet.ability.aegis.MirrorWardAbility;
import com.amuletmod.amulet.ability.chrono.RewindAbility;
import com.amuletmod.amulet.ability.chrono.TimeStopAbility;
import com.amuletmod.amulet.ability.geomancy.BlockHoleAbility;
import com.amuletmod.amulet.ability.geomancy.RockShieldAbility;
import com.amuletmod.amulet.ability.geomancy.SeismicSlamAbility;
import com.amuletmod.amulet.ability.glacial.FrostNovaAbility;
import com.amuletmod.amulet.ability.glacial.GlacialRuptureAbility;
import com.amuletmod.amulet.ability.infernal.HellhoundsAbility;
import com.amuletmod.amulet.ability.infernal.UnderworldExpressAbility;
import com.amuletmod.amulet.ability.librarian.OfudaAbility;
import com.amuletmod.amulet.ability.librarian.PaperCutsAbility;
import com.amuletmod.amulet.ability.librarian.TomeTempestAbility;
import com.amuletmod.amulet.ability.lightning.LightningDashAbility;
import com.amuletmod.amulet.ability.lightning.StormCallAbility;
import com.amuletmod.amulet.ability.meteor.MeteorShowerAbility;
import com.amuletmod.amulet.ability.meteor.MeteorVolleyAbility;
import com.amuletmod.amulet.ability.recall.RecallAbility;
import com.amuletmod.amulet.ability.recall.SetReturnPointAbility;
import com.amuletmod.amulet.ability.rift.RiftAbility;
import com.amuletmod.amulet.ability.rift.RiftKind;
import com.amuletmod.amulet.ability.seal.CaptureSealAbility;
import com.amuletmod.amulet.ability.seal.ContainAbility;
import com.amuletmod.amulet.ability.seal.SealOpeningAbility;
import com.amuletmod.amulet.ability.sovereign.AriseAbility;
import com.amuletmod.amulet.ability.sovereign.AuraSightAbility;
import com.amuletmod.amulet.ability.sovereign.ChainBindingAbility;
import com.amuletmod.amulet.ability.stealth.ShadowSwapAbility;
import com.amuletmod.amulet.ability.stealth.StealthAbility;
import com.amuletmod.amulet.ability.strike.GodStrikeAbility;
import com.amuletmod.amulet.ability.strike.MarkTargetAbility;
import com.amuletmod.amulet.ability.sylvan.BeeMonarchAbility;
import com.amuletmod.amulet.ability.sylvan.PetalGunAbility;
import com.amuletmod.amulet.ability.sylvan.RootEnsnareAbility;
import com.amuletmod.amulet.ability.titan.TitanBladesAbility;
import com.amuletmod.amulet.ability.titan.TitanFistsAbility;
import com.amuletmod.amulet.effect.BlastWardEffect;
import com.amuletmod.amulet.effect.BorrowedTimeEffect;
import com.amuletmod.amulet.effect.EndermanCalmEffect;
import com.amuletmod.amulet.effect.FrostboundEffect;
import com.amuletmod.amulet.effect.InBiomeEffect;
import com.amuletmod.amulet.effect.InDimensionEffect;
import com.amuletmod.amulet.effect.InSunlightEffect;
import com.amuletmod.amulet.effect.InWaterEffect;
import com.amuletmod.amulet.effect.KnockbackResistanceEffect;
import com.amuletmod.amulet.effect.LingeringMobEffect;
import com.amuletmod.amulet.effect.MaxHealthEffect;
import com.amuletmod.amulet.effect.NearBookshelvesEffect;
import com.amuletmod.amulet.effect.PermanentMobEffect;
import com.amuletmod.amulet.effect.ProjectileDeflectEffect;
import com.amuletmod.amulet.effect.ShortCircuitEffect;
import com.amuletmod.amulet.effect.SlowHealingEffect;
import com.amuletmod.amulet.effect.UnboundEffect;
import com.amuletmod.amulet.effect.VoidRescueEffect;
import com.amuletmod.amulet.effect.VulnerabilityEffect;
import com.amuletmod.seal.SealCubeItem;
import java.util.List;
import net.minecraft.tags.DamageTypeTags;
import com.amuletmod.util.VanillaEffects;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import com.amuletmod.neo.registry.DeferredItem;
import com.amuletmod.neo.registry.DeferredRegister;
import com.amuletmod.neo.registry.DeferredRegister.Items;

public final class ModItems {
   public static final Items ITEMS = DeferredRegister.createItems("amuletmod");
   private static final int SECONDS = 20;
   public static final DeferredItem<Item> IRON_AMULET_CHAIN = chain("iron_amulet_chain");
   public static final DeferredItem<Item> GOLD_AMULET_CHAIN = chain("gold_amulet_chain");
   public static final DeferredItem<Item> SHULKER_AMULET_CHAIN = chain("shulker_amulet_chain");
   public static final DeferredItem<Item> LIGHTNING_STONE = gemstone("lightning_stone");
   public static final DeferredItem<Item> SHADOW_STONE = gemstone("shadow_stone");
   public static final DeferredItem<Item> RECALL_STONE = gemstone("recall_stone");
   public static final DeferredItem<Item> METEOR_STONE = gemstone("meteor_stone");
   public static final DeferredItem<Item> GLACIAL_STONE = gemstone("glacial_stone");
   public static final DeferredItem<Item> GEOMANCY_STONE = gemstone("geomancy_stone");
   public static final DeferredItem<Item> AEGIS_STONE = gemstone("aegis_stone");
   public static final DeferredItem<Item> CHRONO_STONE = gemstone("chrono_stone");
   public static final DeferredItem<Item> SYLVAN_STONE = gemstone("sylvan_stone");
   public static final DeferredItem<Item> INFERNAL_STONE = gemstone("infernal_stone");
   public static final DeferredItem<Item> LIBRARIAN_STONE = gemstone("librarian_stone");
   public static final DeferredItem<Item> TITAN_STONE = gemstone("titan_stone");
   public static final DeferredItem<SealCubeItem> SEAL_CUBE = ITEMS.register(
      "seal_cube", () -> new SealCubeItem(props().stacksTo(1).rarity(Rarity.EPIC))
   );
   public static final DeferredItem<AmuletItem> LIGHTNING_AMULET = amulet(
      "lightning_amulet",
      AmuletItem.Definition.builder(AmuletTier.SILVER)
         .effect(new PermanentMobEffect(VanillaEffects.MOVEMENT_SPEED, 0))
         .effect(new ShortCircuitEffect(2.0F, 40))
         .ability(new LightningDashAbility(16.0, 4.0F, 120))
         .ability(new StormCallAbility(25.0, 25, 3, 6.0F, 900))
         .build()
   );
   public static final DeferredItem<AmuletItem> SHADOW_AMULET = amulet(
      "shadow_amulet",
      AmuletItem.Definition.builder(AmuletTier.SILVER).ability(new StealthAbility(400, 1200)).ability(new ShadowSwapAbility(48.0, 12, 1200)).build()
   );
   public static final DeferredItem<AmuletItem> RECALL_AMULET = amulet(
      "recall_amulet",
      AmuletItem.Definition.builder(AmuletTier.SILVER).ability(new SetReturnPointAbility(0)).ability(new RecallAbility(200.0, 1200)).fusionPair(1, 0).build()
   );
   public static final DeferredItem<AmuletItem> METEOR_AMULET = amulet(
      "meteor_amulet",
      AmuletItem.Definition.builder(AmuletTier.SILVER)
         .effect(new BlastWardEffect(0.4F, 0.4F))
         .effect(new InWaterEffect(new PermanentMobEffect(VanillaEffects.WEAKNESS, 0)))
         .ability(new MeteorVolleyAbility(64.0, 15.0F, 2.5F, 240))
         .ability(new MeteorShowerAbility(300, 5, 20.0, 1200))
         .build()
   );
   public static final DeferredItem<AmuletItem> GLACIAL_AMULET = amulet(
      "glacial_amulet",
      AmuletItem.Definition.builder(AmuletTier.SILVER)
         .effect(new FrostboundEffect(60))
         .effect(new VulnerabilityEffect(DamageTypeTags.IS_FIRE, 2.0F))
         .ability(new GlacialRuptureAbility(18.0F, 8.0F, 240))
         .ability(new FrostNovaAbility(6.0F, 6.0F, 600))
         .build()
   );
   public static final DeferredItem<AmuletItem> GEOMANCY_AMULET = amulet(
      "geomancy_amulet",
      AmuletItem.Definition.builder(AmuletTier.GOLD)
         .effect(new PermanentMobEffect(VanillaEffects.DIG_SPEED, 1))
         .effect(new VulnerabilityEffect(DamageTypeTags.IS_FALL, 2.0F))
         .ability(new RockShieldAbility(2.0F, 1200, 1800))
         .ability(new BlockHoleAbility(3.0, 15, 1800))
         .ability(new SeismicSlamAbility(14.0F, 8.0F, 600))
         .build()
   );
   public static final DeferredItem<AmuletItem> AEGIS_AMULET = amulet(
      "aegis_amulet",
      AmuletItem.Definition.builder(AmuletTier.GOLD)
         .effect(new ProjectileDeflectEffect(0.25F))
         .ability(new MirrorWardAbility(120, 600))
         .ability(new AegisDomeAbility(7.0F, 300, 1200))
         .build()
   );
   public static final DeferredItem<AmuletItem> CHRONO_AMULET = amulet(
      "chrono_amulet",
      AmuletItem.Definition.builder(AmuletTier.GOLD)
         .effect(new BorrowedTimeEffect(100, 6000))
         .ability(new RewindAbility(100, 900))
         .ability(new TimeStopAbility(10.0F, 120, 1800))
         .build()
   );
   public static final DeferredItem<AmuletItem> SYLVAN_AMULET = amulet(
      "sylvan_amulet",
      AmuletItem.Definition.builder(AmuletTier.GOLD)
         .effect(new InBiomeEffect(ModTags.SYLVAN_HAVENS, null, new PermanentMobEffect(VanillaEffects.MOVEMENT_SPEED, 1)))
         .effect(new InBiomeEffect(ModTags.SYLVAN_HAVENS, null, new PermanentMobEffect(VanillaEffects.REGENERATION, 0)))
         .effect(new InBiomeEffect(ModTags.SYLVAN_BANES, ModTags.SYLVAN_HAVENS, new LingeringMobEffect(VanillaEffects.MOVEMENT_SLOWDOWN, 0, 300)))
         .effect(new InBiomeEffect(ModTags.SYLVAN_BANES, ModTags.SYLVAN_HAVENS, new LingeringMobEffect(VanillaEffects.WEAKNESS, 0, 300)))
         .ability(new PetalGunAbility(20.0, 2.0F, 100))
         .ability(new BeeMonarchAbility(20, 20, 30, 1200, 2400))
         .ability(new RootEnsnareAbility(24.0, 400, 1800))
         .build()
   );
   public static final DeferredItem<AmuletItem> INFERNAL_AMULET = amulet(
      "infernal_amulet",
      AmuletItem.Definition.builder(AmuletTier.GOLD)
         .effect(new InDimensionEffect(Level.NETHER, new PermanentMobEffect(VanillaEffects.FIRE_RESISTANCE, 0)))
         .effect(new InWaterEffect(new LingeringMobEffect(VanillaEffects.MOVEMENT_SLOWDOWN, 0, 300)))
         .ability(new HellhoundsAbility(4, 600, 2400))
         .ability(new UnderworldExpressAbility(20.0, 10, 1800))
         .build()
   );
   public static final DeferredItem<AmuletItem> LIBRARIAN_AMULET = amulet(
      "librarian_amulet",
      AmuletItem.Definition.builder(AmuletTier.GOLD)
         .effect(new NearBookshelvesEffect(6, new MaxHealthEffect(0.2F)))
         .effect(new VulnerabilityEffect(null, 2.0F, "tooltip.amuletmod.effect.vulnerable.all.quip"))
         .ability(new PaperCutsAbility(48.0, 4.0F, 40))
         .ability(new OfudaAbility(32.0, 600, 1200, 3000))
         .ability(new TomeTempestAbility(20, 100, 50.0, 5.0F, 6000))
         .build()
   );
   public static final DeferredItem<AmuletItem> TITAN_AMULET = amulet(
      "titan_amulet",
      AmuletItem.Definition.builder(AmuletTier.GOLD)
         .effect(new KnockbackResistanceEffect(0.5F))
         .effect(new MaxHealthEffect(0.2F))
         .effect(new PermanentMobEffect(VanillaEffects.HUNGER, 0))
         .ability(new TitanFistsAbility(8.0, 15.0, 5.0F, 20, 40, 160, 120))
         .ability(new TitanBladesAbility(4.0, 24.0, 6, 20, 60, 60, 20, 256.0, 400))
         .build()
   );
   public static final DeferredItem<AmuletItem> RIFT_AMULET = amulet(
      "rift_amulet",
      AmuletItem.Definition.builder(AmuletTier.SHULKER)
         .effect(new InDimensionEffect(Level.NETHER, new PermanentMobEffect(VanillaEffects.FIRE_RESISTANCE, 0)))
         .effect(new InDimensionEffect(Level.END, new EndermanCalmEffect()))
         .effect(new InDimensionEffect(Level.END, new VoidRescueEffect(1200)))
         .ability(new RiftAbility(RiftKind.NETHER, 1200))
         .ability(new RiftAbility(RiftKind.END, 2400))
         .ability(new RiftAbility(RiftKind.OVERWORLD, 1200))
         .build()
   );
   public static final DeferredItem<AmuletItem> SOVEREIGN_AMULET = amulet(
      "sovereign_amulet",
      AmuletItem.Definition.builder(AmuletTier.SHULKER)
         .effect(new PermanentMobEffect(VanillaEffects.NIGHT_VISION, 0))
         .effect(new InSunlightEffect(new PermanentMobEffect(VanillaEffects.WEAKNESS, 0)))
         .ability(new AuraSightAbility(64.0))
         .ability(new AriseAbility(20, 1200, 2400))
         .ability(new ChainBindingAbility(24.0, 1200, 1800))
         .build()
   );
   public static final DeferredItem<AmuletItem> SEAL_AMULET = amulet(
      "seal_amulet",
      AmuletItem.Definition.builder(AmuletTier.SHULKER)
         .effect(new PermanentMobEffect(VanillaEffects.DAMAGE_RESISTANCE, 0))
         .effect(new UnboundEffect(List.of(VanillaEffects.MOVEMENT_SLOWDOWN, VanillaEffects.LEVITATION, VanillaEffects.DIG_SLOWDOWN)))
         .effect(new SlowHealingEffect(0.5F))
         .ability(new SealOpeningAbility(48.0, 600, 1200, 600))
         .ability(new CaptureSealAbility(16.0, 1200))
         .ability(new ContainAbility(50.0F, 1200, 2400))
         .build()
   );
   public static final DeferredItem<AmuletItem> PARAGON_AMULET = ITEMS.register(
      "paragon_amulet", () -> new ParagonAmuletItem(amuletProperties(AmuletTier.SHULKER))
   );
   public static final DeferredItem<AmuletItem> CATACLYSM_AMULET = amulet(
      "cataclysm_amulet",
      AmuletItem.Definition.builder(AmuletTier.SHULKER)
         .charges(3)
         .ability(new MarkTargetAbility(200.0, 20))
         .ability(new GodStrikeAbility(50.0F, 250.0, 1200))
         .fusionPair(1, 0)
         .build()
   );

   private static DeferredItem<Item> chain(String name) {
      return ITEMS.register(name, () -> new Item(props()));
   }

   private static DeferredItem<Item> gemstone(String name) {
      return ITEMS.register(name, () -> new Item(props().rarity(Rarity.UNCOMMON)));
   }

   private static DeferredItem<AmuletItem> amulet(String name, AmuletItem.Definition definition) {
      return ITEMS.register(name, () -> new AmuletItem(amuletProperties(definition.tier()), definition));
   }

   private static Properties amuletProperties(AmuletTier tier) {
      Properties properties = props().stacksTo(1).rarity(Rarity.EPIC);
      return tier == AmuletTier.SHULKER ? properties.fireResistant() : properties;
   }

   private static Properties props() {
      return new Properties().setId(DeferredRegister.currentKey());
   }

   private ModItems() {
   }
}
