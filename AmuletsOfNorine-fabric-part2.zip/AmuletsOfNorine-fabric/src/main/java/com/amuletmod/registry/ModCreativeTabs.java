package com.amuletmod.registry;

import com.amuletmod.amulet.AmuletItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import com.amuletmod.neo.registry.DeferredHolder;
import com.amuletmod.neo.registry.DeferredRegister;

public final class ModCreativeTabs {
   public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "amuletmod");
   public static final DeferredHolder<CreativeModeTab, CreativeModeTab> AMULETS = CREATIVE_MODE_TABS.register(
      "amulets",
      () -> CreativeModeTab.builder()
         .title(Component.translatable("itemGroup.amuletmod.amulets"))
         .icon(() -> ((AmuletItem)ModItems.LIGHTNING_AMULET.get()).getDefaultInstance())
         .displayItems(
            (parameters, output) -> ModItems.ITEMS
               .getEntries()
               .stream()
               .<Item>map(DeferredHolder::get)
               .filter(item -> item != ModItems.SEAL_CUBE.get())
               .forEach(output::accept)
         )
         .build()
   );

   private ModCreativeTabs() {
   }
}
