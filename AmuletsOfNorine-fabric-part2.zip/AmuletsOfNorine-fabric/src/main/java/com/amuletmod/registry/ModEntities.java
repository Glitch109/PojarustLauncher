package com.amuletmod.registry;

import com.amuletmod.entity.AbsorbedBlockEntity;
import com.amuletmod.entity.BarrierEntity;
import com.amuletmod.entity.BlockHoleEntity;
import com.amuletmod.entity.ChainBindEntity;
import com.amuletmod.entity.ContainmentEntity;
import com.amuletmod.entity.HellhoundEntity;
import com.amuletmod.entity.IceSpikeEntity;
import com.amuletmod.entity.MeteorEntity;
import com.amuletmod.entity.MeteorVolleyEntity;
import com.amuletmod.entity.MonarchBeeEntity;
import com.amuletmod.entity.OfudaEntity;
import com.amuletmod.entity.PageBindEntity;
import com.amuletmod.entity.PageEntity;
import com.amuletmod.entity.PageStormEntity;
import com.amuletmod.entity.PetalEntity;
import com.amuletmod.entity.RiftEntity;
import com.amuletmod.entity.RockShellEntity;
import com.amuletmod.entity.RootsEntity;
import com.amuletmod.entity.SealCaptureEntity;
import com.amuletmod.entity.SealCoreEntity;
import com.amuletmod.entity.SealEntity;
import com.amuletmod.entity.SeekingMeteorEntity;
import com.amuletmod.entity.SeismicWaveEntity;
import com.amuletmod.entity.ShadowPlayerEntity;
import com.amuletmod.entity.StormCloudEntity;
import com.amuletmod.entity.TimeFieldEntity;
import com.amuletmod.entity.TitanBladeEntity;
import com.amuletmod.entity.TitanFistEntity;
import com.amuletmod.entity.TitanSlashEntity;
import com.amuletmod.entity.UnderworldHandEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType.Builder;
import com.amuletmod.neo.registry.DeferredHolder;
import com.amuletmod.neo.registry.DeferredRegister;

public final class ModEntities {
   public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(Registries.ENTITY_TYPE, "amuletmod");
   public static final DeferredHolder<EntityType<?>, EntityType<MeteorEntity>> METEOR = ENTITY_TYPES.register(
      "meteor", () -> Builder.of(MeteorEntity::new, MobCategory.MISC).sized(1.0F, 1.0F).fireImmune().clientTrackingRange(8).updateInterval(10).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<SeekingMeteorEntity>> SEEKING_METEOR = ENTITY_TYPES.register(
      "seeking_meteor",
      () -> Builder.of(SeekingMeteorEntity::new, MobCategory.MISC)
         .sized(0.6F, 0.6F)
         .fireImmune()
         .clientTrackingRange(8)
         .updateInterval(2)
         .build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<MeteorVolleyEntity>> METEOR_VOLLEY = ENTITY_TYPES.register(
      "meteor_volley",
      () -> Builder.of(MeteorVolleyEntity::new, MobCategory.MISC)
         .sized(0.5F, 0.5F)
         .fireImmune()
         .clientTrackingRange(10)
         .updateInterval(1)
         .build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<BlockHoleEntity>> BLOCK_HOLE = ENTITY_TYPES.register(
      "block_hole",
      () -> Builder.of(BlockHoleEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(8).updateInterval(1).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<AbsorbedBlockEntity>> ABSORBED_BLOCK = ENTITY_TYPES.register(
      "absorbed_block",
      () -> Builder.of(AbsorbedBlockEntity::new, MobCategory.MISC)
         .sized(0.98F, 0.98F)
         .fireImmune()
         .clientTrackingRange(6)
         .updateInterval(20)
         .build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<RiftEntity>> RIFT = ENTITY_TYPES.register(
      "rift", () -> Builder.of(RiftEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(10).updateInterval(20).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<BarrierEntity>> BARRIER = ENTITY_TYPES.register(
      "barrier",
      () -> Builder.of(BarrierEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(10).updateInterval(1).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<IceSpikeEntity>> ICE_SPIKE = ENTITY_TYPES.register(
      "ice_spike",
      () -> Builder.of(IceSpikeEntity::new, MobCategory.MISC).sized(0.8F, 2.0F).fireImmune().clientTrackingRange(8).updateInterval(20).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<TimeFieldEntity>> TIME_FIELD = ENTITY_TYPES.register(
      "time_field",
      () -> Builder.of(TimeFieldEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(10).updateInterval(20).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<PetalEntity>> PETAL = ENTITY_TYPES.register(
      "petal", () -> Builder.of(PetalEntity::new, MobCategory.MISC).sized(0.25F, 0.25F).clientTrackingRange(4).updateInterval(2).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<MonarchBeeEntity>> MONARCH_BEE = ENTITY_TYPES.register(
      "monarch_bee", () -> Builder.of(MonarchBeeEntity::new, MobCategory.MISC).sized(0.7F, 0.6F).clientTrackingRange(8).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<RootsEntity>> ROOTS = ENTITY_TYPES.register(
      "roots", () -> Builder.of(RootsEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).clientTrackingRange(8).updateInterval(20).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<HellhoundEntity>> HELLHOUND = ENTITY_TYPES.register(
      "hellhound", () -> Builder.of(HellhoundEntity::new, MobCategory.MISC).sized(0.75F, 1.05F).fireImmune().clientTrackingRange(10).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<UnderworldHandEntity>> UNDERWORLD_HAND = ENTITY_TYPES.register(
      "underworld_hand",
      () -> Builder.of(UnderworldHandEntity::new, MobCategory.MISC)
         .sized(0.5F, 0.5F)
         .fireImmune()
         .clientTrackingRange(8)
         .updateInterval(20)
         .build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<RockShellEntity>> ROCK_SHELL = ENTITY_TYPES.register(
      "rock_shell",
      () -> Builder.of(RockShellEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(8).updateInterval(2).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<SeismicWaveEntity>> SEISMIC_WAVE = ENTITY_TYPES.register(
      "seismic_wave",
      () -> Builder.of(SeismicWaveEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(8).updateInterval(20).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<StormCloudEntity>> STORM_CLOUD = ENTITY_TYPES.register(
      "storm_cloud",
      () -> Builder.of(StormCloudEntity::new, MobCategory.MISC).sized(1.0F, 0.5F).fireImmune().clientTrackingRange(10).updateInterval(2).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<ChainBindEntity>> CHAIN_BIND = ENTITY_TYPES.register(
      "chain_bind",
      () -> Builder.of(ChainBindEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(10).updateInterval(1).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<PageEntity>> PAGE = ENTITY_TYPES.register(
      "page", () -> Builder.of(PageEntity::new, MobCategory.MISC).sized(0.3F, 0.3F).fireImmune().clientTrackingRange(6).updateInterval(2).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<PageBindEntity>> PAGE_BIND = ENTITY_TYPES.register(
      "page_bind",
      () -> Builder.of(PageBindEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(8).updateInterval(4).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<OfudaEntity>> OFUDA = ENTITY_TYPES.register(
      "ofuda", () -> Builder.of(OfudaEntity::new, MobCategory.MISC).sized(0.4F, 0.4F).fireImmune().clientTrackingRange(8).updateInterval(1).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<PageStormEntity>> PAGE_STORM = ENTITY_TYPES.register(
      "page_storm",
      () -> Builder.of(PageStormEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(10).updateInterval(4).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<ShadowPlayerEntity>> SHADOW_PLAYER = ENTITY_TYPES.register(
      "shadow_player",
      () -> Builder.of(ShadowPlayerEntity::new, MobCategory.MISC).sized(0.6F, 1.8F).eyeHeight(1.62F).clientTrackingRange(10).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<SealEntity>> SEAL = ENTITY_TYPES.register(
      "seal", () -> Builder.of(SealEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(10).updateInterval(20).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<ContainmentEntity>> CONTAINMENT = ENTITY_TYPES.register(
      "containment",
      () -> Builder.of(ContainmentEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(12).updateInterval(20).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<SealCaptureEntity>> SEAL_CAPTURE = ENTITY_TYPES.register(
      "seal_capture",
      () -> Builder.of(SealCaptureEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(10).updateInterval(1).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<SealCoreEntity>> SEAL_CORE = ENTITY_TYPES.register(
      "seal_core",
      () -> Builder.of(SealCoreEntity::new, MobCategory.MISC).sized(0.9F, 1.5F).fireImmune().clientTrackingRange(4).updateInterval(20).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<TitanFistEntity>> TITAN_FIST = ENTITY_TYPES.register(
      "titan_fist",
      () -> Builder.of(TitanFistEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(10).updateInterval(1).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<TitanSlashEntity>> TITAN_SLASH = ENTITY_TYPES.register(
      "titan_slash",
      () -> Builder.of(TitanSlashEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(8).updateInterval(1).build(DeferredRegister.currentKey())
   );
   public static final DeferredHolder<EntityType<?>, EntityType<TitanBladeEntity>> TITAN_BLADE = ENTITY_TYPES.register(
      "titan_blade",
      () -> Builder.of(TitanBladeEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).fireImmune().clientTrackingRange(16).updateInterval(1).build(DeferredRegister.currentKey())
   );

   private ModEntities() {
   }

   public static void registerAttributes() {
      net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry.register((EntityType) MONARCH_BEE.get(), MonarchBeeEntity.createAttributes());
      net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry.register((EntityType) HELLHOUND.get(), HellhoundEntity.createAttributes());
      net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry.register((EntityType) SHADOW_PLAYER.get(), ShadowPlayerEntity.createAttributes());
      net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry.register((EntityType) SEAL_CORE.get(), SealCoreEntity.createAttributes());
   }
}
