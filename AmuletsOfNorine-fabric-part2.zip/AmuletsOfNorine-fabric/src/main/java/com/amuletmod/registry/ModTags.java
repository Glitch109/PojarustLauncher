package com.amuletmod.registry;

import com.amuletmod.AmuletMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;

public final class ModTags {
   public static final TagKey<Item> AMULET_CHAINS = ItemTags.create(AmuletMod.id("amulet_chains"));
   public static final TagKey<Item> TOMES = ItemTags.create(AmuletMod.id("tomes"));
   public static final TagKey<Biome> SYLVAN_HAVENS = TagKey.create(Registries.BIOME, AmuletMod.id("sylvan_havens"));
   public static final TagKey<Biome> SYLVAN_BANES = TagKey.create(Registries.BIOME, AmuletMod.id("sylvan_banes"));
   public static final TagKey<Block> ROOT_SOIL = BlockTags.create(AmuletMod.id("root_soil"));

   private ModTags() {
   }
}
