package com.amuletmod.entity;

import com.amuletmod.network.FxPacket;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.PacketDistributor;
import org.jetbrains.annotations.Nullable;

public class StormCloudEntity extends Entity {
   public static final int GATHER_TICKS = 20;
   public static final int FADE_TICKS = 30;
   public static final double HEIGHT = 6.5;
   private static final int STRIKE_INTERVAL = 3;
   private static final double MAX_REACH = 40.0;
   private static final EntityDataAccessor<Integer> DATA_OWNER = SynchedEntityData.defineId(StormCloudEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_FADE_START = SynchedEntityData.defineId(StormCloudEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_LAST_STRIKE = SynchedEntityData.defineId(StormCloudEntity.class, EntityDataSerializers.INT);
   @Nullable
   private UUID ownerId;
   private final List<LivingEntity> targets = new ArrayList<>();
   private int[] strikesLeft = new int[0];
   private int cursor;
   private float damage;
   private int strikesMade;

   public StormCloudEntity(EntityType<? extends StormCloudEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public StormCloudEntity(ServerLevel level, ServerPlayer owner, List<LivingEntity> targets, int strikes, float damage) {
      this((EntityType<? extends StormCloudEntity>)ModEntities.STORM_CLOUD.get(), level);
      this.ownerId = owner.getUUID();
      this.targets.addAll(targets);
      this.strikesLeft = new int[targets.size()];
      Arrays.fill(this.strikesLeft, strikes);
      this.damage = damage;
      this.entityData.set(DATA_OWNER, owner.getId());
      this.setPos(owner.position().add(0.0, 6.5, 0.0));
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_OWNER, -1);
      builder.define(DATA_FADE_START, -1);
      builder.define(DATA_LAST_STRIKE, -100);
   }

   @Nullable
   public Entity owner() {
      return this.level().getEntity((Integer)this.entityData.get(DATA_OWNER));
   }

   public int fadeStart() {
      return (Integer)this.entityData.get(DATA_FADE_START);
   }

   public int lastStrike() {
      return (Integer)this.entityData.get(DATA_LAST_STRIKE);
   }

   public float density(float partialTick) {
      float age = this.tickCount + partialTick;
      float gather = Mth.clamp(age / 20.0F, 0.0F, 1.0F);
      int fade = this.fadeStart();
      float thin = fade < 0 ? 0.0F : Mth.clamp((age - fade) / 30.0F, 0.0F, 1.0F);
      return gather * (1.0F - thin);
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         ServerLevel level = (ServerLevel)this.level();
         ServerPlayer owner = this.ownerId == null ? null : level.getServer().getPlayerList().getPlayer(this.ownerId);
         if (owner != null && owner.level() == level) {
            this.setPos(owner.position().add(0.0, 6.5, 0.0));
         } else {
            this.startFading();
         }

         int fade = this.fadeStart();
         if (fade >= 0) {
            if (this.tickCount - fade >= 30) {
               this.discard();
            }
         } else {
            if (this.tickCount == 1) {
               Sounds.play(level, this.position(), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.5F, 0.6F);
            }

            if (this.tickCount >= 20 && this.tickCount % 3 == 0 && !this.strikeNext(level, owner)) {
               this.startFading();
            }
         }
      }
   }

   private void startFading() {
      if (this.fadeStart() < 0) {
         this.entityData.set(DATA_FADE_START, this.tickCount);
      }
   }

   private boolean strikeNext(ServerLevel level, @Nullable ServerPlayer owner) {
      for (int tried = 0; tried < this.targets.size(); tried++) {
         int index = this.cursor;
         this.cursor = (this.cursor + 1) % this.targets.size();
         LivingEntity target = this.targets.get(index);
         if (this.strikesLeft[index] > 0 && target.isAlive() && target.level() == level && !(target.distanceToSqr(this) > 1600.0)) {
            this.strikesLeft[index]--;
            this.strike(level, owner, target);
            return true;
         }
      }

      return false;
   }

   private void strike(ServerLevel level, @Nullable ServerPlayer owner, LivingEntity target) {
      double angle = this.random.nextDouble() * (float) (Math.PI * 2);
      double spread = this.random.nextDouble() * 2.2;
      Vec3 from = this.position().add(Math.cos(angle) * spread, -0.4, Math.sin(angle) * spread);
      Vec3 to = target.position().add(0.0, target.getBbHeight() * 0.6, 0.0);
      if (owner != null) {
         target.setLastHurtByPlayer(owner);
      }

      target.hurt(ModDamage.source(level, ModDamage.STORM, this, owner), this.damage);
      this.entityData.set(DATA_LAST_STRIKE, this.tickCount);
      PacketDistributor.sendToPlayersTrackingEntity(this, new FxPacket(FxPacket.Kind.BOLT, from, to, 1.0F), new CustomPacketPayload[0]);
      level.sendParticles(ParticleTypes.ELECTRIC_SPARK, to.x, to.y, to.z, 14, 0.25, 0.4, 0.25, 0.35);
      Sounds.play(level, to, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.0F, 1.1F + this.random.nextFloat() * 0.5F);
      if (this.strikesMade++ % 4 == 0) {
         Sounds.play(level, this.position(), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.45F, 1.1F + this.random.nextFloat() * 0.4F);
      }
   }

   private void clientTick() {
      float density = this.density(0.0F);
      if (!(density <= 0.1F)) {
         Vec3 center = this.position();
         Entity owner = this.owner();
         if (owner != null) {
            center = owner.position().add(0.0, 6.5, 0.0);
         }

         for (int i = 0; i < 3; i++) {
            double angle = this.random.nextDouble() * (float) (Math.PI * 2);
            double radius = Math.sqrt(this.random.nextDouble()) * 3.0 * density;
            this.level()
               .addParticle(
                  ParticleTypes.FALLING_WATER, center.x + Math.cos(angle) * radius, center.y - 0.5, center.z + Math.sin(angle) * radius, 0.0, 0.0, 0.0
               );
         }

         if (this.random.nextInt(6) == 0) {
            this.level()
               .addParticle(
                  ParticleTypes.ELECTRIC_SPARK,
                  center.x + this.random.nextGaussian() * 1.5,
                  center.y + this.random.nextGaussian() * 0.3,
                  center.z + this.random.nextGaussian() * 1.5,
                  0.0,
                  0.0,
                  0.0
               );
         }
      }
   }

   public AABB getBoundingBoxForCulling() {
      return this.getBoundingBox().inflate(6.0);
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean hurt(DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }
}
