package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.AmuletMod;
import com.amuletmod.client.CameraShake;
import com.amuletmod.client.RootedClient;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Sounds;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.Tags.EntityTypes;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class PageBindEntity extends Entity {
   public static final int WRAP_TICKS = 7;
   public static final int TEAR_TICKS = 8;
   private static final Identifier BOUND_MODIFIER = AmuletMod.id("paper_bound");
   private static final Vector3f CURSE_RED = new Vector3f(0.8F, 0.08F, 0.12F);
   private static final EntityDataAccessor<Integer> DATA_VICTIM = SynchedEntityData.defineId(PageBindEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_TEARS_AT = SynchedEntityData.defineId(PageBindEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Float> DATA_VICTIM_WIDTH = SynchedEntityData.defineId(PageBindEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Float> DATA_VICTIM_HEIGHT = SynchedEntityData.defineId(PageBindEntity.class, EntityDataSerializers.FLOAT);
   @Nullable
   private LivingEntity victim;
   private double anchorX;
   private double anchorZ;

   public PageBindEntity(EntityType<? extends PageBindEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   private PageBindEntity(ServerLevel level, LivingEntity victim, int holdTicks) {
      this((EntityType<? extends PageBindEntity>)ModEntities.PAGE_BIND.get(), level);
      this.victim = victim;
      this.moveTo(victim.getX(), victim.getY(), victim.getZ(), 0.0F, 0.0F);
      this.entityData.set(DATA_VICTIM, victim.getId());
      this.entityData.set(DATA_TEARS_AT, holdTicks);
      this.entityData.set(DATA_VICTIM_WIDTH, victim.getBbWidth());
      this.entityData.set(DATA_VICTIM_HEIGHT, victim.getBbHeight());
   }

   public static void bind(ServerLevel level, LivingEntity victim, int holdTicks) {
      if (victim.isAlive() && !victim.getType().is(EntityTypes.BOSSES) && !isBinding(level, victim)) {
         level.addFreshEntity(new PageBindEntity(level, victim, holdTicks));
      }
   }

   public static boolean isBinding(Level level, LivingEntity entity) {
      return !level.getEntitiesOfClass(
            PageBindEntity.class, entity.getBoundingBox().inflate(3.0), bind -> bind.victimId() == entity.getId() && bind.tickCount < bind.tearsAt()
         )
         .isEmpty();
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_VICTIM, -1);
      builder.define(DATA_TEARS_AT, 100);
      builder.define(DATA_VICTIM_WIDTH, 0.6F);
      builder.define(DATA_VICTIM_HEIGHT, 1.8F);
   }

   public int victimId() {
      return (Integer)this.entityData.get(DATA_VICTIM);
   }

   public int tearsAt() {
      return (Integer)this.entityData.get(DATA_TEARS_AT);
   }

   public int duration() {
      return this.tearsAt() + 8;
   }

   public float victimWidth() {
      return (Float)this.entityData.get(DATA_VICTIM_WIDTH);
   }

   public float victimHeight() {
      return (Float)this.entityData.get(DATA_VICTIM_HEIGHT);
   }

   public Vec3 feet(float partialTick) {
      Entity held = this.level().getEntity(this.victimId());
      return held != null ? held.getPosition(partialTick) : this.getPosition(partialTick);
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         if (this.victim != null && (!this.victim.isAlive() || this.victim.isRemoved() || this.victim.level() != this.level())) {
            this.release();
            if (this.tickCount < this.tearsAt()) {
               this.entityData.set(DATA_TEARS_AT, this.tickCount);
            }
         }

         if (this.victim != null) {
            if (this.tickCount == 1) {
               this.seize(this.victim);
            }

            if (this.tickCount < this.tearsAt()) {
               this.pin(this.victim);
            } else {
               this.release();
            }

            if (this.victim != null) {
               this.setPos(this.victim.position());
            }
         }

         Vec3 at = this.position().add(0.0, this.victimHeight() * 0.5, 0.0);
         if (this.tickCount == 1) {
            Sounds.play(this.level(), at, SoundEvents.BOOK_PAGE_TURN, 1.2F, 0.7F);
            Sounds.play(this.level(), at, SoundEvents.ILLUSIONER_CAST_SPELL, 0.6F, 1.4F);
         } else if (this.tickCount == 7 && this.tickCount < this.tearsAt()) {
            Sounds.play(this.level(), at, SoundEvents.BOOK_PUT, 1.3F, 0.7F);
            Sounds.play(this.level(), at, SoundEvents.LEASH_KNOT_PLACE, 1.0F, 0.8F);
         } else if (this.tickCount == this.tearsAt()) {
            Sounds.play(this.level(), at, SoundEvents.SHEEP_SHEAR, 1.0F, 1.3F);
            Sounds.play(this.level(), at, SoundEvents.BOOK_PAGE_TURN, 1.2F, 1.4F);
         }

         if (this.tickCount >= this.duration()) {
            this.discard();
         }
      }
   }

   private void seize(LivingEntity held) {
      held.stopRiding();
      this.anchorX = held.getX();
      this.anchorZ = held.getZ();
      AttributeInstance speed = held.getAttribute(Attributes.MOVEMENT_SPEED);
      if (speed != null && speed.getModifier(BOUND_MODIFIER) == null) {
         speed.addTransientModifier(new AttributeModifier(BOUND_MODIFIER, -1.0, Operation.ADD_MULTIPLIED_TOTAL));
      }

      if (held instanceof ServerPlayer player) {
         player.stopFallFlying();
      }
   }

   private void pin(LivingEntity held) {
      Vec3 at = held.position();
      double dx = this.anchorX - at.x;
      double dz = this.anchorZ - at.z;
      if (held instanceof ServerPlayer player) {
         if (dx * dx + dz * dz > 0.36) {
            player.connection.teleport(this.anchorX, at.y, this.anchorZ, player.getYRot(), player.getXRot());
         }
      } else {
         if (dx * dx + dz * dz > 0.0025) {
            held.teleportTo(this.anchorX, at.y, this.anchorZ);
         }

         held.setDeltaMovement(0.0, Math.min(0.0, held.getDeltaMovement().y), 0.0);
         if (held instanceof Mob mob) {
            mob.getNavigation().stop();
            mob.setJumping(false);
         }
      }
   }

   private void release() {
      if (this.victim != null) {
         AttributeInstance speed = this.victim.getAttribute(Attributes.MOVEMENT_SPEED);
         if (speed != null) {
            speed.removeModifier(BOUND_MODIFIER);
         }

         this.victim = null;
      }
   }

   public void onRemovedFromLevel() {
      super.onRemovedFromLevel();
      if (!this.level().isClientSide()) {
         this.release();
      }
   }

   private void clientTick() {
      int victimId = this.victimId();
      if (this.tickCount < this.tearsAt()) {
         ClientSide.run(() -> () -> RootedClient.hold(victimId));
      }

      Vec3 feet = this.feet(1.0F);
      float width = this.victimWidth();
      float height = this.victimHeight();
      if (this.tickCount == 7 && this.tickCount < this.tearsAt()) {
         for (int i = 0; i < 12; i++) {
            double angle = this.random.nextDouble() * (float) (Math.PI * 2);
            double radius = width * 0.5 + 0.15;
            this.level()
               .addParticle(
                  new DustParticleOptions(CURSE_RED, 1.0F),
                  feet.x + Math.cos(angle) * radius,
                  feet.y + height * (0.2 + this.random.nextDouble() * 0.65),
                  feet.z + Math.sin(angle) * radius,
                  0.0,
                  0.0,
                  0.0
               );
         }

         ClientSide.run(() -> () -> CameraShake.from(feet, 0.4F, 8.0, 4));
      } else if (this.tickCount == this.tearsAt() + 1) {
         for (int i = 0; i < 18; i++) {
            double angle = this.random.nextDouble() * (float) (Math.PI * 2);
            double radius = width * 0.5 + 0.1;
            this.level()
               .addParticle(
                  PageEntity.scraps(),
                  feet.x + Math.cos(angle) * radius,
                  feet.y + height * (0.15 + this.random.nextDouble() * 0.75),
                  feet.z + Math.sin(angle) * radius,
                  Math.cos(angle) * 0.12,
                  0.05 + this.random.nextDouble() * 0.1,
                  Math.sin(angle) * 0.12
               );
         }
      }
   }

   public AABB getBoundingBoxForCulling() {
      double reach = this.victimWidth() * 0.5 + 2.0;
      return new AABB(
         this.getX() - reach, this.getY() - 1.0, this.getZ() - reach, this.getX() + reach, this.getY() + this.victimHeight() + 1.0, this.getZ() + reach
      );
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(ValueInput input) {
   }

   protected void addAdditionalSaveData(ValueOutput output) {
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }
}
