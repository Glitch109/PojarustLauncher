package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.amulet.AbilityCooldowns;
import com.amuletmod.amulet.AbilityOrigin;
import com.amuletmod.client.CameraShake;
import com.amuletmod.client.ContainmentClient;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Sounds;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.IEntityWithComplexSpawn;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class ContainmentEntity extends Entity implements IEntityWithComplexSpawn {
   public static final float START_REACH = 1.5F;
   public static final float GROW_PER_TICK = 0.5F;
   public static final int FADE_TICKS = 20;
   private static final double CENTER_HEIGHT = 1.0;
   private static final double PLAYER_SLACK = 0.75;
   private static final EntityDataAccessor<Float> DATA_MOST = SynchedEntityData.defineId(ContainmentEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Float> DATA_SET = SynchedEntityData.defineId(ContainmentEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Integer> DATA_SET_TICK = SynchedEntityData.defineId(ContainmentEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_END = SynchedEntityData.defineId(ContainmentEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Vector3f> DATA_IMPACT = SynchedEntityData.defineId(ContainmentEntity.class, EntityDataSerializers.VECTOR3);
   private static final EntityDataAccessor<Integer> DATA_IMPACT_TICK = SynchedEntityData.defineId(ContainmentEntity.class, EntityDataSerializers.INT);
   private static final Map<UUID, ContainmentEntity> ACTIVE = new HashMap<>();
   @Nullable
   private UUID ownerId;
   @Nullable
   private AbilityOrigin ability;
   private int holdTicks;
   private int cooldownTicks;
   private final Set<LivingEntity> held = new LinkedHashSet<>();
   public boolean holdsLocalPlayer;
   private int clientSetTick = -1000;
   private int clientImpactTick = -1000;

   public ContainmentEntity(EntityType<? extends ContainmentEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public ContainmentEntity(ServerLevel level, ServerPlayer owner, float most, int holdTicks, @Nullable AbilityOrigin ability, int cooldownTicks) {
      this((EntityType<? extends ContainmentEntity>)ModEntities.CONTAINMENT.get(), level);
      this.ownerId = owner.getUUID();
      this.ability = ability;
      this.holdTicks = holdTicks;
      this.cooldownTicks = cooldownTicks;
      this.moveTo(owner.getX(), owner.getY() + 1.0, owner.getZ(), 0.0F, 0.0F);
      this.entityData.set(DATA_MOST, Math.max(most, 1.5F));
      ACTIVE.put(this.ownerId, this);
   }

   @Nullable
   public static ContainmentEntity of(ServerPlayer player) {
      ContainmentEntity walls = ACTIVE.get(player.getUUID());
      return walls != null && !walls.isRemoved() && walls.isHolding() ? walls : null;
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_MOST, 10.0F);
      builder.define(DATA_SET, -1.0F);
      builder.define(DATA_SET_TICK, -1);
      builder.define(DATA_END, Integer.MAX_VALUE);
      builder.define(DATA_IMPACT, new Vector3f());
      builder.define(DATA_IMPACT_TICK, -1000);
   }

   public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
      super.onSyncedDataUpdated(key);
      if (DATA_SET.equals(key) && (Float)this.entityData.get(DATA_SET) >= 0.0F) {
         this.clientSetTick = this.tickCount;
      }

      if (DATA_IMPACT_TICK.equals(key)) {
         this.clientImpactTick = this.tickCount;
      }
   }

   public float most() {
      return (Float)this.entityData.get(DATA_MOST);
   }

   public boolean isSpreading() {
      return (Float)this.entityData.get(DATA_SET) < 0.0F;
   }

   public int endTick() {
      return (Integer)this.entityData.get(DATA_END);
   }

   public boolean isHolding() {
      return this.tickCount < this.endTick();
   }

   public float reach(float partialTick) {
      float set = (Float)this.entityData.get(DATA_SET);
      return set >= 0.0F ? set : Math.min(this.most(), 1.5F + 0.5F * (this.tickCount + partialTick));
   }

   public AABB walls(float partialTick) {
      return new AABB(this.position(), this.position()).inflate(this.reach(partialTick));
   }

   public float fall(float partialTick) {
      return Mth.clamp((this.tickCount + partialTick - this.endTick()) / 20.0F, 0.0F, 1.0F);
   }

   public float heldFor(float partialTick) {
      return this.isSpreading()
         ? -1.0F
         : Math.min(this.tickCount + partialTick, (float)this.endTick()) - ((Integer)this.entityData.get(DATA_SET_TICK)).intValue();
   }

   public float sinceSet(float partialTick) {
      return this.tickCount - this.clientSetTick + partialTick;
   }

   public float sinceImpact(float partialTick) {
      return this.tickCount - this.clientImpactTick + partialTick;
   }

   public Vector3f impactPoint() {
      return (Vector3f)this.entityData.get(DATA_IMPACT);
   }

   public int ticksLeft() {
      return this.isSpreading() ? 0 : Math.max(0, this.endTick() - this.tickCount);
   }

   public static Vec3 correction(AABB body, AABB walls) {
      return new Vec3(
         correction(body.minX, body.maxX, walls.minX, walls.maxX),
         correction(body.minY, body.maxY, walls.minY, walls.maxY),
         correction(body.minZ, body.maxZ, walls.minZ, walls.maxZ)
      );
   }

   private static double correction(double min, double max, double wallMin, double wallMax) {
      if (max - min >= wallMax - wallMin) {
         return 0.0;
      } else {
         return min < wallMin ? wallMin - min : (max > wallMax ? wallMax - max : 0.0);
      }
   }

   public void set() {
      if (this.isSpreading()) {
         this.entityData.set(DATA_SET, this.reach(0.0F));
         this.entityData.set(DATA_SET_TICK, this.tickCount);
         this.entityData.set(DATA_END, this.tickCount + this.holdTicks);
         Vec3 at = this.position();
         Sounds.play(this.level(), at, SoundEvents.IRON_DOOR_CLOSE, 4.0F, 0.5F);
         Sounds.play(this.level(), at, SoundEvents.BELL_RESONATE, 4.0F, 0.7F);
         Sounds.play(this.level(), at, SoundEvents.BEACON_POWER_SELECT, 4.0F, 0.6F);
         Sounds.play(this.level(), at, SoundEvents.ANVIL_LAND, 1.2F, 0.5F);
      }
   }

   public void drop() {
      if (this.isHolding()) {
         this.entityData.set(DATA_END, this.tickCount);
         this.fall(this.position());
      }
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         Vec3 at = this.position();
         if (this.tickCount == 1) {
            Sounds.play(this.level(), at, SoundEvents.RESPAWN_ANCHOR_CHARGE, 1.5F, 0.6F);
            Sounds.play(this.level(), at, SoundEvents.BEACON_ACTIVATE, 1.5F, 0.7F);
            Sounds.play(this.level(), at, SoundEvents.ILLUSIONER_PREPARE_MIRROR, 1.2F, 0.6F);
         }

         if (this.isSpreading()) {
            float reach = this.reach(0.0F);
            if (reach >= this.most()) {
               this.set();
            } else if (this.tickCount % 6 == 0) {
               Sounds.play(this.level(), at, SoundEvents.AMETHYST_BLOCK_CHIME, 2.5F, 0.5F + reach / this.most());
            }
         }

         if (this.isHolding()) {
            if (this.tickCount % (this.isSpreading() ? 4 : 10) == 0) {
               this.gather();
            }

            this.hold();
         } else if (!this.held.isEmpty() || ACTIVE.get(this.ownerId) == this) {
            this.fall(at);
         }

         if (this.tickCount - 20 >= this.endTick()) {
            this.discard();
         }
      }
   }

   private void gather() {
      AABB walls = this.walls(0.0F);
      this.held
         .addAll(
            this.level()
               .getEntitiesOfClass(
                  LivingEntity.class,
                  walls,
                  living -> living.isAlive() && !living.isSpectator() && !(living instanceof ArmorStand) && walls.contains(living.getBoundingBox().getCenter())
               )
         );
   }

   private void hold() {
      AABB walls = this.walls(0.0F);
      Iterator<LivingEntity> it = this.held.iterator();

      while (it.hasNext()) {
         LivingEntity living = it.next();
         if (!living.isRemoved() && living.isAlive() && !living.isSpectator() && living.level() == this.level()) {
            Vec3 back = correction(living.getBoundingBox(), walls);
            if (!(back.lengthSqr() < 1.0E-8)) {
               if (living instanceof ServerPlayer player) {
                  if (Math.max(Math.abs(back.x), Math.max(Math.abs(back.y), Math.abs(back.z))) < 0.75) {
                     continue;
                  }

                  player.stopRiding();
                  player.connection.teleport(player.getX() + back.x, player.getY() + back.y, player.getZ() + back.z, player.getYRot(), player.getXRot());
                  player.setDeltaMovement(Vec3.ZERO);
               } else {
                  Entity moved = living.getRootVehicle();
                  if (moved != living && moved.getControllingPassenger() instanceof ServerPlayer) {
                     living.stopRiding();
                     moved = living;
                  }

                  moved.setPos(moved.getX() + back.x, moved.getY() + back.y, moved.getZ() + back.z);
                  Vec3 motion = moved.getDeltaMovement();
                  moved.setDeltaMovement(back.x != 0.0 ? 0.0 : motion.x, back.y != 0.0 ? 0.0 : motion.y, back.z != 0.0 ? 0.0 : motion.z);
                  if (living instanceof Mob mob) {
                     mob.getNavigation().stop();
                  }
               }

               this.strike(living.getBoundingBox().getCenter().add(back));
            }
         } else {
            it.remove();
         }
      }
   }

   private void strike(Vec3 at) {
      if (this.tickCount - (Integer)this.entityData.get(DATA_IMPACT_TICK) >= 5) {
         this.entityData.set(DATA_IMPACT, at.subtract(this.position()).toVector3f());
         this.entityData.set(DATA_IMPACT_TICK, this.tickCount);
         Sounds.play(this.level(), at, SoundEvents.AMETHYST_BLOCK_HIT, 1.0F, 0.6F);
         Sounds.play(this.level(), at, (SoundEvent)SoundEvents.RESPAWN_ANCHOR_DEPLETE.value(), 0.4F, 1.6F);
      }
   }

   private void fall(Vec3 at) {
      this.held.clear();
      if (this.ownerId != null && ACTIVE.get(this.ownerId) == this) {
         ACTIVE.remove(this.ownerId);
      }

      Sounds.play(this.level(), at, SoundEvents.BEACON_DEACTIVATE, 4.0F, 0.7F);
      Sounds.play(this.level(), at, SoundEvents.GLASS_BREAK, 4.0F, 0.6F);
      Sounds.play(this.level(), at, SoundEvents.AMETHYST_CLUSTER_BREAK, 4.0F, 0.6F);
      ServerPlayer owner = this.ownerId != null && this.getServer() != null ? this.getServer().getPlayerList().getPlayer(this.ownerId) : null;
      if (owner != null && this.ability != null && this.cooldownTicks > 0) {
         AbilityCooldowns.start(owner, this.ability, this.cooldownTicks);
      }
   }

   public void onRemovedFromLevel() {
      super.onRemovedFromLevel();
      if (!this.level().isClientSide() && this.ownerId != null && ACTIVE.get(this.ownerId) == this) {
         this.fall(this.position());
      }
   }

   private void clientTick() {
      ClientSide.run(() -> () -> ContainmentClient.tick(this));
      Vec3 at = this.position();
      if (this.tickCount == 1) {
         for (int i = 0; i < 64; i++) {
            double angle = i * (float) (Math.PI * 2) / 64.0;
            this.level().addParticle(ParticleTypes.END_ROD, at.x, at.y - 1.0 + 0.2, at.z, Math.cos(angle) * 0.45, 0.02, Math.sin(angle) * 0.45);
         }

         ClientSide.run(() -> () -> CameraShake.from(at, 1.0F, 20.0, 12));
      }

      if (this.tickCount == this.clientSetTick + 1 || this.tickCount == this.endTick()) {
         double range = this.reach(0.0F) * 1.8 + 16.0;
         ClientSide.run(() -> () -> CameraShake.from(at, 1.6F, range, 14));
      }
   }

   public void writeSpawnData(RegistryFriendlyByteBuf buffer) {
      buffer.writeVarInt(this.tickCount);
   }

   public void readSpawnData(RegistryFriendlyByteBuf buffer) {
      this.tickCount = buffer.readVarInt();
   }

   public AABB getBoundingBoxForCulling() {
      return this.walls(1.0F).inflate(2.0);
   }

   public boolean shouldRenderAtSqrDistance(double distanceSqr) {
      return distanceSqr < 65536.0;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(ValueInput input) {
   }

   protected void addAdditionalSaveData(ValueOutput output) {
   }

   public boolean isAttackable() {
      return false;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean canBeCollidedWith() {
      return false;
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }
}
