package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import com.amuletmod.util.VanillaEffects;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.animal.Bee;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class MonarchBeeEntity extends Bee implements Summons.Owned {
   private static final double GUARD_RADIUS = 18.0;
   private static final int RETARGET_TICKS = 10;
   private static final int SPREAD = 4;
   private static final Vector3f GOLD = new Vector3f(1.0F, 0.82F, 0.25F);
   @Nullable
   private UUID ownerId;
   private int lifetime = 1200;
   private int stingCooldown;
   private int retarget;
   private final float phase = this.random.nextFloat() * (float) (Math.PI * 2);

   public MonarchBeeEntity(EntityType<? extends Bee> type, Level level) {
      super(type, level);
   }

   public static Builder createAttributes() {
      return Bee.createAttributes().add(Attributes.FLYING_SPEED, 0.9).add(Attributes.MAX_HEALTH, 10.0);
   }

   public static MonarchBeeEntity summon(ServerLevel level, ServerPlayer owner, Vec3 at, Vec3 velocity, int lifetime) {
      MonarchBeeEntity bee = new MonarchBeeEntity((EntityType<? extends Bee>)ModEntities.MONARCH_BEE.get(), level);
      bee.ownerId = owner.getUUID();
      bee.lifetime = lifetime;
      bee.moveTo(at.x, at.y, at.z, level.random.nextFloat() * 360.0F, 0.0F);
      bee.setDeltaMovement(velocity);
      bee.setRemainingPersistentAngerTime(40);
      level.addFreshEntity(bee);
      return bee;
   }

   @Nullable
   @Override
   public UUID summonerId() {
      return this.ownerId;
   }

   @Nullable
   private Player owner() {
      return this.ownerId == null ? null : this.level().getPlayerByUUID(this.ownerId);
   }

   protected void registerGoals() {
      super.registerGoals();
      this.goalSelector.removeAllGoals(goal -> true);
      this.targetSelector.removeAllGoals(goal -> true);
   }

   protected void customServerAiStep() {
      super.customServerAiStep();
      Player owner = this.owner();
      if (owner != null && owner.isAlive() && owner.level() == this.level() && --this.lifetime > 0) {
         if (this.stingCooldown > 0) {
            this.stingCooldown--;
         }

         LivingEntity target = this.getTarget();
         if (target != null && (!target.isAlive() || !Summons.isFoe(owner, target) || target.distanceToSqr(owner) > 676.0)) {
            this.setTarget(null);
            target = null;
            this.retarget = 0;
         }

         if (--this.retarget <= 0) {
            this.retarget = 10 + this.random.nextInt(5);
            target = this.pickTarget(owner);
            this.setTarget(target);
         }

         Vec3 wanted;
         double speed;
         if (target != null) {
            Vec3 heart = target.position().add(0.0, target.getBbHeight() * 0.6, 0.0);
            if (this.stingCooldown > 0) {
               double angle = this.tickCount * 0.25 + this.phase;
               double radius = target.getBbWidth() * 0.5 + 1.6;
               wanted = heart.add(Math.cos(angle) * radius, 0.6 + Math.sin(this.tickCount * 0.3 + this.phase) * 0.5, Math.sin(angle) * radius);
               speed = 1.2;
            } else {
               wanted = heart;
               speed = 1.7;
               double reach = target.getBbWidth() * 0.5 + 0.9;
               if (this.position().add(0.0, this.getBbHeight() * 0.5, 0.0).distanceToSqr(heart) < reach * reach) {
                  this.sting(target, owner);
               }
            }
         } else {
            double angle = this.tickCount * 0.06 + this.phase;
            double radius = 2.2 + this.getId() % 5 * 0.4;
            wanted = owner.position().add(Math.cos(angle) * radius, 1.6 + Math.sin(this.tickCount * 0.09 + this.phase) * 0.6, Math.sin(angle) * radius);
            speed = this.distanceToSqr(wanted) > 64.0 ? 1.6 : 1.0;
         }

         this.getMoveControl().setWantedPosition(wanted.x, wanted.y, wanted.z, speed);
         if (this.distanceToSqr(owner) > 2304.0) {
            this.teleportTo(owner.getX(), owner.getY() + 2.0, owner.getZ());
         }
      } else {
         this.vanish();
      }
   }

   @Nullable
   private LivingEntity pickTarget(Player owner) {
      LivingEntity attacker = owner.getLastHurtByMob();
      if (attacker != null && attacker.distanceToSqr(owner) <= 324.0 && Summons.isFoe(owner, attacker) && this.random.nextInt(3) > 0) {
         return attacker;
      } else {
         List<LivingEntity> foes = Summons.foesAround(owner, 18.0);
         return foes.isEmpty() ? null : foes.get(this.random.nextInt(Math.min(4, foes.size())));
      }
   }

   private void sting(LivingEntity target, Player owner) {
      this.stingCooldown = 20 + this.random.nextInt(20);
      target.setLastHurtByPlayer(owner);
      if (target.hurt(ModDamage.source(this.level(), ModDamage.MONARCH_STING, this, this), (float)this.getAttributeValue(Attributes.ATTACK_DAMAGE))) {
         target.setStingerCount(target.getStingerCount() + 1);
         target.addEffect(new MobEffectInstance(VanillaEffects.POISON, 100, 0), this);
         this.playSound(SoundEvents.BEE_STING, 1.0F, 1.0F);
      }
   }

   public void vanish() {
      if (this.level() instanceof ServerLevel level && !this.isRemoved()) {
         Vec3 at = this.position().add(0.0, this.getBbHeight() * 0.5, 0.0);
         level.sendParticles(ParticleTypes.CHERRY_LEAVES, at.x, at.y, at.z, 5, 0.2, 0.2, 0.2, 0.02);
         level.sendParticles(new DustParticleOptions(GOLD, 0.9F), at.x, at.y, at.z, 5, 0.2, 0.2, 0.2, 0.0);
         if (this.random.nextInt(3) == 0) {
            Sounds.play(level, at, SoundEvents.PINK_PETALS_BREAK, 0.6F, 1.2F + this.random.nextFloat() * 0.3F);
         }
      }

      this.discard();
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide() && this.random.nextInt(3) == 0) {
         this.level().addParticle(new DustParticleOptions(GOLD, 0.5F), this.getX(), this.getY() + this.getBbHeight() * 0.5, this.getZ(), 0.0, 0.0, 0.0);
      }
   }

   public void updatePersistentAnger(ServerLevel level, boolean remember) {
      this.setRemainingPersistentAngerTime(40);
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      Entity attacker = source.getEntity();
      return attacker == null
            || this.ownerId == null
            || !this.ownerId.equals(attacker.getUUID()) && !(attacker instanceof Summons.Owned owned && this.ownerId.equals(owned.summonerId()))
         ? super.hurt(source, amount)
         : false;
   }

   public boolean isAlliedTo(Entity other) {
      if (this.ownerId == null || !this.ownerId.equals(other.getUUID()) && !(other instanceof Summons.Owned owned && this.ownerId.equals(owned.summonerId()))) {
         Player owner = this.owner();
         return owner != null && owner.isAlliedTo(other) || super.isAlliedTo(other);
      } else {
         return true;
      }
   }

   public Component getName() {
      Player owner = this.owner();
      return (Component)(!this.hasCustomName() && owner != null
         ? Component.translatable("entity.amuletmod.monarch_bee.owned", new Object[]{owner.getName()})
         : super.getName());
   }

   public InteractionResult mobInteract(Player player, InteractionHand hand) {
      return InteractionResult.PASS;
   }

   public boolean isFood(ItemStack stack) {
      return false;
   }

   @Nullable
   public Bee getBreedOffspring(ServerLevel level, AgeableMob partner) {
      return null;
   }

   public boolean canBeLeashed() {
      return false;
   }

   protected boolean shouldDropLoot() {
      return false;
   }

   protected int getBaseExperienceReward() {
      return 0;
   }

   public boolean removeWhenFarAway(double distance) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   public void addAdditionalSaveData(ValueOutput output) {
   }

   public void readAdditionalSaveData(ValueInput input) {
   }
}
