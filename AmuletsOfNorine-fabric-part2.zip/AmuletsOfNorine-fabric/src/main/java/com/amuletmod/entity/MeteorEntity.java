package com.amuletmod.entity;

import com.amuletmod.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.EventHooks;
import com.amuletmod.neo.event.ExplosionEvent.Detonate;

public class MeteorEntity extends Projectile {
   public static final float EXPLOSION_POWER = 2.0F;
   private static final int MAX_LIFETIME = 200;

   public MeteorEntity(EntityType<? extends MeteorEntity> type, Level level) {
      super(type, level);
   }

   public MeteorEntity(Level level, LivingEntity owner, Vec3 position, Vec3 velocity) {
      this((EntityType<? extends MeteorEntity>)ModEntities.METEOR.get(), level);
      this.setOwner(owner);
      this.setPos(position);
      this.setDeltaMovement(velocity);
   }

   protected void defineSynchedData(Builder builder) {
   }

   public void tick() {
      super.tick();
      this.steer();
      Vec3 motion = this.getDeltaMovement();
      if (!this.level().isClientSide()) {
         HitResult hit = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
         if (hit.getType() != Type.MISS && !EventHooks.onProjectileImpact(this, hit)) {
            this.onHit(hit);
            return;
         }

         if (this.tickCount > this.lifetime()) {
            this.burnOut();
            return;
         }
      } else {
         this.spawnTrail(motion);
      }

      this.setPos(this.getX() + motion.x, this.getY() + motion.y, this.getZ() + motion.z);
   }

   protected void steer() {
   }

   protected int lifetime() {
      return 200;
   }

   protected void burnOut() {
      this.discard();
   }

   protected void spawnTrail(Vec3 motion) {
      RandomSource random = this.random;
      double middle = this.getBbHeight() * 0.5;
      double spread = this.getBbWidth() * 0.7;

      for (int i = 0; i < 3; i++) {
         double back = i / 3.0;
         double x = this.getX() - motion.x * back;
         double y = this.getY() + middle - motion.y * back;
         double z = this.getZ() - motion.z * back;
         this.level()
            .addAlwaysVisibleParticle(
               ParticleTypes.FLAME,
               true,
               x + (random.nextDouble() - 0.5) * spread,
               y + (random.nextDouble() - 0.5) * spread,
               z + (random.nextDouble() - 0.5) * spread,
               0.0,
               0.0,
               0.0
            );
         this.level().addAlwaysVisibleParticle(ParticleTypes.LARGE_SMOKE, true, x, y, z, 0.0, 0.02, 0.0);
      }

      if (random.nextInt(3) == 0) {
         this.level().addAlwaysVisibleParticle(ParticleTypes.LAVA, true, this.getX(), this.getY() + middle, this.getZ(), 0.0, 0.0, 0.0);
      }
   }

   protected boolean canHitEntity(Entity target) {
      return super.canHitEntity(target) && target != this.getOwner() && !(target instanceof MeteorEntity);
   }

   protected void onHit(HitResult result) {
      super.onHit(result);
      if (!this.level().isClientSide()) {
         this.detonate(result.getLocation());
      }
   }

   public void detonate(Vec3 at) {
      this.level().explode(this, this.damageSources().explosion(this, this.getOwner()), null, at.x, at.y, at.z, 2.0F, false, ExplosionInteraction.NONE);
      ((ServerLevel)this.level()).sendParticles(ParticleTypes.LAVA, at.x, at.y + 0.3, at.z, 12, 0.5, 0.2, 0.5, 0.0);
      this.discard();
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean displayFireAnimation() {
      return true;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   public boolean shouldRenderAtSqrDistance(double distanceSqr) {
      return distanceSqr < 25600.0;
   }

   @EventBusSubscriber(
      modid = "amuletmod"
   )
   public static final class MeteorEvents {
      private MeteorEvents() {
      }

      @SubscribeEvent
      public static void onDetonate(Detonate event) {
         if (event.getExplosion().getDirectSourceEntity() instanceof MeteorEntity meteor) {
            Entity var3 = meteor.getOwner();
            event.getAffectedEntities().removeIf(entity -> entity == var3 || entity instanceof MeteorEntity);
         }
      }
   }
}
