package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.client.MeteorVolleyClient;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class MeteorVolleyEntity extends Entity {
   public static final int CIRCLES = 5;
   public static final int APPEAR_STAGGER = 4;
   public static final int APPEAR_TICKS = 8;
   public static final int FIRE_TICK = 44;
   public static final int FIRE_STAGGER = 3;
   public static final int LAST_FIRE = 56;
   public static final int CLOSE_TICKS = 8;
   public static final float CIRCLE_SIZE = 0.62F;
   private static final double FORWARD = 2.6;
   private static final double SPREAD = 1.6;
   private static final float[] FAN = new float[]{195.0F, 142.5F, 90.0F, 37.5F, -15.0F};
   private static final int UNLOCK_TICKS = 10;
   private static final int MAX_AGE = 316;
   private static final Vec3 UP = new Vec3(0.0, 1.0, 0.0);
   private static final EntityDataAccessor<Integer> DATA_CASTER = SynchedEntityData.defineId(MeteorVolleyEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_TARGET = SynchedEntityData.defineId(MeteorVolleyEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Vector3f> DATA_MARK = SynchedEntityData.defineId(MeteorVolleyEntity.class, EntityDataSerializers.VECTOR3);
   private static final EntityDataAccessor<Float> DATA_TARGET_WIDTH = SynchedEntityData.defineId(MeteorVolleyEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Float> DATA_TARGET_HEIGHT = SynchedEntityData.defineId(MeteorVolleyEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Boolean> DATA_LOCKED = SynchedEntityData.defineId(MeteorVolleyEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Integer> DATA_FIZZLE = SynchedEntityData.defineId(MeteorVolleyEntity.class, EntityDataSerializers.INT);
   @Nullable
   private LivingEntity caster;
   @Nullable
   private LivingEntity target;
   private float damage;
   private float blastRadius;
   private final List<SeekingMeteorEntity> meteors = new ArrayList<>();
   private int lastLocked;
   private Vec3 targetVelocity = Vec3.ZERO;
   @Nullable
   private Vec3 markBefore;
   @Nullable
   private Vec3 markNow;
   public float reticleBefore;
   public float reticle;

   public MeteorVolleyEntity(EntityType<? extends MeteorVolleyEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
      this.noCulling = true;
   }

   public MeteorVolleyEntity(ServerLevel level, LivingEntity caster, LivingEntity target, float damage, float blastRadius) {
      this((EntityType<? extends MeteorVolleyEntity>)ModEntities.METEOR_VOLLEY.get(), level);
      this.caster = caster;
      this.target = target;
      this.damage = damage;
      this.blastRadius = blastRadius;
      Vec3 eye = caster.getEyePosition();
      this.moveTo(eye.x, eye.y, eye.z, 0.0F, 0.0F);
      this.entityData.set(DATA_CASTER, caster.getId());
      this.entityData.set(DATA_TARGET, target.getId());
      this.entityData.set(DATA_MARK, middleOf(target).toVector3f());
      this.entityData.set(DATA_TARGET_WIDTH, target.getBbWidth());
      this.entityData.set(DATA_TARGET_HEIGHT, target.getBbHeight());
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_CASTER, -1);
      builder.define(DATA_TARGET, -1);
      builder.define(DATA_MARK, new Vector3f());
      builder.define(DATA_TARGET_WIDTH, 0.6F);
      builder.define(DATA_TARGET_HEIGHT, 1.8F);
      builder.define(DATA_LOCKED, true);
      builder.define(DATA_FIZZLE, -1);
   }

   public int casterId() {
      return (Integer)this.entityData.get(DATA_CASTER);
   }

   public int targetId() {
      return (Integer)this.entityData.get(DATA_TARGET);
   }

   public Vec3 mark() {
      return new Vec3((Vector3f)this.entityData.get(DATA_MARK));
   }

   public float targetWidth() {
      return (Float)this.entityData.get(DATA_TARGET_WIDTH);
   }

   public float targetHeight() {
      return (Float)this.entityData.get(DATA_TARGET_HEIGHT);
   }

   public boolean isLocked() {
      return (Boolean)this.entityData.get(DATA_LOCKED);
   }

   public int fizzledAt() {
      return (Integer)this.entityData.get(DATA_FIZZLE);
   }

   private static Vec3 middleOf(Entity entity) {
      return entity.position().add(0.0, entity.getBbHeight() * 0.5, 0.0);
   }

   public static int opensAt(int k) {
      return k * 4;
   }

   public static int firesAt(int k) {
      return 44 + k * 3;
   }

   public int closesAt(int k) {
      int fizzled = this.fizzledAt();
      return fizzled >= 0 && fizzled < firesAt(k) ? fizzled : firesAt(k);
   }

   public boolean fired(int k) {
      int fizzled = this.fizzledAt();
      return fizzled < 0 || fizzled > firesAt(k);
   }

   public Vec3 eye(float partialTick) {
      Entity who = this.level().getEntity(this.casterId());
      return who != null ? who.getEyePosition(partialTick) : this.getPosition(partialTick);
   }

   public Vec3 aim(float partialTick) {
      Entity who = this.tickCount <= 56 ? this.level().getEntity(this.targetId()) : null;
      if (who != null && who.isAlive()) {
         return who.getPosition(partialTick).add(0.0, who.getBbHeight() * 0.5, 0.0);
      } else {
         return this.markBefore != null && this.markNow != null ? this.markBefore.lerp(this.markNow, partialTick) : this.mark();
      }
   }

   private static Vec3[] frame(Vec3 eye, Vec3 aim) {
      Vec3 forward = aim.subtract(eye);
      forward = forward.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 0.0, 1.0) : forward.normalize();
      Vec3 right = forward.cross(UP);
      right = right.lengthSqr() < 1.0E-4 ? new Vec3(1.0, 0.0, 0.0) : right.normalize();
      return new Vec3[]{forward, right, right.cross(forward)};
   }

   private static Vec3 outward(int k, Vec3[] frame) {
      float angle = FAN[k] * (float) (Math.PI / 180.0);
      return frame[1].scale(Mth.cos(angle)).add(frame[2].scale(Mth.sin(angle)));
   }

   public static Vec3 circleCenter(int k, Vec3 eye, Vec3 aim) {
      Vec3[] frame = frame(eye, aim);
      double forward = Mth.clamp(eye.distanceTo(aim) * 0.5, 1.2, 2.6);
      return eye.add(frame[0].scale(forward)).add(outward(k, frame).scale(1.6));
   }

   public static Vec3 launchHeading(int k, Vec3 eye, Vec3 aim) {
      Vec3[] frame = frame(eye, aim);
      return outward(k, frame).add(frame[0].scale(0.55)).add(frame[2].scale(0.5)).normalize();
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         ServerLevel level = (ServerLevel)this.level();
         boolean casterHere = this.caster != null && this.caster.isAlive() && !this.caster.isRemoved() && this.caster.level() == level;
         if (casterHere) {
            this.setPos(this.caster.getEyePosition());
         } else if (this.fizzledAt() < 0 && this.tickCount <= 56) {
            this.entityData.set(DATA_FIZZLE, this.tickCount);
         }

         if (this.target != null && (!this.target.isAlive() || this.target.isRemoved() || this.target.level() != level)) {
            this.target = null;
         }

         if (this.target != null && this.tickCount <= 56) {
            Vec3 middle = middleOf(this.target);
            this.targetVelocity = SeekingMeteorEntity.trackVelocity(this.targetVelocity, middle.subtract(this.mark()));
            this.entityData.set(DATA_MARK, middle.toVector3f());
         }

         for (int k = 0; k < 5; k++) {
            if (this.tickCount == firesAt(k) && casterHere && this.fired(k)) {
               this.fire(level, k);
            }
         }

         this.sounds(level);
         this.followMeteors();
         if (this.tickCount > 64 && !this.isLocked() && this.tickCount > this.lastLocked + 10 || this.tickCount > 316) {
            this.discard();
         }
      }
   }

   private void fire(ServerLevel level, int k) {
      Vec3 eye = this.caster.getEyePosition();
      Vec3 aim = this.mark();
      Vec3 middle = circleCenter(k, eye, aim);
      BlockPos pos = BlockPos.containing(middle);
      if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) {
         level.sendParticles(ParticleTypes.LARGE_SMOKE, middle.x, middle.y, middle.z, 6, 0.2, 0.2, 0.2, 0.02);
         Sounds.play(level, middle, SoundEvents.FIRE_EXTINGUISH, 0.8F, 0.8F);
      } else {
         SeekingMeteorEntity meteor = new SeekingMeteorEntity(
            level, this.caster, this.target, aim, this.targetVelocity, middle, launchHeading(k, eye, aim), this.damage, this.blastRadius
         );
         level.addFreshEntity(meteor);
         this.meteors.add(meteor);
         Sounds.play(level, middle, SoundEvents.BLAZE_SHOOT, 1.0F, 0.6F + k * 0.07F);
         Sounds.play(level, middle, SoundEvents.FIRECHARGE_USE, 0.9F, 0.7F);
         Sounds.play(level, middle, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 0.3F, 1.8F);
      }
   }

   private void followMeteors() {
      boolean locked = this.tickCount <= 56 && this.fizzledAt() < 0;
      if (this.tickCount > 44) {
         Vec3 sum = Vec3.ZERO;
         int homing = 0;

         for (SeekingMeteorEntity meteor : this.meteors) {
            if (!meteor.isRemoved() && meteor.isGuided()) {
               sum = sum.add(meteor.aim());
               homing++;
            }
         }

         if (homing > 0) {
            locked = true;
            if (this.tickCount > 56) {
               this.entityData.set(DATA_MARK, sum.scale(1.0 / homing).toVector3f());
            }
         }
      }

      if (locked) {
         this.lastLocked = this.tickCount;
      }

      if (locked != this.isLocked()) {
         this.entityData.set(DATA_LOCKED, locked);
      }
   }

   private void sounds(ServerLevel level) {
      if (this.caster != null && this.fizzledAt() < 0) {
         Vec3 eye = this.position();
         Vec3 aim = this.mark();

         for (int k = 0; k < 5; k++) {
            if (this.tickCount == opensAt(k) + 1) {
               Vec3 circle = circleCenter(k, eye, aim);
               Sounds.play(level, circle, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0F, 0.8F + k * 0.1F);
               Sounds.play(level, circle, SoundEvents.FIRECHARGE_USE, 0.45F, 1.2F + k * 0.12F);
            }
         }

         if (this.tickCount == 26) {
            Sounds.play(level, eye, SoundEvents.WARDEN_SONIC_CHARGE, 0.55F, 1.7F);
         }

         if (this.tickCount == 38) {
            Sounds.play(level, eye, SoundEvents.RESPAWN_ANCHOR_CHARGE, 1.0F, 0.6F);
         }
      }
   }

   private void clientTick() {
      this.markBefore = this.markNow == null ? this.mark() : this.markNow;
      this.markNow = this.mark();
      this.reticleBefore = this.reticle;
      this.reticle = this.reticle + ((this.isLocked() ? 1.0F : 0.0F) - this.reticle) * 0.2F;
      Vec3 eye = this.eye(1.0F);
      Vec3 aim = this.aim(1.0F);
      int fizzled = this.fizzledAt();

      for (int k = 0; k < 5; k++) {
         Vec3 circle = circleCenter(k, eye, aim);
         Vec3 facing = aim.subtract(circle).normalize();
         int closes = this.closesAt(k);
         if (this.tickCount > opensAt(k) + 2 && this.tickCount < closes && this.random.nextInt(3) != 0) {
            Vec3 from = circle.add(this.onDisc(facing, 0.8 + this.random.nextDouble() * 0.5));
            Vec3 pull = circle.subtract(from).scale(0.12);
            this.level()
               .addParticle(
                  (ParticleOptions)(this.random.nextBoolean() ? ParticleTypes.SMALL_FLAME : new DustParticleOptions(new Vector3f(1.0F, 0.25F, 0.08F), 0.9F)),
                  from.x,
                  from.y,
                  from.z,
                  pull.x,
                  pull.y,
                  pull.z
               );
         }

         if (this.tickCount == firesAt(k) && this.fired(k)) {
            for (int i = 0; i < 14; i++) {
               Vec3 out = this.onDisc(facing, 1.0);
               Vec3 at = circle.add(out.scale(0.5));
               this.level()
                  .addParticle(
                     ParticleTypes.FLAME, at.x, at.y, at.z, out.x * 0.18 + facing.x * 0.1, out.y * 0.18 + facing.y * 0.1, out.z * 0.18 + facing.z * 0.1
                  );
            }

            for (int i = 0; i < 4; i++) {
               this.level().addParticle(ParticleTypes.LAVA, circle.x, circle.y, circle.z, 0.0, 0.0, 0.0);
            }

            this.level().addParticle(ParticleTypes.FLASH, circle.x, circle.y, circle.z, 0.0, 0.0, 0.0);
         }

         if (this.tickCount == closes + 2 && fizzled >= 0 && fizzled < firesAt(k)) {
            for (int i = 0; i < 6; i++) {
               this.level()
                  .addParticle(
                     ParticleTypes.SMOKE,
                     circle.x + this.random.nextGaussian() * 0.2,
                     circle.y + this.random.nextGaussian() * 0.2,
                     circle.z + this.random.nextGaussian() * 0.2,
                     0.0,
                     0.02,
                     0.0
                  );
            }
         }
      }

      ClientSide.run(() -> () -> MeteorVolleyClient.tick(this));
   }

   private Vec3 onDisc(Vec3 normal, double radius) {
      Vec3 side = normal.cross(Math.abs(normal.y) > 0.95 ? new Vec3(1.0, 0.0, 0.0) : UP).normalize();
      Vec3 other = normal.cross(side);
      double angle = this.random.nextDouble() * (float) (Math.PI * 2);
      return side.scale(Math.cos(angle) * radius).add(other.scale(Math.sin(angle) * radius));
   }

   public boolean shouldRenderAtSqrDistance(double distanceSqr) {
      return distanceSqr < 25600.0;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(ValueInput input) {
   }

   protected void addAdditionalSaveData(ValueOutput output) {
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }
}
