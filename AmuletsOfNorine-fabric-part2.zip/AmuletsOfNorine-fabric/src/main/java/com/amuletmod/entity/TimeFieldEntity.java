package com.amuletmod.entity;

import com.amuletmod.client.CameraShake;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Easing;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.Map.Entry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.EventPriority;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.Tags.EntityTypes;
import com.amuletmod.neo.event.EntityJoinLevelEvent;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;
import com.amuletmod.neo.event.ServerStoppedEvent;
import org.jetbrains.annotations.Nullable;

public class TimeFieldEntity extends Entity {
   public static final int EXPAND_TICKS = 8;
   public static final int COLLAPSE_TICKS = 16;
   private static final int PROJECTILE_GRACE_TICKS = 2;
   private static final double MAX_STORED_PUSH = 1.6;
   private static final String FROZEN_TAG = "amuletmod:time_frozen";
   private static final EntityDataAccessor<Float> DATA_RADIUS = SynchedEntityData.defineId(TimeFieldEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Integer> DATA_DURATION = SynchedEntityData.defineId(TimeFieldEntity.class, EntityDataSerializers.INT);
   private static final Map<Entity, TimeFieldEntity> HOLDERS = new WeakHashMap<>();
   private final Map<Entity, TimeFieldEntity.Frozen> frozen = new LinkedHashMap<>();

   public TimeFieldEntity(EntityType<? extends TimeFieldEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public TimeFieldEntity(ServerLevel level, ServerPlayer caster, float radius, int duration) {
      this((EntityType<? extends TimeFieldEntity>)ModEntities.TIME_FIELD.get(), level);
      this.moveTo(caster.getX(), caster.getY(), caster.getZ(), 0.0F, 0.0F);
      this.entityData.set(DATA_RADIUS, radius);
      this.entityData.set(DATA_DURATION, duration);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_RADIUS, 8.0F);
      builder.define(DATA_DURATION, 100);
   }

   public float radius() {
      return (Float)this.entityData.get(DATA_RADIUS);
   }

   public int duration() {
      return (Integer)this.entityData.get(DATA_DURATION);
   }

   public Vec3 center() {
      return this.position().add(0.0, 1.0, 0.0);
   }

   public boolean isStoppingTime() {
      return this.tickCount < this.duration();
   }

   public float currentRadius(float partialTick) {
      return this.radius() * Easing.outCubic((this.tickCount + partialTick) / 8.0F);
   }

   public boolean encloses(Entity entity, double radius) {
      return entity.position().add(0.0, entity.getBbHeight() * 0.5, 0.0).distanceToSqr(this.center()) < radius * radius;
   }

   public AABB reach(double radius) {
      return new AABB(this.center(), this.center()).inflate(radius);
   }

   public static boolean canFreeze(Entity entity) {
      if (entity instanceof Player || entity instanceof TimeFieldEntity || !entity.isAlive() || entity.getType().is(EntityTypes.BOSSES)) {
         return false;
      } else if (entity instanceof LivingEntity) {
         return true;
      } else {
         return entity instanceof Projectile projectile
            ? !(projectile instanceof FishingHook)
               && !(projectile instanceof FireworkRocketEntity)
               && projectile.tickCount >= 2
               && projectile.getDeltaMovement().lengthSqr() > 1.0E-4
            : entity instanceof PrimedTnt || entity instanceof FallingBlockEntity;
      }
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         if (this.tickCount == 1) {
            this.playStopSounds();
         }

         if (this.isStoppingTime()) {
            double radius = this.currentRadius(0.0F);

            for (Entity entity : this.level()
               .getEntities(this, this.reach(radius), entityx -> !HOLDERS.containsKey(entityx) && canFreeze(entityx) && this.encloses(entityx, radius))) {
               this.freeze(entity);
            }

            this.holdAll();
            if (this.tickCount % 10 == 0) {
               Sounds.play(
                  this.level(),
                  this.center(),
                  this.tickCount % 20 == 0 ? SoundEvents.WOODEN_BUTTON_CLICK_ON : SoundEvents.WOODEN_BUTTON_CLICK_OFF,
                  0.9F,
                  this.tickCount % 20 == 0 ? 1.8F : 1.3F
               );
            }
         } else if (this.tickCount == this.duration()) {
            this.releaseAll(true);
            this.playResumeSounds();
         }

         if (this.tickCount >= this.duration() + 16) {
            this.discard();
         }
      }
   }

   private void freeze(Entity entity) {
      TimeFieldEntity.Frozen state = new TimeFieldEntity.Frozen(entity);
      this.frozen.put(entity, state);
      HOLDERS.put(entity, this);
      CompoundTag saved = new CompoundTag();
      saved.putBoolean("NoGravity", state.hadNoGravity);
      saved.putBoolean("NoAI", state.hadNoAi);
      entity.getPersistentData().put("amuletmod:time_frozen", saved);
      entity.setNoGravity(true);
      if (entity instanceof Mob mob) {
         mob.setNoAi(true);
         mob.getNavigation().stop();
      }

      if (entity instanceof Creeper creeper) {
         creeper.setSwellDir(-1);
      }

      hold(entity, state);
      entity.hasImpulse = true;
      ((ServerLevel)this.level())
         .sendParticles(ParticleTypes.ENCHANT, entity.getX(), entity.getY() + entity.getBbHeight() * 0.5, entity.getZ(), 8, 0.3, 0.3, 0.3, 0.5);
   }

   private static void hold(Entity entity, TimeFieldEntity.Frozen state) {
      entity.setPos(state.position.x, state.position.y, state.position.z);
      entity.setDeltaMovement(state.heldMotion(entity));
      entity.setYRot(state.yRot);
      entity.setXRot(state.xRot);
      entity.fallDistance = 0.0F;
      if (entity instanceof LivingEntity living) {
         living.yHeadRot = state.headRot;
         living.yBodyRot = state.bodyRot;
      }

      if (entity instanceof PrimedTnt tnt) {
         tnt.setFuse(state.fuse);
      }

      if (entity instanceof AbstractHurtingProjectile fireball) {
         fireball.accelerationPower = 0.0;
      }
   }

   private void holdAll() {
      Iterator<Entry<Entity, TimeFieldEntity.Frozen>> it = this.frozen.entrySet().iterator();

      while (it.hasNext()) {
         Entry<Entity, TimeFieldEntity.Frozen> entry = it.next();
         if (entry.getKey().isRemoved()) {
            HOLDERS.remove(entry.getKey());
            it.remove();
         } else {
            hold(entry.getKey(), entry.getValue());
         }
      }
   }

   private void releaseAll(boolean landStoredHits) {
      if (!this.frozen.isEmpty()) {
         List<Entry<Entity, TimeFieldEntity.Frozen>> entries = new ArrayList<>(this.frozen.entrySet());
         this.frozen.clear();
         entries.sort(Comparator.comparingInt(entryx -> entryx.getKey() instanceof LivingEntity ? 0 : 1));

         for (Entry<Entity, TimeFieldEntity.Frozen> entry : entries) {
            this.release(entry.getKey(), entry.getValue(), landStoredHits);
         }
      }
   }

   private void release(Entity entity, TimeFieldEntity.Frozen state, boolean landStoredHits) {
      HOLDERS.remove(entity);
      entity.getPersistentData().remove("amuletmod:time_frozen");
      if (!entity.isRemoved()) {
         entity.setNoGravity(state.hadNoGravity);
         if (entity instanceof Mob mob) {
            mob.setNoAi(state.hadNoAi);
         }

         if (entity instanceof Creeper creeper) {
            creeper.setSwellDir(state.swellDir);
         }

         if (entity instanceof AbstractHurtingProjectile fireball) {
            fireball.accelerationPower = state.power;
         }

         entity.setDeltaMovement(state.motion);
         entity.hasImpulse = true;
         entity.hurtMarked = true;
         if (landStoredHits && state.storedDamage > 0.0F && state.storedSource != null && entity instanceof LivingEntity living && living.isAlive()) {
            this.landStoredHits(living, state);
         }
      }
   }

   private void landStoredHits(LivingEntity living, TimeFieldEntity.Frozen state) {
      living.invulnerableTime = 0;
      living.hurt(state.storedSource, state.storedDamage);
      living.setDeltaMovement(living.getDeltaMovement().add(state.storedPush));
      living.hurtMarked = true;
      ServerLevel level = (ServerLevel)this.level();
      Vec3 at = living.position().add(0.0, living.getBbHeight() * 0.5, 0.0);
      int sparks = Math.min(40, 6 + state.hits * 4);
      level.sendParticles(ParticleTypes.ENCHANTED_HIT, at.x, at.y, at.z, sparks, 0.3, 0.4, 0.3, 0.4);
      level.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, sparks, 0.3, 0.4, 0.3, 0.5);
      Sounds.play(level, at, SoundEvents.PLAYER_ATTACK_CRIT, 1.0F, 0.8F);
      Sounds.play(level, at, SoundEvents.PLAYER_ATTACK_STRONG, 1.0F, 0.7F);
      if (state.hits >= 3) {
         level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
         Sounds.play(level, at, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 0.5F, 1.5F);
      }
   }

   private void storeHit(LivingEntity target, DamageSource source, float amount) {
      TimeFieldEntity.Frozen state = this.frozen.get(target);
      if (state != null) {
         state.storedDamage += amount;
         state.storedSource = source;
         state.hits++;
         Entity attacker = source.getEntity();
         if (attacker != null) {
            Vec3 push = target.position().subtract(attacker.position()).multiply(1.0, 0.0, 1.0);
            if (push.lengthSqr() > 1.0E-4) {
               state.storedPush = state.storedPush.add(push.normalize().scale(0.25)).add(0.0, 0.06, 0.0);
               if (state.storedPush.length() > 1.6) {
                  state.storedPush = state.storedPush.normalize().scale(1.6);
               }
            }
         }

         ServerLevel level = (ServerLevel)this.level();
         Vec3 at = target.position().add(0.0, target.getBbHeight() * 0.6, 0.0);
         level.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 5, 0.25, 0.25, 0.25, 0.0);
         Sounds.play(level, at, SoundEvents.AMETHYST_BLOCK_HIT, 0.7F, 1.4F + level.random.nextFloat() * 0.5F);
      }
   }

   private void playStopSounds() {
      Vec3 at = this.center();
      Sounds.play(this.level(), at, SoundEvents.BELL_BLOCK, 2.0F, 0.5F);
      Sounds.play(this.level(), at, SoundEvents.BEACON_DEACTIVATE, 1.0F, 0.5F);
      Sounds.play(this.level(), at, (SoundEvent)SoundEvents.RESPAWN_ANCHOR_DEPLETE.value(), 1.0F, 0.6F);
      Sounds.play(this.level(), at, SoundEvents.ILLUSIONER_PREPARE_MIRROR, 0.8F, 0.6F);
   }

   private void playResumeSounds() {
      Vec3 at = this.center();
      Sounds.play(this.level(), at, SoundEvents.BELL_BLOCK, 2.0F, 0.8F);
      Sounds.play(this.level(), at, SoundEvents.BEACON_ACTIVATE, 1.0F, 1.6F);
      Sounds.play(this.level(), at, SoundEvents.RESPAWN_ANCHOR_CHARGE, 1.0F, 1.5F);
   }

   private void clientTick() {
      RandomSource random = this.random;
      Vec3 center = this.center();
      float radius = this.radius();
      if (this.tickCount == 1 || this.tickCount == this.duration()) {
         for (int i = 0; i < 64; i++) {
            double angle = i * (float) (Math.PI * 2) / 64.0;
            this.level()
               .addParticle(
                  ParticleTypes.END_ROD, center.x, center.y, center.z, Math.cos(angle) * 0.6, (random.nextDouble() - 0.5) * 0.1, Math.sin(angle) * 0.6
               );
         }

         float strength = this.tickCount == 1 ? 1.4F : 0.9F;
         ClientSide.run(() -> () -> CameraShake.from(center, strength, radius + 8.0, 14));
      }

      if (this.isStoppingTime()) {
         double current = this.currentRadius(0.0F);

         for (int i = 0; i < 3; i++) {
            Vec3 direction = new Vec3(random.nextGaussian(), random.nextGaussian(), random.nextGaussian());
            if (!(direction.lengthSqr() < 1.0E-6)) {
               Vec3 at = center.add(direction.normalize().scale(current * Math.cbrt(random.nextDouble())));
               this.level().addParticle(ParticleTypes.END_ROD, at.x, at.y, at.z, 0.0, 0.0, 0.0);
            }
         }
      }
   }

   public void onRemovedFromLevel() {
      super.onRemovedFromLevel();
      if (!this.level().isClientSide()) {
         this.releaseAll(false);
      }
   }

   public AABB getBoundingBoxForCulling() {
      return this.reach(this.radius() + 1.0);
   }

   public boolean shouldRenderAtSqrDistance(double distanceSqr) {
      return distanceSqr < 25600.0;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
   }

   public boolean isAttackable() {
      return false;
   }

   public boolean hurt(DamageSource source, float amount) {
      return false;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean canBeCollidedWith() {
      return false;
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }

   private static final class Frozen {
      final Vec3 position;
      final Vec3 motion;
      final float yRot;
      final float xRot;
      final float headRot;
      final float bodyRot;
      final boolean hadNoGravity;
      final boolean hadNoAi;
      final int fuse;
      final int swellDir;
      final double power;
      float storedDamage;
      @Nullable
      DamageSource storedSource;
      Vec3 storedPush = Vec3.ZERO;
      int hits;

      Frozen(Entity entity) {
         this.position = entity.position();
         this.motion = entity.getDeltaMovement();
         this.yRot = entity.getYRot();
         this.xRot = entity.getXRot();
         this.headRot = entity instanceof LivingEntity living ? living.yHeadRot : 0.0F;
         this.bodyRot = entity instanceof LivingEntity livingx ? livingx.yBodyRot : 0.0F;
         this.hadNoGravity = entity.isNoGravity();
         this.hadNoAi = entity instanceof Mob mob && mob.isNoAi();
         this.fuse = entity instanceof PrimedTnt tnt ? tnt.getFuse() : 0;
         this.swellDir = entity instanceof Creeper creeper ? creeper.getSwellDir() : 0;
         this.power = entity instanceof AbstractHurtingProjectile fireball ? fireball.accelerationPower : 0.0;
      }

      Vec3 heldMotion(Entity entity) {
         return entity instanceof Projectile && this.motion.lengthSqr() > 1.0E-8 ? this.motion.normalize().scale(0.001) : Vec3.ZERO;
      }
   }

   @EventBusSubscriber(
      modid = "amuletmod"
   )
   public static final class TimeFieldEvents {
      private TimeFieldEvents() {
      }

      @SubscribeEvent(
         priority = EventPriority.HIGH
      )
      public static void onLivingAttack(LivingIncomingDamageEvent event) {
         LivingEntity target = event.getEntity();
         if (!target.level().isClientSide()) {
            TimeFieldEntity field = TimeFieldEntity.HOLDERS.get(target);
            if (field != null) {
               event.setCanceled(true);
               field.storeHit(target, event.getSource(), event.getAmount());
            }
         }
      }

      @SubscribeEvent
      public static void onEntityJoin(EntityJoinLevelEvent event) {
         Entity entity = event.getEntity();
         if (!entity.level().isClientSide() && !TimeFieldEntity.HOLDERS.containsKey(entity) && entity.getPersistentData().contains("amuletmod:time_frozen")) {
            CompoundTag saved = entity.getPersistentData().getCompound("amuletmod:time_frozen");
            entity.getPersistentData().remove("amuletmod:time_frozen");
            entity.setNoGravity(saved.getBoolean("NoGravity"));
            if (entity instanceof Mob mob) {
               mob.setNoAi(saved.getBoolean("NoAI"));
            }
         }
      }

      @SubscribeEvent
      public static void onServerStopped(ServerStoppedEvent event) {
         TimeFieldEntity.HOLDERS.clear();
      }
   }
}
