package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.server.level.ServerLevel;
import com.amuletmod.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

public class AbsorbedBlockEntity extends Entity {
   private static final EntityDataAccessor<BlockState> DATA_BLOCK = SynchedEntityData.defineId(AbsorbedBlockEntity.class, EntityDataSerializers.BLOCK_STATE);
   private static final EntityDataAccessor<Vector3f> DATA_TARGET = SynchedEntityData.defineId(AbsorbedBlockEntity.class, EntityDataSerializers.VECTOR3);
   private static final int MAX_LIFETIME = 200;
   private double startDistance = -1.0;

   public AbsorbedBlockEntity(EntityType<? extends AbsorbedBlockEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public AbsorbedBlockEntity(Level level, BlockPos pos, BlockState state, Vec3 target) {
      this((EntityType<? extends AbsorbedBlockEntity>)ModEntities.ABSORBED_BLOCK.get(), level);
      this.setPos(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
      this.entityData.set(DATA_BLOCK, state);
      this.entityData.set(DATA_TARGET, target.toVector3f());
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_BLOCK, Blocks.AIR.defaultBlockState());
      builder.define(DATA_TARGET, new Vector3f());
   }

   public BlockState getBlockState() {
      return (BlockState)this.entityData.get(DATA_BLOCK);
   }

   private Vec3 target() {
      return new Vec3((Vector3f)this.entityData.get(DATA_TARGET));
   }

   public void tick() {
      super.tick();
      Vec3 toTarget = this.target().subtract(this.position());
      double distance = toTarget.length();
      if (this.startDistance < 0.0) {
         this.startDistance = Math.max(distance, 0.001);
      }

      double speed = Math.min(0.05 + this.tickCount * 0.025, 1.2);
      if (!(distance <= speed) && this.tickCount <= 200) {
         this.setPos(this.position().add(toTarget.scale(speed / distance)));
      } else {
         this.setPos(this.target());
         if (!this.level().isClientSide()) {
            this.discard();
         }
      }
   }

   public float visualScale() {
      return this.startDistance <= 0.0 ? 1.0F : (float)Mth.clamp(this.target().distanceTo(this.position()) / this.startDistance, 0.0, 1.0);
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(ValueInput input) {
   }

   protected void addAdditionalSaveData(ValueOutput output) {
   }

   public boolean isAttackable() {
      return false;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }
}
