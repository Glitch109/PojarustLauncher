package com.amuletmod.entity;

import com.amuletmod.amulet.ability.sovereign.ShadowArmy;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot.Type;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RangedBowAttackGoal;
import net.minecraft.world.entity.ai.goal.RangedCrossbowAttackGoal;
import net.minecraft.world.entity.monster.CrossbowAttackMob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class ShadowPlayerEntity extends Monster implements CrossbowAttackMob {
   private static final EntityDataAccessor<Optional<UUID>> DATA_VICTIM = SynchedEntityData.defineId(
      ShadowPlayerEntity.class, EntityDataSerializers.OPTIONAL_UUID
   );
   private static final String VICTIM_ID = "VictimId";
   private static final String VICTIM_NAME = "VictimName";
   private static final String VICTIM_MAX_HEALTH = "VictimMaxHealth";
   private static final String VICTIM_EFFECTS = "VictimEffects";
   private static final double FULL_DRAW_DAMAGE = 1.875;
   private static final double MELEE_REACH = 2.2;
   private final RangedBowAttackGoal<ShadowPlayerEntity> bowGoal = new RangedBowAttackGoal(this, 1.0, 20, 15.0F);
   private final RangedCrossbowAttackGoal<ShadowPlayerEntity> crossbowGoal = new RangedCrossbowAttackGoal(this, 1.0, 8.0F);
   private final MeleeAttackGoal meleeGoal = new ShadowPlayerEntity.WeaponMeleeGoal(this);
   private String victimName = "";

   public ShadowPlayerEntity(EntityType<? extends ShadowPlayerEntity> type, Level level) {
      super(type, level);
      this.reassessWeaponGoal();
   }

   public static Builder createAttributes() {
      return Monster.createMonsterAttributes()
         .add(Attributes.MAX_HEALTH, 20.0)
         .add(Attributes.MOVEMENT_SPEED, 0.33)
         .add(Attributes.ATTACK_DAMAGE, 1.0)
         .add(Attributes.ATTACK_SPEED, 4.0)
         .add(Attributes.FOLLOW_RANGE, 32.0);
   }

   public static CompoundTag snapshot(ServerPlayer victim) {
      CompoundTag tag = new CompoundTag();
      ListTag hands = new ListTag();
      ListTag armor = new ListTag();

      for (EquipmentSlot slot : EquipmentSlot.values()) {
         if (slot.getType() == Type.HAND || slot.getType() == Type.HUMANOID_ARMOR) {
            (slot.getType() == Type.HAND ? hands : armor).add(victim.getItemBySlot(slot).saveOptional(victim.registryAccess()));
         }
      }

      tag.put("HandItems", hands);
      tag.put("ArmorItems", armor);
      tag.putBoolean("LeftHanded", victim.getMainArm() == HumanoidArm.LEFT);
      tag.putUUID("VictimId", victim.getUUID());
      tag.putString("VictimName", victim.getGameProfile().getName());
      tag.putDouble("VictimMaxHealth", victim.getAttributeBaseValue(Attributes.MAX_HEALTH));
      ListTag effects = new ListTag();

      for (MobEffectInstance effect : victim.getActiveEffects()) {
         if (((MobEffect)effect.getEffect().value()).getCategory() != MobEffectCategory.HARMFUL) {
            effects.add(new MobEffectInstance(effect.getEffect(), -1, effect.getAmplifier(), true, false, false).save());
         }
      }

      tag.put("VictimEffects", effects);
      return tag;
   }

   protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder builder) {
      super.defineSynchedData(builder);
      builder.define(DATA_VICTIM, Optional.empty());
   }

   protected void registerGoals() {
      this.goalSelector.addGoal(0, new FloatGoal(this));
      this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
      this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
   }

   private void reassessWeaponGoal() {
      if (this.level() != null && !this.level().isClientSide()) {
         this.goalSelector.removeGoal(this.meleeGoal);
         this.goalSelector.removeGoal(this.bowGoal);
         this.goalSelector.removeGoal(this.crossbowGoal);
         ItemStack weapon = this.getMainHandItem();
         if (weapon.getItem() instanceof CrossbowItem) {
            this.goalSelector.addGoal(2, this.crossbowGoal);
         } else if (weapon.getItem() instanceof BowItem) {
            this.goalSelector.addGoal(2, this.bowGoal);
         } else {
            this.goalSelector.addGoal(2, this.meleeGoal);
         }
      }
   }

   public void setItemSlot(EquipmentSlot slot, ItemStack stack) {
      super.setItemSlot(slot, stack);
      if (slot == EquipmentSlot.MAINHAND) {
         this.reassessWeaponGoal();
      }
   }

   @Nullable
   public UUID victimId() {
      return (UUID)((Optional)this.entityData.get(DATA_VICTIM)).orElse(null);
   }

   public Component victimName() {
      return Component.literal(this.victimName);
   }

   public void tick() {
      super.tick();
      if (!this.level().isClientSide() && !this.isRemoved() && this.tickCount > 1 && ShadowArmy.ownerOf(this) == null) {
         this.discard();
      }
   }

   public boolean canFireProjectileWeapon(ProjectileWeaponItem weapon) {
      return weapon instanceof BowItem || weapon instanceof CrossbowItem;
   }

   public void performRangedAttack(LivingEntity target, float power) {
      ItemStack weapon = this.getMainHandItem();
      if (weapon.getItem() instanceof CrossbowItem) {
         this.performCrossbowAttack(this, 1.6F);
      } else {
         ItemStack ammo = this.getProjectile(weapon);
         AbstractArrow arrow = ProjectileUtil.getMobArrow(this, ammo, power, weapon);
         if (weapon.getItem() instanceof BowItem bow) {
            arrow = bow.customArrow(arrow, ammo, weapon);
         }

         arrow.setBaseDamage(arrow.getBaseDamage() * 1.875);
         arrow.setCritArrow(power >= 1.0F);
         double dx = target.getX() - this.getX();
         double dy = target.getY(0.3333333333333333) - arrow.getY();
         double dz = target.getZ() - this.getZ();
         arrow.shoot(dx, dy + Math.sqrt(dx * dx + dz * dz) * 0.2, dz, 1.6F, 14 - this.level().getDifficulty().getId() * 4);
         this.playSound(SoundEvents.ARROW_SHOOT, 1.0F, 1.0F / (this.getRandom().nextFloat() * 0.4F + 1.2F) + 0.5F);
         this.level().addFreshEntity(arrow);
      }
   }

   public void setChargingCrossbow(boolean charging) {
   }

   public void onCrossbowAttackPerformed() {
      this.noActionTime = 0;
   }

   protected SoundEvent getHurtSound(DamageSource source) {
      return SoundEvents.PLAYER_HURT;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.PLAYER_DEATH;
   }

   protected boolean shouldDespawnInPeaceful() {
      return false;
   }

   public boolean removeWhenFarAway(double distanceSqr) {
      return false;
   }

   public void addAdditionalSaveData(CompoundTag tag) {
      super.addAdditionalSaveData(tag);
      UUID victim = this.victimId();
      if (victim != null) {
         tag.putUUID("VictimId", victim);
      }

      tag.putString("VictimName", this.victimName);
   }

   public void readAdditionalSaveData(CompoundTag tag) {
      super.readAdditionalSaveData(tag);
      if (tag.hasUUID("VictimId")) {
         this.entityData.set(DATA_VICTIM, Optional.of(tag.getUUID("VictimId")));
      }

      this.victimName = tag.getString("VictimName");
      if (tag.contains("VictimMaxHealth", 99)) {
         this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(Math.max(1.0, tag.getDouble("VictimMaxHealth")));
      }

      ListTag effects = tag.getList("VictimEffects", 10);

      for (int i = 0; i < effects.size(); i++) {
         MobEffectInstance effect = MobEffectInstance.load(effects.getCompound(i));
         if (effect != null) {
            this.addEffect(effect);
         }
      }

      this.reassessWeaponGoal();
   }

   private static final class WeaponMeleeGoal extends MeleeAttackGoal {
      private long nextSwing;

      WeaponMeleeGoal(ShadowPlayerEntity shadow) {
         super(shadow, 1.2, true);
      }

      protected void checkAndPerformAttack(LivingEntity target) {
         long now = this.mob.level().getGameTime();
         if (!(this.mob.distanceToSqr(target) > 4.840000000000001 + target.getBbWidth()) && now >= this.nextSwing) {
            this.nextSwing = now + Mth.clamp(Mth.ceil(20.0 / Math.max(0.1, this.mob.getAttributeValue(Attributes.ATTACK_SPEED))), 5, 40);
            this.mob.swing(InteractionHand.MAIN_HAND);
            this.mob.doHurtTarget(target);
         }
      }
   }
}
