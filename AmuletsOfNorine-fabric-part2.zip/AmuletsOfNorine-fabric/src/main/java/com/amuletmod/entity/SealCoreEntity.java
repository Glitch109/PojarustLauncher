package com.amuletmod.entity;

import com.amuletmod.client.CameraShake;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.seal.SealPrison;
import com.amuletmod.seal.SealVault;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Sounds;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent.BossBarColor;
import net.minecraft.world.BossEvent.BossBarOverlay;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class SealCoreEntity extends LivingEntity {
   private static final int CHECK_TICKS = 20;
   private final ServerBossEvent bar = new ServerBossEvent(Component.empty(), BossBarColor.PINK, BossBarOverlay.NOTCHED_10);
   @Nullable
   private UUID sealId;

   public SealCoreEntity(EntityType<? extends SealCoreEntity> type, Level level) {
      super(type, level);
      this.setNoGravity(true);
      this.bar.setName(this.getDisplayName());
   }

   public SealCoreEntity(ServerLevel level, UUID sealId, Vec3 at, float health, Component name) {
      this((EntityType<? extends SealCoreEntity>)ModEntities.SEAL_CORE.get(), level);
      this.sealId = sealId;
      this.moveTo(at.x, at.y, at.z, 0.0F, 0.0F);
      AttributeInstance max = this.getAttribute(Attributes.MAX_HEALTH);
      if (max != null) {
         max.setBaseValue(Math.max(1.0F, health));
      }

      this.setHealth(this.getMaxHealth());
      this.setCustomName(name);
      this.bar.setName(name);
   }

   public static Builder createAttributes() {
      return LivingEntity.createLivingAttributes().add(Attributes.MAX_HEALTH, 80.0).add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
   }

   public float strain() {
      return 1.0F - this.getHealth() / Math.max(1.0F, this.getMaxHealth());
   }

   public void tick() {
      super.tick();
      this.setDeltaMovement(Vec3.ZERO);
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         this.bar.setProgress(this.getHealth() / Math.max(1.0F, this.getMaxHealth()));
         if (this.tickCount % 20 == 0
            && this.isAlive()
            && this.getServer() != null
            && (this.sealId == null || SealVault.get(this.getServer()).seal(this.sealId) == null)) {
            this.discard();
         }
      }
   }

   public boolean hurt(DamageSource source, float amount) {
      boolean hurt = super.hurt(source, amount);
      if (hurt && this.level() instanceof ServerLevel level) {
         Vec3 at = this.position().add(0.0, this.getBbHeight() * 0.5, 0.0);
         level.sendParticles(ParticleTypes.END_ROD, at.x, at.y, at.z, 6, 0.2, 0.3, 0.2, 0.08);
         level.sendParticles(ParticleTypes.ENCHANTED_HIT, at.x, at.y, at.z, 8, 0.3, 0.4, 0.3, 0.3);
         Sounds.play(level, at, SoundEvents.AMETHYST_CLUSTER_HIT, 1.0F, 0.6F + this.strain() * 0.9F);
      }

      return hurt;
   }

   public void die(DamageSource source) {
      super.die(source);
      if (this.level() instanceof ServerLevel level && this.sealId != null) {
         Vec3 at = this.position().add(0.0, this.getBbHeight() * 0.5, 0.0);
         Sounds.play(level, at, SoundEvents.GLASS_BREAK, 1.5F, 0.5F);
         Sounds.play(level, at, SoundEvents.AMETHYST_CLUSTER_BREAK, 1.5F, 0.5F);
         Sounds.play(level, at, SoundEvents.BEACON_DEACTIVATE, 1.2F, 0.6F);
         Sounds.play(level, at, SoundEvents.LIGHTNING_BOLT_IMPACT, 0.7F, 1.4F);
         Sounds.play(level, at, SoundEvents.END_PORTAL_SPAWN, 0.35F, 1.6F);
         SealPrison.coreBroken(level.getServer(), this.sealId);
      }
   }

   protected void tickDeath() {
      if (++this.deathTime >= 18 && !this.level().isClientSide()) {
         this.discard();
      }
   }

   private void clientTick() {
      Vec3 at = this.position().add(0.0, this.getBbHeight() * 0.5, 0.0);
      if (this.isAlive()) {
         if (this.random.nextFloat() < 0.25F + this.strain() * 0.6F) {
            Vec3 from = at.add(this.random.nextGaussian() * 1.4, this.random.nextGaussian() * 1.0, this.random.nextGaussian() * 1.4);
            Vec3 pull = at.subtract(from);
            this.level().addParticle(ParticleTypes.ENCHANT, from.x, from.y, from.z, pull.x, pull.y, pull.z);
         }

         if (this.strain() > 0.5F && this.random.nextFloat() < this.strain() * 0.3F) {
            this.level()
               .addParticle(
                  ParticleTypes.ELECTRIC_SPARK,
                  at.x,
                  at.y,
                  at.z,
                  this.random.nextGaussian() * 0.3,
                  this.random.nextGaussian() * 0.3,
                  this.random.nextGaussian() * 0.3
               );
         }
      } else {
         if (this.deathTime == 1) {
            BlockParticleOption shard = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.MAGENTA_STAINED_GLASS.defaultBlockState());

            for (int i = 0; i < 60; i++) {
               this.level()
                  .addParticle(shard, at.x, at.y, at.z, this.random.nextGaussian() * 0.3, this.random.nextGaussian() * 0.3, this.random.nextGaussian() * 0.3);
               this.level()
                  .addParticle(
                     ParticleTypes.END_ROD,
                     at.x,
                     at.y,
                     at.z,
                     this.random.nextGaussian() * 0.25,
                     this.random.nextGaussian() * 0.25,
                     this.random.nextGaussian() * 0.25
                  );
            }

            this.level().addParticle(ParticleTypes.FLASH, at.x, at.y, at.z, 0.0, 0.0, 0.0);
            ClientSide.run(() -> () -> CameraShake.from(at, 2.5F, 24.0, 18));
         }
      }
   }

   public void startSeenByPlayer(ServerPlayer player) {
      super.startSeenByPlayer(player);
      this.bar.addPlayer(player);
   }

   public void stopSeenByPlayer(ServerPlayer player) {
      super.stopSeenByPlayer(player);
      this.bar.removePlayer(player);
   }

   public void setCustomName(@Nullable Component name) {
      super.setCustomName(name);
      this.bar.setName(this.getDisplayName());
   }

   public void travel(Vec3 input) {
   }

   public void knockback(double strength, double x, double z) {
   }

   public void push(Entity entity) {
   }

   protected void pushEntities() {
   }

   public boolean isPushable() {
      return false;
   }

   public boolean canBeAffected(MobEffectInstance effect) {
      return false;
   }

   public boolean isAffectedByPotions() {
      return false;
   }

   public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
      return false;
   }

   protected boolean shouldDropLoot() {
      return false;
   }

   public boolean shouldDropExperience() {
      return false;
   }

   protected SoundEvent getHurtSound(DamageSource source) {
      return SoundEvents.GLASS_HIT;
   }

   protected SoundEvent getDeathSound() {
      return SoundEvents.GLASS_BREAK;
   }

   public Iterable<ItemStack> getArmorSlots() {
      return List.of();
   }

   public ItemStack getItemBySlot(EquipmentSlot slot) {
      return ItemStack.EMPTY;
   }

   public void setItemSlot(EquipmentSlot slot, ItemStack stack) {
   }

   public HumanoidArm getMainArm() {
      return HumanoidArm.RIGHT;
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }

   public void addAdditionalSaveData(CompoundTag tag) {
      super.addAdditionalSaveData(tag);
      if (this.sealId != null) {
         tag.putUUID("Seal", this.sealId);
      }
   }

   public void readAdditionalSaveData(CompoundTag tag) {
      super.readAdditionalSaveData(tag);
      this.sealId = tag.hasUUID("Seal") ? tag.getUUID("Seal") : null;
      this.bar.setName(this.getDisplayName());
   }
}
