package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.network.FxPacket;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.PacketDistributor;
import org.jetbrains.annotations.Nullable;

public class HellhoundEntity extends Wolf implements Summons.Owned {
   private static final double GUARD_RADIUS = 16.0;
   private static final int RETARGET_TICKS = 10;
   private static final int BURN_SECONDS = 5;
   private int lifetime = 600;
   private int retarget;

   public HellhoundEntity(EntityType<? extends Wolf> type, Level level) {
      super(type, level);
      this.setPathfindingMalus(PathType.DANGER_FIRE, 0.0F);
      this.setPathfindingMalus(PathType.DAMAGE_FIRE, 0.0F);
   }

   public static Builder createAttributes() {
      return Wolf.createAttributes()
         .add(Attributes.MAX_HEALTH, 30.0)
         .add(Attributes.MOVEMENT_SPEED, 0.36)
         .add(Attributes.ATTACK_DAMAGE, 6.0)
         .add(Attributes.ARMOR, 4.0)
         .add(Attributes.KNOCKBACK_RESISTANCE, 0.3)
         .add(Attributes.FOLLOW_RANGE, 32.0);
   }

   public static HellhoundEntity summon(ServerLevel level, ServerPlayer owner, Vec3 at, int lifetime) {
      HellhoundEntity hound = new HellhoundEntity((EntityType<? extends Wolf>)ModEntities.HELLHOUND.get(), level);
      hound.setOwnerUUID(owner.getUUID());
      hound.lifetime = lifetime;
      hound.moveTo(at.x, at.y, at.z, owner.getYRot() + (level.random.nextFloat() - 0.5F) * 60.0F, 0.0F);
      hound.setYHeadRot(hound.getYRot());
      level.addFreshEntity(hound);
      return hound;
   }

   @Nullable
   @Override
   public UUID summonerId() {
      return this.getOwnerUUID();
   }

   protected void registerGoals() {
      this.goalSelector.addGoal(1, new FloatGoal(this));
      this.goalSelector.addGoal(2, new LeapAtTargetGoal(this, 0.5F));
      this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.4, true));
      this.goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.3, 8.0F, 2.5F));
      this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
   }

   protected void customServerAiStep() {
      super.customServerAiStep();
      LivingEntity owner = this.getOwner();
      if (owner != null && owner.isAlive() && owner.level() == this.level() && --this.lifetime > 0) {
         LivingEntity target = this.getTarget();
         if (target != null && (!target.isAlive() || !Summons.isFoe(owner, target))) {
            this.setTarget(null);
            target = null;
            this.retarget = 0;
         }

         if (--this.retarget <= 0) {
            this.retarget = 10;
            LivingEntity attacker = owner.getLastHurtByMob();
            if (target == null || attacker != null && attacker != target && Summons.isFoe(owner, attacker)) {
               this.setTarget(Summons.findTarget(owner, owner.position(), 16.0, null));
            }
         }
      } else {
         this.vanish();
      }
   }

   public boolean doHurtTarget(Entity target) {
      if (target instanceof LivingEntity living && this.getOwner() instanceof Player owner) {
         living.setLastHurtByPlayer(owner);
      }

      DamageSource bite = ModDamage.source(this.level(), ModDamage.HELLHOUND, this, this);
      boolean hit = target.hurt(bite, (float)this.getAttributeValue(Attributes.ATTACK_DAMAGE));
      if (hit) {
         if (this.level() instanceof ServerLevel server) {
            EnchantmentHelper.doPostAttackEffects(server, target, bite);
         }

         target.igniteForSeconds(5.0F);
         if (this.level() instanceof ServerLevel level) {
            Vec3 at = target.position().add(0.0, target.getBbHeight() * 0.5, 0.0);
            level.sendParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 14, 0.25, 0.3, 0.25, 0.06);
            level.sendParticles(ParticleTypes.LAVA, at.x, at.y, at.z, 2, 0.2, 0.2, 0.2, 0.0);
         }

         this.playSound(SoundEvents.FIRECHARGE_USE, 0.5F, 1.2F + this.random.nextFloat() * 0.3F);
      }

      return hit;
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         if (this.random.nextInt(4) == 0) {
            this.level().addParticle(ParticleTypes.FLAME, this.getRandomX(0.6), this.getRandomY(), this.getRandomZ(0.6), 0.0, 0.02, 0.0);
         }

         if (this.getDeltaMovement().horizontalDistanceSqr() > 0.01 && this.onGround() && this.random.nextBoolean()) {
            this.level().addParticle(ParticleTypes.FLAME, this.getRandomX(0.5), this.getY() + 0.05, this.getRandomZ(0.5), 0.0, 0.01, 0.0);
         }

         if (!this.onGround() && this.getDeltaMovement().lengthSqr() > 0.1) {
            for (int i = 0; i < 3; i++) {
               this.level().addParticle(ParticleTypes.FLAME, this.getRandomX(0.5), this.getRandomY(), this.getRandomZ(0.5), 0.0, 0.0, 0.0);
            }
         }

         if (this.random.nextInt(12) == 0) {
            this.level().addParticle(ParticleTypes.LARGE_SMOKE, this.getRandomX(0.5), this.getY() + this.getBbHeight(), this.getRandomZ(0.5), 0.0, 0.03, 0.0);
         }
      }
   }

   public void vanish() {
      if (this.level() instanceof ServerLevel level && !this.isRemoved()) {
         Vec3 at = this.position().add(0.0, this.getBbHeight() * 0.5, 0.0);
         level.sendParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 40, 0.3, 0.3, 0.3, 0.18);
         level.sendParticles(ParticleTypes.LAVA, at.x, at.y, at.z, 6, 0.3, 0.3, 0.3, 0.0);
         level.sendParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y, at.z, 12, 0.3, 0.4, 0.3, 0.05);
         PacketDistributor.sendToPlayersTrackingEntity(this, new FxPacket(FxPacket.Kind.FIREBALL, at, 1.0F), new CustomPacketPayload[0]);
         Sounds.play(level, at, SoundEvents.FIRECHARGE_USE, 1.0F, 0.6F);
         Sounds.play(level, at, SoundEvents.BLAZE_SHOOT, 0.8F, 0.5F);
      }

      this.discard();
   }

   protected void tickDeath() {
      if (!this.level().isClientSide()) {
         this.vanish();
      }
   }

   public void die(DamageSource source) {
      this.setOwnerUUID(null);
      super.die(source);
   }

   public boolean displayFireAnimation() {
      return true;
   }

   public boolean isAngry() {
      return true;
   }

   public void updatePersistentAnger(ServerLevel level, boolean remember) {
   }

   protected SoundEvent getAmbientSound() {
      return SoundEvents.WOLF_GROWL;
   }

   public float getVoicePitch() {
      return 0.55F + this.random.nextFloat() * 0.15F;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      Entity attacker = source.getEntity();
      UUID ownerId = this.getOwnerUUID();
      return attacker == null
            || ownerId == null
            || !ownerId.equals(attacker.getUUID()) && !(attacker instanceof Summons.Owned owned && ownerId.equals(owned.summonerId()))
         ? super.hurt(source, amount)
         : false;
   }

   public boolean isAlliedTo(Entity other) {
      UUID ownerId = this.getOwnerUUID();
      if (ownerId == null || !ownerId.equals(other.getUUID()) && !(other instanceof Summons.Owned owned && ownerId.equals(owned.summonerId()))) {
         LivingEntity owner = this.getOwner();
         return owner != null && owner.isAlliedTo(other) || super.isAlliedTo(other);
      } else {
         return true;
      }
   }

   public Component getName() {
      LivingEntity owner = this.getOwner();
      return (Component)(!this.hasCustomName() && owner != null
         ? Component.translatable("entity.amuletmod.hellhound.owned", new Object[]{owner.getName()})
         : super.getName());
   }

   public InteractionResult mobInteract(Player player, InteractionHand hand) {
      return InteractionResult.PASS;
   }

   public boolean isFood(ItemStack stack) {
      return false;
   }

   @Nullable
   public Wolf getBreedOffspring(ServerLevel level, AgeableMob partner) {
      return null;
   }

   public boolean canBeLeashed() {
      return false;
   }

   protected boolean shouldDropLoot() {
      return false;
   }

   protected int getBaseExperienceReward() {
      return 0;
   }

   public boolean removeWhenFarAway(double distance) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   public void addAdditionalSaveData(ValueOutput output) {
   }

   public void readAdditionalSaveData(ValueInput input) {
   }
}
