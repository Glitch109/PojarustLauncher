package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.amulet.ability.librarian.Kanji;
import com.amuletmod.client.OfudaClient;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Sounds;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class OfudaEntity extends Entity {
   public static final int UNFURL_TICKS = 5;
   public static final int FALL_TICKS = 4;
   public static final int STRIKES = 3;
   private static final int[] STRIKE_TICKS = new int[]{8, 14, 20};
   public static final int SEAL_TICK = 24;
   public static final int FOLD_TICK = 29;
   public static final int FOLD_TICKS = 7;
   public static final int LAUNCH_TICK = 36;
   public static final int BURN_TICKS = 14;
   public static final int TRAIL_LENGTH = 6;
   public static final float WRITING_HEIGHT = 0.95F;
   private static final double ORB_START_SPEED = 0.3;
   private static final double ORB_ACCELERATION = 0.07;
   private static final double ORB_SPEED = 1.3;
   private static final int MAX_FLIGHT = 100;
   private static final float[] SPOTS = new float[]{0.0F, 180.0F, 62.0F, -62.0F};
   private static final Vec3 UP = new Vec3(0.0, 1.0, 0.0);
   private static final Vector3f INK = new Vector3f(0.1F, 0.08F, 0.06F);
   private static final EntityDataAccessor<Integer> DATA_CASTER = SynchedEntityData.defineId(OfudaEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_TARGET = SynchedEntityData.defineId(OfudaEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_KANJI = SynchedEntityData.defineId(OfudaEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_PHASE = SynchedEntityData.defineId(OfudaEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_SPOT = SynchedEntityData.defineId(OfudaEntity.class, EntityDataSerializers.INT);
   @Nullable
   private ServerPlayer caster;
   @Nullable
   private LivingEntity target;
   private int effectTicks;
   private int phaseTick;
   private int flightTicks;
   private Vec3 velocity = Vec3.ZERO;
   @Nullable
   private OfudaEntity.Phase seenPhase;
   private int seenAt;
   public final Vec3[] trail = new Vec3[6];

   public OfudaEntity(EntityType<? extends OfudaEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public OfudaEntity(ServerLevel level, ServerPlayer caster, LivingEntity target, Kanji[] kanji, int effectTicks) {
      this((EntityType<? extends OfudaEntity>)ModEntities.OFUDA.get(), level);
      this.caster = caster;
      this.target = target;
      this.effectTicks = effectTicks;
      this.entityData.set(DATA_CASTER, caster.getId());
      this.entityData.set(DATA_TARGET, target.getId());
      this.entityData.set(DATA_KANJI, kanji[0].ordinal() | kanji[1].ordinal() << 4 | kanji[2].ordinal() << 8);
      Vec3 at = writingFrame(caster, 1.0F)[0];
      this.moveTo(at.x, at.y, at.z, 0.0F, 0.0F);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_CASTER, -1);
      builder.define(DATA_TARGET, -1);
      builder.define(DATA_KANJI, 0);
      builder.define(DATA_PHASE, 0);
      builder.define(DATA_SPOT, 0);
   }

   public OfudaEntity.Phase phase() {
      OfudaEntity.Phase[] phases = OfudaEntity.Phase.values();
      return phases[Mth.clamp((Integer)this.entityData.get(DATA_PHASE), 0, phases.length - 1)];
   }

   private void setPhase(OfudaEntity.Phase phase) {
      this.entityData.set(DATA_PHASE, phase.ordinal());
      this.phaseTick = this.tickCount;
   }

   public Kanji kanji(int k) {
      return Kanji.byId((Integer)this.entityData.get(DATA_KANJI) >> 4 * k & 15);
   }

   public Kanji drawn() {
      return this.kanji(2);
   }

   public int casterId() {
      return (Integer)this.entityData.get(DATA_CASTER);
   }

   @Nullable
   public Entity caster() {
      return this.level().getEntity(this.casterId());
   }

   @Nullable
   public LivingEntity target() {
      return this.level().getEntity((Integer)this.entityData.get(DATA_TARGET)) instanceof LivingEntity living ? living : null;
   }

   public int spot() {
      return (Integer)this.entityData.get(DATA_SPOT);
   }

   public float phaseAge(float partialTick) {
      return this.tickCount - this.seenAt + partialTick;
   }

   public static int strikesAt(int k) {
      return STRIKE_TICKS[k];
   }

   public static Vec3[] writingFrame(Entity caster, float partialTick) {
      Vec3 eye = caster.getEyePosition(partialTick);
      Vec3 forward = caster.getViewVector(partialTick);
      Vec3 side = UP.cross(forward);
      if (side.lengthSqr() < 1.0E-4) {
         float yaw = caster.getViewYRot(partialTick) * (float) (Math.PI / 180.0);
         side = new Vec3(Mth.cos(yaw), 0.0, Mth.sin(yaw));
      }

      side = side.normalize();
      Vec3 up = forward.cross(side);
      Vec3 wanted = eye.add(forward.scale(1.15)).subtract(up.scale(0.12));
      BlockHitResult wall = caster.level().clip(new ClipContext(eye, wanted, Block.COLLIDER, Fluid.NONE, caster));
      Vec3 at = wall.getType() == Type.MISS
         ? wanted
         : eye.add(wanted.subtract(eye).normalize().scale(Math.max(0.3, wall.getLocation().distanceTo(eye) - 0.25)));
      return new Vec3[]{at, side, up, forward};
   }

   public static Vec3[] stuckFrame(LivingEntity target, int spot, float partialTick) {
      float yaw = (Mth.rotLerp(partialTick, target.yBodyRotO, target.yBodyRot) + SPOTS[Math.floorMod(spot, SPOTS.length)]) * (float) (Math.PI / 180.0);
      Vec3 out = new Vec3(-Mth.sin(yaw), 0.0, Mth.cos(yaw));
      double depth = Math.max(0.17, target.getBbWidth() * 0.32);
      Vec3 at = target.getPosition(partialTick).add(out.scale(depth)).add(0.0, target.getBbHeight() * (0.6 + 0.04 * spot), 0.0);
      return new Vec3[]{at, UP.cross(out), UP, out};
   }

   public static float stuckHeight(LivingEntity target) {
      return 0.5F * Mth.clamp(target.getBbHeight() / 1.8F, 0.55F, 2.0F);
   }

   private static Vec3 chest(LivingEntity living) {
      return living.position().add(0.0, living.getBbHeight() * 0.6, 0.0);
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         switch (this.phase()) {
            case WRITING:
               this.write();
               break;
            case FLYING:
               this.fly();
               break;
            case STUCK:
               this.hold();
               break;
            case BURNING:
               if (this.target != null && this.target.isAlive() && this.target.level() == this.level()) {
                  this.setPos(this.target.position());
               }

               if (this.tickCount - this.phaseTick >= 14) {
                  this.discard();
               }
         }
      }
   }

   private void write() {
      if (this.caster != null && this.caster.isAlive() && !this.caster.isRemoved() && this.caster.level() == this.level()) {
         Vec3 at = writingFrame(this.caster, 1.0F)[0];
         this.setPos(at.x, at.y, at.z);
         if (this.tickCount == 1) {
            Sounds.play(this.level(), at, SoundEvents.BOOK_PAGE_TURN, 1.0F, 0.8F);
            Sounds.play(this.level(), at, SoundEvents.ENCHANTMENT_TABLE_USE, 0.8F, 1.5F);
         }

         for (int k = 0; k < 3; k++) {
            if (this.tickCount == strikesAt(k)) {
               boolean last = k == 2;
               Sounds.play(this.level(), at, SoundEvents.BOOK_PUT, 1.3F, 0.7F + 0.12F * k);
               Sounds.play(this.level(), at, (SoundEvent)SoundEvents.NOTE_BLOCK_BASEDRUM.value(), 1.0F, 0.6F + 0.1F * k);
               Sounds.play(this.level(), at, SoundEvents.PLAYER_ATTACK_STRONG, 0.6F, 1.4F + 0.1F * k);
               if (last) {
                  Sounds.play(this.level(), at, SoundEvents.BELL_BLOCK, 0.7F, 1.5F);
                  Sounds.play(this.level(), at, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0F, 1.2F);
               }
            }
         }

         if (this.tickCount == 24) {
            Sounds.play(this.level(), at, SoundEvents.BOOK_PUT, 1.0F, 0.45F);
         }

         if (this.tickCount == 29) {
            Sounds.play(this.level(), at, SoundEvents.BOOK_PAGE_TURN, 1.0F, 1.6F);
            Sounds.play(this.level(), at, SoundEvents.BEACON_POWER_SELECT, 0.6F, 1.8F);
         }

         if (this.tickCount >= 36) {
            this.launch(at);
         }
      } else {
         ((ServerLevel)this.level()).sendParticles(PageEntity.scraps(), this.getX(), this.getY(), this.getZ(), 10, 0.15, 0.25, 0.15, 0.05);
         this.discard();
      }
   }

   private void launch(Vec3 at) {
      this.setPhase(OfudaEntity.Phase.FLYING);
      this.velocity = this.caster.getViewVector(1.0F).scale(0.3).add(0.0, 0.12, 0.0);
      Sounds.play(this.level(), at, SoundEvents.ALLAY_THROW, 1.0F, 0.8F);
      Sounds.play(this.level(), at, SoundEvents.ILLUSIONER_CAST_SPELL, 0.7F, 1.6F);
      Kanji kanji = this.drawn();
      Component name = Component.translatable(kanji.translationKey());
      Component message = this.target != this.caster && this.target != null
         ? Component.translatable("message.amuletmod.ofuda", new Object[]{name, this.target.getDisplayName(), this.effectTicks / 20})
         : Component.translatable("message.amuletmod.ofuda_self", new Object[]{name, this.effectTicks / 20});
      this.caster.displayClientMessage(message.copy().withStyle(style -> style.withColor(kanji.rgb())), true);
   }

   private void fly() {
      LivingEntity aim = (LivingEntity)(this.target != null && this.target.isAlive() && !this.target.isRemoved() && this.target.level() == this.level()
         ? this.target
         : (this.caster != null && this.caster.isAlive() && !this.caster.isRemoved() && this.caster.level() == this.level() ? this.caster : null));
      if (aim == null) {
         ((ServerLevel)this.level()).sendParticles(ParticleTypes.END_ROD, this.getX(), this.getY(), this.getZ(), 10, 0.1, 0.1, 0.1, 0.08);
         this.discard();
      } else {
         if (aim != this.target) {
            this.target = aim;
            this.entityData.set(DATA_TARGET, aim.getId());
         }

         this.flightTicks++;
         Vec3 to = chest(aim).subtract(this.position());
         double distance = to.length();
         double speed = Math.min(1.3, 0.3 + this.flightTicks * 0.07);
         if (!(distance <= speed + aim.getBbWidth() * 0.5) && this.flightTicks < 100) {
            this.velocity = this.velocity.lerp(to.scale(speed / distance), 0.3);
            this.setPos(this.getX() + this.velocity.x, this.getY() + this.velocity.y, this.getZ() + this.velocity.z);
         } else {
            this.stick(aim);
         }
      }
   }

   private void stick(LivingEntity on) {
      this.target = on;
      this.setPhase(OfudaEntity.Phase.STUCK);
      int taken = this.level()
         .getEntitiesOfClass(
            OfudaEntity.class, on.getBoundingBox().inflate(2.0), other -> other != this && other.target() == on && other.phase() == OfudaEntity.Phase.STUCK
         )
         .size();
      this.entityData.set(DATA_SPOT, taken % SPOTS.length);
      this.setPos(on.position());
      Kanji kanji = this.drawn();
      on.addEffect(new MobEffectInstance(kanji.effect(), this.effectTicks, 1), this.caster);
      ServerLevel level = (ServerLevel)this.level();
      Vec3 at = chest(on);
      level.sendParticles(
         new DustParticleOptions(new Vector3f(kanji.r(), kanji.g(), kanji.b()), 1.4F),
         at.x,
         at.y,
         at.z,
         24,
         on.getBbWidth() * 0.5,
         on.getBbHeight() * 0.3,
         on.getBbWidth() * 0.5,
         0.0
      );
      level.sendParticles(ParticleTypes.END_ROD, at.x, at.y, at.z, 10, 0.1, 0.1, 0.1, 0.12);
      Sounds.play(level, at, SoundEvents.BOOK_PUT, 1.0F, 1.3F);
      Sounds.play(level, at, SoundEvents.BEACON_ACTIVATE, 0.6F, 1.9F);
      Sounds.play(level, at, SoundEvents.AMETHYST_BLOCK_CHIME, 1.2F, 0.9F + kanji.ordinal() * 0.15F);
      if (on instanceof ServerPlayer player && on != this.caster && this.caster != null) {
         player.displayClientMessage(
            Component.translatable(
                  "message.amuletmod.ofuda_received",
                  new Object[]{this.caster.getDisplayName(), Component.translatable(kanji.translationKey()), this.effectTicks / 20}
               )
               .withStyle(style -> style.withColor(kanji.rgb())),
            true
         );
      }
   }

   private void hold() {
      if (this.target != null && this.target.isAlive() && !this.target.isRemoved() && this.target.level() == this.level()) {
         this.setPos(this.target.position());
         if (this.tickCount - this.phaseTick >= this.effectTicks || this.target.getEffect(this.drawn().effect()) == null) {
            this.burn();
         }
      } else {
         this.burn();
      }
   }

   private void burn() {
      this.setPhase(OfudaEntity.Phase.BURNING);
      Sounds.play(this.level(), this.position().add(0.0, 1.0, 0.0), SoundEvents.FIRE_EXTINGUISH, 0.35F, 1.7F);
      Sounds.play(this.level(), this.position().add(0.0, 1.0, 0.0), SoundEvents.BOOK_PAGE_TURN, 0.6F, 1.4F);
   }

   private void clientTick() {
      OfudaEntity.Phase phase = this.phase();
      if (phase != this.seenPhase) {
         this.seenPhase = phase;
         this.seenAt = this.tickCount;
      }

      Entity writer = this.caster();
      int writerId = this.casterId();
      switch (phase) {
         case WRITING:
            ClientSide.run(() -> () -> OfudaClient.writing(this));
            if (writer != null) {
               Vec3 atx = writingFrame(writer, 1.0F)[0];
               if (this.tickCount < 29 && this.random.nextBoolean()) {
                  this.level()
                     .addParticle(
                        ParticleTypes.ENCHANT,
                        atx.x,
                        atx.y,
                        atx.z,
                        this.random.nextGaussian() * 0.8,
                        this.random.nextGaussian() * 0.8,
                        this.random.nextGaussian() * 0.8
                     );
               }

               for (int k = 0; k < 3; k++) {
                  if (this.tickCount == strikesAt(k)) {
                     int strike = k;
                     ClientSide.run(() -> () -> OfudaClient.strike(writerId, strike));

                     for (int i = 0; i < 6; i++) {
                        this.level()
                           .addParticle(
                              new DustParticleOptions(INK, 1.0F),
                              atx.x + this.random.nextGaussian() * 0.15,
                              atx.y + this.random.nextGaussian() * 0.2,
                              atx.z + this.random.nextGaussian() * 0.15,
                              0.0,
                              0.0,
                              0.0
                           );
                     }
                  }
               }
            }
            break;
         case FLYING:
            System.arraycopy(this.trail, 0, this.trail, 1, 5);
            this.trail[0] = this.position();
            Kanji kanji = this.drawn();
            this.level()
               .addParticle(
                  new DustParticleOptions(new Vector3f(kanji.r(), kanji.g(), kanji.b()), 1.0F),
                  this.getX() + this.random.nextGaussian() * 0.08,
                  this.getY() + this.random.nextGaussian() * 0.08,
                  this.getZ() + this.random.nextGaussian() * 0.08,
                  0.0,
                  0.0,
                  0.0
               );
            if (this.random.nextInt(3) == 0) {
               this.level()
                  .addParticle(
                     ParticleTypes.END_ROD,
                     this.getX(),
                     this.getY(),
                     this.getZ(),
                     this.random.nextGaussian() * 0.02,
                     this.random.nextGaussian() * 0.02,
                     this.random.nextGaussian() * 0.02
                  );
            }
            break;
         case STUCK:
            LivingEntity bearerx = this.target();
            if (bearerx != null && this.tickCount % 9 == 0 && !bearerx.isInvisible()) {
               Vec3 atx = stuckFrame(bearerx, this.spot(), 1.0F)[0];
               this.level()
                  .addParticle(ParticleTypes.ENCHANT, atx.x, atx.y + 0.3, atx.z, this.random.nextGaussian() * 0.3, -0.3, this.random.nextGaussian() * 0.3);
            }
            break;
         case BURNING:
            LivingEntity bearer = this.target();
            Vec3 at = bearer != null ? stuckFrame(bearer, this.spot(), 1.0F)[0] : this.position();
            double y = at.y - 0.25 + (this.tickCount - this.seenAt) / 14.0 * 0.5;
            this.level()
               .addParticle(ParticleTypes.SMALL_FLAME, at.x + this.random.nextGaussian() * 0.04, y, at.z + this.random.nextGaussian() * 0.04, 0.0, 0.01, 0.0);
            if (this.random.nextBoolean()) {
               this.level().addParticle(ParticleTypes.WHITE_ASH, at.x, y, at.z, this.random.nextGaussian() * 0.02, 0.03, this.random.nextGaussian() * 0.02);
            }

            if (this.tickCount - this.seenAt == 1) {
               this.level().addParticle(ParticleTypes.SMOKE, at.x, at.y, at.z, 0.0, 0.03, 0.0);
            }
      }
   }

   public AABB getBoundingBoxForCulling() {
      return this.getBoundingBox().inflate(this.phase() != OfudaEntity.Phase.STUCK && this.phase() != OfudaEntity.Phase.BURNING ? 1.0 : 2.0);
   }

   public boolean shouldRenderAtSqrDistance(double distanceSqr) {
      return distanceSqr < 4096.0;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(ValueInput input) {
   }

   protected void addAdditionalSaveData(ValueOutput output) {
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }

   public static enum Phase {
      WRITING,
      FLYING,
      STUCK,
      BURNING;
   }
}
