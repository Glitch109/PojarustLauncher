package com.amuletmod.entity;

import com.amuletmod.amulet.AbilityCooldowns;
import com.amuletmod.amulet.AbilityOrigin;
import com.amuletmod.client.CameraShake;
import com.amuletmod.client.RootedClient;
import com.amuletmod.client.SealCaptureClient;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.seal.SealCubeItem;
import com.amuletmod.seal.SealPrison;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Easing;
import com.amuletmod.util.ServerScheduler;
import com.amuletmod.util.Sounds;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class SealCaptureEntity extends Entity {
   public static final int APPEAR_TICKS = 8;
   public static final int HOLD_TICK = 4;
   public static final int SQUEEZE_TICK = 12;
   public static final int CAPTURE_TICK = 20;
   public static final int FLY_TICKS = 12;
   public static final int END_TICK = 38;
   public static final int FAIL_TICKS = 8;
   public static final float CUBE = 0.2F;
   public static final byte PENDING = 0;
   public static final byte TAKEN = 1;
   public static final byte FAILED = 2;
   private static final EntityDataAccessor<Integer> DATA_VICTIM = SynchedEntityData.defineId(SealCaptureEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_CASTER = SynchedEntityData.defineId(SealCaptureEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Float> DATA_WIDTH = SynchedEntityData.defineId(SealCaptureEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Float> DATA_HEIGHT = SynchedEntityData.defineId(SealCaptureEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Byte> DATA_OUTCOME = SynchedEntityData.defineId(SealCaptureEntity.class, EntityDataSerializers.BYTE);
   @Nullable
   private LivingEntity victim;
   @Nullable
   private UUID casterId;
   @Nullable
   private AbilityOrigin ability;
   private int failedAt;
   private int clientFailTick = -1;

   public SealCaptureEntity(EntityType<? extends SealCaptureEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public SealCaptureEntity(ServerLevel level, ServerPlayer caster, LivingEntity victim, @Nullable AbilityOrigin ability) {
      this((EntityType<? extends SealCaptureEntity>)ModEntities.SEAL_CAPTURE.get(), level);
      this.victim = victim;
      this.casterId = caster.getUUID();
      this.ability = ability;
      this.moveTo(victim.getX(), victim.getY(), victim.getZ(), 0.0F, 0.0F);
      this.entityData.set(DATA_VICTIM, victim.getId());
      this.entityData.set(DATA_CASTER, caster.getId());
      this.entityData.set(DATA_WIDTH, victim.getBbWidth());
      this.entityData.set(DATA_HEIGHT, victim.getBbHeight());
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_VICTIM, -1);
      builder.define(DATA_CASTER, -1);
      builder.define(DATA_WIDTH, 0.6F);
      builder.define(DATA_HEIGHT, 1.8F);
      builder.define(DATA_OUTCOME, (byte)0);
   }

   public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
      super.onSyncedDataUpdated(key);
      if (DATA_OUTCOME.equals(key) && this.outcome() == 2) {
         this.clientFailTick = this.tickCount;
      }
   }

   public int victimId() {
      return (Integer)this.entityData.get(DATA_VICTIM);
   }

   public int casterId() {
      return (Integer)this.entityData.get(DATA_CASTER);
   }

   public float victimWidth() {
      return (Float)this.entityData.get(DATA_WIDTH);
   }

   public float victimHeight() {
      return (Float)this.entityData.get(DATA_HEIGHT);
   }

   public byte outcome() {
      return (Byte)this.entityData.get(DATA_OUTCOME);
   }

   public float failing(float partialTick) {
      return this.clientFailTick < 0 ? 0.0F : Mth.clamp((this.tickCount - this.clientFailTick + partialTick) / 8.0F, 0.0F, 1.0F);
   }

   public static boolean isTaking(Level level, LivingEntity entity) {
      return !level.getEntitiesOfClass(
            SealCaptureEntity.class, entity.getBoundingBox().inflate(4.0), seal -> seal.victimId() == entity.getId() && seal.outcome() == 0
         )
         .isEmpty();
   }

   public static float squeeze(float age) {
      float t = Mth.clamp((age - 12.0F) / 8.0F, 0.0F, 1.0F);
      return t * t;
   }

   public static float cageWidth(float width, float age) {
      return Mth.lerp(squeeze(age), Math.max(0.55F, width * 0.5F + 0.3F), 0.2F);
   }

   public static float cageHeight(float height, float age) {
      return Mth.lerp(squeeze(age), height * 0.5F + 0.3F, 0.2F);
   }

   public static Vec3 heart(float height) {
      return new Vec3(0.0, height * 0.5, 0.0);
   }

   public static float flight(float age) {
      return Easing.smoothstep(0.0F, 1.0F, (age - 20.0F) / 12.0F);
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         ServerLevel level = (ServerLevel)this.level();
         if (this.outcome() == 0) {
            if (this.victim == null || !this.victim.isAlive() || this.victim.isRemoved() || this.victim.level() != level) {
               this.fail(level, "message.amuletmod.capture_lost");
            } else if (this.tickCount < 4) {
               this.setPos(this.victim.position());
            } else if (this.tickCount < 20) {
               this.pin(this.victim);
            } else {
               this.capture(level, this.victim);
            }
         }

         this.sounds(level);
         if (this.tickCount >= 38 || this.outcome() == 2 && this.tickCount >= this.failedAt + 8) {
            this.discard();
         }
      }
   }

   private void pin(LivingEntity held) {
      Vec3 anchor = this.position();
      held.fallDistance = 0.0F;
      if (held instanceof ServerPlayer player) {
         if (held.position().distanceToSqr(anchor) > 0.36) {
            player.connection.teleport(anchor.x, anchor.y, anchor.z, player.getYRot(), player.getXRot());
         }
      } else {
         if (held.position().distanceToSqr(anchor) > 0.0025) {
            held.teleportTo(anchor.x, anchor.y, anchor.z);
         }

         held.setDeltaMovement(Vec3.ZERO);
         if (held instanceof Mob mob) {
            mob.getNavigation().stop();
            mob.setJumping(false);
         }
      }
   }

   private void capture(ServerLevel level, LivingEntity taken) {
      ServerPlayer caster = this.casterId == null ? null : level.getServer().getPlayerList().getPlayer(this.casterId);
      if (caster == null) {
         this.fail(level, null);
      } else {
         Component name = taken.getDisplayName();
         ItemStack cube = null;
         if (taken instanceof ServerPlayer prisoner) {
            UUID seal = SealPrison.imprison(caster, prisoner);
            if (seal == null) {
               this.fail(level, "message.amuletmod.capture_no_realm");
               return;
            }

            cube = SealCubeItem.ofPlayer(seal, prisoner, caster);
         } else if (taken instanceof Mob mob) {
            mob.stopRiding();
            mob.ejectPassengers();
            mob.dropLeash(true, true);
            cube = SealCubeItem.ofCreature(mob, caster);
            if (cube != null) {
               mob.discard();
            }
         }

         if (cube == null) {
            this.fail(level, "message.amuletmod.capture_too_much");
         } else {
            this.entityData.set(DATA_OUTCOME, (byte)1);
            this.victim = null;
            if (!caster.getInventory().add(cube)) {
               caster.drop(cube, false);
            }

            caster.displayClientMessage(
               Component.translatable("message.amuletmod.capture_sealed", new Object[]{name}).withStyle(ChatFormatting.LIGHT_PURPLE), true
            );
            ServerScheduler.schedule(12, () -> {
               if (!caster.isRemoved()) {
                  Sounds.play(caster.level(), caster.position(), SoundEvents.ITEM_PICKUP, 0.7F, 0.8F);
                  Sounds.play(caster.level(), caster.position(), SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.6F);
               }
            });
         }
      }
   }

   private void fail(ServerLevel level, @Nullable String message) {
      this.entityData.set(DATA_OUTCOME, (byte)2);
      this.failedAt = this.tickCount;
      this.victim = null;
      Sounds.play(level, this.position(), SoundEvents.GLASS_BREAK, 0.6F, 1.5F);
      Sounds.play(level, this.position(), SoundEvents.BEACON_DEACTIVATE, 0.6F, 1.8F);
      ServerPlayer caster = this.casterId == null ? null : level.getServer().getPlayerList().getPlayer(this.casterId);
      if (caster != null) {
         if (this.ability != null) {
            AbilityCooldowns.clear(caster, this.ability);
         }

         if (message != null) {
            caster.displayClientMessage(Component.translatable(message).withStyle(ChatFormatting.RED), true);
         }
      }
   }

   private void sounds(ServerLevel level) {
      Vec3 at = this.position().add(heart(this.victimHeight()));
      if (this.tickCount == 1) {
         Sounds.play(level, at, SoundEvents.ENCHANTMENT_TABLE_USE, 1.0F, 1.2F);
         Sounds.play(level, at, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0F, 0.8F);
         Sounds.play(level, at, SoundEvents.BEACON_POWER_SELECT, 0.7F, 1.6F);
      }

      if (this.outcome() != 2) {
         if (this.tickCount == 8) {
            Sounds.play(level, at, SoundEvents.IRON_TRAPDOOR_CLOSE, 1.0F, 0.7F);
            Sounds.play(level, at, SoundEvents.CHAIN_PLACE, 1.0F, 1.4F);
         }

         if (this.tickCount == 12) {
            Sounds.play(level, at, SoundEvents.PISTON_CONTRACT, 0.8F, 0.6F);
            Sounds.play(level, at, SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.8F, 1.4F);
         }

         if (this.tickCount == 20 && this.outcome() == 1) {
            Sounds.play(level, at, SoundEvents.SHULKER_BOX_CLOSE, 1.2F, 0.6F);
            Sounds.play(level, at, SoundEvents.ENDER_CHEST_CLOSE, 1.0F, 1.3F);
            Sounds.play(level, at, SoundEvents.LIGHTNING_BOLT_IMPACT, 0.4F, 1.8F);
            Sounds.play(level, at, SoundEvents.AMETHYST_CLUSTER_BREAK, 0.8F, 1.6F);
         }
      }
   }

   private void clientTick() {
      Entity held = this.level().getEntity(this.victimId());
      float width = this.victimWidth();
      float height = this.victimHeight();
      if (this.tickCount < 4 && held != null) {
         this.setPos(held.position());
      }

      Vec3 feet = this.position();
      Vec3 heart = feet.add(heart(height));
      if (this.outcome() != 2) {
         int victimId = this.victimId();
         if (this.tickCount < 20) {
            if (this.tickCount >= 4) {
               ClientSide.run(() -> () -> RootedClient.hold(victimId));
            }

            float shrunk = 1.0F - 0.85F * squeeze(this.tickCount + 1.0F);
            if (this.tickCount >= 12) {
               ClientSide.run(() -> () -> SealCaptureClient.shrink(victimId, shrunk, height));
            }

            for (int i = 0; i < 2; i++) {
               Vec3 from = heart.add(
                  this.random.nextGaussian() * (width + 1.0), this.random.nextGaussian() * (height * 0.5 + 0.6), this.random.nextGaussian() * (width + 1.0)
               );
               Vec3 pull = heart.subtract(from);
               this.level().addParticle(ParticleTypes.ENCHANT, from.x, from.y, from.z, pull.x, pull.y, pull.z);
            }
         }

         if (this.tickCount == 20) {
            for (int i = 0; i < 24; i++) {
               this.level()
                  .addParticle(
                     ParticleTypes.END_ROD,
                     heart.x,
                     heart.y,
                     heart.z,
                     this.random.nextGaussian() * 0.12,
                     this.random.nextGaussian() * 0.12,
                     this.random.nextGaussian() * 0.12
                  );
            }

            this.level().addParticle(ParticleTypes.FLASH, heart.x, heart.y, heart.z, 0.0, 0.0, 0.0);
            ClientSide.run(() -> () -> CameraShake.from(heart, 1.0F, 16.0, 8));
         }
      }
   }

   public AABB getBoundingBoxForCulling() {
      return new AABB(this.position(), this.position()).inflate(24.0);
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean hurt(DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }
}
