package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.amulet.ability.aegis.Deflection;
import com.amuletmod.client.BarrierHum;
import com.amuletmod.client.CameraShake;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.registry.ModSounds;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Easing;
import com.amuletmod.util.Sounds;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import com.amuletmod.util.VanillaEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class BarrierEntity extends Entity {
   public static final float MAX_RADIUS = 12.0F;
   public static final float WARD_RADIUS = 1.4F;
   public static final float WARD_CENTER_HEIGHT = 0.95F;
   public static final int GROW_TICKS = 10;
   public static final int FADE_TICKS = 16;
   private static final float ZAP_DAMAGE = 2.0F;
   private static final EntityDataAccessor<Byte> DATA_MODE = SynchedEntityData.defineId(BarrierEntity.class, EntityDataSerializers.BYTE);
   private static final EntityDataAccessor<Float> DATA_RADIUS = SynchedEntityData.defineId(BarrierEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Integer> DATA_LIFETIME = SynchedEntityData.defineId(BarrierEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_OWNER = SynchedEntityData.defineId(BarrierEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Vector3f> DATA_IMPACT = SynchedEntityData.defineId(BarrierEntity.class, EntityDataSerializers.VECTOR3);
   private static final EntityDataAccessor<Integer> DATA_IMPACT_TICK = SynchedEntityData.defineId(BarrierEntity.class, EntityDataSerializers.INT);
   private static final Map<UUID, BarrierEntity> WARDS = new HashMap<>();
   @Nullable
   private UUID ownerId;
   private int clientImpactTick = -1000;

   public BarrierEntity(EntityType<? extends BarrierEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   private BarrierEntity(ServerLevel level, ServerPlayer owner, BarrierEntity.Mode mode, float radius, int lifetime) {
      this((EntityType<? extends BarrierEntity>)ModEntities.BARRIER.get(), level);
      this.ownerId = owner.getUUID();
      this.moveTo(owner.getX(), owner.getY(), owner.getZ(), 0.0F, 0.0F);
      this.entityData.set(DATA_MODE, (byte)mode.ordinal());
      this.entityData.set(DATA_RADIUS, radius);
      this.entityData.set(DATA_LIFETIME, lifetime);
      this.entityData.set(DATA_OWNER, owner.getId());
   }

   public static BarrierEntity dome(ServerLevel level, ServerPlayer owner, float radius, int lifetime) {
      return new BarrierEntity(level, owner, BarrierEntity.Mode.DOME, radius, lifetime);
   }

   public static BarrierEntity ward(ServerLevel level, ServerPlayer owner, int lifetime) {
      return new BarrierEntity(level, owner, BarrierEntity.Mode.WARD, 1.4F, lifetime);
   }

   @Nullable
   public static BarrierEntity wardOf(Player player) {
      BarrierEntity ward = WARDS.get(player.getUUID());
      return ward != null && !ward.isRemoved() && ward.isShielding() ? ward : null;
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_MODE, (byte)0);
      builder.define(DATA_RADIUS, 1.0F);
      builder.define(DATA_LIFETIME, 0);
      builder.define(DATA_OWNER, -1);
      builder.define(DATA_IMPACT, new Vector3f(0.0F, 1.0F, 0.0F));
      builder.define(DATA_IMPACT_TICK, -1000);
   }

   public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
      super.onSyncedDataUpdated(key);
      if (DATA_IMPACT_TICK.equals(key)) {
         this.clientImpactTick = this.tickCount;
      }
   }

   public BarrierEntity.Mode mode() {
      return this.entityData.get(DATA_MODE) == 1 ? BarrierEntity.Mode.WARD : BarrierEntity.Mode.DOME;
   }

   public float radius() {
      return (Float)this.entityData.get(DATA_RADIUS);
   }

   public int lifetime() {
      return (Integer)this.entityData.get(DATA_LIFETIME);
   }

   public int ownerEntityId() {
      return (Integer)this.entityData.get(DATA_OWNER);
   }

   public Vec3 center() {
      return this.mode() == BarrierEntity.Mode.WARD ? this.position().add(0.0, 0.95F, 0.0) : this.position();
   }

   public boolean contains(Vec3 point) {
      double radius = this.radius();
      return point.distanceToSqr(this.center()) < radius * radius;
   }

   public boolean isShielding() {
      return this.tickCount < this.lifetime();
   }

   public float scale(float partialTick) {
      return Easing.outBack((this.tickCount + partialTick) / 10.0F);
   }

   public float fade(float partialTick) {
      float t = this.tickCount + partialTick;
      return Mth.clamp(t / 3.0F, 0.0F, 1.0F) * Mth.clamp((this.lifetime() - t) / 16.0F, 0.0F, 1.0F);
   }

   public Vec3 impactDirection() {
      return new Vec3((Vector3f)this.entityData.get(DATA_IMPACT));
   }

   public float sinceImpact(float partialTick) {
      return this.tickCount - this.clientImpactTick + partialTick;
   }

   public void impact(Vec3 at) {
      Vec3 direction = at.subtract(this.center());
      this.entityData.set(DATA_IMPACT, (direction.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 1.0, 0.0) : direction.normalize()).toVector3f());
      this.entityData.set(DATA_IMPACT_TICK, this.tickCount);
   }

   @Nullable
   private ServerPlayer owner() {
      return this.ownerId != null && this.getServer() != null ? this.getServer().getPlayerList().getPlayer(this.ownerId) : null;
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         ServerPlayer owner = this.owner();
         if (this.mode() == BarrierEntity.Mode.WARD) {
            if (owner == null || !owner.isAlive() || owner.level() != this.level()) {
               this.discard();
               return;
            }

            this.setPos(owner.getX(), owner.getY(), owner.getZ());
            if (this.tickCount == 1) {
               WARDS.put(owner.getUUID(), this);
            }
         }

         if (this.tickCount == 1) {
            this.playCastSounds();
         }

         if (!this.isShielding()) {
            this.playEndSounds();
            this.discard();
         } else {
            if (this.mode() == BarrierEntity.Mode.DOME) {
               this.repelMonsters(owner);
               this.returnFire(owner);
               if (this.tickCount % 20 == 0) {
                  this.blessPlayersInside();
               }
            }
         }
      }
   }

   private void repelMonsters(@Nullable ServerPlayer owner) {
      double radius = this.radius() * Math.min(1.0F, this.scale(0.0F));
      Vec3 center = this.center();

      for (Mob mob : this.level()
         .getEntitiesOfClass(Mob.class, new AABB(center, center).inflate(radius + 2.0), mobx -> mobx instanceof Enemy && mobx.isAlive())) {
         Vec3 offset = mob.position().add(0.0, mob.getBbHeight() * 0.5, 0.0).subtract(center);
         if (!(offset.length() > radius + mob.getBbWidth() * 0.5 + 0.3)) {
            Vec3 away = new Vec3(offset.x, 0.0, offset.z);
            away = away.lengthSqr() < 1.0E-4 ? new Vec3(1.0, 0.0, 0.0) : away.normalize();
            double push = offset.length() < radius - 1.0 ? 0.9 : 0.55;
            mob.setDeltaMovement(away.x * push, Math.max(mob.getDeltaMovement().y, 0.25), away.z * push);
            mob.hurtMarked = true;
            if ((this.tickCount + mob.getId()) % 10 == 0) {
               Vec3 contact = center.add(offset.normalize().scale(radius));
               mob.hurt(this.damageSources().indirectMagic(this, owner), 2.0F);
               this.impact(contact);
               Deflection.sparks((ServerLevel)this.level(), contact);
            }
         }
      }
   }

   private void returnFire(@Nullable ServerPlayer owner) {
      double radius = this.radius() * Math.min(1.0F, this.scale(0.0F));
      Vec3 center = this.center();

      for (Projectile projectile : this.level()
         .getEntitiesOfClass(
            Projectile.class,
            new AABB(center, center).inflate(radius + 4.0),
            projectilex -> projectilex.isAlive() && !this.isFriendlyFire(projectilex.getOwner())
         )) {
         Vec3 motion = projectile.getDeltaMovement();
         Vec3 offset = projectile.position().subtract(center);
         if (!(motion.lengthSqr() < 0.001)
            && !(offset.dot(motion) >= 0.0)
            && (!(offset.length() > radius + 0.5) || !(projectile.position().add(motion).distanceTo(center) > radius + 0.5))) {
            Vec3 normal = offset.normalize();
            Vec3 contact = center.add(normal.scale(radius));
            if (projectile instanceof MeteorEntity meteor) {
               meteor.detonate(center.add(normal.scale(radius + 0.5)));
            } else {
               Deflection.returnToSender(projectile, owner, motion.subtract(normal.scale(2.0 * motion.dot(normal))));
            }

            this.impact(contact);
            Deflection.sparks((ServerLevel)this.level(), contact);
         }
      }
   }

   private boolean isFriendlyFire(@Nullable Entity shooter) {
      return shooter == null ? false : shooter.getUUID().equals(this.ownerId) || shooter instanceof Player && this.contains(shooter.position());
   }

   private void blessPlayersInside() {
      Vec3 center = this.center();

      for (Player player : this.level()
         .getEntitiesOfClass(Player.class, new AABB(center, center).inflate(this.radius()), playerx -> playerx.isAlive() && this.contains(playerx.position()))) {
         player.addEffect(new MobEffectInstance(VanillaEffects.REGENERATION, 50, 1, true, true));
         player.addEffect(new MobEffectInstance(VanillaEffects.DAMAGE_RESISTANCE, 50, 0, true, true));
      }
   }

   private void playCastSounds() {
      if (this.mode() == BarrierEntity.Mode.DOME) {
         Sounds.play(this.level(), this.center(), (SoundEvent)ModSounds.AEGIS_SHIELD_SPAWN.get(), 1.4F, 0.88F);
      } else {
         Sounds.play(this.level(), this.center(), (SoundEvent)ModSounds.AEGIS_SHIELD_SPAWN.get(), 1.0F, 1.0F);
      }
   }

   private void playEndSounds() {
      Vec3 at = this.center();
      if (this.mode() == BarrierEntity.Mode.DOME) {
         Sounds.play(this.level(), at, SoundEvents.BEACON_DEACTIVATE, 1.0F, 1.3F);
         Sounds.play(this.level(), at, SoundEvents.GLASS_BREAK, 1.0F, 0.8F);
         Sounds.play(this.level(), at, SoundEvents.AMETHYST_CLUSTER_BREAK, 1.0F, 0.8F);
      } else {
         Sounds.play(this.level(), at, SoundEvents.BEACON_DEACTIVATE, 0.6F, 1.9F);
         Sounds.play(this.level(), at, SoundEvents.AMETHYST_BLOCK_BREAK, 0.8F, 1.4F);
      }
   }

   private void clientTick() {
      RandomSource random = this.random;
      if (this.tickCount == 1) {
         ClientSide.run(() -> () -> BarrierHum.start(this));
      }

      Vec3 center = this.mode() == BarrierEntity.Mode.WARD ? this.wardCenterOnClient() : this.center();
      float radius = this.radius() * Math.min(1.0F, this.scale(0.0F));
      if (this.mode() == BarrierEntity.Mode.DOME) {
         if (this.tickCount == 1) {
            for (int i = 0; i < 48; i++) {
               double angle = i * (float) (Math.PI * 2) / 48.0;
               this.level().addParticle(ParticleTypes.END_ROD, center.x, center.y + 0.2, center.z, Math.cos(angle) * 0.35, 0.02, Math.sin(angle) * 0.35);
            }

            ClientSide.run(() -> () -> CameraShake.from(center, 0.8F, 16.0, 10));
         }

         if (this.fade(0.0F) > 0.2F) {
            Vec3 onShell = randomUpperDirection(random).scale(radius).add(center);
            this.level().addParticle(ParticleTypes.END_ROD, onShell.x, onShell.y, onShell.z, 0.0, -0.01, 0.0);
            double angle = random.nextDouble() * (float) (Math.PI * 2);
            this.level()
               .addParticle(ParticleTypes.ENCHANT, center.x + Math.cos(angle) * radius, center.y + 1.4, center.z + Math.sin(angle) * radius, 0.0, -1.4, 0.0);
         }
      } else if (this.tickCount % 3 == 0) {
         Vec3 onShell = randomUpperDirection(random).scale(radius).add(center);
         this.level().addParticle(ParticleTypes.ELECTRIC_SPARK, onShell.x, onShell.y, onShell.z, 0.0, 0.0, 0.0);
      }
   }

   private Vec3 wardCenterOnClient() {
      Entity owner = this.level().getEntity(this.ownerEntityId());
      return (owner != null ? owner.position() : this.position()).add(0.0, 0.95F, 0.0);
   }

   private static Vec3 randomUpperDirection(RandomSource random) {
      Vec3 direction = new Vec3(random.nextGaussian(), Math.abs(random.nextGaussian()), random.nextGaussian());
      return direction.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 1.0, 0.0) : direction.normalize();
   }

   public void onRemovedFromLevel() {
      super.onRemovedFromLevel();
      if (this.ownerId != null && WARDS.get(this.ownerId) == this) {
         WARDS.remove(this.ownerId);
      }
   }

   public AABB getBoundingBoxForCulling() {
      return new AABB(this.center(), this.center()).inflate(this.radius() + 1.0);
   }

   public boolean shouldRenderAtSqrDistance(double distanceSqr) {
      return distanceSqr < 16384.0;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(ValueInput input) {
   }

   protected void addAdditionalSaveData(ValueOutput output) {
   }

   public boolean isAttackable() {
      return false;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean canBeCollidedWith() {
      return false;
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }

   public static enum Mode {
      DOME,
      WARD;
   }
}
