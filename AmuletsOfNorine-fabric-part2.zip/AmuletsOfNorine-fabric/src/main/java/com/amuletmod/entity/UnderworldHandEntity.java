package com.amuletmod.entity;

import com.amuletmod.client.CameraShake;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Easing;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.ServerStoppedEvent;
import org.jetbrains.annotations.Nullable;

public class UnderworldHandEntity extends Entity {
   public static final int OPEN_TICKS = 8;
   public static final int RISE_START = 6;
   public static final int RISE_END = 16;
   public static final int CLAMP_START = 16;
   public static final int CLAMP_END = 22;
   public static final int DRAG_START = 30;
   public static final int DRAG_END = 50;
   public static final int CLOSE_END = 64;
   private static final EntityDataAccessor<Integer> DATA_VICTIM = SynchedEntityData.defineId(UnderworldHandEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Float> DATA_SCALE = SynchedEntityData.defineId(UnderworldHandEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Float> DATA_FACING = SynchedEntityData.defineId(UnderworldHandEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Float> DATA_VICTIM_WIDTH = SynchedEntityData.defineId(UnderworldHandEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Float> DATA_VICTIM_HEIGHT = SynchedEntityData.defineId(UnderworldHandEntity.class, EntityDataSerializers.FLOAT);
   private static final Set<Integer> SEIZED = new HashSet<>();
   @Nullable
   private LivingEntity victim;
   @Nullable
   private UUID ownerId;
   @Nullable
   private Vec3 seizedAt;
   private boolean wasNoAi;
   private boolean wasNoGravity;

   public UnderworldHandEntity(EntityType<? extends UnderworldHandEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public UnderworldHandEntity(ServerLevel level, LivingEntity victim, Vec3 anchor, @Nullable ServerPlayer owner) {
      this((EntityType<? extends UnderworldHandEntity>)ModEntities.UNDERWORLD_HAND.get(), level);
      this.victim = victim;
      this.ownerId = owner == null ? null : owner.getUUID();
      this.moveTo(anchor.x, anchor.y, anchor.z, 0.0F, 0.0F);
      Vec3 toward = owner == null ? victim.getLookAngle() : owner.position().subtract(anchor);
      this.entityData.set(DATA_FACING, (float)(Mth.atan2(toward.x, toward.z) * 180.0F / (float)Math.PI));
      this.entityData.set(DATA_VICTIM, victim.getId());
      this.entityData.set(DATA_VICTIM_WIDTH, victim.getBbWidth());
      this.entityData.set(DATA_VICTIM_HEIGHT, victim.getBbHeight());
      this.entityData.set(DATA_SCALE, Mth.clamp(Math.max(victim.getBbHeight() / 1.9F, victim.getBbWidth() / 0.9F) * 1.25F, 0.9F, 5.0F));
      SEIZED.add(victim.getId());
   }

   public static boolean isSeized(LivingEntity entity) {
      return SEIZED.contains(entity.getId());
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_VICTIM, -1);
      builder.define(DATA_SCALE, 1.0F);
      builder.define(DATA_FACING, 0.0F);
      builder.define(DATA_VICTIM_WIDTH, 0.6F);
      builder.define(DATA_VICTIM_HEIGHT, 1.8F);
   }

   public float scale() {
      return (Float)this.entityData.get(DATA_SCALE);
   }

   public float facing() {
      return (Float)this.entityData.get(DATA_FACING);
   }

   public float victimWidth() {
      return (Float)this.entityData.get(DATA_VICTIM_WIDTH);
   }

   public float victimHeight() {
      return (Float)this.entityData.get(DATA_VICTIM_HEIGHT);
   }

   public static float clamp(float age) {
      return Easing.outCubic(Mth.clamp((age - 16.0F) / 6.0F, 0.0F, 1.0F));
   }

   public static float drag(float age) {
      float t = Mth.clamp((age - 30.0F) / 20.0F, 0.0F, 1.0F);
      return t * t * t;
   }

   public float victimSink(float age) {
      return drag(age) * (this.victimHeight() + 1.0F);
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         ServerLevel level = (ServerLevel)this.level();
         Vec3 at = this.position();
         if (this.victim != null && (!this.victim.isAlive() || this.victim.isRemoved() || this.victim.level() != level)) {
            this.letGo();
         }

         if (this.tickCount == 1) {
            if (this.victim != null) {
               this.seize(this.victim);
            }

            Sounds.play(level, at, SoundEvents.RESPAWN_ANCHOR_CHARGE, 1.0F, 0.5F);
            Sounds.play(level, at, SoundEvents.BASALT_BREAK, 1.0F, 0.6F);
         }

         if (this.tickCount == 6) {
            Sounds.play(level, at, SoundEvents.ZOMBIE_BREAK_WOODEN_DOOR, 0.9F, 0.5F);
            Sounds.play(level, at, SoundEvents.LAVA_POP, 1.0F, 0.6F);
         }

         if (this.tickCount == 22) {
            Sounds.play(level, at, SoundEvents.ANVIL_LAND, 0.6F, 0.5F);
            Sounds.play(level, at, SoundEvents.ZOMBIE_ATTACK_IRON_DOOR, 0.8F, 0.6F);
            if (this.victim != null) {
               this.victim.hurt(this.damageSource(level), 1.0F);
               this.victim.setInvulnerable(true);
            }
         }

         if (this.tickCount == 30) {
            Sounds.play(level, at, (SoundEvent)SoundEvents.SOUL_ESCAPE.value(), 1.4F, 0.6F);
            Sounds.play(level, at, SoundEvents.GHAST_HURT, 0.7F, 0.5F);
            Sounds.play(level, at, SoundEvents.GRAVEL_BREAK, 1.0F, 0.5F);
         }

         if (this.victim != null) {
            if (this.tickCount >= 50) {
               this.finish(level, this.victim);
            } else {
               this.hold(this.victim);
            }
         }

         if (this.tickCount == 50) {
            Sounds.play(level, at, SoundEvents.FIRECHARGE_USE, 1.0F, 0.5F);
            Sounds.play(level, at, (SoundEvent)SoundEvents.RESPAWN_ANCHOR_DEPLETE.value(), 1.0F, 0.8F);
            level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, at.x, at.y + 0.2, at.z, 30, 0.4, 0.2, 0.4, 0.12);
            level.sendParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y + 0.3, at.z, 16, 0.5, 0.3, 0.5, 0.06);
            level.sendParticles(ParticleTypes.LAVA, at.x, at.y + 0.2, at.z, 6, 0.3, 0.1, 0.3, 0.0);
         }

         if (this.tickCount >= 64) {
            this.discard();
         }
      }
   }

   private DamageSource damageSource(ServerLevel level) {
      ServerPlayer owner = this.ownerId == null ? null : level.getServer().getPlayerList().getPlayer(this.ownerId);
      return ModDamage.source(level, ModDamage.UNDERWORLD, owner, owner);
   }

   private void seize(LivingEntity held) {
      this.seizedAt = held.position();
      held.stopRiding();
      held.ejectPassengers();
      this.wasNoGravity = held.isNoGravity();
      held.setNoGravity(true);
      if (held instanceof Mob mob) {
         this.wasNoAi = mob.isNoAi();
         mob.setNoAi(true);
      }
   }

   private void hold(LivingEntity held) {
      Vec3 anchor = this.position();
      Vec3 goal = anchor;
      if (this.tickCount < 16 && this.seizedAt != null) {
         goal = this.seizedAt.lerp(anchor, Easing.smoothstep(0.0F, 1.0F, this.tickCount / 16.0F));
      }

      goal = goal.subtract(0.0, this.victimSink(this.tickCount), 0.0);
      held.teleportTo(goal.x, goal.y, goal.z);
      held.setDeltaMovement(Vec3.ZERO);
      held.fallDistance = 0.0F;
   }

   private void finish(ServerLevel level, LivingEntity held) {
      Vec3 anchor = this.position();
      held.setInvulnerable(false);
      held.teleportTo(anchor.x, anchor.y + 0.2, anchor.z);
      held.setInvisible(true);
      held.hurt(this.damageSource(level), Float.MAX_VALUE);
      if (held.isDeadOrDying()) {
         SEIZED.remove(held.getId());
         this.victim = null;
         held.discard();
      } else {
         held.setInvisible(false);
         this.letGo();
      }
   }

   private void letGo() {
      LivingEntity held = this.victim;
      if (held != null) {
         this.victim = null;
         SEIZED.remove(held.getId());
         if (held.isAlive()) {
            held.setInvulnerable(false);
            held.setNoGravity(this.wasNoGravity);
            if (held instanceof Mob mob) {
               mob.setNoAi(this.wasNoAi);
            }
         }
      }
   }

   public void onRemovedFromLevel() {
      super.onRemovedFromLevel();
      if (!this.level().isClientSide()) {
         this.letGo();
      }
   }

   private void clientTick() {
      Vec3 at = this.position();
      float scale = this.scale();
      float radius = this.pitRadius();
      if (this.tickCount >= 30 && this.tickCount <= 50 && this.level().getEntity((Integer)this.entityData.get(DATA_VICTIM)) instanceof LivingEntity held) {
         held.setPos(at.x, at.y - this.victimSink(this.tickCount), at.z);
         held.setDeltaMovement(Vec3.ZERO);
      }

      if (this.tickCount < 16 && this.random.nextInt(2) == 0) {
         double angle = this.random.nextDouble() * (float) (Math.PI * 2);
         double r = radius * this.random.nextDouble();
         this.level()
            .addParticle(
               this.random.nextInt(4) == 0 ? ParticleTypes.LAVA : ParticleTypes.FLAME,
               at.x + Math.cos(angle) * r,
               at.y + 0.1,
               at.z + Math.sin(angle) * r,
               0.0,
               0.05,
               0.0
            );
      }

      if (this.tickCount == 7) {
         BlockState ground = this.level().getBlockState(BlockPos.containing(at.x, at.y - 0.2, at.z));
         if (!ground.isAir() && ground.getRenderShape() != RenderShape.INVISIBLE) {
            BlockParticleOption debris = new BlockParticleOption(ParticleTypes.BLOCK, ground);

            for (int i = 0; i < 40; i++) {
               this.level()
                  .addParticle(
                     debris,
                     at.x + this.random.nextGaussian() * radius * 0.5,
                     at.y + 0.2,
                     at.z + this.random.nextGaussian() * radius * 0.5,
                     this.random.nextGaussian() * 0.15,
                     0.3 + this.random.nextDouble() * 0.3,
                     this.random.nextGaussian() * 0.15
                  );
            }
         }

         ClientSide.run(() -> () -> CameraShake.from(at, 1.2F, 16.0, 8));
      }

      if (this.tickCount == 22) {
         ClientSide.run(() -> () -> CameraShake.from(at, 1.8F + scale * 0.3F, 20.0, 10));
      }

      if (this.tickCount >= 30 && this.tickCount < 50) {
         for (int i = 0; i < 2; i++) {
            double angle = this.random.nextDouble() * (float) (Math.PI * 2);
            double r = radius * (0.5 + this.random.nextDouble() * 0.5);
            this.level()
               .addParticle(
                  ParticleTypes.SOUL_FIRE_FLAME,
                  at.x + Math.cos(angle) * r,
                  at.y + 0.1,
                  at.z + Math.sin(angle) * r,
                  0.0,
                  0.08 + this.random.nextDouble() * 0.08,
                  0.0
               );
         }
      }
   }

   public float pitRadius() {
      return Math.max(this.victimWidth() * 0.5F + 0.9F, this.scale() * 0.75F);
   }

   public AABB getBoundingBoxForCulling() {
      double reach = this.scale() * 2.5 + 1.0;
      return new AABB(this.getX() - reach, this.getY() - reach, this.getZ() - reach, this.getX() + reach, this.getY() + reach * 1.5, this.getZ() + reach);
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean hurt(DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }

   @EventBusSubscriber(
      modid = "amuletmod"
   )
   public static final class UnderworldHandEvents {
      private UnderworldHandEvents() {
      }

      @SubscribeEvent
      public static void onServerStopped(ServerStoppedEvent event) {
         UnderworldHandEntity.SEIZED.clear();
      }
   }
}
