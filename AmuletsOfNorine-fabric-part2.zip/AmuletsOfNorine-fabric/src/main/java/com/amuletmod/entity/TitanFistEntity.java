package com.amuletmod.entity;

import com.amuletmod.amulet.ability.sovereign.AuraSight;
import com.amuletmod.amulet.ability.titan.Stance;
import com.amuletmod.amulet.ability.titan.TitanFists;
import com.amuletmod.client.TitanFistClient;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.registry.ModSounds;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Easing;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.IEntityWithComplexSpawn;
import org.jetbrains.annotations.Nullable;

public class TitanFistEntity extends Entity implements IEntityWithComplexSpawn {
   public static final int SHOULDERS = 3;
   public static final int FADE_TICKS = 14;
   public static final int WAVE_TICKS = 10;
   public static final int RISE_TICKS = 4;
   public static final float EMERGE = 1.2F;
   private static final float[] WIDTH = new float[]{1.15F, 2.6F, 2.2F};
   private static final float GROWTH_PER_RANK = 0.07F;
   private static final double CRUSH_HEIGHT = 7.0;
   private static final double MAX_CRUSH_HEIGHT = 16.0;
   private static final double MAX_UPPERCUT_REACH = 12.0;
   private static final EntityDataAccessor<Float> DATA_REACH = SynchedEntityData.defineId(TitanFistEntity.class, EntityDataSerializers.FLOAT);
   private Stance stance = Stance.JAB;
   private Vec3 from = Vec3.ZERO;
   private float width = 1.0F;
   private int shoulder;
   private int travel = 3;
   private float wave;
   @Nullable
   private UUID ownerId;
   @Nullable
   private LivingEntity target;
   private float damage;
   private float might = 1.0F;
   private final Set<Integer> struck = new HashSet<>();

   public TitanFistEntity(EntityType<? extends TitanFistEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public TitanFistEntity(
      ServerLevel level, ServerPlayer owner, Stance stance, Vec3 at, Vec3 from, @Nullable LivingEntity target, float might, int shoulder, float wave
   ) {
      this((EntityType<? extends TitanFistEntity>)ModEntities.TITAN_FIST.get(), level);
      this.stance = stance;
      this.from = from;
      this.ownerId = owner.getUUID();
      this.target = target;
      this.might = might;
      this.damage = TitanFists.damage(might);
      this.shoulder = shoulder;
      this.wave = wave;
      this.width = WIDTH[stance.ordinal()] * (1.0F + 0.07F * AuraSight.rank(AuraSight.power(owner)));
      this.travel = Mth.clamp(Math.round((float)at.distanceTo(from) / 2.5F), 2, 4);
      this.moveTo(at.x, at.y, at.z, 0.0F, 0.0F);
      this.entityData.set(DATA_REACH, stance == Stance.CRUSH ? this.crushHeight(at) : (stance == Stance.UPPERCUT ? this.uppercutReach(at) : 0.0F));
   }

   public static Vec3 shoulder(Vec3 eye, Vec3 look, int shoulder) {
      Vec3 forward = new Vec3(look.x, 0.0, look.z);
      forward = forward.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 0.0, 1.0) : forward.normalize();
      Vec3 right = new Vec3(-forward.z, 0.0, forward.x);

      return switch (shoulder) {
         case 0 -> eye.add(right.scale(0.95)).add(0.0, 0.3, 0.0).subtract(forward.scale(0.4));
         case 1 -> eye.subtract(right.scale(0.95)).add(0.0, 0.3, 0.0).subtract(forward.scale(0.4));
         default -> eye.add(0.0, 1.1, 0.0).subtract(forward.scale(0.3));
      };
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_REACH, 0.0F);
   }

   public int launchTick() {
      return this.stance == Stance.JAB ? 2 : 5;
   }

   public int slamTick() {
      return 8;
   }

   public int impactTick() {
      return switch (this.stance) {
         case JAB -> this.launchTick() + this.travel;
         case CRUSH -> 10;
         case UPPERCUT -> this.launchTick() + 2;
      };
   }

   public int lockTick() {
      return this.stance == Stance.JAB ? this.impactTick() - 1 : this.launchTick();
   }

   public int fadeTick() {
      return this.impactTick() + 14;
   }

   public int lifetime() {
      return switch (this.stance) {
         case JAB -> this.fadeTick() + 14;
         case CRUSH -> this.impactTick() + 50;
         case UPPERCUT -> this.impactTick() + 40;
      };
   }

   public Stance stance() {
      return this.stance;
   }

   public Vec3 from() {
      return this.from;
   }

   public float width() {
      return this.width;
   }

   public boolean leftHanded() {
      return this.stance == Stance.JAB && this.shoulder == 1;
   }

   public float reach() {
      return (Float)this.entityData.get(DATA_REACH);
   }

   public float wave() {
      return this.wave;
   }

   public Vec3 heading(Vec3 position) {
      return switch (this.stance) {
         case JAB -> {
            Vec3 along = position.subtract(this.from);
            yield along.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 0.0, 1.0) : along.normalize();
         }
         case CRUSH -> new Vec3(0.0, -1.0, 0.0);
         case UPPERCUT -> new Vec3(0.0, 1.0, 0.0);
      };
   }

   public Vec3 backFacing(Vec3 position) {
      if (this.stance == Stance.JAB) {
         return new Vec3(0.0, 1.0, 0.0);
      } else {
         Vec3 away = new Vec3(position.x - this.from.x, 0.0, position.z - this.from.z);
         return away.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 0.0, 1.0) : away.normalize();
      }
   }

   public Vec3 circleCenter(Vec3 position) {
      return switch (this.stance) {
         case JAB -> this.from.subtract(position);
         case CRUSH -> new Vec3(0.0, this.reach(), 0.0);
         case UPPERCUT -> new Vec3(0.0, 0.04, 0.0);
      };
   }

   public float circleScale(float age) {
      float open = Easing.outBack(Mth.clamp(age / (this.stance == Stance.JAB ? 2.0F : 5.0F), 0.0F, 1.0F));
      float gone = this.circleGone(age);
      return gone >= 1.0F
         ? 0.0F
         : this.width * (this.stance == Stance.CRUSH ? 1.15F : (this.stance == Stance.UPPERCUT ? 1.05F : 0.95F)) * open * (1.0F + 0.6F * gone);
   }

   public float circleLight(float age) {
      float burst = this.stance == Stance.JAB ? this.launchTick() : this.impactTick();
      float flare = Math.max(0.0F, 1.0F - Math.abs(age - burst) / 2.5F);
      return (1.0F - this.circleGone(age)) * (0.85F + 0.15F * Mth.sin(age * 0.9F)) + 0.9F * flare;
   }

   private float circleGone(float age) {
      float start = this.stance == Stance.JAB ? this.launchTick() : this.impactTick();
      return Mth.clamp((age - start) / (this.stance == Stance.JAB ? 6.0F : 8.0F), 0.0F, 1.0F);
   }

   public Vec3 knuckles(float age, Vec3 position) {
      int launch = this.launchTick();
      int impact = this.impactTick();

      return switch (this.stance) {
         case JAB -> {
            Vec3 back = this.from.subtract(position);
            if (age < launch) {
               yield back;
            } else {
               float t = Mth.clamp((age - launch) / this.travel, 0.0F, 1.0F);
               if (t < 1.0F) {
                  yield back.scale(1.0F - t * t);
               } else {
                  float k = age - impact;
                  double recoil = 0.22 * Math.exp(-k * 0.45) * Math.sin(k * 1.2) * this.width;
                  yield back.lengthSqr() < 1.0E-6 ? Vec3.ZERO : back.normalize().scale(recoil);
               }
            }
         }
         case CRUSH -> {
            float h = this.reach();
            double y;
            if (age < launch) {
               y = h;
            } else if (age < this.slamTick()) {
               y = h - 1.2F * Easing.outCubic((age - launch) / (this.slamTick() - launch));
            } else if (age < impact) {
               float s = (age - this.slamTick()) / (impact - this.slamTick());
               y = (h - 1.2F) * (1.0F - s * s);
            } else {
               y = -0.1 * this.width * Mth.clamp((age - impact) / 2.0F, 0.0F, 1.0F) + 1.5 * this.dissolving(age);
            }

            yield new Vec3(0.0, y, 0.0);
         }
         case UPPERCUT -> {
            float rise = Easing.outCubic(Mth.clamp((age - launch) / 4.0F, 0.0F, 1.0F));
            yield new Vec3(0.0, -0.3 + (this.reach() + 0.3) * rise - this.reach() * 0.8 * this.dissolving(age), 0.0);
         }
      };
   }

   public float grown(float age) {
      return switch (this.stance) {
         case JAB -> 0.35F + 0.65F * Easing.smoothstep(0.0F, 0.5F, (age - this.launchTick()) / this.travel);
         case CRUSH -> 0.4F + 0.6F * Easing.smoothstep(this.launchTick(), this.slamTick(), age);
         case UPPERCUT -> 1.0F;
      };
   }

   public float dissolving(float age) {
      return Easing.smoothstep(this.fadeTick(), this.fadeTick() + 14, age);
   }

   public boolean thrown(float age) {
      return age >= this.launchTick() && this.dissolving(age) < 1.0F;
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         ClientSide.run(() -> () -> TitanFistClient.tick(this));
      } else {
         if (this.tickCount <= this.lockTick()) {
            this.follow();
         }

         if (this.tickCount == 1) {
            this.opened();
         }

         if (this.stance == Stance.CRUSH && this.tickCount == this.slamTick()) {
            Sounds.play(this.level(), this.position().add(0.0, this.reach(), 0.0), SoundEvents.PHANTOM_SWOOP, 1.4F, 0.45F);
         }

         if (this.tickCount == this.impactTick()) {
            this.impact();
         }

         if (this.stance == Stance.CRUSH && this.tickCount > this.impactTick() && this.tickCount <= this.impactTick() + 10) {
            this.shockwave();
         }

         if (this.tickCount >= this.lifetime()) {
            this.discard();
         }
      }
   }

   private void follow() {
      LivingEntity target = this.target;
      if (target != null && target.isAlive() && target.level() == this.level()) {
         switch (this.stance) {
            case JAB:
               this.setPos(target.getBoundingBox().getCenter());
               break;
            case CRUSH:
            case UPPERCUT:
               Vec3 ground = TitanFists.groundUnder(this.level(), target);
               if (ground == null) {
                  return;
               }

               this.setPos(ground);
               this.entityData.set(DATA_REACH, this.stance == Stance.CRUSH ? this.crushHeight(ground) : this.uppercutReach(ground));
         }
      }
   }

   private float crushHeight(Vec3 spot) {
      double wanted = 7.0;
      LivingEntity target = this.target;
      if (target != null) {
         wanted = Mth.clamp(target.getBoundingBox().maxY - spot.y + 2.0, 7.0, 16.0);
      }

      return (float)Math.max(1.5, Math.min(wanted, TitanFists.clearance(this.level(), spot, wanted + 0.5) - 0.4));
   }

   private float uppercutReach(Vec3 ground) {
      LivingEntity target = this.target;
      return target == null ? 3.0F : (float)Mth.clamp(target.getY() + target.getBbHeight() * 0.75 - ground.y, 2.0, 12.0);
   }

   private void opened() {
      Vec3 circle = this.position().add(this.circleCenter(this.position()));
      switch (this.stance) {
         case JAB:
            Sounds.play(this.level(), circle, (SoundEvent)ModSounds.TITAN_JAB_SUMMON.get(), 1.0F, 0.95F + this.random.nextFloat() * 0.1F);
            break;
         case CRUSH:
            Sounds.play(this.level(), circle, (SoundEvent)ModSounds.TITAN_CRUSH_SUMMON.get(), 1.4F, 1.0F);
            break;
         case UPPERCUT:
            Sounds.play(this.level(), circle, (SoundEvent)ModSounds.TITAN_UPPERCUT_SUMMON.get(), 1.4F, 0.96F + this.random.nextFloat() * 0.08F);
      }
   }

   @Nullable
   private Player owner() {
      return this.ownerId == null ? null : this.level().getPlayerByUUID(this.ownerId);
   }

   private void impact() {
      Vec3 at = this.position();
      Player owner = this.owner();
      switch (this.stance) {
         case JAB:
            Vec3 heading = this.heading(at);
            float push = Math.min(2.2F, 0.55F + 0.2F * Mth.sqrt(this.might));
            boolean hit = false;

            for (LivingEntity victim : this.victims(owner, new AABB(at, at).inflate(this.width * 0.6F))) {
               hit |= this.land(owner, victim, this.damage, new Vec3(heading.x * push, 0.25 + Math.max(0.0, heading.y) * push, heading.z * push));
            }

            Sounds.play(this.level(), at, SoundEvents.PLAYER_ATTACK_STRONG, 1.0F, 0.6F);
            Sounds.play(this.level(), at, hit ? SoundEvents.IRON_GOLEM_ATTACK : SoundEvents.PLAYER_ATTACK_KNOCKBACK, 0.9F, 0.6F);
            break;
         case CRUSH:
            float half = this.width * 0.7F;
            double top = at.y + Math.max(this.width * 1.5, this.reach() + 0.5);

            for (LivingEntity victim : this.victims(owner, new AABB(at.x - half, at.y - 0.5, at.z - half, at.x + half, top, at.z + half))) {
               this.land(owner, victim, this.damage * 1.5F, new Vec3(0.0, 0.1, 0.0));
            }

            Sounds.play(this.level(), at, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 1.0F, 0.55F);
            Sounds.play(this.level(), at, (SoundEvent)ModSounds.TITAN_CRUSH_IMPACT.get(), 1.3F, 0.92F + this.random.nextFloat() * 0.16F);
            Sounds.play(this.level(), at, SoundEvents.WARDEN_ATTACK_IMPACT, 1.2F, 0.7F);
            break;
         case UPPERCUT:
            float half = this.width * 0.65F;
            float launch = Mth.clamp(0.9F + 0.32F * (this.might - 1.0F), 0.9F, 3.4F);
            AABB box = new AABB(at.x - half, at.y - 0.5, at.z - half, at.x + half, at.y + this.reach() + 0.5, at.z + half);

            for (LivingEntity victim : this.victims(owner, box)) {
               Vec3 off = new Vec3(victim.getX() - at.x, 0.0, victim.getZ() - at.z);
               this.land(owner, victim, this.damage * 1.25F, new Vec3(off.x * 0.15, launch, off.z * 0.15));
            }

            if (owner instanceof ServerPlayer self && self.isAlive() && !self.isPassenger() && self.getBoundingBox().intersects(box)) {
               TitanFists.launch(self, new Vec3((self.getX() - at.x) * 0.15, launch, (self.getZ() - at.z) * 0.15));
            }

            Sounds.play(this.level(), at, SoundEvents.WARDEN_ATTACK_IMPACT, 1.2F, 0.9F);
            Sounds.play(this.level(), at, SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.0F, 0.6F);
            Sounds.play(this.level(), at, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 0.5F, 1.2F);
      }
   }

   private void shockwave() {
      Player owner = this.owner();
      if (owner != null) {
         Vec3 at = this.position();
         double radius = this.wave * Easing.outCubic((this.tickCount - this.impactTick()) / 10.0F);
         float push = Math.min(1.8F, 0.6F + 0.15F * Mth.sqrt(this.might));

         for (LivingEntity victim : this.level()
            .getEntitiesOfClass(
               LivingEntity.class,
               new AABB(at, at).inflate(radius, 2.5, radius),
               victimx -> !this.struck.contains(victimx.getId()) && TitanFists.canStrike(owner, victimx)
            )) {
            Vec3 out = new Vec3(victim.getX() - at.x, 0.0, victim.getZ() - at.z);
            double distance = out.length();
            if (!(distance > radius)) {
               this.struck.add(victim.getId());
               out = distance < 0.001 ? new Vec3(1.0, 0.0, 0.0) : out.scale(1.0 / distance);
               this.land(
                  owner, victim, this.damage * 0.6F * (1.0F - 0.5F * (float)(distance / Math.max(1.0F, this.wave))), new Vec3(out.x * push, 0.35, out.z * push)
               );
            }
         }
      }
   }

   private List<LivingEntity> victims(@Nullable Player owner, AABB box) {
      List<LivingEntity> victims = new ArrayList<>();
      if (owner == null) {
         return victims;
      } else {
         victims.addAll(this.level().getEntitiesOfClass(LivingEntity.class, box, victim -> TitanFists.canStrike(owner, victim)));
         LivingEntity target = this.target;
         if (target != null && !victims.contains(target) && TitanFists.canStrike(owner, target) && target.getBoundingBox().inflate(1.0).intersects(box)) {
            victims.add(target);
         }

         victims.forEach(victim -> this.struck.add(victim.getId()));
         return victims;
      }
   }

   private boolean land(@Nullable Player owner, LivingEntity victim, float amount, Vec3 push) {
      if (owner == null) {
         return false;
      } else {
         DamageSource source = ModDamage.source(this.level(), ModDamage.TITAN_FIST, (Entity)(this.stance == Stance.JAB ? owner : this), owner);
         if (!victim.hurt(source, amount)) {
            return false;
         } else {
            double resist = 1.0 - victim.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE);
            if (resist > 0.0) {
               victim.setDeltaMovement(victim.getDeltaMovement().scale(0.25).add(push.scale(resist)));
               victim.hurtMarked = true;
            }

            return true;
         }
      }
   }

   public AABB getBoundingBoxForCulling() {
      Vec3 at = this.position();
      AABB box = new AABB(at, this.stance == Stance.JAB ? this.from : at.add(0.0, Math.max(this.reach(), 1.0F), 0.0));
      return box.inflate(this.width * 2.0F + this.wave);
   }

   public boolean shouldRenderAtSqrDistance(double distance) {
      double range = 96.0 * getViewScale();
      return distance < range * range;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
   }

   public void writeSpawnData(RegistryFriendlyByteBuf buffer) {
      buffer.writeByte(this.stance.ordinal());
      buffer.writeDouble(this.from.x);
      buffer.writeDouble(this.from.y);
      buffer.writeDouble(this.from.z);
      buffer.writeFloat(this.width);
      buffer.writeByte(this.shoulder);
      buffer.writeByte(this.travel);
      buffer.writeFloat(this.wave);
   }

   public void readSpawnData(RegistryFriendlyByteBuf buffer) {
      this.stance = Stance.byId(buffer.readByte());
      this.from = new Vec3(buffer.readDouble(), buffer.readDouble(), buffer.readDouble());
      this.width = buffer.readFloat();
      this.shoulder = buffer.readByte();
      this.travel = buffer.readByte();
      this.wave = buffer.readFloat();
   }
}
