package com.amuletmod.entity;

import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.EventPriority;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;
import com.amuletmod.neo.event.ServerStoppedEvent;
import com.amuletmod.neo.event.ServerTickEvent.Post;
import org.jetbrains.annotations.Nullable;

public class RockShellEntity extends Entity {
   public static final float FLIGHT_TICKS = 14.0F;
   public static final float LAUNCH_SPACING = 0.55F;
   public static final List<RockShellEntity.Piece> LAYOUT = layout();
   public static final int PIECES = LAYOUT.size();
   private static final int[] BREAK_RANK = breakRanks();
   private static final Map<RockShellEntity.Part, Vec3> PIVOTS = Map.of(
      RockShellEntity.Part.HEAD,
      Vec3.ZERO,
      RockShellEntity.Part.BODY,
      Vec3.ZERO,
      RockShellEntity.Part.RIGHT_ARM,
      new Vec3(-5.0, 2.0, 0.0),
      RockShellEntity.Part.LEFT_ARM,
      new Vec3(5.0, 2.0, 0.0),
      RockShellEntity.Part.RIGHT_LEG,
      new Vec3(-1.9, 12.0, 0.0),
      RockShellEntity.Part.LEFT_LEG,
      new Vec3(1.9, 12.0, 0.0)
   );
   private static final int HIT_COOLDOWN = 10;
   private static final EntityDataAccessor<Integer> DATA_OWNER = SynchedEntityData.defineId(RockShellEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Float> DATA_INTEGRITY = SynchedEntityData.defineId(RockShellEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<CompoundTag> DATA_SOURCES = SynchedEntityData.defineId(RockShellEntity.class, EntityDataSerializers.COMPOUND_TAG);
   private static final Map<UUID, RockShellEntity> ACTIVE = new HashMap<>();
   private static final Map<Integer, RockShellEntity> CLIENT_SHELLS = new HashMap<>();
   private static final Map<UUID, Float> PENDING = new HashMap<>();
   @Nullable
   private UUID ownerId;
   private float capacity;
   private float remaining;
   private int lifetime;
   private int lastHitTick = -10;
   private float lastHit;
   @Nullable
   private List<RockShellEntity.Source> sources;
   @Nullable
   private List<BlockState> shellStates;
   private int shownPieces = -1;
   private static final double PLAYER_SCALE = 0.9375;

   public RockShellEntity(EntityType<? extends RockShellEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public RockShellEntity(ServerLevel level, ServerPlayer owner, List<RockShellEntity.Source> sources, float capacity, int lifetime) {
      this((EntityType<? extends RockShellEntity>)ModEntities.ROCK_SHELL.get(), level);
      this.ownerId = owner.getUUID();
      this.capacity = this.remaining = capacity;
      this.lifetime = lifetime;
      this.setPos(owner.position());
      this.entityData.set(DATA_OWNER, owner.getId());
      int[] offsets = new int[sources.size()];
      int[] states = new int[sources.size()];
      BlockPos origin = owner.blockPosition();

      for (int i = 0; i < sources.size(); i++) {
         BlockPos offset = sources.get(i).pos().subtract(origin);
         offsets[i] = offset.getX() + 128 << 16 | offset.getY() + 128 << 8 | offset.getZ() + 128;
         states[i] = Block.getId(sources.get(i).state());
      }

      CompoundTag tag = new CompoundTag();
      tag.putLong("origin", origin.asLong());
      tag.putIntArray("offsets", offsets);
      tag.putIntArray("states", states);
      this.entityData.set(DATA_SOURCES, tag);
   }

   @Nullable
   public static RockShellEntity of(LivingEntity owner) {
      RockShellEntity shell = ACTIVE.get(owner.getUUID());
      return shell != null && !shell.isRemoved() ? shell : null;
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_OWNER, -1);
      builder.define(DATA_INTEGRITY, 1.0F);
      builder.define(DATA_SOURCES, new CompoundTag());
   }

   @Nullable
   public Entity owner() {
      return this.level().getEntity((Integer)this.entityData.get(DATA_OWNER));
   }

   public float integrity() {
      return (Float)this.entityData.get(DATA_INTEGRITY);
   }

   public int piecesLeft() {
      return Mth.ceil(this.integrity() * PIECES);
   }

   public static boolean attached(int index, int piecesLeft) {
      return BREAK_RANK[index] < piecesLeft;
   }

   @Nullable
   public static RockShellEntity clientShell(Entity owner) {
      RockShellEntity shell = CLIENT_SHELLS.get(owner.getId());
      return shell != null && !shell.isRemoved() && shell.level() == owner.level() ? shell : null;
   }

   public List<RockShellEntity.Source> sources() {
      if (this.sources == null) {
         CompoundTag tag = (CompoundTag)this.entityData.get(DATA_SOURCES);
         BlockPos origin = BlockPos.of(tag.getLong("origin"));
         int[] offsets = tag.getIntArray("offsets");
         int[] states = tag.getIntArray("states");
         List<RockShellEntity.Source> list = new ArrayList<>();

         for (int i = 0; i < Math.min(offsets.length, states.length); i++) {
            list.add(
               new RockShellEntity.Source(
                  origin.offset((offsets[i] >> 16 & 0xFF) - 128, (offsets[i] >> 8 & 0xFF) - 128, (offsets[i] & 0xFF) - 128), Block.stateById(states[i])
               )
            );
         }

         this.sources = list;
      }

      return this.sources;
   }

   public List<BlockState> shellStates() {
      if (this.shellStates == null) {
         Set<BlockState> distinct = new LinkedHashSet<>();

         for (RockShellEntity.Source source : this.sources()) {
            distinct.add(source.state().getBlock().defaultBlockState());
         }

         if (distinct.isEmpty()) {
            distinct.add(Blocks.STONE.defaultBlockState());
            distinct.add(Blocks.COBBLESTONE.defaultBlockState());
            distinct.add(Blocks.ANDESITE.defaultBlockState());
         }

         this.shellStates = new ArrayList<>(distinct);
      }

      return this.shellStates;
   }

   private static List<RockShellEntity.Piece> layout() {
      List<RockShellEntity.Piece> pieces = new ArrayList<>();

      for (float y : new float[]{10.2F, 6.5F, 2.5F}) {
         for (RockShellEntity.Part leg : new RockShellEntity.Part[]{RockShellEntity.Part.RIGHT_LEG, RockShellEntity.Part.LEFT_LEG}) {
            pieces.add(piece(pieces.size(), leg, 0.0F, y, y > 10.0F ? -0.4F : 0.0F, y > 10.0F ? 5.6F : 5.3F));
         }
      }

      for (float y : new float[]{10.0F, 6.2F}) {
         for (float x : new float[]{-2.0F, 2.0F}) {
            pieces.add(piece(pieces.size(), RockShellEntity.Part.BODY, x, y, 0.0F, 5.9F));
         }
      }

      pieces.add(piece(pieces.size(), RockShellEntity.Part.BODY, 0.0F, 4.5F, -2.4F, 4.3F));
      pieces.add(piece(pieces.size(), RockShellEntity.Part.BODY, 0.0F, 5.0F, 2.5F, 4.7F));

      for (float x : new float[]{-2.0F, 2.0F}) {
         pieces.add(piece(pieces.size(), RockShellEntity.Part.BODY, x, 2.2F, 0.0F, 6.2F));
      }

      for (float y : new float[]{8.2F, 4.0F, -0.5F}) {
         for (RockShellEntity.Part arm : new RockShellEntity.Part[]{RockShellEntity.Part.RIGHT_ARM, RockShellEntity.Part.LEFT_ARM}) {
            pieces.add(piece(pieces.size(), arm, arm == RockShellEntity.Part.RIGHT_ARM ? -1.0F : 1.0F, y, 0.0F, y < 0.0F ? 5.8F : 5.3F));
         }
      }

      for (RockShellEntity.Part arm : new RockShellEntity.Part[]{RockShellEntity.Part.RIGHT_ARM, RockShellEntity.Part.LEFT_ARM}) {
         pieces.add(piece(pieces.size(), arm, arm == RockShellEntity.Part.RIGHT_ARM ? -1.6F : 1.6F, -2.3F, 0.0F, 4.4F));
      }

      pieces.add(piece(pieces.size(), RockShellEntity.Part.HEAD, 0.0F, -4.0F, 3.2F, 5.6F));

      for (float x : new float[]{-3.6F, 3.6F}) {
         pieces.add(piece(pieces.size(), RockShellEntity.Part.HEAD, x, -4.2F, 0.6F, 4.4F));
      }

      for (float z : new float[]{1.2F, -2.2F}) {
         for (float x : new float[]{-2.2F, 2.2F}) {
            pieces.add(piece(pieces.size(), RockShellEntity.Part.HEAD, x, z > 0.0F ? -7.3F : -7.6F, z, z > 0.0F ? 5.0F : 4.2F));
         }
      }

      return List.copyOf(pieces);
   }

   private static RockShellEntity.Piece piece(int index, RockShellEntity.Part part, float x, float y, float z, float size) {
      float scale = 0.95F + index * 37 % 7 * 0.02F;
      return new RockShellEntity.Piece(part, x, y, z, size * scale, index * 53 % 31 - 15.0F, index * 97 % 41 - 20.0F, index * 71 % 29 - 14.0F);
   }

   private static int[] breakRanks() {
      List<Integer> order = new ArrayList<>();

      for (int i = 0; i < PIECES; i++) {
         order.add(i);
      }

      order.sort(Comparator.comparingInt(i -> Integer.reverse(i * -1640531527)));
      int[] ranks = new int[PIECES];
      int rank = 0;

      while (rank < PIECES) {
         ranks[order.get(rank)] = rank++;
      }

      return ranks;
   }

   public static float formsAt(int index) {
      return index * 0.55F + 14.0F;
   }

   public static float launchAt(int index) {
      return index * 0.55F;
   }

   public static Vec3 pieceInWorld(int index, Vec3 feet, float bodyYaw) {
      RockShellEntity.Piece piece = LAYOUT.get(index);
      Vec3 pivot = PIVOTS.get(piece.part());
      double x = -(pivot.x + piece.x()) / 16.0 * 0.9375;
      double y = -((pivot.y + piece.y()) / 16.0 - 1.501) * 0.9375;
      double z = (pivot.z + piece.z()) / 16.0 * 0.9375;
      double angle = (180.0 - bodyYaw) * (float) (Math.PI / 180.0);
      double cos = Math.cos(angle);
      double sin = Math.sin(angle);
      return feet.add(x * cos + z * sin, y, -x * sin + z * cos);
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         Entity owner = this.owner();
         if (owner instanceof LivingEntity living && living.isAlive() && owner.getUUID().equals(this.ownerId)) {
            this.setPos(owner.position());
            if (--this.lifetime <= 0) {
               this.shatter(false);
            }
         } else {
            this.discard();
         }
      }
   }

   private float absorb(DamageSource source, float amount, LivingEntity owner) {
      float cost = amount;
      if (this.tickCount - this.lastHitTick < 10) {
         cost = Math.max(0.0F, amount - this.lastHit);
         this.lastHit = Math.max(this.lastHit, amount);
      } else {
         this.lastHitTick = this.tickCount;
         this.lastHit = amount;
      }

      float taken = Math.min(cost, this.remaining);
      float handled = taken + (amount - cost);
      if (taken <= 0.0F) {
         return handled;
      } else {
         this.remaining -= taken;
         this.entityData.set(DATA_INTEGRITY, Math.max(0.0F, this.remaining / this.capacity));
         ServerLevel level = (ServerLevel)this.level();
         Vec3 at = owner.position().add(0.0, owner.getBbHeight() * 0.5, 0.0);
         if (source.getSourcePosition() != null) {
            at = at.add(source.getSourcePosition().subtract(at).normalize().scale(owner.getBbWidth() * 0.5 + 0.4));
         }

         level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, this.shellStates().get(0)), at.x, at.y, at.z, 10, 0.2, 0.2, 0.2, 0.1);
         Sounds.play(level, at, SoundEvents.DEEPSLATE_HIT, 1.0F, 0.7F + this.random.nextFloat() * 0.3F);
         if (this.remaining <= 0.0F) {
            this.shatter(true);
         }

         return handled;
      }
   }

   private void shatter(boolean smashed) {
      ServerLevel level = (ServerLevel)this.level();
      Entity owner = this.owner();
      Vec3 at = owner == null ? this.position() : owner.position().add(0.0, owner.getBbHeight() * 0.5, 0.0);

      for (BlockState state : this.shellStates()) {
         level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state), at.x, at.y, at.z, 40, 0.5, 0.6, 0.5, 0.15);
      }

      Sounds.play(level, at, SoundEvents.DEEPSLATE_BREAK, 1.3F, smashed ? 0.6F : 0.8F);
      Sounds.play(level, at, SoundEvents.STONE_BREAK, 1.3F, smashed ? 0.5F : 0.7F);
      if (smashed) {
         Sounds.play(level, at, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 0.35F, 1.6F);
      }

      if (owner instanceof ServerPlayer player) {
         player.displayClientMessage(
            Component.translatable(smashed ? "message.amuletmod.rock_shield_broken" : "message.amuletmod.rock_shield_crumbled").withStyle(ChatFormatting.GRAY),
            true
         );
      }

      this.discard();
   }

   public void onAddedToLevel() {
      super.onAddedToLevel();
      if (!this.level().isClientSide() && this.ownerId != null) {
         RockShellEntity old = ACTIVE.put(this.ownerId, this);
         if (old != null && old != this) {
            old.discard();
         }
      }
   }

   public void onRemovedFromLevel() {
      super.onRemovedFromLevel();
      if (!this.level().isClientSide() && this.ownerId != null) {
         ACTIVE.remove(this.ownerId, this);
      }

      if (this.level().isClientSide()) {
         CLIENT_SHELLS.values().remove(this);
      }
   }

   private void clientTick() {
      Entity owner = this.owner();
      if (owner != null) {
         CLIENT_SHELLS.put(owner.getId(), this);
         Vec3 feet = owner.position();
         float bodyYaw = owner instanceof LivingEntity living ? living.yBodyRot : owner.getYRot();

         for (int i = 0; i < PIECES; i += 3) {
            if (this.tickCount == Mth.ceil(formsAt(i))) {
               Vec3 at = pieceInWorld(i, feet, bodyYaw);
               this.level().playLocalSound(at.x, at.y, at.z, SoundEvents.STONE_PLACE, SoundSource.PLAYERS, 0.6F, 0.55F + this.random.nextFloat() * 0.3F, false);
            }
         }

         List<RockShellEntity.Source> list = this.sources();
         if (!list.isEmpty()) {
            for (int ix = 0; ix < PIECES; ix++) {
               float t = (this.tickCount - launchAt(ix)) / 14.0F;
               if (t > 0.0F && t < 1.0F && this.random.nextInt(4) == 0) {
                  RockShellEntity.Source source = list.get(ix % list.size());
                  Vec3 at = flightPosition(source, ix, this.tickCount, feet, bodyYaw);
                  this.level().addParticle(new BlockParticleOption(ParticleTypes.BLOCK, source.state()), at.x, at.y, at.z, 0.0, 0.0, 0.0);
               }
            }
         }

         int pieces = this.piecesLeft();
         if (this.shownPieces > pieces) {
            boolean sounded = false;

            for (int ixx = 0; ixx < PIECES; ixx++) {
               if (attached(ixx, this.shownPieces) && !attached(ixx, pieces)) {
                  Vec3 at = pieceInWorld(ixx, feet, bodyYaw);
                  BlockParticleOption debris = new BlockParticleOption(ParticleTypes.BLOCK, this.shellStates().get(ixx % this.shellStates().size()));

                  for (int k = 0; k < 10; k++) {
                     this.level()
                        .addParticle(
                           debris, at.x, at.y, at.z, this.random.nextGaussian() * 0.1, this.random.nextDouble() * 0.18, this.random.nextGaussian() * 0.1
                        );
                  }

                  if (!sounded) {
                     this.level().playLocalSound(at.x, at.y, at.z, SoundEvents.STONE_BREAK, SoundSource.PLAYERS, 0.9F, 0.8F, false);
                     sounded = true;
                  }
               }
            }
         }

         this.shownPieces = pieces;
      }
   }

   public static Vec3 flightPosition(RockShellEntity.Source source, int index, float age, Vec3 ownerFeet, float bodyYaw) {
      float t = Mth.clamp((age - launchAt(index)) / 14.0F, 0.0F, 1.0F);
      Vec3 from = Vec3.atCenterOf(source.pos());
      Vec3 to = pieceInWorld(index, ownerFeet, bodyYaw);
      return from.lerp(to, t * t).add(0.0, Math.sin(t * Math.PI) * 1.2, 0.0);
   }

   public AABB getBoundingBoxForCulling() {
      return this.getBoundingBox().inflate(12.0);
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean hurt(DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }

   public static enum Part {
      HEAD,
      BODY,
      RIGHT_ARM,
      LEFT_ARM,
      RIGHT_LEG,
      LEFT_LEG;
   }

   public record Piece(RockShellEntity.Part part, float x, float y, float z, float size, float tiltX, float tiltY, float tiltZ) {
   }

   @EventBusSubscriber(
      modid = "amuletmod"
   )
   public static final class RockShellEvents {
      private RockShellEvents() {
      }

      @SubscribeEvent(
         priority = EventPriority.HIGH
      )
      public static void onLivingAttack(LivingIncomingDamageEvent event) {
         LivingEntity owner = event.getEntity();
         DamageSource source = event.getSource();
         if (!owner.level().isClientSide()
            && !(event.getAmount() <= 0.0F)
            && !source.is(DamageTypeTags.BYPASSES_ARMOR)
            && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
            && !owner.isInvulnerableTo(source)
            && !(owner instanceof Player player && player.getAbilities().invulnerable)) {
            RockShellEntity shell = RockShellEntity.of(owner);
            if (shell != null) {
               float amount = event.getAmount();
               float handled = shell.absorb(source, amount, owner);
               if (handled >= amount) {
                  event.setCanceled(true);
               } else {
                  RockShellEntity.PENDING.put(owner.getUUID(), handled);
               }
            }
         }
      }

      @SubscribeEvent(
         priority = EventPriority.LOWEST
      )
      public static void onLivingHurt(LivingIncomingDamageEvent event) {
         Float taken = RockShellEntity.PENDING.remove(event.getEntity().getUUID());
         if (taken != null) {
            event.setAmount(Math.max(0.0F, event.getAmount() - taken));
         }
      }

      @SubscribeEvent
      public static void onServerTick(Post event) {
         RockShellEntity.PENDING.clear();
      }

      @SubscribeEvent
      public static void onServerStopped(ServerStoppedEvent event) {
         RockShellEntity.ACTIVE.clear();
         RockShellEntity.PENDING.clear();
      }
   }

   public record Source(BlockPos pos, BlockState state) {
   }
}
