package com.amuletmod.entity;

import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.client.CameraShake;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import com.amuletmod.util.VanillaEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class SeismicWaveEntity extends Entity {
   public static final int SPREAD_TICKS = 18;
   public static final int SETTLE_TICKS = 12;
   private static final double REACH_UP = 3.5;
   private static final EntityDataAccessor<Float> DATA_RADIUS = SynchedEntityData.defineId(SeismicWaveEntity.class, EntityDataSerializers.FLOAT);
   @Nullable
   private UUID ownerId;
   private float damage;
   private final Set<UUID> hit = new HashSet<>();
   @Nullable
   private List<SeismicWaveEntity.Column> columns;

   public SeismicWaveEntity(EntityType<? extends SeismicWaveEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public SeismicWaveEntity(ServerLevel level, ServerPlayer owner, Vec3 center, float radius, float damage) {
      this((EntityType<? extends SeismicWaveEntity>)ModEntities.SEISMIC_WAVE.get(), level);
      this.ownerId = owner.getUUID();
      this.damage = damage;
      this.entityData.set(DATA_RADIUS, radius);
      this.setPos(center);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_RADIUS, 12.0F);
   }

   public float radius() {
      return (Float)this.entityData.get(DATA_RADIUS);
   }

   public float front(float age) {
      return this.radius() * Mth.clamp(age / 18.0F, 0.0F, 1.0F);
   }

   public float lift(float distance, float age) {
      float front = this.front(age);
      float offset = (distance - front) / 0.9F;
      float strength = 0.9F * (1.0F - 0.45F * front / this.radius()) * (1.0F - Mth.clamp((age - 18.0F) / 12.0F, 0.0F, 1.0F));
      return strength * (float)Math.exp(-offset * offset);
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else if (this.tickCount > 30) {
         this.discard();
      } else if (this.tickCount <= 18) {
         ServerLevel level = (ServerLevel)this.level();
         ServerPlayer owner = this.ownerId == null ? null : level.getServer().getPlayerList().getPlayer(this.ownerId);
         float inner = this.front(this.tickCount - 1) - 0.75F;
         float outer = this.front(this.tickCount) + 0.75F;
         Vec3 center = this.position();
         if (owner != null) {
            for (LivingEntity target : level.getEntitiesOfClass(
               LivingEntity.class,
               new AABB(center, center).inflate(outer, 3.5, outer),
               targetx -> !this.hit.contains(targetx.getUUID()) && Summons.isFoe(owner, targetx)
            )) {
               double distance = Math.sqrt(target.distanceToSqr(center.x, target.getY(), center.z));
               if (!(distance < inner) && !(distance > outer)) {
                  this.hit.add(target.getUUID());
                  this.strike(level, owner, target, center);
               }
            }
         }

         if (this.tickCount % 4 == 0) {
            float front = this.front(this.tickCount);

            for (int i = 0; i < 3; i++) {
               double angle = this.random.nextDouble() * (float) (Math.PI * 2);
               Vec3 at = center.add(Math.cos(angle) * front, 0.0, Math.sin(angle) * front);
               Sounds.play(level, at, i == 0 ? SoundEvents.DEEPSLATE_BREAK : SoundEvents.GRAVEL_BREAK, 0.8F, 0.5F + this.random.nextFloat() * 0.2F);
            }
         }
      }
   }

   private void strike(ServerLevel level, ServerPlayer owner, LivingEntity target, Vec3 center) {
      if (target.hurt(ModDamage.source(level, ModDamage.SEISMIC, owner, owner), this.damage)) {
         Vec3 away = target.position().subtract(center).multiply(1.0, 0.0, 1.0);
         away = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize();
         target.setDeltaMovement(away.x * 0.35, 0.85, away.z * 0.35);
         target.hurtMarked = true;
         target.addEffect(new MobEffectInstance(VanillaEffects.MOVEMENT_SLOWDOWN, 60, 1), owner);
         level.sendParticles(ParticleTypes.EXPLOSION, target.getX(), target.getY() + 0.2, target.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
      }
   }

   private void clientTick() {
      List<SeismicWaveEntity.Column> ground = this.columns();
      if (this.tickCount == 1) {
         Vec3 at = this.position();
         ClientSide.run(() -> () -> CameraShake.from(at, 2.2F, this.radius() + 10.0, 22));
      }

      if (this.tickCount <= 18 && !ground.isEmpty()) {
         float front = this.front(this.tickCount);

         for (int i = 0; i < 14; i++) {
            SeismicWaveEntity.Column column = ground.get(this.random.nextInt(ground.size()));
            if (!(Math.abs(column.distance() - front) > 1.2F)) {
               BlockPos pos = column.pos();
               this.level()
                  .addParticle(
                     new BlockParticleOption(ParticleTypes.BLOCK, column.state()),
                     pos.getX() + this.random.nextDouble(),
                     pos.getY() + 1.1,
                     pos.getZ() + this.random.nextDouble(),
                     0.0,
                     0.25 + this.random.nextDouble() * 0.25,
                     0.0
                  );
               if (this.random.nextInt(4) == 0) {
                  this.level().addParticle(ParticleTypes.POOF, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 0.0, 0.05, 0.0);
               }
            }
         }
      }
   }

   public List<SeismicWaveEntity.Column> columns() {
      if (this.columns != null) {
         return this.columns;
      } else {
         List<SeismicWaveEntity.Column> found = new ArrayList<>();
         int reach = Mth.ceil(this.radius());
         BlockPos center = BlockPos.containing(this.getX(), this.getY() - 0.5, this.getZ());
         MutableBlockPos pos = new MutableBlockPos();

         for (int dx = -reach; dx <= reach; dx++) {
            for (int dz = -reach; dz <= reach; dz++) {
               double offsetX = center.getX() + dx + 0.5 - this.getX();
               double offsetZ = center.getZ() + dz + 0.5 - this.getZ();
               float distance = (float)Math.sqrt(offsetX * offsetX + offsetZ * offsetZ);
               if (!(distance > reach + 0.5F)) {
                  for (int dy = 3; dy >= -5; dy--) {
                     pos.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                     BlockState state = this.level().getBlockState(pos);
                     if (state.getRenderShape() == RenderShape.MODEL
                        && !state.getCollisionShape(this.level(), pos).isEmpty()
                        && this.level().getBlockState(pos.above()).getCollisionShape(this.level(), pos.above()).isEmpty()) {
                        BlockPos above = pos.above();
                        int light = this.level().getBrightness(LightLayer.SKY, above) << 20 | this.level().getBrightness(LightLayer.BLOCK, above) << 4;
                        found.add(new SeismicWaveEntity.Column(pos.immutable(), state, distance, light));
                        break;
                     }
                  }
               }
            }
         }

         this.columns = found;
         return found;
      }
   }

   public AABB getBoundingBoxForCulling() {
      double reach = this.radius() + 2.0;
      return new AABB(this.getX() - reach, this.getY() - 6.0, this.getZ() - reach, this.getX() + reach, this.getY() + 4.0, this.getZ() + reach);
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean hurt(DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }

   public record Column(BlockPos pos, BlockState state, float distance, int light) {
   }
}
