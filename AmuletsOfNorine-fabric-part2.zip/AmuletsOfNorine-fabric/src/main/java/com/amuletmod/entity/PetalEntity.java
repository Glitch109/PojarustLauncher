package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.amulet.ability.sylvan.PetalSwarms;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.UUID;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import com.amuletmod.util.VanillaEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class PetalEntity extends Projectile implements Summons.Owned {
   public static final int TRAIL_LENGTH = 6;
   private static final int MAX_AGE = 80;
   private static final int FLUTTER_TICKS = 14;
   private static final EntityDataAccessor<Integer> DATA_COLOR = SynchedEntityData.defineId(PetalEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_TARGET = SynchedEntityData.defineId(PetalEntity.class, EntityDataSerializers.INT);
   private float damage;
   @Nullable
   private Item flower;
   private boolean retargeted;
   private int lostTicks;
   public final Vec3[] trail = new Vec3[6];

   public PetalEntity(EntityType<? extends PetalEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public PetalEntity(ServerLevel level, ServerPlayer owner, LivingEntity target, Vec3 from, Vec3 velocity, int color, @Nullable Item flower, float damage) {
      this((EntityType<? extends PetalEntity>)ModEntities.PETAL.get(), level);
      this.setOwner(owner);
      this.moveTo(from.x, from.y, from.z, 0.0F, 0.0F);
      this.setDeltaMovement(velocity);
      this.entityData.set(DATA_COLOR, color);
      this.entityData.set(DATA_TARGET, target.getId());
      this.flower = flower;
      this.damage = damage;
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_COLOR, 16777215);
      builder.define(DATA_TARGET, -1);
   }

   @Nullable
   @Override
   public UUID summonerId() {
      Entity owner = this.getOwner();
      return owner == null ? null : owner.getUUID();
   }

   public int color() {
      return (Integer)this.entityData.get(DATA_COLOR);
   }

   @Nullable
   private LivingEntity target() {
      return this.level().getEntity((Integer)this.entityData.get(DATA_TARGET)) instanceof LivingEntity living && living.isAlive() ? living : null;
   }

   public void tick() {
      super.tick();
      Vec3 position = this.position();
      Vec3 velocity = this.getDeltaMovement();
      LivingEntity target = this.target();
      if (target == null && !this.level().isClientSide() && !this.retargeted && this.getOwner() instanceof LivingEntity owner) {
         this.retargeted = true;
         target = Summons.findTarget(owner, position, 10.0, null);
         this.setTarget(target);
      }

      if (target != null) {
         this.lostTicks = 0;
         Vec3 aim = target.position().add(0.0, target.getBbHeight() * 0.55, 0.0).subtract(position);
         double speed = Math.min(1.6, 0.45 + this.tickCount * 0.09);
         double steer = Math.min(0.6, 0.1 + this.tickCount * 0.045);
         velocity = velocity.lerp(aim.normalize().scale(speed), steer);
         if (!this.level().isClientSide()) {
            AABB body = target.getBoundingBox().inflate(0.35);
            if (body.contains(position) || body.clip(position, position.add(velocity)).isPresent()) {
               this.strike(target);
               return;
            }
         }
      } else {
         velocity = velocity.scale(0.82).add(Math.sin(this.tickCount * 0.5) * 0.02, -0.025, Math.cos(this.tickCount * 0.4) * 0.02);
         if (!this.level().isClientSide() && ++this.lostTicks > 14) {
            this.wilt();
            return;
         }
      }

      this.setDeltaMovement(velocity);
      this.setPos(position.add(velocity));
      if (velocity.lengthSqr() > 1.0E-6) {
         this.setYRot((float)(Mth.atan2(velocity.x, velocity.z) * 180.0F / (float)Math.PI));
         this.setXRot((float)(Mth.atan2(velocity.y, velocity.horizontalDistance()) * 180.0F / (float)Math.PI));
      }

      if (this.level().isClientSide()) {
         this.clientTick(position);
      } else if (this.tickCount > 80) {
         this.wilt();
      }
   }

   private void setTarget(@Nullable LivingEntity target) {
      int from = (Integer)this.entityData.get(DATA_TARGET);
      int to = target == null ? -1 : target.getId();
      this.entityData.set(DATA_TARGET, to);
      PetalSwarms.track(this.summonerId(), from, to);
   }

   private void clientTick(Vec3 previous) {
      System.arraycopy(this.trail, 0, this.trail, 1, 5);
      this.trail[0] = previous;
      if (this.random.nextInt(3) == 0) {
         Vector3f rgb = PetalSwarms.rgb(this.color());
         this.level().addParticle(new DustParticleOptions(rgb, 0.6F), this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
      }
   }

   private void strike(LivingEntity target) {
      ServerLevel level = (ServerLevel)this.level();
      Entity owner = this.getOwner();
      if (owner instanceof ServerPlayer player) {
         target.setLastHurtByPlayer(player);
      }

      DamageSource source = ModDamage.source(level, ModDamage.PETAL, this, owner);
      if (target.hurt(source, this.damage) && this.flower == Items.WITHER_ROSE) {
         target.addEffect(new MobEffectInstance(VanillaEffects.WITHER, 40, 0), owner);
      }

      Vec3 at = this.position();
      level.sendParticles(new DustParticleOptions(PetalSwarms.rgb(this.color()), 1.1F), at.x, at.y, at.z, 6, 0.15, 0.15, 0.15, 0.0);
      level.sendParticles(ParticleTypes.CHERRY_LEAVES, at.x, at.y, at.z, 1, 0.1, 0.1, 0.1, 0.0);
      Sounds.play(level, at, SoundEvents.PINK_PETALS_BREAK, 0.6F, 1.3F + this.random.nextFloat() * 0.4F);
      Sounds.play(level, at, SoundEvents.AMETHYST_BLOCK_HIT, 0.35F, 1.6F + this.random.nextFloat() * 0.3F);
      this.discard();
   }

   private void wilt() {
      ((ServerLevel)this.level()).sendParticles(ParticleTypes.CHERRY_LEAVES, this.getX(), this.getY(), this.getZ(), 1, 0.05, 0.05, 0.05, 0.0);
      this.discard();
   }

   public void onRemovedFromLevel() {
      super.onRemovedFromLevel();
      if (!this.level().isClientSide()) {
         PetalSwarms.track(this.summonerId(), (Integer)this.entityData.get(DATA_TARGET), -1);
      }
   }

   public boolean isPickable() {
      return false;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   public boolean shouldRenderAtSqrDistance(double distance) {
      return distance < 4096.0;
   }

   protected void readAdditionalSaveData(ValueInput input) {
   }

   protected void addAdditionalSaveData(ValueOutput output) {
   }
}
