package com.amuletmod.entity;

import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.amulet.ability.meteor.MeteorBlast;
import com.amuletmod.client.MeteorWhooshSound;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Easing;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class SeekingMeteorEntity extends MeteorEntity {
   public static final int TRAIL_LENGTH = 8;
   public static final double LAUNCH_SPEED = 0.6;
   public static final double MAX_SPEED = 3.0;
   private static final double ACCELERATION = 0.12;
   public static final double VELOCITY_SMOOTHING = 0.15;
   private static final double AIM_SPEED = 3.0;
   private static final double MAX_LEAD_TICKS = 60.0;
   private static final double GAIN = 2.2;
   private static final double LAUNCH_STEER = 0.04;
   private static final double COMMIT_TICKS = 7.0;
   private static final double HELD_SPEED = 0.05;
   private static final int LIFETIME = 200;
   private static final EntityDataAccessor<Vector3f> DATA_AIM = SynchedEntityData.defineId(SeekingMeteorEntity.class, EntityDataSerializers.VECTOR3);
   private static final EntityDataAccessor<Boolean> DATA_GUIDED = SynchedEntityData.defineId(SeekingMeteorEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Float> DATA_RAMP = SynchedEntityData.defineId(SeekingMeteorEntity.class, EntityDataSerializers.FLOAT);
   @Nullable
   private LivingEntity target;
   @Nullable
   private UUID launcher;
   private float damage;
   private float blastRadius;
   private boolean committed;
   @Nullable
   private Entity struck;
   private Vec3 targetVelocity = Vec3.ZERO;
   @Nullable
   private Vec3 lastTargetMiddle;
   public final Vec3[] trail = new Vec3[8];
   private boolean whooshing;

   public SeekingMeteorEntity(EntityType<? extends SeekingMeteorEntity> type, Level level) {
      super(type, level);
   }

   public SeekingMeteorEntity(
      ServerLevel level,
      LivingEntity owner,
      @Nullable LivingEntity target,
      Vec3 aim,
      Vec3 targetVelocity,
      Vec3 middle,
      Vec3 heading,
      float damage,
      float blastRadius
   ) {
      this((EntityType<? extends SeekingMeteorEntity>)ModEntities.SEEKING_METEOR.get(), level);
      this.setOwner(owner);
      this.launcher = owner.getUUID();
      this.target = target;
      this.targetVelocity = targetVelocity;
      this.lastTargetMiddle = aim;
      this.damage = damage;
      this.blastRadius = blastRadius;
      this.moveTo(middle.x, middle.y - this.getBbHeight() * 0.5, middle.z, 0.0F, 0.0F);
      this.setDeltaMovement(heading.normalize().scale(0.6));
      this.entityData.set(DATA_AIM, aim.toVector3f());
      this.entityData.set(DATA_RAMP, (float)Mth.clamp(aim.distanceTo(middle) * 0.22, 4.0, 13.0));
   }

   @Override
   protected void defineSynchedData(Builder builder) {
      super.defineSynchedData(builder);
      builder.define(DATA_AIM, new Vector3f());
      builder.define(DATA_GUIDED, true);
      builder.define(DATA_RAMP, 8.0F);
   }

   public Vec3 aim() {
      return new Vec3((Vector3f)this.entityData.get(DATA_AIM));
   }

   public boolean isGuided() {
      return (Boolean)this.entityData.get(DATA_GUIDED);
   }

   public Vec3 middle() {
      return this.position().add(0.0, this.getBbHeight() * 0.5, 0.0);
   }

   @Override
   public void tick() {
      Vec3 before = this.middle();
      super.tick();
      if (this.level().isClientSide() && !this.isRemoved()) {
         System.arraycopy(this.trail, 0, this.trail, 1, 7);
         this.trail[0] = before;
         if (!this.whooshing) {
            this.whooshing = true;
            ClientSide.run(() -> () -> MeteorWhooshSound.follow(this));
         }
      }
   }

   @Override
   protected void steer() {
      if (!this.level().isClientSide() && this.isGuided() && !this.stillGuided()) {
         this.entityData.set(DATA_GUIDED, false);
      }

      if (this.isGuided()) {
         Vec3 velocity = this.getDeltaMovement();
         double speed = velocity.length();
         if (!(speed < 0.05)) {
            Vec3 lineOfSight = this.aim().subtract(this.middle());
            double distance = lineOfSight.length();
            if (!(distance < 0.001)) {
               speed = Math.min(3.0, speed + 0.12);
               double share = 0.04 + 0.96 * Easing.smoothstep(0.0F, (Float)this.entityData.get(DATA_RAMP), this.tickCount);
               double turn = Math.min(1.0, share * 2.2 * speed / Math.max(distance, 0.1));
               Vec3 heading = velocity.scale(1.0 / velocity.length());
               heading = heading.add(lineOfSight.scale(1.0 / distance).subtract(heading).scale(turn));
               if (heading.lengthSqr() < 1.0E-6) {
                  heading = lineOfSight;
               }

               this.setDeltaMovement(heading.normalize().scale(speed));
            }
         }
      }
   }

   private boolean stillGuided() {
      Entity owner = this.getOwner();
      if (owner != null && owner.getUUID().equals(this.launcher)) {
         Vec3 velocity = this.getDeltaMovement();
         double speed = velocity.length();
         if (speed < 0.05) {
            return true;
         } else {
            Vec3 aim = this.aim();
            if (!this.committed && this.target != null && this.target.isAlive() && this.target.level() == this.level()) {
               Vec3 targetMiddle = this.target.position().add(0.0, this.target.getBbHeight() * 0.5, 0.0);
               if (this.lastTargetMiddle != null) {
                  this.targetVelocity = trackVelocity(this.targetVelocity, targetMiddle.subtract(this.lastTargetMiddle));
               }

               this.lastTargetMiddle = targetMiddle;
               Vec3 predicted = targetMiddle.add(
                  this.targetVelocity.scale(interceptTicks(this.middle(), Math.max(speed, 2.4000000000000004), targetMiddle, this.targetVelocity))
               );
               Vec3 toward = predicted.subtract(aim);
               double gap = toward.length();
               if (gap > 0.001) {
                  aim = aim.add(toward.scale(Math.min(1.0, 3.0 / gap)));
                  this.entityData.set(DATA_AIM, aim.toVector3f());
               }
            }

            Vec3 lineOfSight = aim.subtract(this.middle());
            if (lineOfSight.length() < 7.0 * speed) {
               this.committed = true;
            }

            return !this.committed || lineOfSight.dot(velocity) > 0.0 && lineOfSight.length() > 0.4;
         }
      } else {
         return false;
      }
   }

   public static Vec3 trackVelocity(Vec3 estimate, Vec3 moved) {
      return estimate.add(moved.subtract(estimate).scale(0.15));
   }

   private static double interceptTicks(Vec3 from, double speed, Vec3 at, Vec3 velocity) {
      Vec3 gap = at.subtract(from);
      double a = velocity.lengthSqr() - speed * speed;
      double b = 2.0 * velocity.dot(gap);
      double c = gap.lengthSqr();
      double ticks = -1.0;
      if (Math.abs(a) < 1.0E-6) {
         ticks = b < 0.0 ? -c / b : -1.0;
      } else {
         double discriminant = b * b - 4.0 * a * c;
         if (discriminant >= 0.0) {
            double root = Math.sqrt(discriminant);
            double early = (-b - root) / (2.0 * a);
            double late = (-b + root) / (2.0 * a);
            ticks = Math.min(early, late) > 0.0 ? Math.min(early, late) : Math.max(early, late);
         }
      }

      if (ticks <= 0.0) {
         ticks = gap.length() / speed;
      }

      return Math.min(ticks, 60.0);
   }

   @Override
   protected void spawnTrail(Vec3 motion) {
      double middle = this.getBbHeight() * 0.5;
      int flames = 2 + (int)(motion.length() * 1.5);

      for (int i = 0; i < flames; i++) {
         double back = (double)i / flames;
         this.level()
            .addAlwaysVisibleParticle(
               ParticleTypes.FLAME,
               true,
               this.getX() - motion.x * back + this.random.nextGaussian() * 0.12,
               this.getY() + middle - motion.y * back + this.random.nextGaussian() * 0.12,
               this.getZ() - motion.z * back + this.random.nextGaussian() * 0.12,
               -motion.x * 0.04,
               -motion.y * 0.04,
               -motion.z * 0.04
            );
      }

      this.level()
         .addAlwaysVisibleParticle(
            ParticleTypes.SMALL_FLAME,
            true,
            this.getX(),
            this.getY() + middle,
            this.getZ(),
            this.random.nextGaussian() * 0.06,
            this.random.nextGaussian() * 0.06,
            this.random.nextGaussian() * 0.06
         );
      if (this.tickCount % 2 == 0) {
         this.level().addAlwaysVisibleParticle(ParticleTypes.LARGE_SMOKE, true, this.getX(), this.getY() + middle, this.getZ(), 0.0, 0.03, 0.0);
      }

      if (this.random.nextInt(5) == 0) {
         this.level().addAlwaysVisibleParticle(ParticleTypes.LAVA, true, this.getX(), this.getY() + middle, this.getZ(), 0.0, 0.0, 0.0);
      }
   }

   @Override
   protected boolean canHitEntity(Entity candidate) {
      if (!super.canHitEntity(candidate)) {
         return false;
      } else {
         Entity owner = this.getOwner();
         return owner == null
            || !candidate.isAlliedTo(owner)
               && !owner.isAlliedTo(candidate)
               && !(owner instanceof LivingEntity living && Summons.isSummonedBy(candidate, living));
      }
   }

   @Override
   protected void onHit(HitResult result) {
      if (result instanceof EntityHitResult hit) {
         this.struck = hit.getEntity();
      }

      super.onHit(result);
   }

   @Override
   public void detonate(Vec3 at) {
      Vec3 motion = this.getDeltaMovement();
      Vec3 center;
      if (this.struck != null) {
         center = this.middle();
      } else if (motion.lengthSqr() > 1.0E-6) {
         center = at.subtract(motion.normalize().scale(0.25));
      } else {
         center = at;
      }

      MeteorBlast.explode((ServerLevel)this.level(), this, this.getOwner(), center, this.struck, this.damage, this.blastRadius);
      this.discard();
   }

   @Override
   protected int lifetime() {
      return 200;
   }

   @Override
   protected void burnOut() {
      this.detonate(this.middle());
   }
}
