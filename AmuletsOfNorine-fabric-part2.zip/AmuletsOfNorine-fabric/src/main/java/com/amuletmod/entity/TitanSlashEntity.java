package com.amuletmod.entity;

import com.amuletmod.amulet.ability.titan.TitanBlades;
import com.amuletmod.amulet.ability.titan.TitanFists;
import com.amuletmod.client.TitanBladeClient;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.registry.ModSounds;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Easing;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import com.amuletmod.neo.IEntityWithComplexSpawn;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class TitanSlashEntity extends Entity implements IEntityWithComplexSpawn {
   public static final int SWING_TICKS = 3;
   private static final int STRIKE_TICK = 1;
   public static final int HANG_TICKS = 26;
   public static final int FADE_TICKS = 8;
   public static final float FLIGHT_SPEED = 2.2F;
   public static final int BURST_TICKS = 10;
   public static final int CRESCENT_SEGMENTS = 24;
   private static final float SHRINK_TICKS = 2.0F;
   public static final float SWEEP = (float)Math.toRadians(55.0);
   public static final float RADIUS = 3.0F;
   public static final float THROWN_SCALE = 0.8F;
   private static final float VOLLEY_SHARE = 0.75F;
   private static final EntityDataAccessor<Integer> DATA_LAUNCH = SynchedEntityData.defineId(TitanSlashEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Vector3f> DATA_HEADING = SynchedEntityData.defineId(TitanSlashEntity.class, EntityDataSerializers.VECTOR3);
   private static final EntityDataAccessor<Float> DATA_STOP = SynchedEntityData.defineId(TitanSlashEntity.class, EntityDataSerializers.FLOAT);
   private int cut;
   private Vec3 eye = Vec3.ZERO;
   private float yaw;
   private float pitch;
   private float distance = 3.5F;
   private ItemStack weapon = ItemStack.EMPTY;
   private int ownerId = -1;
   @Nullable
   private UUID ownerUuid;
   private float attack;
   private float multiplier = 1.0F;
   private double reach;
   private double range;
   private final Set<Integer> struck = new HashSet<>();
   private final Set<Integer> flown = new HashSet<>();

   public TitanSlashEntity(EntityType<? extends TitanSlashEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public TitanSlashEntity(
      ServerLevel level,
      ServerPlayer owner,
      int cut,
      Vec3 eye,
      float yaw,
      float pitch,
      double distance,
      ItemStack weapon,
      float attack,
      float multiplier,
      double reach,
      double range
   ) {
      this((EntityType<? extends TitanSlashEntity>)ModEntities.TITAN_SLASH.get(), level);
      this.cut = cut;
      this.eye = eye;
      this.yaw = yaw;
      this.pitch = pitch;
      this.distance = (float)distance;
      this.weapon = weapon.copyWithCount(1);
      this.ownerId = owner.getId();
      this.ownerUuid = owner.getUUID();
      this.attack = attack;
      this.multiplier = multiplier;
      this.reach = reach;
      this.range = range;
      Vec3 centre = this.centre();
      this.moveTo(centre.x, centre.y, centre.z, 0.0F, 0.0F);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_LAUNCH, -1);
      builder.define(DATA_HEADING, new Vector3f());
      builder.define(DATA_STOP, -1.0F);
   }

   public void launch(Vec3 heading, int inTicks) {
      this.entityData.set(DATA_HEADING, heading.normalize().toVector3f());
      this.entityData.set(DATA_LAUNCH, this.tickCount + inTicks);
   }

   public int cut() {
      return this.cut;
   }

   public ItemStack weapon() {
      return this.weapon;
   }

   public int ownerId() {
      return this.ownerId;
   }

   public Vec3 look() {
      return Vec3.directionFromRotation(this.pitch, this.yaw);
   }

   public Vec3 right() {
      return Vec3.directionFromRotation(0.0F, this.yaw + 90.0F);
   }

   public Vec3 up() {
      return this.right().cross(this.look()).normalize();
   }

   public float scale() {
      return this.distance / 3.5F;
   }

   public Vec3 centre() {
      return this.eye.add(this.look().scale(this.distance));
   }

   public Vec3 sweep() {
      Vec3 right = this.right();
      Vec3 up = this.up();

      return switch (this.cut) {
         case 0 -> right.scale(-1.0).subtract(up).normalize();
         case 1 -> right.subtract(up).normalize();
         default -> right.scale(-1.0);
      };
   }

   public Vec3 bow() {
      Vec3 right = this.right();
      Vec3 up = this.up();

      return switch (this.cut) {
         case 0 -> right.scale(-1.0).add(up).normalize();
         case 1 -> right.add(up).normalize();
         default -> up;
      };
   }

   public float radius() {
      return 3.0F * this.scale();
   }

   public Vec3 pivot() {
      return this.centre().subtract(this.bow().scale(this.radius()));
   }

   public Vec3 arc(float angle, float along) {
      return this.pivot().add(this.bow().scale(Mth.cos(angle) * along)).add(this.sweep().scale(Mth.sin(angle) * along));
   }

   public float swing(float age) {
      return -SWEEP + (2.0F * SWEEP + 0.25F) * Easing.outCubic(Mth.clamp(age / 3.0F, 0.0F, 1.0F));
   }

   public int launchAge() {
      return (Integer)this.entityData.get(DATA_LAUNCH);
   }

   public boolean thrown() {
      return this.launchAge() >= 0;
   }

   public Vec3 heading() {
      return new Vec3((Vector3f)this.entityData.get(DATA_HEADING));
   }

   public float stop() {
      return (Float)this.entityData.get(DATA_STOP);
   }

   public float travelled(float age) {
      if (!this.thrown()) {
         return 0.0F;
      } else {
         float gone = 2.2F * Math.max(0.0F, age - this.launchAge());
         float stop = this.stop();
         return stop >= 0.0F ? Math.min(gone, stop) : gone;
      }
   }

   public float thrownSize(float age) {
      return Mth.lerp(Easing.outCubic(Mth.clamp((age - this.launchAge()) / 2.0F, 0.0F, 1.0F)), 1.0F, 0.8F);
   }

   public Vec3 flying(float age) {
      return this.centre().add(this.heading().scale(this.travelled(age)));
   }

   public static Vec3 crescentPoint(Vec3 middle, Vec3 bow, Vec3 sweep, float radius, float angle, float in) {
      double out = radius - in;
      return middle.add(bow.scale(Mth.cos(angle) * out - radius)).add(sweep.scale(Mth.sin(angle) * out));
   }

   public float breaksAt(int segment, int segments) {
      int hash = this.getId() * 73856093 ^ segment * 19349663;
      hash ^= hash >>> 13;
      hash *= 1540483477;
      hash ^= hash >>> 15;
      float scatter = (hash & 65535) / 65536.0F;
      float middle = Mth.sin((segment + 0.5F) / segments * (float) Math.PI);
      return 0.7F * scatter + 0.3F * middle;
   }

   public float sinceStop(float age) {
      float stop = this.stop();
      return this.thrown() && !(stop < 0.0F) ? Math.max(0.0F, age - this.launchAge() - stop / 2.2F) : -1.0F;
   }

   public float lineLight(float age) {
      if (this.thrown()) {
         float since = this.sinceStop(age);
         return since < 0.0F ? 1.0F : 1.0F - Mth.clamp(since / 10.0F, 0.0F, 1.0F);
      } else {
         return 1.0F - Easing.smoothstep(29.0F, 37.0F, age);
      }
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         if (this.thrown() && this.tickCount > this.launchAge() && this.sinceStop(this.tickCount) < 0.0F) {
            this.setPos(this.centre().add(this.heading().scale(this.travelled(this.tickCount))));
         }

         ClientSide.run(() -> () -> TitanBladeClient.tickSlash(this));
      } else {
         ServerPlayer owner = this.owner();
         if (this.tickCount == 1 && owner != null) {
            this.cutThrough(owner);
         }

         if (this.thrown()) {
            if (this.tickCount == this.launchAge() && this.cut == 2) {
               Sounds.play(this.level(), this.centre(), (SoundEvent)ModSounds.TITAN_SLASH_VOLLEY.get(), 1.3F, 1.0F);
            }

            if (this.tickCount > this.launchAge() && this.stop() < 0.0F) {
               this.fly(owner);
            }

            float since = this.sinceStop(this.tickCount);
            if (since >= 10.0F) {
               this.discard();
            }
         } else if (this.tickCount >= 37) {
            this.discard();
         }
      }
   }

   @Nullable
   private ServerPlayer owner() {
      return this.ownerUuid != null && ((ServerLevel)this.level()).getEntity(this.ownerUuid) instanceof ServerPlayer player && player.isAlive() ? player : null;
   }

   private void cutThrough(ServerPlayer owner) {
      Vec3 look = this.look();
      ItemStack held = owner.getMainHandItem();
      boolean inHand = ItemStack.isSameItem(held, this.weapon);
      DamageSource source = ModDamage.source(this.level(), ModDamage.TITAN_BLADE, owner, owner);
      boolean hit = false;

      for (LivingEntity victim : TitanBlades.cutVictims(owner, this.eye, look, this.reach)) {
         if (this.struck.add(victim.getId())
            && TitanBlades.strike(owner, inHand ? held : this.weapon, this.attack, this.multiplier, victim, source, look, inHand)) {
            hit = true;
            Vec3 at = victim.getBoundingBox().getCenter();
            ((ServerLevel)this.level()).sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 10, 0.3, 0.3, 0.3, 0.4);
         }
      }

      if (hit) {
         Sounds.play(this.level(), this.centre(), SoundEvents.PLAYER_ATTACK_SWEEP, 0.9F, 1.1F);
      }
   }

   private void fly(@Nullable ServerPlayer owner) {
      Vec3 heading = this.heading();
      Vec3 centre = this.centre();
      float before = 2.2F * (this.tickCount - 1 - this.launchAge());
      float after = 2.2F * (this.tickCount - this.launchAge());
      Vec3 from = centre.add(heading.scale(before));
      Vec3 to = centre.add(heading.scale(after));
      BlockHitResult wall = this.level().clip(new ClipContext(from, to, Block.COLLIDER, Fluid.NONE, this));
      if (wall.getType() != Type.MISS) {
         to = wall.getLocation();
         this.entityData.set(DATA_STOP, before + (float)from.distanceTo(to));
         Sounds.play(this.level(), to, SoundEvents.PLAYER_ATTACK_SWEEP, 0.8F, 0.6F);
      } else if (after >= this.range) {
         this.entityData.set(DATA_STOP, (float)this.range);
      }

      if (owner != null) {
         this.sweepThrough(owner, from, to);
      }

      this.setPos(to);
   }

   private void sweepThrough(ServerPlayer owner, Vec3 from, Vec3 to) {
      Vec3 heading = this.heading();
      Vec3 sweep = this.sweep();
      Vec3 bow = this.bow();
      double halfWidth = this.radius() * Mth.sin(SWEEP) * 0.8F;
      double halfDepth = 0.9 * this.scale();
      double bowsBack = 0.55 * this.scale();
      DamageSource source = ModDamage.source(this.level(), ModDamage.TITAN_BLADE, this, owner);
      Vec3 segment = to.subtract(from);
      double length = segment.lengthSqr();

      for (LivingEntity victim : this.level()
         .getEntitiesOfClass(
            LivingEntity.class,
            new AABB(from, to).inflate(halfWidth + 1.0),
            victimx -> TitanFists.canStrike(owner, victimx) && !this.flown.contains(victimx.getId())
         )) {
         Vec3 at = victim.getBoundingBox().getCenter();
         double t = length < 1.0E-6 ? 0.0 : Mth.clamp(at.subtract(from).dot(segment) / length, 0.0, 1.0);
         Vec3 off = at.subtract(from.add(segment.scale(t))).add(bow.scale(bowsBack));
         if (!(Math.abs(off.dot(sweep)) > halfWidth + victim.getBbWidth() * 0.5) && !(Math.abs(off.dot(bow)) > halfDepth + victim.getBbHeight() * 0.5)) {
            this.flown.add(victim.getId());
            if (TitanBlades.strike(owner, this.weapon, this.attack, this.multiplier * 0.75F, victim, source, heading, false)) {
               ((ServerLevel)this.level()).sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 8, 0.3, 0.3, 0.3, 0.3);
            }
         }
      }
   }

   public AABB getBoundingBoxForCulling() {
      return new AABB(this.centre(), this.position()).inflate(this.radius() + 1.5);
   }

   public boolean shouldRenderAtSqrDistance(double distance) {
      double range = 96.0 * getViewScale();
      return distance < range * range;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
   }

   public void writeSpawnData(RegistryFriendlyByteBuf buffer) {
      buffer.writeByte(this.cut);
      buffer.writeDouble(this.eye.x);
      buffer.writeDouble(this.eye.y);
      buffer.writeDouble(this.eye.z);
      buffer.writeFloat(this.yaw);
      buffer.writeFloat(this.pitch);
      buffer.writeFloat(this.distance);
      ItemStack.OPTIONAL_STREAM_CODEC.encode(buffer, this.weapon);
      buffer.writeVarInt(this.ownerId);
   }

   public void readSpawnData(RegistryFriendlyByteBuf buffer) {
      this.cut = buffer.readByte();
      this.eye = new Vec3(buffer.readDouble(), buffer.readDouble(), buffer.readDouble());
      this.yaw = buffer.readFloat();
      this.pitch = buffer.readFloat();
      this.distance = buffer.readFloat();
      this.weapon = (ItemStack)ItemStack.OPTIONAL_STREAM_CODEC.decode(buffer);
      this.ownerId = buffer.readVarInt();
   }
}
