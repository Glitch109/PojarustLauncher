package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.AmuletMod;
import com.amuletmod.client.CameraShake;
import com.amuletmod.client.RootedClient;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Sounds;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.event.EntityJoinLevelEvent;
import org.jetbrains.annotations.Nullable;

public class ChainBindEntity extends Entity {
   public static final int CIRCLES = 5;
   public static final int APPEAR_TICKS = 10;
   public static final int APPEAR_STAGGER = 2;
   public static final int FIRE_TICK = 32;
   public static final int FIRE_STAGGER = 1;
   public static final int FLIGHT_TICKS = 5;
   public static final int WRAP_TICKS = 8;
   public static final int RELEASE_TICKS = 14;
   public static final int SEIZE_TICK = 37;
   private static final float[] HEIGHTS = new float[]{0.12F, 0.95F, 0.5F, 1.15F, 0.3F};
   private static final Identifier BOUND_MODIFIER = AmuletMod.id("chain_bound");
   private static final EntityDataAccessor<Integer> DATA_VICTIM = SynchedEntityData.defineId(ChainBindEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_DURATION = SynchedEntityData.defineId(ChainBindEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Float> DATA_VICTIM_WIDTH = SynchedEntityData.defineId(ChainBindEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Float> DATA_VICTIM_HEIGHT = SynchedEntityData.defineId(ChainBindEntity.class, EntityDataSerializers.FLOAT);
   private static final String SUSPENDED_TAG = "amuletmod.chain_suspended";
   @Nullable
   private LivingEntity victim;

   public ChainBindEntity(EntityType<? extends ChainBindEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public ChainBindEntity(ServerLevel level, LivingEntity victim, int holdTicks) {
      this((EntityType<? extends ChainBindEntity>)ModEntities.CHAIN_BIND.get(), level);
      this.victim = victim;
      this.moveTo(victim.getX(), victim.getY(), victim.getZ(), 0.0F, 0.0F);
      this.entityData.set(DATA_VICTIM, victim.getId());
      this.entityData.set(DATA_DURATION, 37 + holdTicks + 14);
      this.entityData.set(DATA_VICTIM_WIDTH, victim.getBbWidth());
      this.entityData.set(DATA_VICTIM_HEIGHT, victim.getBbHeight());
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_VICTIM, -1);
      builder.define(DATA_DURATION, 1200);
      builder.define(DATA_VICTIM_WIDTH, 0.6F);
      builder.define(DATA_VICTIM_HEIGHT, 1.8F);
   }

   public int victimId() {
      return (Integer)this.entityData.get(DATA_VICTIM);
   }

   public int duration() {
      return (Integer)this.entityData.get(DATA_DURATION);
   }

   public int releaseAt() {
      return this.duration() - 14;
   }

   public float victimWidth() {
      return (Float)this.entityData.get(DATA_VICTIM_WIDTH);
   }

   public float victimHeight() {
      return (Float)this.entityData.get(DATA_VICTIM_HEIGHT);
   }

   public static boolean isBinding(Level level, LivingEntity entity) {
      return !level.getEntitiesOfClass(
            ChainBindEntity.class, entity.getBoundingBox().inflate(4.0), bind -> bind.victimId() == entity.getId() && bind.tickCount < bind.releaseAt()
         )
         .isEmpty();
   }

   public static float ringRadius(float width) {
      return Math.max(1.7F, width * 0.5F + 1.5F);
   }

   public static float circleSize(float width, float height) {
      return Mth.clamp(0.45F + Math.max(width, height * 0.5F) * 0.25F, 0.5F, 1.4F);
   }

   public static Vec3 circleCenter(int k, float width, float height, int seed) {
      float angle = k * (float) (Math.PI * 2) / 5.0F + Math.floorMod(seed, 628) * 0.01F;
      float radius = ringRadius(width);
      float y = Math.max(0.3F, height * HEIGHTS[k] + 0.2F);
      return new Vec3(Mth.cos(angle) * radius, y, Mth.sin(angle) * radius);
   }

   public static Vec3 grip(int k, float width, float height, int seed) {
      Vec3 center = circleCenter(k, width, height, seed);
      double horizontal = Math.max(1.0E-4, Math.sqrt(center.x * center.x + center.z * center.z));
      double surface = width * 0.5 + 0.05;
      float y = Mth.clamp((float)center.y, height * 0.15F, height * 0.85F);
      return new Vec3(center.x / horizontal * surface, y, center.z / horizontal * surface);
   }

   public static Vec3 coil(int k, float t, float width, float height, int seed) {
      Vec3 grip = grip(k, width, height, seed);
      double start = Math.atan2(grip.z, grip.x);
      double angle = start + (k % 2 == 0 ? 1.0 : -1.0) * t * 1.25 * (float) (Math.PI * 2);
      double radius = width * 0.5 + 0.06;
      double y = grip.y + (height * 0.5 - grip.y) * 0.6 * t;
      return new Vec3(Math.cos(angle) * radius, y, Math.sin(angle) * radius);
   }

   public static int firesAt(int k) {
      return 32 + k * 1;
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         ServerLevel level = (ServerLevel)this.level();
         if (this.victim != null && (!this.victim.isAlive() || this.victim.isRemoved() || this.victim.level() != level)) {
            this.letGo();
            if (this.tickCount < this.releaseAt()) {
               this.entityData.set(DATA_DURATION, this.tickCount + 14);
            }
         }

         if (this.victim != null) {
            if (this.tickCount < 37) {
               this.setPos(this.victim.position());
            } else if (this.tickCount == 37) {
               this.seize(this.victim);
            }

            if (this.tickCount >= 37) {
               if (this.tickCount < this.releaseAt()) {
                  this.pin(this.victim);
               } else {
                  this.letGo();
               }
            }
         }

         this.sounds(level);
         if (this.tickCount >= this.duration()) {
            this.discard();
         }
      }
   }

   private void sounds(ServerLevel level) {
      Vec3 feet = this.position();
      float width = this.victimWidth();
      float height = this.victimHeight();
      if (this.tickCount == 1) {
         Sounds.play(level, feet, SoundEvents.ENCHANTMENT_TABLE_USE, 1.2F, 0.6F);
         Sounds.play(level, feet, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0F, 0.5F);
      }

      for (int k = 0; k < 5; k++) {
         Vec3 circle = feet.add(circleCenter(k, width, height, this.getId()));
         if (this.tickCount == 1 + k * 2) {
            Sounds.play(level, circle, SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 0.7F + k * 0.12F);
         }

         if (this.tickCount == firesAt(k) && this.tickCount < this.releaseAt()) {
            Sounds.play(level, circle, SoundEvents.CHAIN_PLACE, 1.2F, 0.6F + k * 0.05F);
            Sounds.play(level, circle, (SoundEvent)SoundEvents.TRIDENT_THROW.value(), 0.5F, 0.6F);
         }

         if (this.tickCount == firesAt(k) + 5 && this.tickCount < this.releaseAt()) {
            Sounds.play(level, feet.add(grip(k, width, height, this.getId())), SoundEvents.CHAIN_HIT, 1.2F, 0.7F);
         }
      }

      if (this.tickCount == 24) {
         Sounds.play(level, feet, SoundEvents.BEACON_POWER_SELECT, 0.8F, 1.6F);
      }

      if (this.tickCount == 37 && this.tickCount < this.releaseAt()) {
         Sounds.play(level, feet, SoundEvents.ANVIL_PLACE, 0.35F, 1.5F);
      }

      if (this.tickCount == firesAt(4) + 5 + 8 && this.tickCount < this.releaseAt()) {
         Sounds.play(level, feet, SoundEvents.IRON_DOOR_CLOSE, 0.8F, 0.6F);
         Sounds.play(level, feet, SoundEvents.CHAIN_PLACE, 1.0F, 0.5F);
      } else if (this.tickCount > 77 && this.tickCount < this.releaseAt() && this.tickCount % 50 == 0) {
         Sounds.play(level, feet, SoundEvents.CHAIN_STEP, 0.6F, 0.6F + this.random.nextFloat() * 0.2F);
      }

      if (this.tickCount == this.releaseAt()) {
         Sounds.play(level, feet, SoundEvents.CHAIN_BREAK, 1.3F, 0.7F);
         Sounds.play(level, feet, SoundEvents.AMETHYST_CLUSTER_BREAK, 1.0F, 0.8F);
         Sounds.play(level, feet, SoundEvents.GLASS_BREAK, 0.5F, 1.5F);
      }
   }

   private void seize(LivingEntity held) {
      held.stopRiding();
      this.setPos(held.position());
      if (!held.isNoGravity()) {
         held.addTag("amuletmod.chain_suspended");
         held.setNoGravity(true);
      }

      held.setDeltaMovement(Vec3.ZERO);
      AttributeInstance speed = held.getAttribute(Attributes.MOVEMENT_SPEED);
      if (speed != null && speed.getModifier(BOUND_MODIFIER) == null) {
         speed.addTransientModifier(new AttributeModifier(BOUND_MODIFIER, -1.0, Operation.ADD_MULTIPLIED_TOTAL));
      }

      if (held instanceof ServerPlayer player) {
         player.stopFallFlying();
      }
   }

   private void pin(LivingEntity held) {
      Vec3 anchor = this.position();
      held.fallDistance = 0.0F;
      if (held instanceof ServerPlayer player) {
         if (held.position().distanceToSqr(anchor) > 0.36) {
            player.connection.teleport(anchor.x, anchor.y, anchor.z, player.getYRot(), player.getXRot());
         }
      } else {
         if (held.position().distanceToSqr(anchor) > 0.0025) {
            held.teleportTo(anchor.x, anchor.y, anchor.z);
         }

         held.setDeltaMovement(Vec3.ZERO);
         if (held instanceof Mob mob) {
            mob.getNavigation().stop();
            mob.setJumping(false);
         }
      }
   }

   private void letGo() {
      LivingEntity held = this.victim;
      if (held != null) {
         this.victim = null;
         release(held);
      }
   }

   private static void release(Entity held) {
      if (held.removeTag("amuletmod.chain_suspended")) {
         held.setNoGravity(false);
      }

      if (held instanceof LivingEntity living) {
         AttributeInstance speed = living.getAttribute(Attributes.MOVEMENT_SPEED);
         if (speed != null) {
            speed.removeModifier(BOUND_MODIFIER);
         }
      }
   }

   public void onRemovedFromLevel() {
      super.onRemovedFromLevel();
      if (!this.level().isClientSide()) {
         this.letGo();
      }
   }

   private void clientTick() {
      Entity held = this.level().getEntity(this.victimId());
      float width = this.victimWidth();
      float height = this.victimHeight();
      if (this.tickCount < 37 && held != null) {
         this.setPos(held.position());
      }

      Vec3 feet = this.position();

      for (int k = 0; k < 5; k++) {
         Vec3 circle = feet.add(circleCenter(k, width, height, this.getId()));
         Vec3 middle = feet.add(0.0, height * 0.5, 0.0);
         if (this.tickCount > k * 2 && this.tickCount < firesAt(k) && this.random.nextInt(3) == 0) {
            Vec3 from = circle.add(this.random.nextGaussian() * 0.6, this.random.nextGaussian() * 0.6, this.random.nextGaussian() * 0.6);
            Vec3 pull = circle.subtract(from);
            this.level().addParticle(ParticleTypes.ENCHANT, from.x, from.y, from.z, pull.x, pull.y, pull.z);
         }

         if (this.tickCount == firesAt(k) + 5 && this.tickCount < this.releaseAt()) {
            Vec3 grip = feet.add(grip(k, width, height, this.getId()));

            for (int i = 0; i < 8; i++) {
               this.level()
                  .addParticle(
                     ParticleTypes.ELECTRIC_SPARK,
                     grip.x,
                     grip.y,
                     grip.z,
                     this.random.nextGaussian() * 0.2,
                     this.random.nextGaussian() * 0.2,
                     this.random.nextGaussian() * 0.2
                  );
            }

            this.level().addParticle(ParticleTypes.FLASH, middle.x, middle.y, middle.z, 0.0, 0.0, 0.0);
         }

         if (this.tickCount == this.releaseAt() + 1) {
            BlockParticleOption links = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.CHAIN.defaultBlockState());

            for (int i = 0; i < 10; i++) {
               Vec3 at = circle.lerp(feet.add(grip(k, width, height, this.getId())), this.random.nextDouble());
               this.level()
                  .addParticle(links, at.x, at.y, at.z, this.random.nextGaussian() * 0.15, this.random.nextDouble() * 0.2, this.random.nextGaussian() * 0.15);
               this.level()
                  .addParticle(
                     ParticleTypes.END_ROD,
                     at.x,
                     at.y,
                     at.z,
                     this.random.nextGaussian() * 0.05,
                     this.random.nextGaussian() * 0.05,
                     this.random.nextGaussian() * 0.05
                  );
            }
         }
      }

      if (this.tickCount == 37) {
         ClientSide.run(() -> () -> CameraShake.from(feet, 0.8F, 14.0, 8));
      }

      int victimId = this.victimId();
      if (this.tickCount >= 37 && this.tickCount < this.releaseAt()) {
         ClientSide.run(() -> () -> RootedClient.hold(victimId));
      }
   }

   public AABB getBoundingBoxForCulling() {
      double reach = ringRadius(this.victimWidth()) + circleSize(this.victimWidth(), this.victimHeight()) + 1.0;
      return new AABB(
         this.getX() - reach, this.getY() - 1.0, this.getZ() - reach, this.getX() + reach, this.getY() + this.victimHeight() * 1.3 + 2.0, this.getZ() + reach
      );
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(ValueInput input) {
   }

   protected void addAdditionalSaveData(ValueOutput output) {
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }

   @EventBusSubscriber(
      modid = "amuletmod"
   )
   public static final class ChainBindEvents {
      private ChainBindEvents() {
      }

      @SubscribeEvent
      public static void onEntityJoin(EntityJoinLevelEvent event) {
         if (!event.getLevel().isClientSide() && event.getEntity().getTags().contains("amuletmod.chain_suspended")) {
            ChainBindEntity.release(event.getEntity());
         }
      }
   }
}
