package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.client.CameraShake;
import com.amuletmod.client.TempestClient;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Easing;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class PageStormEntity extends Entity {
   public static final int CHARGE_TICKS = 240;
   public static final int PAGES_PER_BOOK = 5;
   public static final int RELEASE_RATE = 4;
   public static final int SETTLE_TICKS = 12;
   public static final int SCATTER_TICKS = 30;
   private static final int FIRST_LAUNCH = 10;
   private static final int LAST_LAUNCH = 150;
   private static final int LAUNCH_SPACING = 7;
   private static final float SPIN_START = 0.02617994F;
   private static final float SPIN_END = (float) (Math.PI / 6);
   private static final double PAGE_SPEED = 2.4;
   private static final int MIN_FLIGHT = 5;
   private static final int MAX_FLIGHT = 26;
   private static final EntityDataAccessor<Integer> DATA_CASTER = SynchedEntityData.defineId(PageStormEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_SEED = SynchedEntityData.defineId(PageStormEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<CompoundTag> DATA_BOOKS = SynchedEntityData.defineId(PageStormEntity.class, EntityDataSerializers.COMPOUND_TAG);
   private static final EntityDataAccessor<CompoundTag> DATA_PLAN = SynchedEntityData.defineId(PageStormEntity.class, EntityDataSerializers.COMPOUND_TAG);
   private static final EntityDataAccessor<Integer> DATA_COLLAPSED = SynchedEntityData.defineId(PageStormEntity.class, EntityDataSerializers.INT);
   private PageStormEntity.Book[] books = new PageStormEntity.Book[0];
   private PageStormEntity.Orbit[] orbits = new PageStormEntity.Orbit[0];
   private int[] launches = new int[0];
   private int[] targetIds = new int[0];
   private byte[] assigned = new byte[0];
   private byte[] flights = new byte[0];
   @Nullable
   private ServerPlayer caster;
   private float damage;
   private double range;
   private final List<LivingEntity> targets = new ArrayList<>();
   private int endTick = Integer.MAX_VALUE;

   public PageStormEntity(EntityType<? extends PageStormEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
      this.noCulling = true;
   }

   public PageStormEntity(ServerLevel level, ServerPlayer caster, List<BlockPos> shelves, double range, float damage) {
      this((EntityType<? extends PageStormEntity>)ModEntities.PAGE_STORM.get(), level);
      this.caster = caster;
      this.range = range;
      this.damage = damage;
      this.moveTo(caster.getX(), caster.getY(), caster.getZ(), 0.0F, 0.0F);
      this.entityData.set(DATA_CASTER, caster.getId());
      this.entityData.set(DATA_SEED, caster.getRandom().nextInt());
      Vec3 chest = caster.position().add(0.0, 1.2, 0.0);
      int spacing = Math.min(7, 140 / Math.max(1, shelves.size() - 1));
      ListTag list = new ListTag();

      for (int b = 0; b < shelves.size(); b++) {
         BlockPos shelf = shelves.get(b);
         CompoundTag book = new CompoundTag();
         Vec3 source = chest;
         int flight = 10;
         if (shelf != null) {
            Vec3 middle = Vec3.atCenterOf(shelf);
            source = middle.add(chest.subtract(middle).normalize().scale(0.6));
            flight = Mth.clamp((int)Math.round(source.distanceTo(chest) / 0.55), 14, 44);
         }

         book.putBoolean("Shelf", shelf != null);
         book.putDouble("X", source.x);
         book.putDouble("Y", source.y);
         book.putDouble("Z", source.z);
         book.putInt("Launch", 10 + b * spacing);
         book.putInt("Flight", flight);
         list.add(book);
      }

      CompoundTag tag = new CompoundTag();
      tag.put("Books", list);
      this.entityData.set(DATA_BOOKS, tag);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_CASTER, -1);
      builder.define(DATA_SEED, 0);
      builder.define(DATA_BOOKS, new CompoundTag());
      builder.define(DATA_PLAN, new CompoundTag());
      builder.define(DATA_COLLAPSED, -1);
   }

   public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
      super.onSyncedDataUpdated(key);
      if (DATA_BOOKS.equals(key) || DATA_SEED.equals(key)) {
         this.rebuild();
      } else if (DATA_PLAN.equals(key)) {
         this.readPlan();
      }
   }

   private void rebuild() {
      ListTag list = ((CompoundTag)this.entityData.get(DATA_BOOKS)).getList("Books", 10);
      this.books = new PageStormEntity.Book[list.size()];

      for (int b = 0; b < this.books.length; b++) {
         CompoundTag book = list.getCompound(b);
         this.books[b] = new PageStormEntity.Book(
            book.getBoolean("Shelf"), new Vec3(book.getDouble("X"), book.getDouble("Y"), book.getDouble("Z")), book.getInt("Launch"), book.getInt("Flight")
         );
      }

      RandomSource random = RandomSource.create(((Integer)this.entityData.get(DATA_SEED)).intValue());
      this.orbits = new PageStormEntity.Orbit[this.books.length * 5];

      for (int i = 0; i < this.orbits.length; i++) {
         float radius = 2.6F + 3.6F * Mth.sqrt(random.nextFloat());
         float speed = (0.85F + 0.3F * random.nextFloat()) * Mth.sqrt(4.0F / radius);
         this.orbits[i] = new PageStormEntity.Orbit(
            radius, 0.3F + 3.9F * random.nextFloat(), random.nextFloat() * (float) (Math.PI * 2), speed, random.nextFloat() * (float) (Math.PI * 2)
         );
      }

      Integer[] order = new Integer[this.orbits.length];

      for (int i = 0; i < order.length; i++) {
         order[i] = i;
      }

      float spin = spin(240.0F);
      Arrays.sort(order, Comparator.comparingDouble(i -> Mth.positiveModulo(this.orbits[i].phase() + this.orbits[i].speed() * spin, (float) (Math.PI * 2))));
      this.launches = new int[this.orbits.length];

      for (int rank = 0; rank < order.length; rank++) {
         this.launches[order[rank]] = 240 + rank / 4;
      }
   }

   private void readPlan() {
      CompoundTag plan = (CompoundTag)this.entityData.get(DATA_PLAN);
      this.targetIds = (int[])plan.getIntArray("Targets").clone();
      this.assigned = (byte[])plan.getByteArray("Assigned").clone();
      this.flights = (byte[])plan.getByteArray("Flights").clone();
   }

   private void writePlan() {
      CompoundTag plan = new CompoundTag();
      plan.putIntArray("Targets", (int[])this.targetIds.clone());
      plan.putByteArray("Assigned", (byte[])this.assigned.clone());
      plan.putByteArray("Flights", (byte[])this.flights.clone());
      this.entityData.set(DATA_PLAN, plan);
   }

   public int casterId() {
      return (Integer)this.entityData.get(DATA_CASTER);
   }

   public Vec3 center(float partialTick) {
      Entity who = this.level().getEntity(this.casterId());
      return who != null ? who.getPosition(partialTick) : this.getPosition(partialTick);
   }

   public int collapsedAt() {
      return (Integer)this.entityData.get(DATA_COLLAPSED);
   }

   public PageStormEntity.Book[] books() {
      return this.books;
   }

   public int pages() {
      return this.orbits.length;
   }

   public boolean hasPlan() {
      return this.assigned.length == this.orbits.length && this.assigned.length > 0;
   }

   public static float charge(float age) {
      return Mth.clamp(age / 240.0F, 0.0F, 1.0F);
   }

   public static float spin(float age) {
      if (age <= 240.0F) {
         float x = Math.max(0.0F, age) / 240.0F;
         return 0.02617994F * Math.max(0.0F, age) + 119.38052F * x * x * x / 3.0F;
      } else {
         return spin(240.0F) + (float) (Math.PI / 6) * (age - 240.0F);
      }
   }

   public int bornAt(int i) {
      return this.books[i / 5].arrival();
   }

   public int launchAt(int i) {
      return this.launches[i];
   }

   private Vec3 orbit(int i, float age) {
      PageStormEntity.Orbit orbit = this.orbits[i];
      float angle = orbit.phase() + orbit.speed() * spin(age);
      float charge = charge(age);
      float radius = orbit.radius() * (1.0F - 0.15F * charge * charge);
      return new Vec3(Mth.cos(angle) * radius, orbit.height() + 0.35F * Mth.sin(age * 0.06F + orbit.bob()), Mth.sin(angle) * radius);
   }

   public Vec3 burstPoint(int b) {
      return this.orbit(b * 5, this.books[b].arrival());
   }

   public Vec3 whirling(int i, float age) {
      int b = i / 5;
      float settle = Easing.outCubic(Mth.clamp((age - this.books[b].arrival()) / 12.0F, 0.0F, 1.0F));
      return this.burstPoint(b).lerp(this.orbit(i, age), settle);
   }

   @Nullable
   public Vec3 pagePosition(int i, float age, Vec3 center, float partialTick) {
      if (i < this.orbits.length && !(age < this.bornAt(i))) {
         int collapsed = this.collapsedAt();
         if (collapsed >= 0 && this.bornAt(i) > collapsed) {
            return null;
         } else if (collapsed >= 0 && age >= collapsed) {
            return scatter(center.add(this.whirling(i, collapsed)), center, (age - collapsed) / 30.0F);
         } else {
            int launch = this.launches[i];
            if (!(age < launch) && this.hasPlan()) {
               Vec3 from = center.add(this.whirling(i, launch));
               int k = this.assigned[i];
               if (k < 0) {
                  return scatter(from, center, (age - launch) / 30.0F);
               } else {
                  float s = (age - launch) / Math.max(1, this.flights[i]);
                  if (s >= 1.0F) {
                     return null;
                  } else {
                     Entity target = k < this.targetIds.length ? this.level().getEntity(this.targetIds[k]) : null;
                     if (target == null) {
                        return scatter(from, center, s);
                     } else {
                        Vec3 to = target.getPosition(partialTick).add(0.0, target.getBbHeight() * 0.55, 0.0);
                        Vec3 out = from.subtract(center).multiply(1.0, 0.0, 1.0);
                        out = out.lengthSqr() < 1.0E-4 ? Vec3.ZERO : out.normalize();
                        Vec3 bend = from.add(out.scale(2.5)).add(0.0, 2.0, 0.0);
                        float u = (float)Math.pow(s, 1.4);
                        return from.scale((1.0F - u) * (1.0F - u)).add(bend.scale(2.0F * (1.0F - u) * u)).add(to.scale(u * u));
                     }
                  }
               }
            } else {
               return center.add(this.whirling(i, age));
            }
         }
      } else {
         return null;
      }
   }

   @Nullable
   private static Vec3 scatter(Vec3 from, Vec3 center, float s) {
      if (s >= 1.0F) {
         return null;
      } else {
         Vec3 out = from.subtract(center).multiply(1.0, 0.0, 1.0);
         out = out.lengthSqr() < 1.0E-4 ? new Vec3(1.0, 0.0, 0.0) : out.normalize();
         return from.add(out.scale(9.0 * s)).add(0.0, 2.5 * s - 3.5 * s * s, 0.0);
      }
   }

   public float pageScale(int i, float age) {
      float born = Math.max(0.0F, Easing.outBack(Mth.clamp((age - this.bornAt(i)) / 4.0F, 0.0F, 1.0F)));
      int collapsed = this.collapsedAt();
      float scattered = -1.0F;
      if (collapsed >= 0 && age >= collapsed) {
         scattered = (age - collapsed) / 30.0F;
      } else if (this.hasPlan() && age >= this.launches[i] && this.assigned[i] < 0) {
         scattered = (age - this.launches[i]) / 30.0F;
      }

      return scattered < 0.0F ? born : born * (1.0F - Easing.smoothstep(0.6F, 1.0F, scattered));
   }

   @Nullable
   public Vec3 bookPosition(int b, float age, Vec3 center) {
      PageStormEntity.Book book = this.books[b];
      int collapsed = this.collapsedAt();
      if (!(age < book.launch()) && !(age >= book.arrival()) && (collapsed < 0 || !(age >= collapsed))) {
         float s = Easing.smoothstep(0.0F, 1.0F, (age - book.launch()) / book.flight());
         Vec3 from = book.fromShelf() ? book.source() : center.add(0.0, 1.2, 0.0);
         Vec3 to = center.add(this.burstPoint(b));
         Vec3 bend = from.lerp(to, 0.5).add(0.0, 1.5 + 0.12 * from.distanceTo(to), 0.0);
         return from.scale((1.0F - s) * (1.0F - s)).add(bend.scale(2.0F * (1.0F - s) * s)).add(to.scale(s * s));
      } else {
         return null;
      }
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         ServerLevel level = (ServerLevel)this.level();
         boolean casterHere = this.caster != null && this.caster.isAlive() && !this.caster.isRemoved() && this.caster.level() == level;
         if (casterHere) {
            this.setPos(this.caster.position());
         }

         int collapsed = this.collapsedAt();
         if (collapsed < 0 && this.tickCount <= 240 && !casterHere) {
            this.entityData.set(DATA_COLLAPSED, this.tickCount);
            this.endTick = this.tickCount + 30;
            Sounds.play(level, this.position().add(0.0, 2.0, 0.0), SoundEvents.BOOK_PAGE_TURN, 1.5F, 0.5F);
         }

         if (collapsed < 0 && casterHere) {
            this.chargeSounds(level);
         }

         if (this.tickCount == 240 && this.collapsedAt() < 0) {
            this.release(level);
         }

         if (this.tickCount > 240 && this.hasPlan()) {
            this.landHits(level);
         }

         if (this.tickCount >= this.endTick) {
            this.discard();
         }
      }
   }

   private void chargeSounds(ServerLevel level) {
      Vec3 heart = this.position().add(0.0, 1.5, 0.0);
      if (this.tickCount == 1) {
         Sounds.play(level, heart, SoundEvents.ENCHANTMENT_TABLE_USE, 1.4F, 0.5F);
         Sounds.play(level, heart, SoundEvents.BEACON_ACTIVATE, 1.0F, 0.8F);
         Sounds.play(level, heart, SoundEvents.EVOKER_PREPARE_SUMMON, 0.8F, 1.3F);
      }

      for (int b = 0; b < this.books.length; b++) {
         PageStormEntity.Book book = this.books[b];
         if (this.tickCount == book.launch()) {
            Vec3 from = book.fromShelf() ? book.source() : heart;
            Sounds.play(level, from, SoundEvents.CHISELED_BOOKSHELF_PICKUP, 1.0F, 0.85F + this.random.nextFloat() * 0.3F);
            Sounds.play(level, from, SoundEvents.BOOK_PAGE_TURN, 0.7F, 1.1F + this.random.nextFloat() * 0.2F);
         }

         if (this.tickCount == book.arrival()) {
            Vec3 burst = this.position().add(this.burstPoint(b));
            Sounds.play(level, burst, SoundEvents.BOOK_PAGE_TURN, 1.1F, 1.4F + this.random.nextFloat() * 0.3F);
            Sounds.play(level, burst, SoundEvents.CHISELED_BOOKSHELF_PICKUP_ENCHANTED, 0.8F, 1.2F + this.random.nextFloat() * 0.3F);
            Sounds.play(level, burst, SoundEvents.AMETHYST_BLOCK_CHIME, 0.6F, 1.3F + this.random.nextFloat() * 0.4F);
         }
      }

      if (this.tickCount == 195) {
         Sounds.play(level, heart, SoundEvents.WARDEN_SONIC_CHARGE, 1.2F, 1.2F);
      }

      if (this.tickCount == 228) {
         Sounds.play(level, heart, SoundEvents.BEACON_POWER_SELECT, 1.2F, 0.6F);
         Sounds.play(level, heart, SoundEvents.RESPAWN_ANCHOR_CHARGE, 1.0F, 1.4F);
      }
   }

   private void release(ServerLevel level) {
      Vec3 heart = this.position().add(0.0, 1.5, 0.0);
      Sounds.play(level, heart, (SoundEvent)SoundEvents.TRIDENT_RIPTIDE_3.value(), 1.6F, 0.8F);
      Sounds.play(level, heart, SoundEvents.ILLUSIONER_CAST_SPELL, 1.4F, 0.6F);
      Sounds.play(level, heart, SoundEvents.PLAYER_ATTACK_SWEEP, 1.4F, 0.6F);
      Sounds.play(level, heart, SoundEvents.ENCHANTMENT_TABLE_USE, 1.4F, 1.6F);
      this.targets.clear();
      if (this.caster != null) {
         double rangeSqr = this.range * this.range;
         this.targets
            .addAll(
               level.getEntitiesOfClass(
                  LivingEntity.class,
                  this.caster.getBoundingBox().inflate(this.range),
                  living -> living.distanceToSqr(this.caster) <= rangeSqr && isFoe(this.caster, living) && this.caster.hasLineOfSight(living)
               )
            );
         this.targets.sort(Comparator.comparingDouble(living -> living.distanceToSqr(this.caster)));
         if (this.targets.size() > this.orbits.length) {
            this.targets.subList(this.orbits.length, this.targets.size()).clear();
         }
      }

      this.targetIds = this.targets.stream().mapToInt(Entity::getId).toArray();
      this.assigned = new byte[this.orbits.length];
      this.flights = new byte[this.orbits.length];
      Arrays.fill(this.assigned, (byte)-1);
      Arrays.fill(this.flights, (byte)30);
      if (!this.targets.isEmpty()) {
         this.share();
      }

      this.writePlan();
      this.updateEnd();
      if (this.caster != null) {
         this.caster
            .displayClientMessage(
               (this.targets.isEmpty()
                     ? Component.translatable("message.amuletmod.tome_tempest_scatter", new Object[]{(int)this.range})
                     : Component.translatable("message.amuletmod.tome_tempest_release", new Object[]{this.orbits.length, this.targets.size()}))
                  .withStyle(ChatFormatting.LIGHT_PURPLE),
               true
            );
      }
   }

   private void share() {
      int pages = this.orbits.length;
      int count = this.targets.size();
      float total = 0.0F;

      for (LivingEntity target : this.targets) {
         total += Math.max(1.0F, target.getMaxHealth());
      }

      int[] shares = new int[count];
      int given = 0;

      for (int k = 0; k < count; k++) {
         shares[k] = Math.max(1, (int)(pages * Math.max(1.0F, this.targets.get(k).getMaxHealth()) / total));
         given += shares[k];
      }

      Integer[] toughest = new Integer[count];

      for (int k = 0; k < count; k++) {
         toughest[k] = k;
      }

      Arrays.sort(toughest, Comparator.comparingDouble(k -> -this.targets.get(k).getMaxHealth()));

      for (int j = 0; given != pages; j++) {
         int k = toughest[j % count];
         if (given < pages) {
            shares[k]++;
            given++;
         } else if (shares[k] > 1) {
            shares[k]--;
            given--;
         }
      }

      List<float[]> slots = new ArrayList<>();

      for (int k = 0; k < count; k++) {
         for (int jx = 0; jx < shares[k]; jx++) {
            slots.add(new float[]{(jx + 0.5F) / shares[k], k});
         }
      }

      slots.sort(Comparator.comparingDouble(slot -> slot[0]));
      Integer[] byLaunch = new Integer[pages];

      for (int i = 0; i < pages; i++) {
         byLaunch[i] = i;
      }

      Arrays.sort(byLaunch, Comparator.comparingInt(i -> this.launches[i]));

      for (int rank = 0; rank < pages; rank++) {
         this.aim(byLaunch[rank], (int)slots.get(rank)[1]);
      }
   }

   private void aim(int i, int k) {
      this.assigned[i] = (byte)k;
      double distance = this.targets.get(k).position().distanceTo(this.position()) + 4.0;
      this.flights[i] = (byte)Mth.clamp((int)Math.round(distance / 2.4), 5, 26);
   }

   private void updateEnd() {
      int last = 240;

      for (int i = 0; i < this.orbits.length; i++) {
         last = Math.max(last, this.launches[i] + (this.assigned[i] < 0 ? 30 : this.flights[i]));
      }

      this.endTick = last + 10;
   }

   private static boolean isFoe(ServerPlayer caster, LivingEntity living) {
      if (living == caster || !living.isAlive() || living.isSpectator()) {
         return false;
      } else {
         return !(living instanceof Player player)
            ? Summons.isFoe(caster, living)
            : !player.isCreative() && caster.canHarmPlayer(player) && !player.isAlliedTo(caster) && !caster.isAlliedTo(player);
      }
   }

   private boolean stillThere(LivingEntity target) {
      return target.isAlive() && !target.isRemoved() && target.level() == this.level();
   }

   private void landHits(ServerLevel level) {
      int[] hits = new int[this.targets.size()];
      DamageSource source = ModDamage.source(level, ModDamage.PAGE, this, this.caster);

      for (int i = 0; i < this.orbits.length; i++) {
         int k = this.assigned[i];
         if (k >= 0 && this.launches[i] + this.flights[i] == this.tickCount) {
            LivingEntity target = this.targets.get(k);
            if (this.stillThere(target) && target.hurt(source, this.damage)) {
               hits[k]++;
            }
         }
      }

      for (int k = 0; k < hits.length; k++) {
         if (hits[k] != 0) {
            LivingEntity target = this.targets.get(k);
            Vec3 at = target.position().add(0.0, target.getBbHeight() * 0.55, 0.0);
            level.sendParticles(PageEntity.scraps(), at.x, at.y, at.z, 3 * hits[k], 0.2, 0.3, 0.2, 0.15);
            level.sendParticles(ParticleTypes.ENCHANTED_HIT, at.x, at.y, at.z, 2 * hits[k], 0.3, 0.4, 0.3, 0.3);
            Sounds.play(level, at, SoundEvents.PLAYER_ATTACK_SWEEP, 0.7F, 1.5F + this.random.nextFloat() * 0.5F);
            Sounds.play(level, at, SoundEvents.BOOK_PAGE_TURN, 0.6F, 1.7F + this.random.nextFloat() * 0.3F);
         }
      }

      if (this.tickCount % 2 == 0 && this.tickCount < 240 + this.orbits.length / 4 + 1) {
         Sounds.play(level, this.position().add(0.0, 1.5, 0.0), SoundEvents.PLAYER_ATTACK_SWEEP, 0.6F, 1.4F + this.random.nextFloat() * 0.5F);
      }

      boolean changed = false;
      List<Integer> standing = new ArrayList<>();

      for (int kx = 0; kx < this.targets.size(); kx++) {
         if (this.stillThere(this.targets.get(kx))) {
            standing.add(kx);
         }
      }

      int next = 0;

      for (int ix = 0; ix < this.orbits.length; ix++) {
         int kxx = this.assigned[ix];
         if (kxx >= 0 && this.launches[ix] > this.tickCount && !this.stillThere(this.targets.get(kxx))) {
            if (standing.isEmpty()) {
               this.assigned[ix] = -1;
               this.flights[ix] = 30;
            } else {
               this.aim(ix, standing.get(next++ % standing.size()));
            }

            changed = true;
         }
      }

      if (changed) {
         this.writePlan();
         this.updateEnd();
      }
   }

   private void clientTick() {
      if (this.tickCount == 1) {
         ClientSide.run(() -> () -> TempestClient.started(this));
      }

      Vec3 center = this.center(1.0F);
      float charge = charge(this.tickCount);
      int collapsed = this.collapsedAt();
      boolean whirling = this.tickCount < 240 && collapsed < 0;
      if (whirling) {
         int motes = 1 + (int)(4.0F * charge * charge);

         for (int i = 0; i < motes; i++) {
            double angle = this.random.nextDouble() * (float) (Math.PI * 2);
            double radius = 6.5 + this.random.nextDouble();
            this.level()
               .addParticle(
                  ParticleTypes.ENCHANT,
                  center.x,
                  center.y + 1.5 + this.random.nextDouble() * 2.0,
                  center.z,
                  Math.cos(angle) * radius,
                  this.random.nextDouble() * 0.5 - 1.0,
                  Math.sin(angle) * radius
               );
         }

         if (charge > 0.8F && this.random.nextInt(3) != 0) {
            double angle = this.random.nextDouble() * (float) (Math.PI * 2);
            double radius = 2.0 + this.random.nextDouble() * 4.0;
            this.level()
               .addParticle(
                  ParticleTypes.END_ROD,
                  center.x + Math.cos(angle) * radius,
                  center.y + this.random.nextDouble() * 4.0,
                  center.z + Math.sin(angle) * radius,
                  -Math.sin(angle) * 0.25,
                  0.02,
                  Math.cos(angle) * 0.25
               );
         }
      }

      for (int b = 0; b < this.books.length; b++) {
         Vec3 book = this.bookPosition(b, this.tickCount, center);
         if (book != null) {
            this.level()
               .addParticle(
                  ParticleTypes.ENCHANT,
                  book.x,
                  book.y,
                  book.z,
                  this.random.nextGaussian() * 0.4,
                  this.random.nextGaussian() * 0.4,
                  this.random.nextGaussian() * 0.4
               );
         }

         if (this.tickCount == this.books[b].arrival() && whirling) {
            Vec3 burst = center.add(this.burstPoint(b));

            for (int i = 0; i < 8; i++) {
               this.level()
                  .addParticle(
                     PageEntity.scraps(),
                     burst.x,
                     burst.y,
                     burst.z,
                     this.random.nextGaussian() * 0.12,
                     this.random.nextGaussian() * 0.12,
                     this.random.nextGaussian() * 0.12
                  );
            }

            for (int i = 0; i < 3; i++) {
               this.level()
                  .addParticle(
                     ParticleTypes.END_ROD,
                     burst.x,
                     burst.y,
                     burst.z,
                     this.random.nextGaussian() * 0.06,
                     this.random.nextGaussian() * 0.06,
                     this.random.nextGaussian() * 0.06
                  );
            }
         }
      }

      if (this.tickCount == 240 && collapsed < 0) {
         for (int i = 0; i < 40; i++) {
            double angle = i * (float) (Math.PI * 2) / 40.0;
            this.level()
               .addParticle(
                  ParticleTypes.ENCHANTED_HIT,
                  center.x + Math.cos(angle),
                  center.y + 0.3,
                  center.z + Math.sin(angle),
                  Math.cos(angle) * 1.2,
                  0.1,
                  Math.sin(angle) * 1.2
               );
         }

         this.level().addParticle(ParticleTypes.FLASH, center.x, center.y + 1.5, center.z, 0.0, 0.0, 0.0);
         int casterId = this.casterId();
         ClientSide.run(() -> () -> {
            CameraShake.from(center, 1.6F, 36.0, 14);
            TempestClient.broke(casterId);
         });
      }

      if (whirling && this.tickCount > 180) {
         int casterId = this.casterId();
         float build = (this.tickCount - 180) / 60.0F;
         ClientSide.run(() -> () -> TempestClient.building(casterId, build));
      }
   }

   public boolean shouldRenderAtSqrDistance(double distanceSqr) {
      return distanceSqr < 16384.0;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(ValueInput input) {
   }

   protected void addAdditionalSaveData(ValueOutput output) {
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }

   public record Book(boolean fromShelf, Vec3 source, int launch, int flight) {
      public int arrival() {
         return this.launch + this.flight;
      }
   }

   private record Orbit(float radius, float height, float phase, float speed, float bob) {
   }
}
