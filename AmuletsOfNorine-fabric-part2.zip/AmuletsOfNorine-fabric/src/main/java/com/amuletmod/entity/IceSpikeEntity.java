package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.amulet.ability.glacial.Frost;
import com.amuletmod.client.CameraShake;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Easing;
import com.amuletmod.util.Sounds;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class IceSpikeEntity extends Entity {
   public static final int RISE_TICKS = 4;
   public static final int SHATTER_TICKS = 6;
   private static final float WIDTH = 0.8F;
   private static final float HIT_RADIUS = 0.75F;
   private static final int CHILL_TICKS = 60;
   private static final EntityDataAccessor<Float> DATA_HEIGHT = SynchedEntityData.defineId(IceSpikeEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Float> DATA_TILT_YAW = SynchedEntityData.defineId(IceSpikeEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Float> DATA_TILT = SynchedEntityData.defineId(IceSpikeEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Integer> DATA_LIFETIME = SynchedEntityData.defineId(IceSpikeEntity.class, EntityDataSerializers.INT);
   @Nullable
   private UUID ownerId;
   private float damage;
   private Set<UUID> hits = new HashSet<>();

   public IceSpikeEntity(EntityType<? extends IceSpikeEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public IceSpikeEntity(
      ServerLevel level, Vec3 base, float height, float tiltYaw, float tilt, int lifetime, @Nullable ServerPlayer owner, float damage, Set<UUID> hits
   ) {
      this((EntityType<? extends IceSpikeEntity>)ModEntities.ICE_SPIKE.get(), level);
      this.entityData.set(DATA_HEIGHT, height);
      this.entityData.set(DATA_TILT_YAW, tiltYaw);
      this.entityData.set(DATA_TILT, tilt);
      this.entityData.set(DATA_LIFETIME, lifetime);
      this.refreshDimensions();
      this.moveTo(base.x, base.y, base.z, 0.0F, 0.0F);
      this.ownerId = owner == null ? null : owner.getUUID();
      this.damage = damage;
      this.hits = hits;
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_HEIGHT, 2.0F);
      builder.define(DATA_TILT_YAW, 0.0F);
      builder.define(DATA_TILT, 0.0F);
      builder.define(DATA_LIFETIME, 40);
   }

   public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
      super.onSyncedDataUpdated(key);
      if (DATA_HEIGHT.equals(key)) {
         this.refreshDimensions();
      }
   }

   public EntityDimensions getDimensions(Pose pose) {
      return EntityDimensions.scalable(0.8F, this.spikeHeight());
   }

   public float spikeHeight() {
      return (Float)this.entityData.get(DATA_HEIGHT);
   }

   public float tiltYaw() {
      return (Float)this.entityData.get(DATA_TILT_YAW);
   }

   public float tilt() {
      return (Float)this.entityData.get(DATA_TILT);
   }

   public int lifetime() {
      return (Integer)this.entityData.get(DATA_LIFETIME);
   }

   public float rise(float partialTick) {
      return Easing.outBack((this.tickCount + partialTick) / 4.0F);
   }

   public float shatter(float partialTick) {
      return Mth.clamp((this.tickCount + partialTick - (this.lifetime() - 6)) / 6.0F, 0.0F, 1.0F);
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         if (this.tickCount == 1) {
            this.impale();
         }

         if (this.tickCount == this.lifetime() - 6 && this.random.nextBoolean()) {
            Sounds.play(
               this.level(), this.position().add(0.0, this.spikeHeight() * 0.5, 0.0), SoundEvents.GLASS_BREAK, 0.35F, 1.1F + this.random.nextFloat() * 0.4F
            );
         }

         if (this.tickCount >= this.lifetime()) {
            this.discard();
         }
      }
   }

   private void impale() {
      ServerLevel level = (ServerLevel)this.level();
      ServerPlayer owner = this.ownerId == null ? null : level.getServer().getPlayerList().getPlayer(this.ownerId);
      AABB zone = new AABB(this.getX() - 0.75, this.getY(), this.getZ() - 0.75, this.getX() + 0.75, this.getY() + this.spikeHeight(), this.getZ() + 0.75);
      Vec3 lean = Vec3.directionFromRotation(0.0F, this.tiltYaw());

      for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, zone, targetx -> Frost.canHarm(targetx, owner))) {
         if (this.hits.add(target.getUUID())) {
            float amount = target.getType().is(EntityTypeTags.FREEZE_HURTS_EXTRA_TYPES) ? this.damage * 2.0F : this.damage;
            if (target.hurt(this.damageSources().indirectMagic(this, owner), amount)) {
               Vec3 motion = target.getDeltaMovement();
               target.setDeltaMovement(motion.x + lean.x * 0.25, 0.75, motion.z + lean.z * 0.25);
               target.hurtMarked = true;
               Frost.chill(target, 60);
            }
         }
      }
   }

   private void clientTick() {
      RandomSource random = this.random;
      float height = this.spikeHeight();
      if (this.tickCount == 1) {
         BlockState ground = this.level().getBlockState(BlockPos.containing(this.getX(), this.getY() - 0.2, this.getZ()));
         if (!ground.isAir() && ground.getRenderShape() != RenderShape.INVISIBLE) {
            BlockParticleOption debris = new BlockParticleOption(ParticleTypes.BLOCK, ground);

            for (int i = 0; i < 14; i++) {
               this.level()
                  .addParticle(
                     debris,
                     this.getX(),
                     this.getY() + 0.1,
                     this.getZ(),
                     random.nextGaussian() * 0.2,
                     0.25 + random.nextDouble() * 0.2,
                     random.nextGaussian() * 0.2
                  );
            }
         }

         for (int i = 0; i < 10; i++) {
            this.level()
               .addParticle(
                  ParticleTypes.SNOWFLAKE,
                  this.getX(),
                  this.getY() + random.nextDouble() * height,
                  this.getZ(),
                  random.nextGaussian() * 0.12,
                  random.nextDouble() * 0.1,
                  random.nextGaussian() * 0.12
               );
         }

         this.level().addParticle(ParticleTypes.POOF, this.getX(), this.getY() + 0.2, this.getZ(), 0.0, 0.05, 0.0);
         Vec3 at = this.position();
         ClientSide.run(() -> () -> CameraShake.from(at, 0.5F, 10.0, 6));
      } else if (this.tickCount < this.lifetime() - 6 && random.nextInt(5) == 0) {
         this.level()
            .addParticle(
               ParticleTypes.SNOWFLAKE,
               this.getX() + random.nextGaussian() * 0.3,
               this.getY() + random.nextDouble() * height,
               this.getZ() + random.nextGaussian() * 0.3,
               0.0,
               -0.02,
               0.0
            );
      }

      if (this.tickCount == this.lifetime() - 6) {
         BlockParticleOption shard = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.ICE.defaultBlockState());

         for (int i = 0; i < 24; i++) {
            this.level()
               .addParticle(
                  shard,
                  this.getX() + random.nextGaussian() * 0.25,
                  this.getY() + random.nextDouble() * height,
                  this.getZ() + random.nextGaussian() * 0.25,
                  random.nextGaussian() * 0.15,
                  random.nextDouble() * 0.15,
                  random.nextGaussian() * 0.15
               );
         }

         for (int i = 0; i < 6; i++) {
            this.level()
               .addParticle(
                  ParticleTypes.SNOWFLAKE,
                  this.getX(),
                  this.getY() + random.nextDouble() * height,
                  this.getZ(),
                  random.nextGaussian() * 0.08,
                  0.02,
                  random.nextGaussian() * 0.08
               );
         }
      }
   }

   public AABB getBoundingBoxForCulling() {
      double reach = this.spikeHeight() * 0.7 + 1.0;
      return new AABB(
         this.getX() - reach, this.getY() - 0.5, this.getZ() - reach, this.getX() + reach, this.getY() + this.spikeHeight() + 0.5, this.getZ() + reach
      );
   }

   public boolean canBeCollidedWith() {
      return this.shatter(0.0F) <= 0.0F;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean isAttackable() {
      return false;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(ValueInput input) {
   }

   protected void addAdditionalSaveData(ValueOutput output) {
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }
}
