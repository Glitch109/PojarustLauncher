package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.amulet.ability.Summons;
import com.amuletmod.amulet.ability.librarian.PageAim;
import com.amuletmod.amulet.ability.librarian.PageLoad;
import com.amuletmod.amulet.ability.librarian.PageLook;
import com.amuletmod.amulet.ability.librarian.PageStrike;
import com.amuletmod.client.PaperCutsClient;
import com.amuletmod.network.FxPacket;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Easing;
import com.amuletmod.util.ModDamage;
import com.amuletmod.util.Sounds;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import com.amuletmod.neo.EventPriority;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.NeoForge;
import com.amuletmod.neo.event.EventHooks;
import com.amuletmod.neo.event.LivingDeathEvent;
import com.amuletmod.neo.event.LivingDropsEvent;
import com.amuletmod.neo.event.BlockEvent.BreakEvent;
import com.amuletmod.neo.event.ServerTickEvent.Post;
import com.amuletmod.neo.PacketDistributor;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class PageEntity extends Projectile implements Summons.Owned {
   public static final int VOLLEY = 3;
   public static final int APPEAR_TICKS = 3;
   public static final int IMPACT_TICK = 3;
   public static final int FIRE_TICK = 5;
   public static final int FIRE_STAGGER = 2;
   public static final int TRAIL_LENGTH = 5;
   private static final double LAUNCH_SPEED = 1.3;
   private static final double MAX_SPEED = 2.8;
   private static final double ACCELERATION = 0.25;
   private static final double BOW = 0.3;
   private static final double GAIN = 2.4;
   private static final double LAUNCH_STEER = 0.2;
   private static final float STEER_RAMP_TICKS = 6.0F;
   private static final double AIM_SPEED = 0.5;
   private static final double COMMIT_TICKS = 3.0;
   private static final double HELD_SPEED = 0.05;
   private static final int MAX_FLIGHT = 30;
   private static final int MAX_HOLD = 21;
   private static final Vec3 UP = new Vec3(0.0, 1.0, 0.0);
   private static final Vector3f CURSE_RED = new Vector3f(0.75F, 0.05F, 0.1F);
   private static final EntityDataAccessor<Integer> DATA_THROWER = SynchedEntityData.defineId(PageEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_SLOT = SynchedEntityData.defineId(PageEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_VOLLEY = SynchedEntityData.defineId(PageEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_LOOK = SynchedEntityData.defineId(PageEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Boolean> DATA_FLYING = SynchedEntityData.defineId(PageEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Boolean> DATA_GUIDED = SynchedEntityData.defineId(PageEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Vector3f> DATA_AIM = SynchedEntityData.defineId(PageEntity.class, EntityDataSerializers.VECTOR3);
   private PageLoad load = PageLoad.of(ItemStack.EMPTY);
   private float damage;
   private double range;
   @Nullable
   private UUID launcher;
   @Nullable
   private LivingEntity target;
   private boolean committed;
   private int flightTicks;
   public final Vec3[] trail = new Vec3[5];
   private int flungAt = -1;
   private Vec3 flingGap = Vec3.ZERO;

   public PageEntity(EntityType<? extends PageEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public PageEntity(ServerLevel level, ServerPlayer thrower, int slot, int volley, PageLoad load, float damage, double range) {
      this((EntityType<? extends PageEntity>)ModEntities.PAGE.get(), level);
      this.setOwner(thrower);
      this.launcher = thrower.getUUID();
      this.load = load;
      this.damage = damage;
      this.range = range;
      this.entityData.set(DATA_THROWER, thrower.getId());
      this.entityData.set(DATA_SLOT, slot);
      this.entityData.set(DATA_VOLLEY, volley);
      this.entityData.set(DATA_LOOK, load.look().ordinal());
      Vec3 at = holdPosition(thrower, slot, volley, 1.0F);
      this.moveTo(at.x, at.y, at.z, 0.0F, 0.0F);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_THROWER, -1);
      builder.define(DATA_SLOT, 0);
      builder.define(DATA_VOLLEY, 3);
      builder.define(DATA_LOOK, 0);
      builder.define(DATA_FLYING, false);
      builder.define(DATA_GUIDED, true);
      builder.define(DATA_AIM, new Vector3f());
   }

   @Nullable
   @Override
   public UUID summonerId() {
      Entity owner = this.getOwner();
      return owner == null ? null : owner.getUUID();
   }

   @Nullable
   public Entity thrower() {
      return this.level().getEntity((Integer)this.entityData.get(DATA_THROWER));
   }

   public int slot() {
      return (Integer)this.entityData.get(DATA_SLOT);
   }

   public int volley() {
      return (Integer)this.entityData.get(DATA_VOLLEY);
   }

   public PageLoad load() {
      return this.load;
   }

   public PageLook look() {
      return PageLook.byId((Integer)this.entityData.get(DATA_LOOK));
   }

   public boolean isFlying() {
      return (Boolean)this.entityData.get(DATA_FLYING);
   }

   public boolean isGuided() {
      return (Boolean)this.entityData.get(DATA_GUIDED);
   }

   public Vec3 aim() {
      return new Vec3((Vector3f)this.entityData.get(DATA_AIM));
   }

   public int flungAt() {
      return this.flungAt;
   }

   public Vec3 flingOffset(float partialTick) {
      if (this.flungAt < 0) {
         return Vec3.ZERO;
      } else {
         float fade = Mth.clamp((this.tickCount + partialTick - this.flungAt) / 3.0F, 0.0F, 1.0F);
         return this.flingGap.scale(1.0F - Easing.outCubic(fade));
      }
   }

   public static int firesAt(int slot, int volley) {
      return 5 + slot * 2 * 3 / Math.max(1, volley);
   }

   public static float appearsAt(int slot, int volley) {
      return slot * 3.0F / Math.max(3, volley);
   }

   public static ParticleOptions scraps() {
      return new ItemParticleOption(ParticleTypes.ITEM, new ItemStack(Items.PAPER));
   }

   public static Vec3 holdPosition(Entity thrower, int slot, int volley, float partialTick) {
      Vec3 eye = thrower.getEyePosition(partialTick);
      Vec3 forward = thrower.getViewVector(partialTick);
      Vec3 right = forward.cross(UP);
      if (right.lengthSqr() < 1.0E-4) {
         float yaw = thrower.getViewYRot(partialTick) * (float) (Math.PI / 180.0);
         right = new Vec3(-Mth.cos(yaw), 0.0, -Mth.sin(yaw));
      }

      right = right.normalize();
      Vec3 up = right.cross(forward);
      double angle = volley <= 1 ? (float) (Math.PI / 2) : Math.PI * (1.0 - (double)slot / (volley - 1));
      double extra = Math.max(0, volley - 3);
      double width = 0.85 + 0.1 * extra;
      double height = 0.6 + 0.08 * extra;
      Vec3 offset = forward.scale(1.15 + 0.15 * Math.sin(angle)).add(right.scale(width * Math.cos(angle))).add(up.scale(height * Math.sin(angle) - 0.1));
      Vec3 wanted = eye.add(offset);
      BlockHitResult wall = thrower.level().clip(new ClipContext(eye, wanted, Block.COLLIDER, Fluid.NONE, thrower));
      return wall.getType() == Type.MISS ? wanted : eye.add(offset.normalize().scale(Math.max(0.0, wall.getLocation().distanceTo(eye) - 0.2)));
   }

   public void tick() {
      super.tick();
      if (this.isFlying()) {
         this.fly();
      } else {
         this.hold();
      }
   }

   private void hold() {
      Entity thrower = this.thrower();
      if (this.level().isClientSide()) {
         if (thrower != null) {
            if (this.slot() == 0 && this.tickCount == 3) {
               int id = thrower.getId();
               ClientSide.run(() -> () -> PaperCutsClient.impactFrame(id));
            }

            Vec3 at = holdPosition(thrower, this.slot(), this.volley(), 1.0F);
            this.level()
               .addParticle(
                  ParticleTypes.ENCHANT, at.x, at.y, at.z, this.random.nextGaussian() * 0.6, this.random.nextGaussian() * 0.6, this.random.nextGaussian() * 0.6
               );
         }
      } else if (thrower instanceof ServerPlayer player && player.isAlive() && player.level() == this.level() && this.tickCount <= 21) {
         Vec3 at = holdPosition(player, this.slot(), this.volley(), 1.0F);
         this.setPos(at.x, at.y, at.z);
         this.setDeltaMovement(Vec3.ZERO);
         if (this.tickCount >= firesAt(this.slot(), this.volley())) {
            this.fling(player);
         }
      } else {
         this.burst(this.position(), 4, 0.03);
         this.discard();
      }
   }

   private void fling(ServerPlayer thrower) {
      PageAim aim = PageAim.of(thrower, this.range);
      this.target = aim.target();
      Vec3 from = this.position();
      Vec3 toward = aim.point().subtract(from);
      Vec3 forward = toward.lengthSqr() < 1.0E-4 ? thrower.getViewVector(1.0F) : toward.normalize();
      Vec3 side = from.subtract(thrower.getEyePosition());
      side = side.subtract(forward.scale(side.dot(forward)));
      Vec3 heading = side.lengthSqr() < 1.0E-4 ? forward : forward.add(side.normalize().scale(0.3)).normalize();
      this.setDeltaMovement(heading.scale(1.3));
      this.entityData.set(DATA_AIM, aim.point().toVector3f());
      this.entityData.set(DATA_FLYING, true);
      this.hasImpulse = true;
      ServerLevel level = (ServerLevel)this.level();
      float rise = (float)this.slot() / Math.max(1, this.volley() - 1);
      Sounds.play(level, from, SoundEvents.PLAYER_ATTACK_SWEEP, 0.7F, 1.5F + 0.3F * rise);
      Sounds.play(level, from, SoundEvents.BOOK_PAGE_TURN, 0.9F, 1.6F + 0.2F * rise);
   }

   private void fly() {
      Vec3 velocity = this.getDeltaMovement();
      double speed = velocity.length();
      if (speed >= 0.05) {
         this.flightTicks++;
         if (!this.level().isClientSide()) {
            this.followTarget(speed);
         }

         velocity = this.steer(velocity, speed);
         this.setDeltaMovement(velocity);
      }

      Vec3 from = this.position();
      if (!this.level().isClientSide()) {
         HitResult hit = this.findHit(from);
         if (hit.getType() != Type.MISS && !EventHooks.onProjectileImpact(this, hit)) {
            this.onHit(hit);
            return;
         }

         if (this.flightTicks > 30) {
            this.burst(from, 6, 0.02);
            this.discard();
            return;
         }

         velocity = this.getDeltaMovement();
      } else {
         this.clientFlightTick(from);
      }

      this.setPos(from.x + velocity.x, from.y + velocity.y, from.z + velocity.z);
   }

   private Vec3 steer(Vec3 velocity, double speed) {
      double newSpeed = Math.min(2.8, speed + 0.25);
      Vec3 heading = velocity.scale(1.0 / speed);
      if (this.isGuided()) {
         Vec3 lineOfSight = this.aim().subtract(this.position());
         double distance = lineOfSight.length();
         if (distance > 0.001) {
            double share = 0.2 + 0.8 * Easing.smoothstep(0.0F, 6.0F, this.flightTicks);
            double turn = Math.min(1.0, share * 2.4 * newSpeed / Math.max(distance, 0.1));
            heading = heading.add(lineOfSight.scale(1.0 / distance).subtract(heading).scale(turn));
            if (heading.lengthSqr() < 1.0E-6) {
               heading = lineOfSight;
            }
         }
      }

      return heading.normalize().scale(newSpeed);
   }

   private void followTarget(double speed) {
      if (this.isGuided()) {
         Entity owner = this.getOwner();
         if (owner != null && owner.getUUID().equals(this.launcher)) {
            Vec3 aim = this.aim();
            if (!this.committed && this.target != null && this.target.isAlive() && !this.target.isRemoved() && this.target.level() == this.level()) {
               Vec3 gap = this.target.position().add(0.0, this.target.getBbHeight() * 0.5, 0.0).subtract(aim);
               double length = gap.length();
               if (length > 0.001) {
                  aim = aim.add(gap.scale(Math.min(1.0, 0.5 / length)));
                  this.entityData.set(DATA_AIM, aim.toVector3f());
               }
            }

            Vec3 lineOfSight = aim.subtract(this.position());
            double distance = lineOfSight.length();
            if (distance < 3.0 * Math.max(speed, 1.3)) {
               this.committed = true;
            }

            if (this.committed && (lineOfSight.dot(this.getDeltaMovement()) <= 0.0 || distance < 0.3)) {
               this.entityData.set(DATA_GUIDED, false);
            }
         } else {
            this.entityData.set(DATA_GUIDED, false);
         }
      }
   }

   private HitResult findHit(Vec3 at) {
      for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(0.3), this::canHitEntity)) {
         if (entity.getBoundingBox().inflate(0.3).contains(at)) {
            return new EntityHitResult(entity, at);
         }
      }

      return ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
   }

   public boolean canStrike(Entity candidate) {
      if (!(candidate instanceof PageEntity) && candidate.isAlive() && !candidate.isSpectator()) {
         Entity owner = this.getOwner();
         return owner == null
            || candidate != owner
               && !candidate.isAlliedTo(owner)
               && !owner.isAlliedTo(candidate)
               && !(owner instanceof LivingEntity living && Summons.isSummonedBy(candidate, living));
      } else {
         return false;
      }
   }

   protected boolean canHitEntity(Entity candidate) {
      return super.canHitEntity(candidate) && this.canStrike(candidate);
   }

   protected void onHitEntity(EntityHitResult result) {
      super.onHitEntity(result);
      ServerLevel level = (ServerLevel)this.level();
      Entity hit = result.getEntity();
      LivingEntity thrower = this.getOwner() instanceof LivingEntity living ? living : null;
      if (hit instanceof LivingEntity livingx) {
         this.strike(level, livingx, thrower);
      } else {
         hit.hurt(this.source(level, thrower), this.damage);
      }

      Vec3 at = result.getLocation();
      PacketDistributor.sendToPlayersTrackingEntity(
         this, new FxPacket(FxPacket.Kind.PAGE_CUT, at, at.add(this.getDeltaMovement().normalize()), this.look().ordinal()), new CustomPacketPayload[0]
      );
      this.burst(at, 8, 0.12);
      this.discard();
   }

   private void strike(ServerLevel level, LivingEntity target, @Nullable LivingEntity thrower) {
      DamageSource source = this.source(level, thrower);
      float amount = this.load.breach(target, source, this.load.damage(this.damage, target));
      boolean landed = target.hurt(source, amount);
      PageStrike strike = new PageStrike(level, this, thrower, target, source, amount, this.getDeltaMovement().normalize());
      if (landed) {
         this.load.wound(strike);
      }

      this.load.touch(strike);
      Vec3 at = target.position().add(0.0, target.getBbHeight() * 0.6, 0.0);
      if (landed) {
         Sounds.play(level, at, SoundEvents.PLAYER_ATTACK_STRONG, 0.6F, 1.6F + this.random.nextFloat() * 0.2F);
         Sounds.play(level, at, SoundEvents.PLAYER_ATTACK_SWEEP, 0.5F, 1.8F + this.random.nextFloat() * 0.2F);
         if (amount >= this.damage * 2.0F) {
            level.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 10, 0.3, 0.4, 0.3, 0.4);
            Sounds.play(level, at, SoundEvents.PLAYER_ATTACK_CRIT, 0.8F, 1.3F);
         }
      }
   }

   private DamageSource source(ServerLevel level, @Nullable Entity thrower) {
      return ModDamage.source(level, this.load.piercesArmor() ? ModDamage.PIERCING_PAGE : ModDamage.PAGE, this, thrower);
   }

   protected void onHitBlock(BlockHitResult result) {
      super.onHitBlock(result);
      ServerLevel level = (ServerLevel)this.level();
      boolean cut = this.cut(level, result.getBlockPos());
      this.burst(result.getLocation(), cut ? 4 : 8, 0.1);
      this.discard();
   }

   private boolean cut(ServerLevel level, BlockPos pos) {
      float power = this.load.cuttingPower();
      if (!(power <= 0.0F) && this.getOwner() instanceof ServerPlayer player) {
         BlockState state = level.getBlockState(pos);
         float hardness = state.getDestroySpeed(level, pos);
         if (state.isAir() || hardness < 0.0F || hardness > power) {
            return false;
         } else if (!player.blockActionRestricted(level, pos, player.gameMode.getGameModeForPlayer())
            && level.mayInteract(player, pos)
            && !((BreakEvent)NeoForge.EVENT_BUS.post(new BreakEvent(level, pos, state, player))).isCanceled()) {
            BlockEntity blockEntity = state.hasBlockEntity() ? level.getBlockEntity(pos) : null;
            net.minecraft.world.level.block.Block.dropResources(state, level, pos, blockEntity, player, this.load.cuttingTool());
            level.destroyBlock(pos, false, player);
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void burst(Vec3 at, int scraps, double speed) {
      ServerLevel level = (ServerLevel)this.level();
      level.sendParticles(scraps(), at.x, at.y, at.z, scraps, 0.08, 0.08, 0.08, speed);
      if (this.look().glints()) {
         level.sendParticles(ParticleTypes.ENCHANTED_HIT, at.x, at.y, at.z, 4, 0.1, 0.1, 0.1, 0.2);
      }

      Sounds.play(level, at, SoundEvents.BOOK_PAGE_TURN, 0.8F, 1.6F + this.random.nextFloat() * 0.3F);
   }

   private void clientFlightTick(Vec3 before) {
      if (this.flungAt < 0) {
         this.flungAt = this.tickCount;
         Entity thrower = this.thrower();
         if (thrower != null) {
            this.flingGap = holdPosition(thrower, this.slot(), this.volley(), 1.0F).subtract(before);
            int id = thrower.getId();
            ClientSide.run(() -> () -> PaperCutsClient.flung(id));
         }
      }

      System.arraycopy(this.trail, 0, this.trail, 1, 4);
      this.trail[0] = before;
      Vec3 motion = this.getDeltaMovement();
      double x = before.x + motion.x * 0.5;
      double y = before.y + motion.y * 0.5;
      double z = before.z + motion.z * 0.5;
      switch (this.look()) {
         case ENCHANTED:
            this.level()
               .addParticle(
                  ParticleTypes.ENCHANT, x, y, z, this.random.nextGaussian() * 0.3, this.random.nextGaussian() * 0.3, this.random.nextGaussian() * 0.3
               );
            break;
         case FIERY:
            this.level().addParticle(ParticleTypes.SMALL_FLAME, x, y, z, 0.0, 0.01, 0.0);
            break;
         case FROSTY:
            this.level().addParticle(ParticleTypes.SNOWFLAKE, x, y, z, 0.0, 0.0, 0.0);
            break;
         case WINDY:
            this.level().addParticle(ParticleTypes.SMALL_GUST, x, y, z, 0.0, 0.0, 0.0);
            break;
         case STORMY:
            this.level()
               .addParticle(
                  ParticleTypes.ELECTRIC_SPARK, x, y, z, this.random.nextGaussian() * 0.1, this.random.nextGaussian() * 0.1, this.random.nextGaussian() * 0.1
               );
            break;
         case CURSED:
            this.level().addParticle(new DustParticleOptions(CURSE_RED, 0.9F), x, y, z, 0.0, 0.0, 0.0);
      }
   }

   public boolean isPickable() {
      return false;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   public boolean shouldRenderAtSqrDistance(double distanceSqr) {
      return distanceSqr < 9216.0;
   }

   protected void readAdditionalSaveData(ValueInput input) {
   }

   protected void addAdditionalSaveData(ValueOutput output) {
   }

   @EventBusSubscriber(
      modid = "amuletmod"
   )
   public static final class PageEvents {
      private static int lootingKill;

      private PageEvents() {
      }

      public static int lootingKill() {
         return lootingKill;
      }

      @SubscribeEvent(
         priority = EventPriority.LOWEST
      )
      public static void onDeath(LivingDeathEvent event) {
         lootingKill = event.getSource().getDirectEntity() instanceof PageEntity page ? page.load.looting() : 0;
      }

      @SubscribeEvent
      public static void onDrops(LivingDropsEvent event) {
         lootingKill = 0;
      }

      @SubscribeEvent
      public static void onServerTick(Post event) {
         lootingKill = 0;
      }
   }
}
