package com.amuletmod.entity;

import com.amuletmod.amulet.ability.seal.Openings;
import com.amuletmod.client.CameraShake;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.seal.SealBarrierBlock;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Sounds;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.Direction.AxisDirection;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.SubscribeEvent;
import com.amuletmod.neo.EventBusSubscriber;
import com.amuletmod.neo.IEntityWithComplexSpawn;
import com.amuletmod.neo.event.PlayerInteractEvent.LeftClickBlock;
import org.jetbrains.annotations.Nullable;

public class SealEntity extends Entity implements IEntityWithComplexSpawn {
   public static final int SPREAD_PER_TICK = 2;
   public static final int SHATTER_TICKS = 14;
   public static final int WARN_TICKS = 60;
   public static final double INSET = 0.0625;
   private static final int PANE_GRACE_TICKS = 40;
   private static final int MAX_MARKS = 6;
   private static final EntityDataAccessor<Integer> DATA_END = SynchedEntityData.defineId(SealEntity.class, EntityDataSerializers.INT);
   private Direction facing = Direction.UP;
   private BlockPos anchor = BlockPos.ZERO;
   private int[] us = new int[0];
   private int[] vs = new int[0];
   private int[] depths = new int[0];
   @Nullable
   private SealEntity.Layout layout;
   @Nullable
   private Set<Long> covered;
   @Nullable
   private UUID ownerId;
   private int placed;
   private int watched = -1;
   private boolean broken;
   private boolean scattered;

   public SealEntity(EntityType<? extends SealEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public SealEntity(ServerLevel level, ServerPlayer owner, Openings.Opening opening, int lifetime) {
      this((EntityType<? extends SealEntity>)ModEntities.SEAL.get(), level);
      this.ownerId = owner.getUUID();
      this.facing = opening.facing();
      this.anchor = opening.anchor();
      this.us = opening.us();
      this.vs = opening.vs();
      this.depths = opening.depths();
      this.entityData.set(DATA_END, lifetime);
      SealEntity.Mark heart = this.layout().marks().get(0);
      Vec3 at = this.planePoint(heart.u(), heart.v());
      this.moveTo(at.x, at.y, at.z, 0.0F, 0.0F);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_END, 600);
   }

   public int endTick() {
      return (Integer)this.entityData.get(DATA_END);
   }

   public Direction facing() {
      return this.facing;
   }

   public int size() {
      return this.us.length;
   }

   public int u(int i) {
      return this.us[i];
   }

   public int v(int i) {
      return this.vs[i];
   }

   public int depth(int i) {
      return this.depths[i];
   }

   public float spread(float partialTick) {
      return (this.tickCount + partialTick) * 2.0F;
   }

   public float shatter(float partialTick) {
      return Mth.clamp((this.tickCount + partialTick - this.endTick()) / 14.0F, 0.0F, 1.0F);
   }

   public BlockPos cell(int i) {
      return Openings.cell(this.anchor, this.facing.getAxis(), this.us[i], this.vs[i]);
   }

   public Vec3 planePoint(double u, double v) {
      Axis axis = this.facing.getAxis();
      double depth = this.facing.getAxisDirection() == AxisDirection.POSITIVE ? 0.9375 : 0.0625;
      return Vec3.atLowerCornerOf(this.anchor).add(unit(axis).scale(depth)).add(unit(Openings.uAxis(axis)).scale(u)).add(unit(Openings.vAxis(axis)).scale(v));
   }

   public static Vec3 unit(Axis axis) {
      return new Vec3(axis == Axis.X ? 1.0 : 0.0, axis == Axis.Y ? 1.0 : 0.0, axis == Axis.Z ? 1.0 : 0.0);
   }

   private static long key(int u, int v) {
      return (long)u << 32 | v & 4294967295L;
   }

   private Set<Long> covered() {
      if (this.covered == null) {
         this.covered = new HashSet<>();

         for (int i = 0; i < this.us.length; i++) {
            this.covered.add(key(this.us[i], this.vs[i]));
         }
      }

      return this.covered;
   }

   public boolean covers(BlockPos pos) {
      Axis axis = this.facing.getAxis();
      return pos.get(axis) != this.anchor.get(axis)
         ? false
         : this.covered()
            .contains(
               key(pos.get(Openings.uAxis(axis)) - this.anchor.get(Openings.uAxis(axis)), pos.get(Openings.vAxis(axis)) - this.anchor.get(Openings.vAxis(axis)))
            );
   }

   public SealEntity.Layout layout() {
      if (this.layout == null) {
         this.layout = this.lay();
      }

      return this.layout;
   }

   private SealEntity.Layout lay() {
      Set<Long> cells = this.covered();
      int[][] sides = new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
      List<int[]> walls = new ArrayList<>();
      Set<Long> seenWalls = new HashSet<>();
      float[] rim = new float[this.us.length * 4 * 5];
      int segments = 0;
      int deepest = 0;

      for (int i = 0; i < this.us.length; i++) {
         int u = this.us[i];
         int v = this.vs[i];
         deepest = Math.max(deepest, this.depths[i]);

         for (int du = -1; du <= 1; du++) {
            for (int dv = -1; dv <= 1; dv++) {
               if (!cells.contains(key(u + du, v + dv)) && seenWalls.add(key(u + du, v + dv))) {
                  walls.add(new int[]{u + du, v + dv});
               }
            }
         }

         for (int[] side : sides) {
            if (!cells.contains(key(u + side[0], v + side[1]))) {
               int at = segments++ * 5;
               rim[at] = u + (side[0] > 0 ? 1 : 0);
               rim[at + 1] = v + (side[1] > 0 ? 1 : 0);
               rim[at + 2] = side[0] != 0 ? rim[at] : u + 1;
               rim[at + 3] = side[1] != 0 ? rim[at + 1] : v + 1;
               rim[at + 4] = this.depths[i];
            }
         }
      }

      List<SealEntity.Mark> spots = new ArrayList<>();

      for (int i = 0; i < this.us.length; i++) {
         spots.add(new SealEntity.Mark(this.us[i] + 0.5F, this.vs[i] + 0.5F, room(walls, this.us[i] + 0.5F, this.vs[i] + 0.5F), this.depths[i]));
         if (cells.contains(key(this.us[i] + 1, this.vs[i]))
            && cells.contains(key(this.us[i], this.vs[i] + 1))
            && cells.contains(key(this.us[i] + 1, this.vs[i] + 1))) {
            spots.add(new SealEntity.Mark(this.us[i] + 1.0F, this.vs[i] + 1.0F, room(walls, this.us[i] + 1.0F, this.vs[i] + 1.0F), this.depths[i]));
         }
      }

      spots.sort((a, b) -> Float.compare(b.radius(), a.radius()));
      List<SealEntity.Mark> marks = new ArrayList<>();

      for (SealEntity.Mark spot : spots) {
         if (marks.size() >= 6 || !marks.isEmpty() && spot.radius() < 1.0F) {
            break;
         }

         boolean clear = true;

         for (SealEntity.Mark mark : marks) {
            clear &= Mth.sqrt(Mth.square(mark.u() - spot.u()) + Mth.square(mark.v() - spot.v())) >= mark.radius() + spot.radius();
         }

         if (clear) {
            marks.add(spot);
         }
      }

      marks.replaceAll(markx -> new SealEntity.Mark(markx.u(), markx.v(), markx.radius() + 0.4F, markx.depth()));
      float[] trimmed = new float[segments * 5];
      System.arraycopy(rim, 0, trimmed, 0, trimmed.length);
      return new SealEntity.Layout(List.copyOf(marks), trimmed, deepest);
   }

   private static float room(List<int[]> walls, float u, float v) {
      float least = Float.MAX_VALUE;

      for (int[] wall : walls) {
         float du = Math.max(Math.abs(u - (wall[0] + 0.5F)) - 0.5F, 0.0F);
         float dv = Math.max(Math.abs(v - (wall[1] + 0.5F)) - 0.5F, 0.0F);
         least = Math.min(least, du * du + dv * dv);
      }

      return Mth.sqrt(least);
   }

   @Nullable
   public static SealEntity at(Level level, BlockPos pos) {
      List<SealEntity> seals = level.getEntitiesOfClass(SealEntity.class, new AABB(pos).inflate(66.0), seal -> seal.covers(pos));
      return seals.isEmpty() ? null : seals.get(0);
   }

   public boolean isOwnedBy(Player player) {
      return player.getUUID().equals(this.ownerId);
   }

   public void shatterNow() {
      if (this.tickCount < this.endTick()) {
         this.entityData.set(DATA_END, this.tickCount);
      }
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         ServerLevel level = (ServerLevel)this.level();
         Vec3 at = this.position();
         if (this.tickCount < this.endTick()) {
            if (this.tickCount == 1) {
               Sounds.play(level, at, SoundEvents.ENCHANTMENT_TABLE_USE, 1.2F, 0.7F);
               Sounds.play(level, at, SoundEvents.BEACON_POWER_SELECT, 0.8F, 1.4F);
               Sounds.play(level, at, SoundEvents.BOOK_PAGE_TURN, 1.2F, 0.6F);
            }

            if (this.placed < this.us.length) {
               this.write(level, at);
            } else if (this.tickCount % 20 == 0 && (this.watched < 0 || !level.getBlockState(this.cell(this.watched)).is(SealBarrierBlock.block()))) {
               this.shatterNow();
            }

            int left = this.endTick() - this.tickCount;
            if (left == 60 || left == 40 || left == 20) {
               Sounds.play(level, at, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0F, 2.0F - left / 60.0F);
            }
         } else if (!this.broken) {
            this.shatter(level, at);
         }

         if (this.tickCount >= this.endTick() + 14) {
            this.discard();
         }
      }
   }

   private void write(ServerLevel level, Vec3 at) {
      int reach = this.tickCount * 2;

      for (int ticks = this.endTick() - this.tickCount + 40; this.placed < this.us.length && this.depths[this.placed] <= reach; this.placed++) {
         if (SealBarrierBlock.seal(level, this.cell(this.placed), this.facing, ticks) && this.watched < 0) {
            this.watched = this.placed;
         }
      }

      if (this.tickCount % 2 == 0) {
         Sounds.play(level, at, SoundEvents.AMETHYST_BLOCK_CHIME, 0.6F, 0.7F + 0.9F * this.placed / this.us.length);
      }

      if (this.placed == this.us.length) {
         Sounds.play(level, at, SoundEvents.IRON_DOOR_CLOSE, 1.0F, 0.6F);
         Sounds.play(level, at, SoundEvents.RESPAWN_ANCHOR_SET_SPAWN, 0.8F, 1.3F);
         Sounds.play(level, at, SoundEvents.BELL_RESONATE, 0.5F, 1.6F);
         Sounds.play(level, at, SoundEvents.ANVIL_LAND, 0.25F, 0.6F);
      }
   }

   private void shatter(ServerLevel level, Vec3 at) {
      this.broken = true;
      this.clearPanes(level);
      Sounds.play(level, at, SoundEvents.GLASS_BREAK, 1.2F, 0.7F);
      Sounds.play(level, at, SoundEvents.AMETHYST_CLUSTER_BREAK, 1.0F, 0.7F);
      Sounds.play(level, at, SoundEvents.BEACON_DEACTIVATE, 0.8F, 1.4F);
   }

   private void clearPanes(ServerLevel level) {
      for (int i = 0; i < this.placed; i++) {
         SealBarrierBlock.dissolve(level, this.cell(i));
      }

      this.placed = 0;
   }

   public void remove(RemovalReason reason) {
      if (!this.level().isClientSide() && reason.shouldDestroy() && !this.broken) {
         this.broken = true;
         this.clearPanes((ServerLevel)this.level());
      }

      super.remove(reason);
   }

   private void clientTick() {
      int count = this.us.length;
      if (count != 0) {
         SealEntity.Layout layout = this.layout();
         Axis axis = this.facing.getAxis();
         Vec3 out = Vec3.atLowerCornerOf(this.facing.getNormal());
         int end = this.endTick();
         if (this.tickCount < end) {
            float reach = this.spread(0.0F);
            if (reach <= layout.deepest() + 2) {
               for (int i = 0; i < count; i++) {
                  if (this.depths[i] <= reach && this.depths[i] > reach - 2.0F && this.random.nextInt(3) == 0) {
                     Vec3 at = this.planePoint(this.us[i] + this.random.nextDouble(), this.vs[i] + this.random.nextDouble());
                     this.level().addParticle(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, out.x * 0.1, out.y * 0.1, out.z * 0.1);
                  }
               }
            }

            for (int n = 0; n < 1 + count / 96; n++) {
               int ix = this.random.nextInt(count);
               if (!(this.depths[ix] > reach)) {
                  Vec3 at = this.planePoint(this.us[ix] + this.random.nextDouble(), this.vs[ix] + this.random.nextDouble());
                  double drift = this.random.nextBoolean() ? 0.02 : -0.02;
                  this.level().addParticle(ParticleTypes.END_ROD, at.x, at.y, at.z, out.x * drift, out.y * drift, out.z * drift);
               }
            }

            if (this.tickCount % 70 == 20) {
               this.level().playLocalSound(this.getX(), this.getY(), this.getZ(), SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 0.7F, 0.6F, false);
            }
         } else if (!this.scattered) {
            this.scattered = true;
            BlockParticleOption shard = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.MAGENTA_STAINED_GLASS.defaultBlockState());
            int stride = Math.max(1, count / 160);

            for (int ix = this.random.nextInt(stride); ix < count; ix += stride) {
               Vec3 at = this.planePoint(this.us[ix] + 0.5, this.vs[ix] + 0.5);
               this.level()
                  .addParticle(shard, at.x, at.y, at.z, this.random.nextGaussian() * 0.12, this.random.nextGaussian() * 0.12, this.random.nextGaussian() * 0.12);
               this.level()
                  .addParticle(
                     ParticleTypes.END_ROD,
                     at.x,
                     at.y,
                     at.z,
                     this.random.nextGaussian() * 0.06,
                     this.random.nextGaussian() * 0.06,
                     this.random.nextGaussian() * 0.06
                  );
            }

            Vec3 heart = this.position();
            this.level().addParticle(ParticleTypes.FLASH, heart.x, heart.y, heart.z, 0.0, 0.0, 0.0);
            ClientSide.run(() -> () -> CameraShake.from(heart, 0.9F, 20.0, 10));
         }

         if (this.tickCount == Mth.ceil(layout.deepest() / 2.0F) + 1 && this.tickCount < end) {
            Vec3 heart = this.position();
            ClientSide.run(() -> () -> CameraShake.from(heart, 0.7F, 18.0, 8));
         }
      }
   }

   public void writeSpawnData(RegistryFriendlyByteBuf buffer) {
      buffer.writeVarInt(this.tickCount);
      buffer.writeEnum(this.facing);
      buffer.writeBlockPos(this.anchor);
      buffer.writeVarInt(this.us.length);

      for (int i = 0; i < this.us.length; i++) {
         buffer.writeByte(this.us[i]);
         buffer.writeByte(this.vs[i]);
         buffer.writeVarInt(this.depths[i]);
      }
   }

   public void readSpawnData(RegistryFriendlyByteBuf buffer) {
      this.tickCount = buffer.readVarInt();
      this.facing = (Direction)buffer.readEnum(Direction.class);
      this.anchor = buffer.readBlockPos();
      int count = Math.min(buffer.readVarInt(), 1024);
      this.us = new int[count];
      this.vs = new int[count];
      this.depths = new int[count];

      for (int i = 0; i < count; i++) {
         this.us[i] = buffer.readByte();
         this.vs[i] = buffer.readByte();
         this.depths[i] = buffer.readVarInt();
      }

      this.layout = null;
      this.covered = null;
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
      tag.putInt("Age", this.tickCount);
      tag.putInt("End", this.endTick());
      tag.putInt("Placed", this.placed);
      tag.putInt("Watched", this.watched);
      tag.putBoolean("Broken", this.broken);
      tag.putInt("Facing", this.facing.get3DDataValue());
      tag.put("Anchor", NbtUtils.writeBlockPos(this.anchor));
      tag.putIntArray("U", this.us);
      tag.putIntArray("V", this.vs);
      tag.putIntArray("Depth", this.depths);
      if (this.ownerId != null) {
         tag.putUUID("Owner", this.ownerId);
      }
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
      this.tickCount = tag.getInt("Age");
      this.entityData.set(DATA_END, tag.getInt("End"));
      this.broken = tag.getBoolean("Broken");
      this.facing = Direction.from3DDataValue(tag.getInt("Facing"));
      this.anchor = NbtUtils.readBlockPos(tag, "Anchor").orElse(this.blockPosition());
      this.us = tag.getIntArray("U");
      this.vs = tag.getIntArray("V");
      this.depths = tag.getIntArray("Depth");
      if (this.vs.length != this.us.length || this.depths.length != this.us.length) {
         this.us = this.vs = this.depths = new int[0];
      }

      this.placed = Mth.clamp(tag.getInt("Placed"), 0, this.us.length);
      this.watched = Mth.clamp(tag.getInt("Watched"), -1, this.us.length - 1);
      this.ownerId = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
      this.layout = null;
      this.covered = null;
   }

   public AABB getBoundingBoxForCulling() {
      double reach = 34.0;
      Vec3 heart = this.planePoint(0.5, 0.5);
      return new AABB(heart, heart).inflate(reach);
   }

   public boolean shouldRenderAtSqrDistance(double distanceSqr) {
      return distanceSqr < 25600.0;
   }

   public boolean isAttackable() {
      return false;
   }

   public boolean hurt(DamageSource source, float amount) {
      return false;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean canBeCollidedWith() {
      return false;
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }

   public record Layout(List<SealEntity.Mark> marks, float[] rim, int deepest) {
   }

   public record Mark(float u, float v, float radius, int depth) {
   }

   @EventBusSubscriber(
      modid = "amuletmod"
   )
   public static final class SealEvents {
      private SealEvents() {
      }

      @SubscribeEvent
      public static void onLeftClickBlock(LeftClickBlock event) {
         Player player = event.getEntity();
         Level level = event.getLevel();
         if (!level.isClientSide() && player.isShiftKeyDown() && level.getBlockState(event.getPos()).is(SealBarrierBlock.block())) {
            SealEntity seal = SealEntity.at(level, event.getPos());
            if (seal != null && seal.isOwnedBy(player)) {
               seal.shatterNow();
            }
         }
      }
   }
}
