package com.amuletmod.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import com.amuletmod.registry.ModEntities;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.NeoForge;
import com.amuletmod.neo.event.BlockEvent.BreakEvent;
import org.jetbrains.annotations.Nullable;

public class BlockHoleEntity extends Entity {
   public static final int TRAVEL_TICKS = 15;
   public static final int CHARGE_TICKS = 100;
   public static final int ABSORB_TICKS = 300;
   public static final int COLLAPSE_TICKS = 15;
   private static final int MAX_FLYING_BLOCKS_PER_TICK = 12;
   private static final EntityDataAccessor<Integer> DATA_PHASE = SynchedEntityData.defineId(BlockHoleEntity.class, EntityDataSerializers.INT);
   private Vec3 from = Vec3.ZERO;
   private Vec3 to = Vec3.ZERO;
   private Block block = Blocks.AIR;
   private int radius;
   @Nullable
   private UUID ownerId;
   private int phaseTicks;
   private List<BlockPos> targets = List.of();
   private int processed;
   private int clientPhaseStart;

   public BlockHoleEntity(EntityType<? extends BlockHoleEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public BlockHoleEntity(ServerLevel level, ServerPlayer owner, Vec3 from, Vec3 to, Block block, int radius) {
      this((EntityType<? extends BlockHoleEntity>)ModEntities.BLOCK_HOLE.get(), level);
      this.ownerId = owner.getUUID();
      this.from = from;
      this.to = to;
      this.block = block;
      this.radius = radius;
      this.setPos(from);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_PHASE, BlockHoleEntity.Phase.TRAVEL.ordinal());
   }

   public BlockHoleEntity.Phase phase() {
      return BlockHoleEntity.Phase.values()[Math.floorMod((Integer)this.entityData.get(DATA_PHASE), BlockHoleEntity.Phase.values().length)];
   }

   private void setPhase(BlockHoleEntity.Phase phase) {
      this.entityData.set(DATA_PHASE, phase.ordinal());
      this.phaseTicks = 0;
   }

   public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
      super.onSyncedDataUpdated(key);
      if (DATA_PHASE.equals(key)) {
         this.clientPhaseStart = this.tickCount;
      }
   }

   public float clientPhaseAge(float partialTick) {
      return this.tickCount - this.clientPhaseStart + partialTick;
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.spawnClientParticles();
      } else {
         ServerPlayer owner = this.ownerId == null ? null : this.getServer().getPlayerList().getPlayer(this.ownerId);
         if (owner == null) {
            this.discard();
         } else {
            this.phaseTicks++;
            switch (this.phase()) {
               case TRAVEL:
                  float t = Math.min(1.0F, this.phaseTicks / 15.0F);
                  this.setPos(this.from.lerp(this.to, 1.0F - (1.0F - t) * (1.0F - t)));
                  if (this.phaseTicks >= 15) {
                     this.setPhase(BlockHoleEntity.Phase.CHARGE);
                     this.playSound(SoundEvents.BEACON_ACTIVATE, 1.5F);
                  }
                  break;
               case CHARGE:
                  if (this.phaseTicks >= 100) {
                     this.collectTargets();
                     this.setPhase(BlockHoleEntity.Phase.ABSORB);
                     this.playSound(SoundEvents.BEACON_POWER_SELECT, 0.8F);
                  }
                  break;
               case ABSORB:
                  this.absorbDueBlocks(owner);
                  if (this.phaseTicks >= 300) {
                     this.setPhase(BlockHoleEntity.Phase.COLLAPSE);
                  }
                  break;
               case COLLAPSE:
                  if (this.phaseTicks >= 15) {
                     ((ServerLevel)this.level()).sendParticles(ParticleTypes.FLASH, this.getX(), this.getY(), this.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
                     this.playSound(SoundEvents.BEACON_DEACTIVATE, 1.2F);
                     this.discard();
                  }
            }
         }
      }
   }

   private void collectTargets() {
      BlockPos center = this.blockPosition();
      double maxDistSqr = (this.radius + 0.5) * (this.radius + 0.5);
      List<BlockPos> found = new ArrayList<>();
      MutableBlockPos pos = new MutableBlockPos();

      for (int dx = -this.radius; dx <= this.radius; dx++) {
         for (int dy = -this.radius; dy <= this.radius; dy++) {
            for (int dz = -this.radius; dz <= this.radius; dz++) {
               if (!(dx * dx + dy * dy + dz * dz > maxDistSqr)) {
                  pos.setWithOffset(center, dx, dy, dz);
                  if (this.level().isInWorldBounds(pos) && this.level().getBlockState(pos).is(this.block)) {
                     found.add(pos.immutable());
                  }
               }
            }
         }
      }

      found.sort(Comparator.comparingDouble(p -> p.distSqr(center)));
      this.targets = found;
      this.processed = 0;
   }

   private void absorbDueBlocks(ServerPlayer owner) {
      if (!this.targets.isEmpty()) {
         ServerLevel level = (ServerLevel)this.level();
         float progress = Math.min(1.0F, this.phaseTicks / 300.0F);
         int due = Math.min(this.targets.size(), (int)Math.ceil(this.targets.size() * progress * progress));
         int flying = 0;

         while (this.processed < due) {
            BlockPos pos = this.targets.get(this.processed++);
            BlockState state = level.getBlockState(pos);
            if (state.is(this.block)
               && !state.hasBlockEntity()
               && !(state.getDestroySpeed(level, pos) < 0.0F)
               && !((BreakEvent)NeoForge.EVENT_BUS.post(new BreakEvent(level, pos, state, owner))).isCanceled()) {
               level.removeBlock(pos, false);
               if (flying++ < 12) {
                  level.addFreshEntity(new AbsorbedBlockEntity(level, pos, state, this.position()));
               } else {
                  level.sendParticles(
                     new BlockParticleOption(ParticleTypes.BLOCK, state), pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 4, 0.25, 0.25, 0.25, 0.05
                  );
               }
            }
         }

         if (flying > 0 && this.phaseTicks % 4 == 0) {
            this.playSound(SoundEvents.CHORUS_FRUIT_TELEPORT, 0.6F + progress);
         }
      }
   }

   private void playSound(SoundEvent sound, float pitch) {
      this.level().playSound(null, this.getX(), this.getY(), this.getZ(), sound, SoundSource.PLAYERS, 1.0F, pitch);
   }

   private void spawnClientParticles() {
      BlockHoleEntity.Phase phase = this.phase();
      if (phase == BlockHoleEntity.Phase.CHARGE || phase == BlockHoleEntity.Phase.ABSORB) {
         RandomSource random = this.random;
         int count = phase == BlockHoleEntity.Phase.CHARGE ? 2 : 4;
         double reach = phase == BlockHoleEntity.Phase.CHARGE ? 2.5 : 5.0;

         for (int i = 0; i < count; i++) {
            Vec3 offset = new Vec3(random.nextGaussian(), random.nextGaussian(), random.nextGaussian())
               .normalize()
               .scale(reach * (0.5 + random.nextDouble() * 0.5));
            this.level()
               .addParticle(
                  phase == BlockHoleEntity.Phase.CHARGE ? ParticleTypes.ENCHANT : ParticleTypes.PORTAL,
                  this.getX(),
                  this.getY(),
                  this.getZ(),
                  offset.x,
                  offset.y,
                  offset.z
               );
         }

         if (phase == BlockHoleEntity.Phase.ABSORB && random.nextInt(2) == 0) {
            this.level()
               .addParticle(
                  ParticleTypes.END_ROD,
                  this.getX() + random.nextGaussian() * 0.3,
                  this.getY() + random.nextGaussian() * 0.3,
                  this.getZ() + random.nextGaussian() * 0.3,
                  0.0,
                  0.0,
                  0.0
               );
         }
      }
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(ValueInput input) {
   }

   protected void addAdditionalSaveData(ValueOutput output) {
   }

   public boolean shouldRenderAtSqrDistance(double distanceSqr) {
      return distanceSqr < 16384.0;
   }

   public boolean isAttackable() {
      return false;
   }

   public boolean hurtServer(ServerLevel serverLevel, DamageSource source, float amount) {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean canBeCollidedWith() {
      return false;
   }

   public boolean isPickable() {
      return false;
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }

   public static enum Phase {
      TRAVEL,
      CHARGE,
      ABSORB,
      COLLAPSE;
   }
}
