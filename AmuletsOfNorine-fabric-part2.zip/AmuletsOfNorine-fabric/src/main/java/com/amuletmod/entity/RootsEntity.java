package com.amuletmod.entity;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.CameraShake;
import com.amuletmod.client.RootedClient;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Easing;
import com.amuletmod.util.Sounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class RootsEntity extends Entity {
   public static final int GROW_TICKS = 12;
   public static final int WITHER_TICKS = 16;
   private static final int YANK_TICKS = 8;
   private static final Identifier ROOTED_MODIFIER = AmuletMod.id("rooted");
   private static final EntityDataAccessor<Integer> DATA_VICTIM = SynchedEntityData.defineId(RootsEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_DURATION = SynchedEntityData.defineId(RootsEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Float> DATA_VICTIM_WIDTH = SynchedEntityData.defineId(RootsEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Float> DATA_VICTIM_HEIGHT = SynchedEntityData.defineId(RootsEntity.class, EntityDataSerializers.FLOAT);
   @Nullable
   private LivingEntity victim;
   @Nullable
   private Vec3 seizedAt;

   public RootsEntity(EntityType<? extends RootsEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public RootsEntity(ServerLevel level, LivingEntity victim, Vec3 anchor, int duration) {
      this((EntityType<? extends RootsEntity>)ModEntities.ROOTS.get(), level);
      this.victim = victim;
      this.moveTo(anchor.x, anchor.y, anchor.z, 0.0F, 0.0F);
      this.entityData.set(DATA_VICTIM, victim.getId());
      this.entityData.set(DATA_DURATION, duration);
      this.entityData.set(DATA_VICTIM_WIDTH, victim.getBbWidth());
      this.entityData.set(DATA_VICTIM_HEIGHT, victim.getBbHeight());
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_VICTIM, -1);
      builder.define(DATA_DURATION, 600);
      builder.define(DATA_VICTIM_WIDTH, 0.6F);
      builder.define(DATA_VICTIM_HEIGHT, 1.8F);
   }

   public int duration() {
      return (Integer)this.entityData.get(DATA_DURATION);
   }

   public float victimWidth() {
      return (Float)this.entityData.get(DATA_VICTIM_WIDTH);
   }

   public float victimHeight() {
      return (Float)this.entityData.get(DATA_VICTIM_HEIGHT);
   }

   public static boolean isHolding(Level level, LivingEntity entity) {
      return !level.getEntitiesOfClass(
            RootsEntity.class,
            entity.getBoundingBox().inflate(3.0),
            roots -> (Integer)roots.entityData.get(DATA_VICTIM) == entity.getId() && roots.tickCount < roots.duration() - 16
         )
         .isEmpty();
   }

   public float growth(float partialTick) {
      float age = this.tickCount + partialTick;
      float grow = Mth.clamp(age / 12.0F, 0.0F, 1.0F);
      float wither = Mth.clamp((age - (this.duration() - 16)) / 16.0F, 0.0F, 1.0F);
      return grow * (1.0F - wither);
   }

   public float witherProgress(float partialTick) {
      return Mth.clamp((this.tickCount + partialTick - (this.duration() - 16)) / 16.0F, 0.0F, 1.0F);
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         boolean holding = this.tickCount < this.duration() - 16;
         if (this.victim != null && (!this.victim.isAlive() || this.victim.isRemoved() || this.victim.level() != this.level())) {
            this.release();
            if (holding) {
               this.entityData.set(DATA_DURATION, this.tickCount + 16);
               holding = false;
            }
         }

         if (this.victim != null) {
            if (this.tickCount == 1) {
               this.seize(this.victim);
            }

            if (holding) {
               this.pin(this.victim);
            } else {
               this.release();
            }
         }

         if (this.tickCount == this.duration() - 16) {
            Sounds.play(this.level(), this.position(), SoundEvents.ROOTED_DIRT_BREAK, 1.0F, 0.7F);
            Sounds.play(this.level(), this.position(), SoundEvents.AZALEA_LEAVES_BREAK, 0.8F, 0.8F);
         } else if (holding && this.tickCount % 45 == 20) {
            Sounds.play(this.level(), this.position(), SoundEvents.MANGROVE_ROOTS_STEP, 0.6F, 0.6F + this.random.nextFloat() * 0.2F);
         }

         if (this.tickCount >= this.duration()) {
            this.discard();
         }
      }
   }

   private void seize(LivingEntity held) {
      this.seizedAt = held.position();
      held.stopRiding();
      AttributeInstance speed = held.getAttribute(Attributes.MOVEMENT_SPEED);
      if (speed != null && speed.getModifier(ROOTED_MODIFIER) == null) {
         speed.addTransientModifier(new AttributeModifier(ROOTED_MODIFIER, -1.0, Operation.ADD_MULTIPLIED_TOTAL));
      }

      if (held instanceof ServerPlayer player) {
         player.stopFallFlying();
      }

      Vec3 at = this.position();
      Sounds.play(this.level(), at, SoundEvents.ROOTED_DIRT_BREAK, 1.2F, 0.6F);
      Sounds.play(this.level(), at, SoundEvents.MANGROVE_ROOTS_BREAK, 1.2F, 0.7F);
      Sounds.play(this.level(), at, SoundEvents.WOOD_BREAK, 1.0F, 0.5F);
      Sounds.play(this.level(), at, SoundEvents.EVOKER_FANGS_ATTACK, 0.8F, 0.7F);
   }

   private void pin(LivingEntity held) {
      Vec3 anchor = this.position();
      Vec3 at = held.position();
      Vec3 goal = anchor;
      if (this.tickCount <= 8 && this.seizedAt != null) {
         goal = this.seizedAt.lerp(anchor, Easing.outCubic(this.tickCount / 8.0F));
      }

      held.fallDistance = 0.0F;
      if (held instanceof ServerPlayer player) {
         if (at.distanceToSqr(goal) > (this.tickCount <= 8 ? 0.04 : 0.36)) {
            player.connection.teleport(goal.x, goal.y, goal.z, player.getYRot(), player.getXRot());
         }
      } else {
         if (at.distanceToSqr(goal) > 0.0025) {
            held.teleportTo(goal.x, goal.y, goal.z);
         }

         held.setDeltaMovement(0.0, Math.min(0.0, held.getDeltaMovement().y), 0.0);
         if (held instanceof Mob mob) {
            mob.getNavigation().stop();
            mob.setJumping(false);
         }
      }
   }

   private void release() {
      if (this.victim != null) {
         AttributeInstance speed = this.victim.getAttribute(Attributes.MOVEMENT_SPEED);
         if (speed != null) {
            speed.removeModifier(ROOTED_MODIFIER);
         }

         this.victim = null;
      }
   }

   public void onRemovedFromLevel() {
      super.onRemovedFromLevel();
      if (!this.level().isClientSide()) {
         this.release();
      }
   }

   private void clientTick() {
      Vec3 at = this.position();
      float width = this.victimWidth();
      if (this.tickCount == 1) {
         BlockState ground = this.level().getBlockState(BlockPos.containing(at.x, at.y - 0.2, at.z));
         BlockParticleOption debris = new BlockParticleOption(
            ParticleTypes.BLOCK, !ground.isAir() && ground.getRenderShape() != RenderShape.INVISIBLE ? ground : Blocks.ROOTED_DIRT.defaultBlockState()
         );

         for (int i = 0; i < 30; i++) {
            double angle = this.random.nextDouble() * (float) (Math.PI * 2);
            double radius = width * 0.5 + 0.4 + this.random.nextDouble() * 1.2;
            this.level()
               .addParticle(
                  debris,
                  at.x + Math.cos(angle) * radius,
                  at.y + 0.1,
                  at.z + Math.sin(angle) * radius,
                  Math.cos(angle) * 0.1,
                  0.2 + this.random.nextDouble() * 0.25,
                  Math.sin(angle) * 0.1
               );
         }

         ClientSide.run(() -> () -> CameraShake.from(at, 0.8F, 12.0, 8));
      } else if (this.tickCount == this.duration() - 16 + 2) {
         BlockParticleOption bark = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.MANGROVE_ROOTS.defaultBlockState());

         for (int i = 0; i < 24; i++) {
            this.level()
               .addParticle(
                  bark,
                  at.x + this.random.nextGaussian() * width * 0.5,
                  at.y + this.random.nextDouble() * this.victimHeight(),
                  at.z + this.random.nextGaussian() * width * 0.5,
                  0.0,
                  0.0,
                  0.0
               );
         }
      } else if (this.tickCount < this.duration() - 16 && this.random.nextInt(6) == 0) {
         this.level()
            .addParticle(
               ParticleTypes.SPORE_BLOSSOM_AIR,
               at.x + this.random.nextGaussian() * 0.6,
               at.y + this.random.nextDouble() * this.victimHeight(),
               at.z + this.random.nextGaussian() * 0.6,
               0.0,
               0.01,
               0.0
            );
      }

      int victimId = (Integer)this.entityData.get(DATA_VICTIM);
      if (this.tickCount < this.duration() - 16) {
         ClientSide.run(() -> () -> RootedClient.hold(victimId));
      }
   }

   public AABB getBoundingBoxForCulling() {
      double reach = this.victimWidth() * 0.5 + 2.0;
      return new AABB(
         this.getX() - reach, this.getY() - 1.0, this.getZ() - reach, this.getX() + reach, this.getY() + this.victimHeight() + 1.0, this.getZ() + reach
      );
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean hurt(DamageSource source, float amount) {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }
}
