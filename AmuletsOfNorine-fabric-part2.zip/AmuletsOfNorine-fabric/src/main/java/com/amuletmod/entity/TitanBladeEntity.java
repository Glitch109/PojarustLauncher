package com.amuletmod.entity;

import com.amuletmod.client.TitanBladeClient;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Sounds;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.amuletmod.neo.IEntityWithComplexSpawn;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class TitanBladeEntity extends Entity implements IEntityWithComplexSpawn {
   public static final int RISE_TICKS = 8;
   public static final int CIRCLE_TICKS = 18;
   public static final int LODGE_TICKS = 70;
   public static final int DISSOLVE_TICKS = 16;
   private static final int GONE_TICKS = 3;
   private static final int STRAY_TICKS = 600;
   public static final float EMBED = 0.35F;
   public static final float HALF_LENGTH = 0.62F;
   public static final byte HOVERING = 0;
   public static final byte TURNING = 1;
   public static final byte LODGED = 2;
   public static final byte GONE = 3;
   public static final byte DISSOLVING = 4;
   private static final EntityDataAccessor<Vector3f> DATA_FROM = SynchedEntityData.defineId(TitanBladeEntity.class, EntityDataSerializers.VECTOR3);
   private static final EntityDataAccessor<Vector3f> DATA_TO = SynchedEntityData.defineId(TitanBladeEntity.class, EntityDataSerializers.VECTOR3);
   private static final EntityDataAccessor<Byte> DATA_FACE = SynchedEntityData.defineId(TitanBladeEntity.class, EntityDataSerializers.BYTE);
   private static final EntityDataAccessor<Byte> DATA_PHASE = SynchedEntityData.defineId(TitanBladeEntity.class, EntityDataSerializers.BYTE);
   private int ownerId = -1;
   private Vec3 offset = Vec3.ZERO;
   private ItemStack weapon = ItemStack.EMPTY;
   private int slot;
   private float attack;
   private int phaseAt;

   public TitanBladeEntity(EntityType<? extends TitanBladeEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public TitanBladeEntity(ServerLevel level, ServerPlayer owner, ItemStack weapon, Vec3 offset, float attack, int slot) {
      this((EntityType<? extends TitanBladeEntity>)ModEntities.TITAN_BLADE.get(), level);
      this.ownerId = owner.getId();
      this.offset = offset;
      this.weapon = weapon.copyWithCount(1);
      this.attack = attack;
      this.slot = slot;
      Vec3 at = place(owner.position(), owner.getYRot(), offset);
      this.moveTo(at.x, at.y, at.z, 0.0F, 0.0F);
   }

   public static Vec3 place(Vec3 feet, float yaw, Vec3 offset) {
      float turn = yaw * (float) (Math.PI / 180.0);
      double sin = Mth.sin(turn);
      double cos = Mth.cos(turn);
      return feet.add(-cos * offset.x - sin * offset.z, offset.y, -sin * offset.x + cos * offset.z);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_FROM, new Vector3f());
      builder.define(DATA_TO, new Vector3f());
      builder.define(DATA_FACE, (byte)-1);
      builder.define(DATA_PHASE, (byte)0);
   }

   public void turn() {
      this.setPhase((byte)1);
   }

   public void fire(Vec3 from, Vec3 to, @Nullable Direction face) {
      this.entityData.set(DATA_FROM, from.toVector3f());
      this.entityData.set(DATA_TO, to.toVector3f());
      this.entityData.set(DATA_FACE, (byte)(face == null ? -1 : face.get3DDataValue()));
      this.setPhase((byte)(face == null ? 3 : 2));
      if (face != null) {
         this.setPos(to);
      }
   }

   private void setPhase(byte phase) {
      this.entityData.set(DATA_PHASE, phase);
      this.phaseAt = this.tickCount;
   }

   public byte phase() {
      return (Byte)this.entityData.get(DATA_PHASE);
   }

   public float sincePhase(float age) {
      return age - this.phaseAt;
   }

   public boolean fired() {
      return this.phase() >= 2;
   }

   public ItemStack weapon() {
      return this.weapon;
   }

   public float attack() {
      return this.attack;
   }

   public int slot() {
      return this.slot;
   }

   public int ownerId() {
      return this.ownerId;
   }

   public Vec3 offset() {
      return this.offset;
   }

   public Vec3 from() {
      return new Vec3((Vector3f)this.entityData.get(DATA_FROM));
   }

   public Vec3 to() {
      return new Vec3((Vector3f)this.entityData.get(DATA_TO));
   }

   public Vec3 heading() {
      Vec3 heading = this.to().subtract(this.from());
      return heading.lengthSqr() < 1.0E-6 ? new Vec3(0.0, -1.0, 0.0) : heading.normalize();
   }

   @Nullable
   public Direction face() {
      byte face = (Byte)this.entityData.get(DATA_FACE);
      return face < 0 ? null : Direction.from3DDataValue(face);
   }

   @Nullable
   public Entity owner() {
      Entity owner = this.level().getEntity(this.ownerId);
      return owner != null && owner.isAlive() ? owner : null;
   }

   public void tick() {
      super.tick();
      byte phase = this.phase();
      if (phase <= 1) {
         Entity owner = this.owner();
         if (owner != null) {
            this.setPos(place(owner.position(), owner.getYRot(), this.offset));
         } else if (!this.level().isClientSide()) {
            this.setPhase((byte)4);
         }
      }

      if (this.level().isClientSide()) {
         ClientSide.run(() -> () -> TitanBladeClient.tickBlade(this));
      } else {
         float since = this.sincePhase(this.tickCount);
         switch (phase) {
            case 0:
               if (this.tickCount > 600) {
                  this.setPhase((byte)4);
               }
            case 1:
            default:
               break;
            case 2:
               if (since >= 70.0F) {
                  this.setPhase((byte)4);
                  Sounds.play(this.level(), this.position(), SoundEvents.AMETHYST_CLUSTER_BREAK, 0.5F, 1.6F);
               }
               break;
            case 3:
               if (since >= 3.0F) {
                  this.discard();
               }
               break;
            case 4:
               if (since >= 16.0F) {
                  this.discard();
               }
         }
      }
   }

   public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
      super.onSyncedDataUpdated(key);
      if (key.equals(DATA_PHASE) && this.level().isClientSide()) {
         this.phaseAt = this.tickCount;
         byte phase = this.phase();
         if ((phase == 2 || phase == 3) && this.tickCount > 0) {
            ClientSide.run(() -> () -> TitanBladeClient.fired(this));
         }
      }
   }

   public AABB getBoundingBoxForCulling() {
      return this.getBoundingBox().inflate(1.5);
   }

   public boolean shouldRenderAtSqrDistance(double distance) {
      double range = 128.0 * getViewScale();
      return distance < range * range;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
   }

   public void writeSpawnData(RegistryFriendlyByteBuf buffer) {
      buffer.writeVarInt(this.ownerId);
      buffer.writeDouble(this.offset.x);
      buffer.writeDouble(this.offset.y);
      buffer.writeDouble(this.offset.z);
      ItemStack.OPTIONAL_STREAM_CODEC.encode(buffer, this.weapon);
      buffer.writeByte(this.slot);
   }

   public void readSpawnData(RegistryFriendlyByteBuf buffer) {
      this.ownerId = buffer.readVarInt();
      this.offset = new Vec3(buffer.readDouble(), buffer.readDouble(), buffer.readDouble());
      this.weapon = (ItemStack)ItemStack.OPTIONAL_STREAM_CODEC.decode(buffer);
      this.slot = buffer.readByte();
   }
}
