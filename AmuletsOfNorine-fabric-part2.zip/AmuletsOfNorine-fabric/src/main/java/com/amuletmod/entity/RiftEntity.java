package com.amuletmod.entity;

import com.amuletmod.amulet.ability.rift.RiftDestinations;
import com.amuletmod.amulet.ability.rift.RiftKind;
import com.amuletmod.amulet.ability.rift.RiftTeleporter;
import com.amuletmod.client.CameraShake;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.util.ClientSide;
import com.amuletmod.util.Easing;
import com.amuletmod.util.ServerScheduler;
import com.amuletmod.util.Sounds;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class RiftEntity extends Entity {
   public static final float HEIGHT = 3.2F;
   public static final float HALF_WIDTH = 0.95F;
   public static final int OPEN_TICKS = 14;
   public static final int CLOSE_TICKS = 16;
   private static final int ENTRANCE_TEAR_TICK = 10;
   private static final int EXIT_TEAR_TICK = 2;
   private static final int ENTRANCE_OPEN_DURATION = 200;
   private static final int EXIT_OPEN_DURATION = 24;
   private static final int STRAGGLER_TICKS = 60;
   private static final EntityDataAccessor<Byte> DATA_KIND = SynchedEntityData.defineId(RiftEntity.class, EntityDataSerializers.BYTE);
   private static final EntityDataAccessor<Boolean> DATA_EXIT = SynchedEntityData.defineId(RiftEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Integer> DATA_CLOSE_AT = SynchedEntityData.defineId(RiftEntity.class, EntityDataSerializers.INT);
   @Nullable
   private UUID ownerId;
   private final Set<UUID> travellers = new HashSet<>();

   public RiftEntity(EntityType<? extends RiftEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   private RiftEntity(ServerLevel level, Vec3 pos, float yaw, RiftKind kind, boolean exit) {
      this((EntityType<? extends RiftEntity>)ModEntities.RIFT.get(), level);
      this.moveTo(pos.x, pos.y, pos.z, yaw, 0.0F);
      this.entityData.set(DATA_KIND, (byte)kind.ordinal());
      this.entityData.set(DATA_EXIT, exit);
      this.entityData.set(DATA_CLOSE_AT, this.tearTick() + 14 + (exit ? 24 : 200));
   }

   public static RiftEntity entrance(ServerLevel level, Vec3 pos, float yaw, RiftKind kind, ServerPlayer owner) {
      RiftEntity rift = new RiftEntity(level, pos, yaw, kind, false);
      rift.ownerId = owner.getUUID();
      return rift;
   }

   public static RiftEntity exit(ServerLevel level, Vec3 pos, float yaw, RiftKind kind) {
      return new RiftEntity(level, pos, yaw, kind, true);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_KIND, (byte)0);
      builder.define(DATA_EXIT, false);
      builder.define(DATA_CLOSE_AT, 0);
   }

   public RiftKind kind() {
      return RiftKind.byId((Byte)this.entityData.get(DATA_KIND));
   }

   public boolean isExit() {
      return (Boolean)this.entityData.get(DATA_EXIT);
   }

   public int tearTick() {
      return this.isExit() ? 2 : 10;
   }

   public int closeAt() {
      return (Integer)this.entityData.get(DATA_CLOSE_AT);
   }

   public static float halfWidthAt(float v) {
      return !(v <= 0.0F) && !(v >= 1.0F) ? 0.95F * (float)Math.pow(Mth.sin(v * (float) Math.PI), 0.7) : 0.0F;
   }

   public float openness(float partialTick) {
      float t = this.tickCount + partialTick;
      float opening = (t - this.tearTick()) / 14.0F;
      if (opening <= 0.0F) {
         return 0.0F;
      } else {
         float open = opening >= 1.0F ? 1.0F : Easing.outBack(opening);
         float closing = (t - this.closeAt()) / 16.0F;
         return closing <= 0.0F ? open : open * (1.0F - Easing.smoothstep(0.0F, 0.65F, closing));
      }
   }

   public float seamLength(float partialTick) {
      float t = this.tickCount + partialTick;
      float closing = (t - this.closeAt()) / 16.0F;
      return closing > 0.0F ? 1.0F - Easing.smoothstep(0.55F, 1.0F, closing) : Easing.smoothstep(0.0F, 1.0F, t / this.tearTick());
   }

   public boolean isPassable() {
      return !this.isExit() && this.tickCount >= this.tearTick() + 7 && this.tickCount < this.closeAt();
   }

   public Vec3 forward() {
      return Vec3.directionFromRotation(0.0F, this.getYRot());
   }

   public Vec3 pointOnPlane(double side, double height) {
      float yaw = this.getYRot() * (float) (Math.PI / 180.0);
      return new Vec3(this.getX() + Mth.cos(yaw) * side, this.getY() + height, this.getZ() + Mth.sin(yaw) * side);
   }

   public Vec3 center() {
      return this.pointOnPlane(0.0, 1.6F);
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide()) {
         this.clientTick();
      } else {
         if (this.tickCount == 1 && !this.isExit()) {
            this.playOpeningSounds();
         }

         if (this.tickCount == this.tearTick()) {
            this.playTearSounds();
         }

         if (this.tickCount == this.closeAt()) {
            this.playClosingSounds();
         }

         if (this.tickCount >= this.closeAt() + 16) {
            this.discard();
         } else {
            if (this.isPassable()) {
               this.pullInTravellers();
            }
         }
      }
   }

   private void pullInTravellers() {
      AABB area = new AABB(this.getX() - 2.0, this.getY() - 1.0, this.getZ() - 2.0, this.getX() + 2.0, this.getY() + 3.2F + 1.0, this.getZ() + 2.0);

      for (ServerPlayer player : this.level().getEntitiesOfClass(ServerPlayer.class, area, this::isStepping)) {
         this.travellers.add(player.getUUID());
         ServerScheduler.schedule(1, () -> this.carry(player));
      }
   }

   private boolean isStepping(ServerPlayer player) {
      if (player.isAlive() && !player.isSpectator() && !this.travellers.contains(player.getUUID())) {
         Vec3 forward = this.forward();
         Vec3 rel = player.position().add(0.0, player.getBbHeight() * 0.5, 0.0).subtract(this.position());
         double depth = rel.x * forward.x + rel.z * forward.z;
         double side = rel.x * forward.z - rel.z * forward.x;
         return !(Math.abs(depth) > 0.5) && !(rel.y < 0.0) && !(rel.y > 3.2F)
            ? Math.abs(side) < Math.max(0.35F, halfWidthAt((float)(rel.y / 3.2F)) * this.openness(0.0F))
            : false;
      } else {
         return false;
      }
   }

   private void carry(ServerPlayer player) {
      if (player.isAlive() && !player.isRemoved() && player.level() == this.level()) {
         ServerLevel source = (ServerLevel)this.level();
         ServerLevel target = RiftDestinations.targetLevel(player.server, this.kind());
         if (target != null && target != source) {
            Vec3 departure = player.position();
            float yaw = player.getYRot();
            Vec3 arrival = RiftDestinations.arrival(player, target);
            player.stopRiding();
            if (player.changeDimension(RiftTeleporter.to(target, arrival, yaw, player)) != null) {
               source.sendParticles(ParticleTypes.REVERSE_PORTAL, departure.x, departure.y + 1.0, departure.z, 40, 0.3, 0.7, 0.3, 0.08);
               Sounds.play(source, departure, SoundEvents.ILLUSIONER_MIRROR_MOVE, 1.0F, 0.7F);
               Vec3 behind = arrival.subtract(Vec3.directionFromRotation(0.0F, yaw).scale(1.2));
               target.addFreshEntity(exit(target, behind, yaw, RiftKind.of(source.dimension())));
               Sounds.play(target, arrival, SoundEvents.ILLUSIONER_MIRROR_MOVE, 1.0F, 0.9F);
               if (player.getUUID().equals(this.ownerId) && !this.isRemoved() && this.closeAt() > this.tickCount + 60) {
                  this.entityData.set(DATA_CLOSE_AT, this.tickCount + 60);
               }
            }
         }
      }
   }

   private void playOpeningSounds() {
      Vec3 at = this.center();
      Sounds.play(this.level(), at, SoundEvents.WARDEN_SONIC_CHARGE, 0.8F, 1.4F);
      Sounds.play(this.level(), at, SoundEvents.PORTAL_TRIGGER, 0.5F, 1.7F);
   }

   private void playTearSounds() {
      Vec3 at = this.center();
      float volume = this.isExit() ? 0.55F : 1.0F;
      Sounds.play(this.level(), at, SoundEvents.GLASS_BREAK, volume, 0.5F);
      Sounds.play(this.level(), at, SoundEvents.LIGHTNING_BOLT_IMPACT, 0.7F * volume, 0.6F);
      switch (this.kind()) {
         case NETHER:
            Sounds.play(this.level(), at, SoundEvents.RESPAWN_ANCHOR_SET_SPAWN, volume, 0.6F);
            Sounds.play(this.level(), at, SoundEvents.BLAZE_SHOOT, 0.8F * volume, 0.5F);
            Sounds.play(this.level(), at, SoundEvents.FIRECHARGE_USE, 0.8F * volume, 0.6F);
            break;
         case END:
            Sounds.play(this.level(), at, SoundEvents.END_PORTAL_SPAWN, 0.45F * volume, 1.3F);
            Sounds.play(this.level(), at, SoundEvents.ENDER_EYE_DEATH, volume, 0.6F);
            Sounds.play(this.level(), at, SoundEvents.ENDER_DRAGON_GROWL, 0.25F * volume, 1.6F);
            break;
         case OVERWORLD:
            Sounds.play(this.level(), at, SoundEvents.BEACON_ACTIVATE, volume, 1.3F);
            Sounds.play(this.level(), at, SoundEvents.AMETHYST_BLOCK_RESONATE, volume, 0.7F);
            Sounds.play(this.level(), at, SoundEvents.BELL_RESONATE, 0.6F * volume, 1.5F);
      }
   }

   private void playClosingSounds() {
      Vec3 at = this.center();
      float volume = this.isExit() ? 0.5F : 1.0F;
      Sounds.play(this.level(), at, SoundEvents.BEACON_DEACTIVATE, 0.8F * volume, 1.4F);
      switch (this.kind()) {
         case NETHER:
            Sounds.play(this.level(), at, SoundEvents.FIRE_EXTINGUISH, 0.7F * volume, 0.6F);
            break;
         case END:
            Sounds.play(this.level(), at, SoundEvents.CHORUS_FRUIT_TELEPORT, 0.9F * volume, 0.5F);
            break;
         case OVERWORLD:
            Sounds.play(this.level(), at, SoundEvents.AMETHYST_BLOCK_CHIME, 1.2F * volume, 0.6F);
      }
   }

   private void clientTick() {
      RandomSource random = this.random;
      RiftKind kind = this.kind();
      float open = this.openness(0.0F);
      if (this.tickCount < this.tearTick()) {
         this.seamSparks(random);
      }

      if (this.tickCount == this.tearTick()) {
         this.burst(kind, random);
         float strength = this.isExit() ? 0.6F : 2.2F;
         Vec3 center = this.center();
         ClientSide.run(() -> () -> CameraShake.from(center, strength, 24.0, 18));
      }

      if (open > 0.05F) {
         this.ambientParticles(kind, open, random);
      }

      if (open > 0.5F && this.tickCount % 40 == 0) {
         this.ambientSound(kind, random);
      }

      if (this.tickCount == this.closeAt() + 10) {
         this.implode(kind, random);
      }
   }

   private Vec3 randomEdgePoint(RandomSource random, float open) {
      float v = 0.05F + random.nextFloat() * 0.9F;
      float side = halfWidthAt(v) * open * (random.nextBoolean() ? 1.0F : -1.0F);
      return this.pointOnPlane(side, v * 3.2F);
   }

   private Vec3 randomInsidePoint(RandomSource random, float open) {
      float v = 0.15F + random.nextFloat() * 0.7F;
      float side = halfWidthAt(v) * open * 0.8F * (random.nextFloat() * 2.0F - 1.0F);
      return this.pointOnPlane(side, v * 3.2F);
   }

   private void ambientMote(RandomSource random, ParticleOptions particle, double radius) {
      Vec3 c = this.center();
      this.level()
         .addParticle(
            particle,
            c.x + (random.nextDouble() * 2.0 - 1.0) * radius,
            c.y + (random.nextDouble() * 2.0 - 1.0) * radius * 0.8,
            c.z + (random.nextDouble() * 2.0 - 1.0) * radius,
            0.0,
            0.0,
            0.0
         );
   }

   private void addParticle(ParticleOptions particle, Vec3 at, double dx, double dy, double dz) {
      this.level().addParticle(particle, at.x, at.y, at.z, dx, dy, dz);
   }

   private void seamSparks(RandomSource random) {
      float seam = this.seamLength(0.0F);

      for (int i = 0; i < 2; i++) {
         Vec3 p = this.pointOnPlane(0.0, 3.2F * (0.5 + (random.nextDouble() - 0.5) * seam));
         this.addParticle(ParticleTypes.ELECTRIC_SPARK, p, random.nextGaussian() * 0.08, random.nextGaussian() * 0.08, random.nextGaussian() * 0.08);
      }

      if (random.nextBoolean()) {
         Vec3 p = this.pointOnPlane(0.0, 3.2F * (0.5 + (random.nextDouble() - 0.5) * seam));
         this.addParticle(ParticleTypes.END_ROD, p, random.nextGaussian() * 0.02, random.nextGaussian() * 0.02, random.nextGaussian() * 0.02);
      }
   }

   private void burst(RiftKind kind, RandomSource random) {
      Vec3 c = this.center();
      this.addParticle(ParticleTypes.FLASH, c, 0.0, 0.0, 0.0);
      int count = this.isExit() ? 20 : 48;

      for (int i = 0; i < count; i++) {
         Vec3 p = this.pointOnPlane(0.0, random.nextDouble() * 3.2F);

         ParticleOptions particle = switch (kind) {
            case NETHER -> i % 3 == 0 ? ParticleTypes.LAVA : (i % 3 == 1 ? ParticleTypes.FLAME : ParticleTypes.LARGE_SMOKE);
            case END -> i % 2 == 0 ? ParticleTypes.END_ROD : ParticleTypes.REVERSE_PORTAL;
            case OVERWORLD -> i % 3 == 0 ? ParticleTypes.END_ROD : (i % 3 == 1 ? ParticleTypes.CHERRY_LEAVES : ParticleTypes.HAPPY_VILLAGER);
         };
         this.addParticle(particle, p, random.nextGaussian() * 0.18, random.nextGaussian() * 0.1, random.nextGaussian() * 0.18);
      }

      BlockState ground = this.level().getBlockState(BlockPos.containing(this.getX(), this.getY() - 0.5, this.getZ()));
      if (!ground.isAir() && ground.getRenderShape() != RenderShape.INVISIBLE) {
         BlockParticleOption debris = new BlockParticleOption(ParticleTypes.BLOCK, ground);

         for (int i = 0; i < 28; i++) {
            double angle = i * (float) (Math.PI * 2) / 28.0;
            this.level().addParticle(debris, this.getX(), this.getY() + 0.1, this.getZ(), Math.cos(angle) * 0.4, 0.18, Math.sin(angle) * 0.4);
         }
      }
   }

   private void ambientParticles(RiftKind kind, float open, RandomSource random) {
      Vec3 forward = this.forward();
      double through = random.nextBoolean() ? 1.0 : -1.0;
      switch (kind) {
         case NETHER:
            for (int i = 0; i < 2; i++) {
               this.addParticle(ParticleTypes.FLAME, this.randomEdgePoint(random, open), random.nextGaussian() * 0.015, 0.025, random.nextGaussian() * 0.015);
            }

            this.addParticle(ParticleTypes.SMALL_FLAME, this.randomInsidePoint(random, open), forward.x * 0.07 * through, 0.01, forward.z * 0.07 * through);
            if (random.nextInt(8) == 0) {
               this.addParticle(ParticleTypes.LAVA, this.randomEdgePoint(random, open), 0.0, 0.0, 0.0);
            }

            if (random.nextInt(3) == 0) {
               this.addParticle(ParticleTypes.LARGE_SMOKE, this.pointOnPlane(0.0, 2.9440000438690186), 0.0, 0.05, 0.0);
            }

            this.ambientMote(random, ParticleTypes.ASH, 3.0);
            this.ambientMote(random, ParticleTypes.ASH, 3.0);
            this.ambientMote(random, ParticleTypes.CRIMSON_SPORE, 3.0);
            break;
         case END:
            for (int i = 0; i < 3; i++) {
               this.addParticle(
                  ParticleTypes.PORTAL,
                  this.randomInsidePoint(random, open),
                  random.nextGaussian() * 1.2,
                  random.nextGaussian() * 0.8,
                  random.nextGaussian() * 1.2
               );
            }

            if (random.nextBoolean()) {
               this.addParticle(
                  ParticleTypes.END_ROD,
                  this.randomEdgePoint(random, open),
                  random.nextGaussian() * 0.02,
                  random.nextGaussian() * 0.02,
                  random.nextGaussian() * 0.02
               );
            }

            if (random.nextInt(3) == 0) {
               this.addParticle(ParticleTypes.REVERSE_PORTAL, this.randomInsidePoint(random, open), forward.x * 0.05 * through, 0.0, forward.z * 0.05 * through);
            }

            if (random.nextInt(4) == 0) {
               this.ambientMote(random, ParticleTypes.DRAGON_BREATH, 2.5);
            }
            break;
         case OVERWORLD:
            if (random.nextBoolean()) {
               this.addParticle(ParticleTypes.CHERRY_LEAVES, this.randomInsidePoint(random, open), 0.0, 0.0, 0.0);
            }

            if (random.nextBoolean()) {
               this.addParticle(ParticleTypes.HAPPY_VILLAGER, this.randomEdgePoint(random, open), 0.0, 0.0, 0.0);
            }

            if (random.nextInt(3) == 0) {
               this.addParticle(ParticleTypes.END_ROD, this.randomEdgePoint(random, open), random.nextGaussian() * 0.015, 0.02, random.nextGaussian() * 0.015);
            }

            this.ambientMote(random, ParticleTypes.SPORE_BLOSSOM_AIR, 3.0);
            if (random.nextInt(6) == 0) {
               this.addParticle(ParticleTypes.CLOUD, this.pointOnPlane(0.0, 0.1), random.nextGaussian() * 0.03, 0.01, random.nextGaussian() * 0.03);
            }
      }
   }

   private void ambientSound(RiftKind kind, RandomSource random) {
      Vec3 c = this.center();
      switch (kind) {
         case NETHER:
            this.localSound(c, SoundEvents.PORTAL_AMBIENT, 0.4F, 0.5F + random.nextFloat() * 0.1F);
            this.localSound(c, SoundEvents.FIRE_AMBIENT, 1.0F, 0.7F);
            break;
         case END:
            this.localSound(c, SoundEvents.PORTAL_AMBIENT, 0.35F, 1.2F + random.nextFloat() * 0.1F);
            this.localSound(c, SoundEvents.BEACON_AMBIENT, 0.6F, 0.8F);
            break;
         case OVERWORLD:
            this.localSound(c, SoundEvents.BEACON_AMBIENT, 0.8F, 1.4F);
            this.localSound(c, SoundEvents.AMETHYST_BLOCK_CHIME, 0.6F, 0.8F + random.nextFloat() * 0.3F);
      }
   }

   private void localSound(Vec3 at, SoundEvent sound, float volume, float pitch) {
      this.level().playLocalSound(at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, pitch, false);
   }

   private void implode(RiftKind kind, RandomSource random) {
      Vec3 c = this.center();

      for (int i = 0; i < 30; i++) {
         Vec3 dir = new Vec3(random.nextGaussian(), random.nextGaussian(), random.nextGaussian()).normalize().scale(1.2 + random.nextDouble() * 0.8);
         this.level().addParticle(ParticleTypes.END_ROD, c.x + dir.x, c.y + dir.y * 1.4, c.z + dir.z, -dir.x * 0.05, -dir.y * 0.07, -dir.z * 0.05);
      }

      if (kind == RiftKind.NETHER) {
         for (int i = 0; i < 6; i++) {
            this.addParticle(ParticleTypes.LARGE_SMOKE, c, random.nextGaussian() * 0.04, 0.03, random.nextGaussian() * 0.04);
         }
      }
   }

   public AABB getBoundingBoxForCulling() {
      return new AABB(this.getX() - 2.5, this.getY() - 1.0, this.getZ() - 2.5, this.getX() + 2.5, this.getY() + 3.2F + 1.0, this.getZ() + 2.5);
   }

   public boolean shouldRenderAtSqrDistance(double distanceSqr) {
      return distanceSqr < 16384.0;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
   }

   public boolean isAttackable() {
      return false;
   }

   public boolean hurt(DamageSource source, float amount) {
      return false;
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean canBeCollidedWith() {
      return false;
   }

   protected boolean canRide(Entity vehicle) {
      return false;
   }
}
