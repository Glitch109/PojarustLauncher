package com.amuletmod.mixin;

import com.amuletmod.amulet.ability.stealth.Stealth;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ServerPlayer.class})
public abstract class ServerPlayerMixin {
   @Inject(
      method = {"broadcastToPlayer"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void amuletmod$hideWhileStealthed(ServerPlayer viewer, CallbackInfoReturnable<Boolean> cir) {
      ServerPlayer self = (ServerPlayer)this;
      if (viewer != self && Stealth.isStealthed(self)) {
         cir.setReturnValue(false);
      }
   }
}
