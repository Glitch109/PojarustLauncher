package com.amuletmod.mixin;

import com.amuletmod.neo.NeoBus;
import com.amuletmod.neo.event.EnderManAngerEvent;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EnderMan.class)
public abstract class EnderManMixin {
	@Inject(method = "isLookingAtMe", at = @At("HEAD"), cancellable = true)
	private void amuletmod$anger(Player player, CallbackInfoReturnable<Boolean> cir) {
		if (NeoBus.EVENT_BUS.post(new EnderManAngerEvent((EnderMan) (Object) this, player)).isCanceled()) cir.setReturnValue(false);
	}
}
