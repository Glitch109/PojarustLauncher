package com.amuletmod.mixin;

import com.amuletmod.neo.NeoBus;
import com.amuletmod.neo.event.LivingDropsEvent;
import com.amuletmod.neo.event.LivingFallEvent;
import com.amuletmod.neo.event.LivingHealEvent;
import com.amuletmod.neo.event.LivingIncomingDamageEvent;
import com.amuletmod.neo.event.MobEffectEvent;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;

/** Re-creates the NeoForge living-entity events the mod listens to. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
	@WrapMethod(method = "hurtServer")
	private boolean amuletmod$incomingDamage(ServerLevel level, DamageSource source, float amount, Operation<Boolean> original) {
		LivingIncomingDamageEvent event = NeoBus.EVENT_BUS.post(new LivingIncomingDamageEvent((LivingEntity) (Object) this, source, amount));
		if (event.isCanceled()) return false;
		return original.call(level, source, event.getAmount());
	}

	@WrapMethod(method = "heal")
	private void amuletmod$heal(float amount, Operation<Void> original) {
		LivingHealEvent event = NeoBus.EVENT_BUS.post(new LivingHealEvent((LivingEntity) (Object) this, amount));
		if (event.isCanceled()) return;
		original.call(event.getAmount());
	}

	@WrapMethod(method = "causeFallDamage")
	private boolean amuletmod$fall(double distance, float multiplier, DamageSource source, Operation<Boolean> original) {
		LivingFallEvent event = NeoBus.EVENT_BUS.post(new LivingFallEvent((LivingEntity) (Object) this, distance, multiplier));
		if (event.isCanceled()) return false;
		return original.call(event.getDistance(), event.getDamageMultiplier(), source);
	}

	@WrapMethod(method = "dropAllDeathLoot")
	private void amuletmod$drops(ServerLevel level, DamageSource source, Operation<Void> original) {
		LivingDropsEvent event = NeoBus.EVENT_BUS.post(new LivingDropsEvent((LivingEntity) (Object) this, source));
		if (event.isCanceled()) return;
		original.call(level, source);
	}

	@WrapMethod(method = "addEffect(Lnet/minecraft/world/effect/MobEffectInstance;Lnet/minecraft/world/entity/Entity;)Z")
	private boolean amuletmod$effectAdded(MobEffectInstance effect, @Nullable Entity source, Operation<Boolean> original) {
		boolean added = original.call(effect, source);
		if (added) NeoBus.EVENT_BUS.post(new MobEffectEvent.Added((LivingEntity) (Object) this, effect, source));
		return added;
	}
}
