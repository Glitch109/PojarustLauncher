package com.amuletmod.mixin;

import com.amuletmod.neo.NeoBus;
import com.amuletmod.neo.event.ProjectileImpactEvent;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Projectile.class)
public abstract class ProjectileMixin {
	@Inject(method = "onHit", at = @At("HEAD"), cancellable = true)
	private void amuletmod$impact(HitResult hit, CallbackInfo ci) {
		if (hit.getType() == HitResult.Type.MISS) return;
		if (NeoBus.EVENT_BUS.post(new ProjectileImpactEvent((Projectile) (Object) this, hit)).isCanceled()) ci.cancel();
	}
}
