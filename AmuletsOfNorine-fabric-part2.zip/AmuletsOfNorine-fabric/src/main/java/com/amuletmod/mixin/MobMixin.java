package com.amuletmod.mixin;

import com.amuletmod.neo.NeoBus;
import com.amuletmod.neo.event.LivingChangeTargetEvent;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Mob.class)
public abstract class MobMixin {
	@WrapMethod(method = "setTarget")
	private void amuletmod$changeTarget(@Nullable LivingEntity target, Operation<Void> original) {
		LivingChangeTargetEvent event = NeoBus.EVENT_BUS.post(new LivingChangeTargetEvent((Mob) (Object) this, target));
		if (event.isCanceled()) return;
		original.call(event.getNewAboutToBeSetTarget());
	}
}
