# Sound effects

Custom sounds for Amulets of Norine. Drop `.ogg` files into the folder for what makes the noise; they're wired up in
code afterwards (see "Hooking a sound up" below). Until then a file here does nothing, so it's safe to add sounds
before anything plays them.

## Folders

```
sounds/
  amulet/<code name>/   one folder per amulet: its abilities, fists, summons, rites
  block/<block id>/     blocks (Jeweler's Bench, Runic Obelisk)
  entity/<entity id>/   creatures and projectiles that aren't tied to one amulet
  ui/                   screens, menus, notifications
```

Only `amulet/titan/` and `amulet/aegis/` exist so far (each with a README of its sounds); make the others when the
first sound for them arrives.

### Amulet code names

An amulet's folder is named after its **item id** with `_amulet` dropped, not after its display name:
`titan_amulet` -> `amulet/titan/`. The display name ("Titan Amulet") lives only in `lang/en_us.json`, so it can be
renamed as often as you like without moving any sound. The item id is the same one the textures use
(`textures/item/titan_amulet.png`) and the one F3+H shows in game (`amuletmod:titan_amulet`).

If the item id itself is ever renamed, leave the folder where it is: the folder name is just a code name, and moving
it would mean editing every path that points at it.

## File rules

- **Names:** lowercase letters, digits, `_` and `-` only. No spaces, no capitals. Minecraft refuses to load
  `Crush Impact.ogg`; `crush_impact.ogg` is fine.
- **Pattern:** `<move>_<moment>.ogg`, e.g. `jab_hit.ogg`, `crush_impact.ogg`, `stance_change.ogg`.
- **Variations:** number them `_1`, `_2`, `_3` (`jab_hit_1.ogg`, `jab_hit_2.ogg`). One sound event can pick one at
  random each time, so repeated punches don't sound identical.
- **Format:** Ogg Vorbis (`.ogg`). In Audacity: File > Export > Export as OGG.
- **Mono** for anything that happens in the world. Stereo files aren't placed in 3D: they play at the same volume
  wherever you stand, even from far away. Stereo is only right for `ui/` sounds.
- Trim the silence at the start, or the sound lags behind what you see.
- **Loops** (a hum for as long as something lasts) should run from their end straight back into their start, at an
  even loudness. One that swells or fades, or clicks at the join, gets evened out and its end crossfaded into its
  start when it's wired up, as the Aegis shield hum was.

## Hooking a sound up

Each file becomes a sound event in `assets/amuletmod/sounds.json` (created with the first sound), registered in code
and played in place of the vanilla sound it replaces:

```json
"titan.jab_hit": {
  "subtitle": "subtitles.amuletmod.titan.jab_hit",
  "sounds": ["amuletmod:amulet/titan/jab_hit_1", "amuletmod:amulet/titan/jab_hit_2"]
}
```

Paths in `sounds.json` start at this folder and leave off `.ogg`.
