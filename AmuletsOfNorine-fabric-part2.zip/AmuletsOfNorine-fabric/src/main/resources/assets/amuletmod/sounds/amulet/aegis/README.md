# Aegis Amulet sounds

Code name `aegis` (item id `aegis_amulet`). Its two shields, the Mirror Ward (ability 1, round the wearer) and the
dome (ability 2, 7 blocks across), are one entity (`entity/BarrierEntity`), so they share their sounds: the dome's
play a little deeper.

## In use

| File | Sound event | Moment |
|---|---|---|
| `shield_spawn.ogg` | `aegis.shield_spawn` | A shield opens (Mirror Ward at pitch 1.0; dome at 0.88, louder so it carries further) |
| `shield_loop.ogg` | `aegis.shield_loop` | Loops while a shield is up, fading in and out with it (Mirror Ward follows the wearer, softer; dome at 0.88, from its middle) |

Both arrived as stereo files with spaces in their names (`aegis shield spawn sound.ogg`,
`magic shield heavy active loop.ogg`) and were renamed and downmixed to mono. The loop's original swelled up in its
first second and faded to a third by its end, so looped as it was it would pulse and dip at the join: its loudness was
evened out and its last half second crossfaded into its first, so it now runs on without a seam (4.0 s instead of
4.5 s). It plays from `client/BarrierHum`.

## Still vanilla

| Moment | Who hears it | Vanilla sounds now | Suggested file |
|---|---|---|---|
| A shield ends | Everyone nearby | Beacon deactivate + glass and amethyst breaking (dome); beacon deactivate + amethyst break, higher (ward) | `shield_end.ogg` |
| A melee blow rebounds off the ward | Everyone nearby | Shield block, under the sparks below | `ward_rebound.ogg` |
| Sparks where a shield turns something back (a shot, a blow, a God Strike on the dome) | Everyone nearby | Shield block + amethyst hit | `shield_spark.ogg` |

Where they're played: `entity/BarrierEntity` (`playCastSounds`, `playEndSounds`), `client/BarrierHum` (the loop),
`AegisEvents` (the ward's rebound) and `Deflection.sparks`.
