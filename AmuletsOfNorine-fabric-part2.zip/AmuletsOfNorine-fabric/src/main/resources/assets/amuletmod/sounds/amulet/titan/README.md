# Titan Amulet sounds

Code name `titan` (item id `titan_amulet`), shown in game as the Warlord Amulet. The display name can change; this
folder doesn't.

Every moment the amulet makes a noise today: the custom file playing there, or the vanilla sounds layered for it until
one arrives, with a suggested file name. Names are only suggestions; anything that follows the rules in
`../../README.md` works.

## In use

| File(s) | Sound event | Moment |
|---|---|---|
| `power_select.ogg` | `titan.power_select` | Either key: choosing a power. Wearer only, a step higher round each cycle (Jab 0.95, Crush 1.0, Uppercut 1.05; Slash 1.0, Blade Storm 1.08) |
| `power_cancel.ogg` | `titan.power_cancel` | Either key: going back to off. Wearer only (fists 1.0, blades 1.06) |
| `jab_summon_1.ogg`, `jab_summon_2.ogg` | `titan.jab_summon` | Jab: circle opens (one of the two at random) |
| `crush_summon.ogg` | `titan.crush_summon` | Crush: circle opens |
| `crush_impact_1.ogg`, `crush_impact_2.ogg` | `titan.crush_impact` | Crush: fist lands (one of the two at random, pitch 0.92 to 1.08), over vanilla's explosion and Warden impact |
| `uppercut_summon.ogg` | `titan.uppercut_summon` | Uppercut: circle opens (pitch 0.96 to 1.04) |
| `slash_1.ogg` to `slash_3.ogg` | `titan.slash` | Slash: each cut |
| `slash_volley_1.ogg`, `slash_volley_2.ogg` | `titan.slash_volley` | Slash: the third cut throws all three |
| `storm_summon_1.ogg` to `storm_summon_3.ogg` | `titan.storm_summon` | Blade Storm: a blade is called (one of the three, pitch 0.94 to 1.06, rising a little with each blade) |

These arrived as stereo files with spaces in their names, and were renamed and downmixed to mono so they're placed in
the world. `power_select` and `power_cancel` kept their stereo: only the wearer hears them, at their own position.
Silence before the sound starts was trimmed off the uppercut and storm files. The originals were
`jab_summon2.ogg`, `sword slice single 1-3.ogg`, `triple sword combo 1-2.ogg`, `crush impact ground 1-2.ogg`,
`uppercut spawn.ogg`, `volley spawn 1-3.ogg`, `select new power (titan amulet abilities).ogg` and
`no power selected - cancel (titan amulet abilities).ogg`.

## Still vanilla

| Moment | Who hears it | Vanilla sounds now | Suggested file |
|---|---|---|---|
| Fists or blades: switching on | Everyone nearby | Fire charge (higher for the blades) | `hands_ignite.ogg` |
| Fists or blades: switching off | Everyone nearby | Fire extinguish | `hands_out.ogg` |
| Jab: fist hits a creature | Everyone nearby | Strong attack + iron golem attack | `jab_hit.ogg` |
| Jab: fist hits nothing | Everyone nearby | Strong attack + knockback whoosh | `jab_miss.ogg` |
| Crush: fist falls | Everyone nearby | Phantom swoop | `crush_fall.ogg` |
| Uppercut: fist bursts up | Everyone nearby | Warden impact + knockback + small explosion | `uppercut_impact.ogg` |
| Slash: a cut hits something | Everyone nearby | Sweep attack | `slash_hit.ogg` |
| Slash: a thrown cut hits a wall | Everyone nearby | Sweep attack, low | `slash_break.ogg` |
| Blade Storm: the blades turn | Everyone nearby | Illusioner mirror + riptide | `storm_turn.ogg` |
| Blade Storm: a blade fires | Everyone nearby | Trident throw | `storm_fire.ogg` |
| Blade Storm: a blade sticks in | Everyone nearby | Trident hitting the ground | `storm_lodge.ogg` |
| Blade Storm: a blade crumbles | Everyone nearby | Amethyst cluster break | `storm_crumble.ogg` |

Where they're played: `TitanFistsAbility` and `TitanBladesAbility` (choosing a power, switching on and off),
`entity/TitanFistEntity` (`opened()` for the circles, `impact()` for the hits), `entity/TitanSlashEntity` (cuts and
throws), `TitanBlades` (each cut, and the storm's calling, turning and firing) and `entity/TitanBladeEntity`
(crumbling).
