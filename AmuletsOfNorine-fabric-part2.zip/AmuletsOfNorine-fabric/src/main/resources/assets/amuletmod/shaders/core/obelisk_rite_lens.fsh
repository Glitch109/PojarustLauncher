#version 150

// The rite's second pass (client/ObeliskRitePost), once the whole level is drawn: the frame seen through a lens.
// Light streams out from the heart of the rite in shafts through whatever stands in front of it, the colours split
// and the view smears towards the heart, the edges sink into violet, and the last flash stays burned in for a moment.
// At the strike, the shatter and the birth the view stops dead on an impact frame: the frame held from that instant,
// cut down to ink.
//
// Focus = (the heart on screen, 1 if it's in front of the camera); Lens = (aberration, zoom blur, light shafts,
// seconds); Impact = (strength 0..1, style, 1 to show the held frame, focus lines 0..1); Grade = (afterimage of the held
// frame 0..1, vignette 0..1, film grain 0..1, unused). Styles: 1 the strike (ink and screentone on white), 2 the shatter
// (the world's edges split into the amulets' three colours on black), 3 the birth's negative, 4 the birth (black
// shapes on a white world, the heart burning in every colour).

#moj_import <amuletmod:god_strike.glsl>

uniform sampler2D DiffuseSampler;
uniform sampler2D HeldSampler;

uniform vec3 Focus;
uniform vec4 Lens;
uniform vec4 Impact;
uniform vec4 Grade;
uniform vec2 OutSize;

in vec2 texCoord;

out vec4 fragColor;

const vec3 RUBY = vec3(1.0, 0.35, 0.47);
const vec3 EMERALD = vec3(0.35, 0.94, 0.63);
const vec3 SAPPHIRE = vec3(0.3, 0.48, 1.0);
const vec3 TINT = vec3(0.34, 0.2, 0.56);

vec3 frame(vec2 uv) {
    uv = clamp(uv, vec2(0.0005), vec2(0.9995));
    return Impact.z > 0.5 ? texture(HeldSampler, uv).rgb : texture(DiffuseSampler, uv).rgb;
}

vec3 split(vec2 uv, vec2 off) {
    return vec3(frame(uv + off).r, frame(uv).g, frame(uv - off).b);
}

vec3 gem(float u) {
    u = mod(u, 3.0);
    vec3 a = u < 1.0 ? RUBY : u < 2.0 ? EMERALD : SAPPHIRE;
    vec3 b = u < 1.0 ? EMERALD : u < 2.0 ? SAPPHIRE : RUBY;
    return mix(a, b, smoothstep(0.2, 0.8, fract(u)));
}

// Light shafts: walking from this pixel towards the heart, gathering whatever burns on the way
vec3 shafts(vec2 uv, vec2 light) {
    vec2 delta = (light - uv) * (0.85 / 32.0);
    vec2 at = uv + delta * hash12(uv * OutSize);
    vec3 sum = vec3(0.0);
    float w = 1.0;
    for (int i = 0; i < 32; i++) {
        at += delta;
        vec3 s = frame(at);
        sum += s * (max(lum(s) - 0.72, 0.0) / 0.28) * w;
        w *= 0.955;
    }
    return sum / 32.0;
}

// Manga focus lines: wedges converging on the heart, dealt afresh every other tick
float focusLines(vec2 d, float t) {
    float a = (atan(d.y, d.x) / TAU + 0.5) * 150.0;
    float id = floor(a);
    float beat = floor(t * 10.0);
    float h = hash12(vec2(id, beat));
    float start = 0.16 + 0.4 * hash12(vec2(id + 3.0, beat));
    float r = length(d);
    float width = (0.15 + 0.35 * hash12(vec2(id + 7.0, beat))) * saturate((r - start) / 0.3);
    return step(0.5, h) * step(abs(fract(a) - 0.5) * 2.0, width) * step(start, r);
}

void main() {
    vec2 uv = texCoord;
    float aspect = OutSize.x / OutSize.y;
    float t = Lens.w;
    vec2 focus = Focus.z > 0.5 ? clamp(Focus.xy, vec2(-0.5), vec2(1.5)) : vec2(0.5);
    vec2 d = (uv - focus) * vec2(aspect, 1.0);

    // The colours split apart out from the heart, red outward and blue inward
    vec2 off = (uv - focus) * Lens.x * (0.003 + 0.012 * dot(d, d));
    vec3 col;
    if (Lens.y > 0.001) {
        // Smeared towards the heart
        vec3 sum = vec3(0.0);
        float total = 0.0;
        for (int i = 0; i < 10; i++) {
            float k = float(i) / 10.0;
            float w = 1.0 - k * 0.6;
            sum += split(mix(uv, focus, Lens.y * 0.14 * k), off) * w;
            total += w;
        }
        col = sum / total;
    } else {
        col = Lens.x > 0.001 ? split(uv, off) : frame(uv);
    }

    if (Lens.z > 0.001 && Focus.z > 0.5) {
        col += shafts(uv, focus) * mix(vec3(0.85, 0.7, 1.0), vec3(1.0), 0.5) * Lens.z * 2.2;
    }

    // The last flash burned in: the held frame's light, soft and bleached, over what's there now
    if (Grade.x > 0.001) {
        vec3 held = vec3(0.0);
        for (int i = 0; i < 5; i++) {
            vec2 o = i == 0 ? vec2(0.0) : vec2(cos(float(i) * 1.5708), sin(float(i) * 1.5708)) * 0.006;
            held += texture(HeldSampler, clamp(uv + o, vec2(0.0005), vec2(0.9995))).rgb;
        }
        float ghost = smoothstep(0.1, 0.9, lum(held / 5.0)) * saturate(Grade.x);
        col = 1.0 - (1.0 - col) * (1.0 - ghost * vec3(0.95, 0.92, 1.0));
    }

    if (Grade.y > 0.001) {
        float edge = smoothstep(0.3, 1.05, length((uv - 0.5) * vec2(aspect, 1.0)));
        col = mix(col, col * TINT, saturate(Grade.y * edge));
    }
    if (Grade.z > 0.001) {
        col += (hash12(uv * OutSize + fract(t * 7.3) * 431.0) - 0.5) * Grade.z * 0.12;
    }

    // Impact frame: the held frame cut down to two tones by comparing each pixel with the brightness round it, so the
    // shapes hold however bright or dark the frame is, with inked edges
    if (Impact.x > 0.001) {
        vec3 here = frame(uv);
        float l = lum(here);
        float around = 0.0;
        for (int i = 0; i < 8; i++) {
            float a = float(i) * (TAU / 8.0);
            around += lum(frame(uv + vec2(cos(a) / aspect, sin(a)) * 0.04));
        }
        around /= 8.0;
        vec2 px = 1.5 / OutSize;
        float gx = lum(frame(uv + vec2(px.x, 0.0))) - lum(frame(uv - vec2(px.x, 0.0)));
        float gy = lum(frame(uv + vec2(0.0, px.y))) - lum(frame(uv - vec2(0.0, px.y)));
        float ink = smoothstep(0.05, 0.16, length(vec2(gx, gy)));
        float two = step(around + 0.01, l);
        float hot = step(max(around + 0.2, 0.82), l);
        float lines = focusLines(d, t) * Impact.w;
        float style = Impact.y;
        vec3 shot;
        if (style < 1.5) {
            // The strike: black ink on white paper, the midtones in screentone, every light left white
            vec2 tp = mat2(0.7071, -0.7071, 0.7071, 0.7071) * (uv * OutSize) / 5.0;
            float tone = saturate((l - around) * 5.0 + 0.5);
            float dots = step(length(fract(tp) - 0.5), sqrt(saturate(1.0 - tone)) * 0.62);
            float mid = smoothstep(0.15, 0.35, tone) * (1.0 - smoothstep(0.65, 0.85, tone));
            shot = vec3(two);
            shot = mix(shot, vec3(1.0 - dots), mid * 0.85);
            shot = mix(shot, vec3(1.0), hot);
            shot *= 1.0 - ink * 0.9 * (1.0 - hot);
            shot = mix(shot, vec3(0.04, 0.02, 0.07), lines * (1.0 - hot));
            shot *= mix(vec3(1.0), vec3(0.96, 0.93, 1.0), two);
        } else if (style < 2.5) {
            // The shatter: the world's edges on black, split into the three colours outward from the heart
            vec2 out1 = normalize(d + 1e-5) / vec2(aspect, 1.0);
            vec3 edges = vec3(0.0);
            for (int k = 0; k < 3; k++) {
                vec2 o = uv + out1 * float(k - 1) * (0.004 + 0.005 * length(d));
                float ex = lum(frame(o + vec2(px.x, 0.0))) - lum(frame(o - vec2(px.x, 0.0)));
                float ey = lum(frame(o + vec2(0.0, px.y))) - lum(frame(o - vec2(0.0, px.y)));
                edges += (k == 0 ? RUBY : k == 1 ? EMERALD : SAPPHIRE) * smoothstep(0.04, 0.14, length(vec2(ex, ey)));
            }
            shot = vec3(0.01, 0.008, 0.02) + edges * 0.9;
            shot = mix(shot, vec3(1.0), hot * 0.9);
            shot += PALE * lines * 0.35;
        } else if (style < 3.5) {
            // The birth's first frame: the negative, the light gone black and the dark burning white, its rims in colour
            shot = vec3(1.0 - two) * (1.0 - ink * 0.3);
            shot = mix(shot, vec3(0.03, 0.0, 0.06), hot);
            shot = mix(shot, gem(atan(d.y, d.x) / TAU * 6.0 + t * 3.0) * 1.1, ink * (1.0 - hot) * 0.8);
        } else {
            // The birth: black shapes on a white world, the heart burning in rings of every colour, black focus lines
            float r = length(d);
            vec3 heart = gem(r * 14.0 - t * 12.0) * (1.0 - smoothstep(0.05, 0.45, r));
            shot = mix(vec3(0.0), vec3(1.0), max(two, hot));
            shot *= 1.0 - ink * 0.85;
            shot = mix(shot, mix(vec3(1.0), heart, 0.75), hot * (1.0 - smoothstep(0.1, 0.5, r)));
            shot = mix(shot, vec3(0.0), lines * (1.0 - hot));
        }
        col = mix(col, shot, saturate(Impact.x));
    }
    fragColor = vec4(col, 1.0);
}
