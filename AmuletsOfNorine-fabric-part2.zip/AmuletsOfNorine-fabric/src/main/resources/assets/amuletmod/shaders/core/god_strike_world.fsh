#version 150

// The God Strike, painted onto the frame (client/GodStrikePost). The world so far is rebuilt from the depth buffer,
// camera-relative, in blocks:
// - the sky, cut into shards of glass round the rift, each holding the world a little askew (shifted, turned, some
//   mirrored, its colours split), some fallen out onto the void behind, the cracks between them burning;
// - the ground round the mark waking with each magic circle: a ring of runes, then veins of light, then a second
//   ring and light welling up at its heart;
// - the air round the beam shimmering, and the ground glowing where the beam goes into it;
// - and everything near the strike drained of colour and dimmed, as under an eclipse.
//
// Awaken = (circles open 0..3, ground radius, charge 0..1, seconds); Shatter = (broken 0..1, how far the cracks have
// run 0..1, jolt 0..1, share of shards fallen out); Grade = (gloom 0..1, unused, seed, heat of the beam 0..1).
// Alpha out is 1 for sky, 0 for anything in front of it.

#moj_import <amuletmod:god_strike.glsl>

uniform sampler2D DiffuseSampler;
uniform sampler2D DepthSampler;

uniform mat4 InvViewProj;
uniform mat4 ViewProj;
uniform vec3 Target;
uniform vec3 Rift;
uniform vec3 Entry;
uniform vec4 Awaken;
uniform vec4 Shatter;
uniform vec4 Grade;
uniform vec2 OutSize;

in vec2 texCoord;

out vec4 fragColor;

const float SPOKES = 13.0;
const float RINGS = 9.0;

vec3 unproject(vec2 uv, float depth) {
    vec4 p = InvViewProj * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}

vec3 rayAt(vec2 uv) {
    return normalize(unproject(uv, 1.0) - unproject(uv, 0.0));
}

// Screen position of a camera-relative point; z is 0 if it's behind the camera
vec3 project(vec3 p) {
    vec4 c = ViewProj * vec4(p, 1.0);
    if (c.w <= 0.0) {
        return vec3(0.5, 0.5, 0.0);
    }
    return vec3(c.xy / c.w * 0.5 + 0.5, 1.0);
}

vec3 scene(vec2 uv) {
    return texture(DiffuseSampler, clamp(uv, vec2(0.0005), vec2(0.9995))).rgb;
}

// How close a ray from the camera comes to the segment a..b; t gets how far along the ray that is
float raySegment(vec3 rd, vec3 a, vec3 b, out float t) {
    vec3 ba = b - a;
    float baba = dot(ba, ba);
    float bard = dot(ba, rd);
    float baoa = dot(ba, -a);
    float rdoa = dot(rd, -a);
    float denom = baba - bard * bard;
    float s = denom > 1e-6 ? saturate((baoa - bard * rdoa) / denom) : 0.0;
    vec3 q = a + ba * s;
    t = max(dot(q, rd), 0.0);
    return length(rd * t - q);
}

// ---- The shattered sky
// Shards are laid out round the rift as on a pane struck at that point: cracks running out from it (spokes),
// crossed by rings that crowd in close to it. They're found from the view direction, so they hold still in the sky.

vec3 skyAxis;
vec3 skySide;
vec3 skyUp;

vec3 skyDirection(float theta, float phi) {
    return cos(theta) * skyAxis + sin(theta) * (cos(phi) * skySide + sin(phi) * skyUp);
}

// The shard at (theta from the rift, phi round it): its id, how far the point is from the shard's edge (radians
// across the sky), and roughly its middle, as (theta, phi)
vec2 shardAt(float theta, float phi, float seed, out float edge, out vec2 middle) {
    // The cracks out from the rift run nearly straight, a little jagged
    vec3 around = vec3(cos(phi), sin(phi), theta * 1.3);
    float wander = (vnoise3(around * 1.2 + seed) - 0.5) * 0.35 + (vnoise3(around * 9.0 + seed * 2.0) - 0.5) * 0.06;
    float s = phi / TAU * SPOKES + wander;
    float spoke = floor(s);
    float sector = mod(spoke, SPOKES);
    float across = s - spoke;
    float sectorAngle = TAU / SPOKES;
    float sinTheta = max(sin(theta), 1e-3);

    // The cracks round it run straight from one spoke to the next, as chords, all tilted the same way within a
    // sector and set at their own distances, so they never line up across a spoke
    float tilt = (hash11(sector * 3.71 + seed) - 0.5) * 0.7;
    float lean = max(cos((across - 0.5) * sectorAngle - tilt * sectorAngle), 0.3);
    float straight = theta * lean;
    float r = sqrt(straight / PI) * RINGS + (hash11(sector * 7.13 + seed) - 0.5) * 0.9;
    float ring = floor(r);
    float out01 = r - ring;

    float spokeEdge = min(across, 1.0 - across) * sectorAngle * sinTheta;
    float ringEdge = min(out01, 1.0 - out01) * 2.0 * sqrt(max(straight, 1e-4) * PI) / RINGS / lean;
    edge = min(spokeEdge, ringEdge);

    // Further out, a sector may split along a crack of its own that branches off a ring
    float branch = 0.0;
    if (ring >= 2.0 + floor(hash11(sector * 5.17 + seed) * 4.0)) {
        float splitAt = 0.5 + (hash11(sector * 9.31 + seed) - 0.5) * 0.4;
        edge = min(edge, abs(across - splitAt) * sectorAngle * sinTheta);
        branch = across > splitAt ? 0.5 : 0.0;
    }
    middle = vec2(PI * sqr(clamp((ring + 0.5) / RINGS, 0.02, 1.0)), (spoke + 0.25 + branch) / SPOKES * TAU);
    return vec2(sector + branch, ring);
}

// What's behind the sky where a shard has fallen out: a dark void, a violet haze, stars
vec3 voidBeyond(vec3 rd, float t) {
    vec3 col = vec3(0.012, 0.004, 0.03);
    col += VIOLET * smoothstep(0.45, 0.85, fbm3(rd * 3.0 + vec3(0.0, t * 0.03, 0.0))) * 0.4;
    col += MAGENTA * smoothstep(0.6, 0.95, fbm3(rd * 6.0 + 3.1)) * 0.2;
    vec3 cell = floor(rd * 90.0);
    float h = hash13(cell);
    if (h > 0.93) {
        vec3 jitter = vec3(hash13(cell + 1.7), hash13(cell + 3.1), hash13(cell + 5.3)) - 0.5;
        vec3 star = normalize((cell + 0.5 + jitter * 0.6) / 90.0);
        float d = length(rd - star) * 90.0;
        float twinkle = 0.7 + 0.3 * sin(t * 3.0 + h * 50.0);
        col += vec3(0.9, 0.85, 1.0) * exp(-d * d * 8.0) * (h - 0.93) * 14.0 * twinkle;
    }
    return col;
}

// The sky as seen through the broken glass; light gets the glow of the cracks
vec3 shatteredSky(vec2 uv, vec3 rd, float pixel, out vec3 light) {
    light = vec3(0.0);
    vec3 base = scene(uv);
    float broken = Shatter.x;
    float front = Shatter.y * PI;
    if (broken < 0.001) {
        return base;
    }

    skyAxis = normalize(Rift);
    skySide = cross(skyAxis, vec3(0.0, 1.0, 0.0));
    if (dot(skySide, skySide) < 1e-5) {
        skySide = vec3(1.0, 0.0, 0.0);
    }
    skySide = normalize(skySide);
    skyUp = cross(skySide, skyAxis);

    float theta = acos(clamp(dot(rd, skyAxis), -1.0, 1.0));
    float phi = atan(dot(rd, skyUp), dot(rd, skySide));
    float t = Awaken.w;

    // The leading edge of the cracks, racing out across the sky
    if (Shatter.y < 0.999) {
        light += PALE * exp(-sqr((theta - front) / 0.035)) * broken * 1.5;
    }
    if (theta > front) {
        return base;
    }

    float seed = Grade.z;
    float edge;
    vec2 middle;
    vec2 id = shardAt(theta, phi, seed, edge, middle);
    float h1 = hash12(id + seed);
    float h2 = hash12(id * 1.37 + vec2(4.1, seed));
    float h3 = hash12(id * 2.11 + vec2(9.7, seed));
    float h4 = hash12(id * 3.03 + vec2(seed, 2.9));

    // A shard only comes loose once the front has gone well past it
    float loose = smoothstep(front, front - 0.25, theta);
    float move = broken * loose * (0.3 + 0.7 * Shatter.z);

    vec3 glass;
    if (h4 < Shatter.w * loose) {
        glass = voidBeyond(rd, t);
    } else {
        // Each shard holds the world a little askew round its own middle
        vec2 aspect = vec2(OutSize.x / OutSize.y, 1.0);
        vec3 m = project(skyDirection(middle.x, middle.y));
        vec2 centre = m.z > 0.5 ? m.xy : uv;
        vec2 p = (uv - centre) * aspect;
        p = rot((h1 - 0.5) * 0.6 * move) * p;
        p *= 1.0 + (h2 - 0.5) * 0.4 * move;
        if (h3 > 0.66) {
            // A mirror: the world turned over inside it
            float a = h1 * PI;
            p = mix(p, reflect(p, vec2(cos(a), sin(a))), smoothstep(0.1, 0.5, move));
        }
        vec2 shift = (hash22(id + seed * 3.0) - 0.5) * 0.09 * move;
        vec2 suv = centre + p / aspect + shift;
        vec2 split = normalize(hash22(id * 5.3) - 0.5 + 1e-4) * 0.007 * move / aspect;
        glass = vec3(scene(suv + split).r, scene(suv).g, scene(suv - split).b);
        glass *= mix(vec3(1.0), mix(vec3(0.82, 0.78, 1.18), vec3(1.16, 0.84, 1.04), h1), 0.5 * broken);
        // Each shard sits at its own angle, so the light falls across it in its own direction
        float facet = dot((uv - centre) * aspect, normalize(hash22(id * 7.7 + seed) - 0.5 + 1e-4));
        glass *= 1.0 + clamp(facet * 0.9, -0.3, 0.3) * broken;
    }

    // A sheen sweeping across the glass, broken up by the cracks
    float sweep = fract(t * 0.11) * 2.6 - 1.3;
    float sheen = exp(-sqr((dot(rd, normalize(skySide + skyUp * 0.4)) - sweep + (h2 - 0.5) * 0.3) / 0.07));
    light += PALE * sheen * 0.16 * broken;

    // The cracks: a white-hot core in a magenta glow, freshest and brightest just behind the front, pulsing outward
    float width = 0.0007 + 0.8 * pixel;
    float core = 1.0 - smoothstep(width, width + pixel * 1.5, edge);
    float halo = sqr(width * 4.0) / (sqr(edge) + sqr(width * 4.0));
    float fresh = exp(-max(front - theta, 0.0) * 4.0);
    float pulse = 0.6 + 0.4 * sin(t * 6.0 - theta * 8.0);
    // Near the rift the glass is crazed into powder
    float crazed = exp(-theta * 9.0);
    float brightness = broken * (0.65 + 0.35 * pulse + 1.2 * fresh);
    light += (PALE * core * 1.1 + mix(MAGENTA, VIOLET, h2) * halo * 0.45) * brightness;
    // The edge of each shard catches the light a little, like the bevel of broken glass
    light += PALE * smoothstep(width * 6.0 + pixel * 2.0, width, edge) * 0.12 * broken * h3;
    light += MAGENTA * crazed * broken * 0.6;
    return glass;
}

// ---- The ground waking round the mark

float rune(vec2 g, float id) {
    float h = hash11(id * 13.7 + 1.3);
    float d = segment(g, vec2(0.5, 0.12), vec2(0.5, 0.88));
    if (fract(h * 2.0) > 0.5) d = min(d, segment(g, vec2(0.22, 0.8), vec2(0.78, 0.8)));
    if (fract(h * 4.0) > 0.5) d = min(d, segment(g, vec2(0.5, 0.5), vec2(0.8, 0.28)));
    if (fract(h * 8.0) > 0.5) d = min(d, segment(g, vec2(0.2, 0.3), vec2(0.5, 0.5)));
    if (fract(h * 16.0) > 0.5) d = min(d, abs(length(g - vec2(0.5, 0.36)) - 0.14));
    if (fract(h * 32.0) > 0.5) d = min(d, segment(g, vec2(0.25, 0.12), vec2(0.75, 0.12)));
    return d;
}

// A line of half-width w at distance d, as (core, halo); aa is a pixel. Lines too thin to see dim rather than thicken
vec2 glowLine(float d, float w, float aa) {
    float core = (1.0 - smoothstep(w, w + aa, d)) * min(1.0, 2.0 * w / max(aa, 1e-6) + 0.3);
    return vec2(core, exp(-sqr(d / (w * 3.0 + aa * 2.0))));
}

// A band of runes between radii r0 and r1 of a circle of radius 1; aa is a pixel in the circle's units
vec2 runeBand(vec2 c, float r0, float r1, float count, float spin, float aa) {
    float r = length(c);
    if (r < r0 || r > r1) {
        return vec2(0.0);
    }
    float cell = (atan(c.y, c.x) / TAU + spin) * count;
    float id = mod(floor(cell), count);
    float wide = TAU * r / count / (r1 - r0);
    vec2 g = vec2((fract(cell) - 0.5) * wide + 0.5, (r - r0) / (r1 - r0));
    return glowLine(rune(g, id) * (r1 - r0), 0.004, aa);
}

vec2 ringLine(float r, float at, float w, float aa) {
    return glowLine(abs(r - at), w, aa);
}

// A star polygon {points/skip} inscribed in radius
vec2 starPolygon(vec2 c, float radius, float points, float skip, float spin, float w, float aa) {
    float d = 1e3;
    for (int i = 0; i < 8; i++) {
        if (float(i) >= points) {
            break;
        }
        float a0 = float(i) * TAU / points + spin;
        float a1 = (float(i) + skip) * TAU / points + spin;
        d = min(d, segment(c, radius * vec2(cos(a0), sin(a0)), radius * vec2(cos(a1), sin(a1))));
    }
    return glowLine(d, w, aa);
}

// The outer sigil: a double ring, a band of runes, and a hexagram turning slowly
vec2 outerSigil(vec2 c, float t, float aa) {
    float r = length(c);
    if (r > 1.1) {
        return vec2(0.0);
    }
    vec2 v = ringLine(r, 1.0, 0.006, aa) + ringLine(r, 0.965, 0.003, aa);
    v += runeBand(c, 0.79, 0.94, 40.0, t * 0.015, aa);
    v += ringLine(r, 0.77, 0.004, aa) + ringLine(r, 0.745, 0.0025, aa);
    v += starPolygon(c, 0.745, 6.0, 2.0, t * 0.04, 0.004, aa);
    return v;
}

// The inner sigil, turning against it: an octagram in a ring of runes
vec2 innerSigil(vec2 c, float t, float aa) {
    float r = length(c);
    if (r > 0.55) {
        return vec2(0.0);
    }
    vec2 v = ringLine(r, 0.46, 0.004, aa) + ringLine(r, 0.34, 0.003, aa);
    v += runeBand(c, 0.355, 0.445, 22.0, -t * 0.03, aa);
    v += starPolygon(c, 0.34, 8.0, 3.0, -t * 0.07, 0.003, aa);
    v += ringLine(r, 0.12, 0.004, aa);
    return v;
}

// Veins of light splitting the ground, pulsing in towards the mark; blocks is a pixel's size on the ground. The vein
// is where the noise crosses its middle, measured in blocks (by its slope) so it's as wide near and far
vec2 veins(vec2 xz, float r, float radius, float t, float blocks) {
    vec2 at = xz * 0.09 + 7.3;
    float f = fbm2(at) - 0.5;
    float e = 0.05;
    vec2 slope = vec2(fbm2(at + vec2(e, 0.0)) - 0.5 - f, fbm2(at + vec2(0.0, e)) - 0.5 - f) / e;
    float d = abs(f) / max(length(slope), 0.05) / 0.09;
    float fade = 1.0 - smoothstep(radius * 0.75, radius * 1.05, r);
    float pulse = 0.55 + 0.45 * sin(r * 0.35 + t * 7.0);
    return glowLine(d, 0.22, blocks) * fade * pulse;
}

// The light the ground gives off at p, and (in shade) how much the ground's own light is dimmed under it
vec3 wakingGround(vec3 p, vec3 rd, float pixel, out float shade) {
    shade = 0.0;
    vec3 light = vec3(0.0);
    float level = Awaken.x;
    float radius = Awaken.y;
    float t = Awaken.w;
    float dist = length(p);
    float blocks = pixel * dist / max(abs(rd.y), 0.2);

    vec3 q = p - Target;
    float r = length(q.xz);
    if (level > 0.001 && r < radius * 1.3 && abs(q.y) < radius * 0.5 + 6.0) {
        float height = 1.0 - smoothstep(radius * 0.2 + 2.0, radius * 0.5 + 6.0, abs(q.y));
        vec2 c = q.xz / radius;
        float aa = blocks / radius;
        float first = saturate(level);
        float second = saturate(level - 1.0);
        float third = saturate(level - 2.0);
        vec2 lines = first * outerSigil(c, t, aa) + second * veins(q.xz, r, radius, t, blocks)
                + third * innerSigil(c, t, aa);
        float heart = (second * 0.25 + third * 0.7) * exp(-sqr(r / (radius * 0.16)));
        float flicker = 0.85 + 0.15 * sin(t * 11.0 + r * 0.3);
        light += (mix(MAGENTA, PALE, 0.4) * saturate(lines.x) * 1.2 + MAGENTA * min(lines.y, 1.0) * 0.25 + VIOLET * heart)
                * height * flicker;
        shade = (0.18 * first + 0.17 * second + 0.2 * third) * (1.0 - smoothstep(radius * 0.9, radius * 1.25, r)) * height;
    }

    // Where the beam bites: the mark itself, and where it goes into the ground on its way down
    float heat = Grade.w;
    if (heat > 0.001) {
        float bite = length(p - Target);
        light += mix(MAGENTA, PALE, 0.5) * exp(-sqr(bite / (1.5 + 4.0 * heat))) * heat * 1.4;
        if (distance(Entry, Target) > 2.0) {
            float d = length(p - Entry);
            float wound = exp(-sqr(d / (2.0 + 3.0 * heat))) * heat;
            light += mix(MAGENTA, PALE, wound) * wound * 1.6;
            light += MAGENTA * exp(-sqr((d - (3.0 + 4.0 * heat)) / 0.9)) * heat * 0.7;
        }
    }
    return light;
}

void main() {
    vec2 uv = texCoord;
    float depth = texture(DepthSampler, uv).r;
    bool sky = depth > 0.999999;
    vec3 rd = rayAt(uv);
    float pixel = length(rayAt(uv + vec2(0.0, 1.0 / OutSize.y)) - rd);
    vec3 p = sky ? rd * 1e5 : unproject(uv, depth);
    float sceneT = sky ? 1e9 : length(p);

    // The air shimmers round the beam
    float heat = Grade.w;
    vec2 suv = uv;
    if (heat > 0.001) {
        float along;
        float d = raySegment(rd, Rift, Target, along);
        if (along < sceneT) {
            float k = (1.0 - smoothstep(0.0, 2.0 + 6.0 * heat, d)) * heat;
            vec2 wobble = vec2(vnoise2(uv * 40.0 + vec2(0.0, Awaken.w * 4.0)), vnoise2(uv * 40.0 + vec2(5.2, Awaken.w * 4.3))) - 0.5;
            suv += wobble * k * 0.012;
        }
    }

    vec3 light;
    float shade = 0.0;
    vec3 col;
    if (sky) {
        col = shatteredSky(suv, rd, pixel, light);
    } else {
        col = scene(suv);
        light = wakingGround(p, rd, pixel, shade);
    }

    // Under the strike the world drains of colour and dims, as in an eclipse; then its own light shines out of it
    float gloom = Grade.x;
    col = mix(col, lum(col) * vec3(0.8, 0.72, 1.0), gloom * 0.55);
    col *= (1.0 - gloom * 0.3) * (1.0 - shade);
    // Alpha marks the sky for the lens pass's impact frames
    fragColor = vec4(col + light, sky ? 1.0 : 0.0);
}
