// Shared by the God Strike's two full-screen passes (god_strike_world, god_strike_lens): constants, hashes and noise.

#define PI 3.14159265
#define TAU 6.28318531

const vec3 MAGENTA = vec3(1.0, 0.36, 0.92);
const vec3 VIOLET = vec3(0.55, 0.22, 1.0);
const vec3 PALE = vec3(1.0, 0.93, 1.0);

float saturate(float x) {
    return clamp(x, 0.0, 1.0);
}

// x * x. Never pow(x, 2.0): pow is undefined below zero, and some drivers return NaN there
float sqr(float x) {
    return x * x;
}

float lum(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

mat2 rot(float a) {
    float c = cos(a);
    float s = sin(a);
    return mat2(c, s, -s, c);
}

// Sine-free hashes, so they give the same pattern on every GPU
float hash11(float p) {
    p = fract(p * 0.1031);
    p *= p + 33.33;
    p *= p + p;
    return fract(p);
}

float hash12(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}

vec2 hash22(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    q += dot(q, q.yzx + 33.33);
    return fract((q.xx + q.yz) * q.zy);
}

float hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}

float vnoise2(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash12(i), hash12(i + vec2(1.0, 0.0)), u.x),
               mix(hash12(i + vec2(0.0, 1.0)), hash12(i + vec2(1.0, 1.0)), u.x), u.y);
}

float vnoise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    float below = mix(mix(hash13(i), hash13(i + vec3(1.0, 0.0, 0.0)), u.x),
                      mix(hash13(i + vec3(0.0, 1.0, 0.0)), hash13(i + vec3(1.0, 1.0, 0.0)), u.x), u.y);
    float above = mix(mix(hash13(i + vec3(0.0, 0.0, 1.0)), hash13(i + vec3(1.0, 0.0, 1.0)), u.x),
                      mix(hash13(i + vec3(0.0, 1.0, 1.0)), hash13(i + vec3(1.0, 1.0, 1.0)), u.x), u.y);
    return mix(below, above, u.z);
}

float fbm2(vec2 p) {
    float sum = 0.0;
    float weight = 0.5;
    for (int i = 0; i < 4; i++) {
        sum += weight * vnoise2(p);
        p = p * 2.07 + vec2(13.1, 7.7);
        weight *= 0.5;
    }
    return sum;
}

float fbm3(vec3 p) {
    float sum = 0.0;
    float weight = 0.5;
    for (int i = 0; i < 3; i++) {
        sum += weight * vnoise3(p);
        p = p * 2.03 + vec3(5.3, 11.9, 3.7);
        weight *= 0.5;
    }
    return sum;
}

// Distance from p to the segment from a to b
float segment(vec2 p, vec2 a, vec2 b) {
    vec2 pa = p - a;
    vec2 ba = b - a;
    float h = saturate(dot(pa, ba) / dot(ba, ba));
    return length(pa - ba * h);
}
