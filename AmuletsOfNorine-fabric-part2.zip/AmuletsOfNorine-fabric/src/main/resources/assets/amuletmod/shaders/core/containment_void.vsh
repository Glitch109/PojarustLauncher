#version 150

// Contain's walls turned to the void (client/renderer/SubspaceWalls). Positions come in from the walls' centre, in
// blocks, so the fragment shader can trace the view out past them.

in vec3 Position;
in vec2 UV0;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec3 local;
out vec2 tileUv;
out vec4 tile;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    local = Position;
    tileUv = UV0;
    tile = Color;
}
