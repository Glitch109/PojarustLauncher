#version 150

// Contain's walls turned to the void (client/renderer/SubspaceWalls): each tile of a wall fills from its middle out with
// the End portal's starfield, a seal-red rim burning at the edge as it spreads.
//
// The stars aren't painted on the walls. Each of the End portal's layers hangs on a sphere round the walls' centre, far
// beyond them, and the view is traced out through the wall to it: so the starfield holds still as the viewer turns,
// its layers slide against each other as they move (the nearer spheres hold the bigger stars), and it runs on unbroken
// round the corners. A sphere is mapped from three sides at once, blended by which way it faces.
//
// Void = (reach in blocks, time 0..1 over twenty minutes, 1 to fog the walls (for a viewer outside them), unused).
// Per tile, in the vertex colour: red is how far the void has filled it, green how bright its rim burns.

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

uniform vec3 Camera;
uniform vec4 Void;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in vec3 local;
in vec2 tileUv;
in vec4 tile;

out vec4 fragColor;

// The End portal's colours: the backdrop's, then one per layer of stars
const vec3[] COLORS = vec3[](
    vec3(0.022087, 0.098399, 0.110818),
    vec3(0.011892, 0.095924, 0.089485),
    vec3(0.027636, 0.101689, 0.100326),
    vec3(0.046564, 0.109883, 0.114838),
    vec3(0.064901, 0.117696, 0.097189),
    vec3(0.063761, 0.086895, 0.123646),
    vec3(0.084817, 0.111994, 0.166380),
    vec3(0.097489, 0.154120, 0.091064),
    vec3(0.106152, 0.131144, 0.195191),
    vec3(0.097721, 0.110188, 0.187229),
    vec3(0.133516, 0.138278, 0.148582),
    vec3(0.070006, 0.243332, 0.235792),
    vec3(0.196766, 0.142899, 0.214696),
    vec3(0.047281, 0.315338, 0.321970),
    vec3(0.204675, 0.390010, 0.302066),
    vec3(0.080955, 0.314821, 0.661491)
);

const vec3 GLOW = vec3(1.0, 0.22, 0.42);
const vec3 PALE = vec3(1.0, 0.84, 0.9);

// Star texture coordinates per unit of sphere, before each layer's own scale; and how much faster than the End
// portal the layers drift
const float STAR_SCALE = 0.42;
const float DRIFT = 2.0;

// Where the ray from `from` along `dir` (a unit vector) leaves the sphere of `radius` round the centre, as a direction
// from the centre. `from` is always inside it: the walls are, and every sphere is bigger than them.
vec3 sphereExit(vec3 from, vec3 dir, float radius) {
    float b = dot(from, dir);
    float c = dot(from, from) - radius * radius;
    return normalize(from + dir * (sqrt(max(b * b - c, 0.0)) - b));
}

// `tex` laid over the unit sphere from its three axes, at direction `n`; each layer shifted, turned and scaled as the
// End portal's are. Faces that barely show are skipped.
vec3 sphereSample(sampler2D tex, vec3 n, vec2 shift, mat2 turn, float scale) {
    vec3 weight = pow(abs(n), vec3(6.0));
    weight /= weight.x + weight.y + weight.z;
    vec3 color = vec3(0.0);
    if (weight.x > 0.02)
        color += texture(tex, turn * (n.yz * STAR_SCALE + shift) * scale).rgb * weight.x;
    if (weight.y > 0.02)
        color += texture(tex, turn * (n.zx * STAR_SCALE + shift) * scale).rgb * weight.y;
    if (weight.z > 0.02)
        color += texture(tex, turn * (n.xy * STAR_SCALE + shift) * scale).rgb * weight.z;
    return color;
}

void main() {
    // The void grows out of the middle of its tile as a square
    vec2 offCentre = abs(tileUv - 0.5) * 2.0;
    float fromCentre = max(offCentre.x, offCentre.y);
    float filled = tile.r;
    if (fromCentre > filled)
        discard;

    float reach = Void.x;
    float time = Void.y;
    vec3 dir = normalize(local - Camera);

    vec3 color = sphereSample(Sampler0, sphereExit(local, dir, reach * 10.0), vec2(0.0), mat2(1.0), 1.0) * COLORS[0];
    for (int i = 0; i < 15; i++) {
        float layer = float(i + 1);
        vec2 shift = vec2(17.0 / layer, (2.0 + layer / 1.5) * time * 1.5 * DRIFT);
        float angle = radians(mod((layer * layer * 4321.0 + layer * 9.0) * 2.0, 360.0));
        mat2 turn = mat2(cos(angle), -sin(angle), sin(angle), cos(angle));
        float scale = (4.5 - layer / 4.0) * 2.0;
        // The biggest stars on the nearest spheres
        float radius = reach * (1.6 + 0.45 * (16.0 - layer));
        color += sphereSample(Sampler1, sphereExit(local, dir, radius), shift, turn, scale) * COLORS[i];
    }

    // The rim: a hard line at the void's edge with a softer glow inside it
    float inside = filled - fromCentre;
    float line = 1.0 - smoothstep(0.0, 0.05 + fwidth(fromCentre) * 1.5, inside);
    float halo = 1.0 - smoothstep(0.0, 0.35, inside);
    color += (mix(GLOW, PALE, line) * line * 1.2 + GLOW * halo * 0.35) * tile.g;

    if (Void.z > 0.5) {
        float away = length(local - Camera);
        if (away > FogStart) {
            float fog = away < FogEnd ? smoothstep(FogStart, FogEnd, away) : 1.0;
            color = mix(color, FogColor.rgb, fog * FogColor.a);
        }
    }
    fragColor = vec4(color, 1.0);
}
