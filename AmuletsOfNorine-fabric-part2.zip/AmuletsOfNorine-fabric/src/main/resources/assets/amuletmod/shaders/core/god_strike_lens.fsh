#version 150

// The God Strike's second pass (client/GodStrikePost): the frame god_strike_world painted (its alpha marking the sky),
// put back on screen through a lens. Its colours split apart out from the rift, for a few frames at the tear and at
// impact the world turns to a stark two-tone impact frame, and the edges darken towards violet.
//
// Lens = (aberration, impact frame 0..1, which frame: 1 the tear, 2 the impact, seconds); Tint = (vignette colour,
// strength); Focus = (the rift on screen, 1 if it's in front of the camera).

#moj_import <amuletmod:god_strike.glsl>

uniform sampler2D DiffuseSampler;

uniform vec4 Lens;
uniform vec4 Tint;
uniform vec3 Focus;
uniform vec2 OutSize;

in vec2 texCoord;

out vec4 fragColor;

vec3 frame(vec2 uv) {
    return texture(DiffuseSampler, clamp(uv, vec2(0.0005), vec2(0.9995))).rgb;
}

void main() {
    vec2 uv = texCoord;
    float aspect = OutSize.x / OutSize.y;

    // Chromatic aberration: the frame smeared into a spectrum, red outward and blue inward, from near the rift
    vec3 col = frame(uv);
    if (Lens.x > 0.001) {
        vec2 centre = Focus.z > 0.5 ? mix(vec2(0.5), clamp(Focus.xy, vec2(0.0), vec2(1.0)), 0.35) : vec2(0.5);
        vec2 d = uv - centre;
        vec2 da = d * vec2(aspect, 1.0);
        vec2 off = d * Lens.x * (0.004 + 0.02 * dot(da, da));
        vec3 sum = vec3(0.0);
        vec3 total = vec3(0.0);
        for (int i = 0; i < 6; i++) {
            float f = float(i) / 5.0;
            vec3 w = vec3(saturate(1.0 - 2.0 * f), 1.0 - abs(2.0 * f - 1.0), saturate(2.0 * f - 1.0)) + 0.15;
            sum += frame(uv + off * (1.0 - 2.0 * f)) * w;
            total += w;
        }
        col = sum / total;
    }

    // Impact frame: the world cut down to two tones, with inked edges. The sky (alpha, from the first pass) is one
    // tone and the land the other, so the shapes hold however bright or dark the frame is; whatever glows burns white
    if (Lens.y > 0.001) {
        vec4 here = texture(DiffuseSampler, uv);
        float l = lum(here.rgb);
        float around = 0.0;
        for (int i = 0; i < 8; i++) {
            float a = float(i) * (TAU / 8.0);
            around += lum(frame(uv + vec2(cos(a) / aspect, sin(a)) * 0.03));
        }
        around /= 8.0;
        vec2 px = 1.5 / OutSize;
        float gx = lum(frame(uv + vec2(px.x, 0.0))) - lum(frame(uv - vec2(px.x, 0.0)));
        float gy = lum(frame(uv + vec2(0.0, px.y))) - lum(frame(uv - vec2(0.0, px.y)));
        float ink = smoothstep(0.05, 0.16, length(vec2(gx, gy)));
        float detail = step(around + 0.04, l);
        float hot = step(max(around + 0.25, 0.85), l);
        float sky = here.a;
        vec3 shot;
        if (Lens.z < 1.5) {
            // The tear: a violet sky over a black world, every light in it white
            shot = mix(vec3(0.02, 0.0, 0.05) + vec3(0.12, 0.04, 0.2) * detail, vec3(0.62, 0.3, 1.0), sky);
            shot = mix(shot, PALE, hot);
            shot *= 1.0 - ink * 0.85 * (1.0 - hot);
        } else {
            // The impact: the sky blown out white over black silhouettes, the light in the land magenta
            shot = mix(vec3(0.03, 0.0, 0.05) + vec3(0.1, 0.05, 0.12) * detail, vec3(1.0, 0.97, 1.0), sky);
            shot = mix(shot, MAGENTA, hot * (1.0 - sky));
            shot *= 1.0 - ink * 0.85 * sky;
        }
        col = mix(col, shot, saturate(Lens.y));
    }

    // The edges of the view sink towards violet
    if (Tint.a > 0.001) {
        float edge = smoothstep(0.35, 1.05, length((uv - 0.5) * vec2(aspect, 1.0)));
        col = mix(col, col * Tint.rgb, saturate(Tint.a * edge));
    }

    fragColor = vec4(col, 1.0);
}
