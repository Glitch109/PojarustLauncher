#version 150

// The rite of fusion at a Runic Obelisk, painted onto the frame (client/ObeliskRitePost) before the rite's own light
// is drawn over it. The world so far is rebuilt from the depth buffer, camera-relative, in blocks:
// - the sky falls into night round the obelisk: the stars come out and wheel about the point straight over it (the
//   pole), trailing light as they speed up and swirling into it near the middle, and an aurora corona streams in
//   towards it in the three amulets' colours. At the birth a ring of light races out across the sky from the pole,
//   split into its colours and bending the sky as it passes, and the day comes back behind it;
// - the ground round the obelisk: a sigil drawing itself line by line as the circles open, with three rings at its
//   heart (one per amulet) closing into one; the land lit by the beam, and a ring of light racing over it at the birth;
// - the air round the beam shimmering, and everything near drained of colour and dimmed.
//
// Heavens = (night 0..1, how far the stars have turned in radians, how long their trails are in radians, aurora 0..1)
// Eye = (light at the pole 0..1, swirl, the birth's ring in radians out from the pole (< 0 before it), white-out 0..1)
// Ground = (sigil lines drawn 0..6, the three rings closing 0..1, light from the beam, gloom 0..1)
// Pulse = (the ring of light on the ground: radius in blocks and strength 0..1; the beam's heat 0..1; seconds)
// Extra = (how far from the pole the aurora starts in radians, implosion 0..1, charge 0..1, how brightly the sigil burns)
// Alpha passes through untouched.

#moj_import <amuletmod:god_strike.glsl>

uniform sampler2D DiffuseSampler;
uniform sampler2D DepthSampler;

uniform mat4 InvViewProj;
uniform mat4 ViewProj;
uniform vec3 Obelisk;
uniform vec3 Pole;
uniform vec3 BeamTop;
uniform vec3 BeamBottom;
uniform vec4 Heavens;
uniform vec4 Eye;
uniform vec4 Ground;
uniform vec4 Pulse;
uniform vec4 Extra;
uniform vec2 OutSize;

in vec2 texCoord;

out vec4 fragColor;

const vec3 RUBY = vec3(1.0, 0.35, 0.47);
const vec3 EMERALD = vec3(0.35, 0.94, 0.63);
const vec3 SAPPHIRE = vec3(0.3, 0.48, 1.0);
const vec3 RUNE = vec3(0.72, 0.45, 1.0);
const float SIGIL = 9.0;
const float STAR_RINGS = 64.0;

vec3 unproject(vec2 uv, float depth) {
    vec4 p = InvViewProj * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}

vec3 rayAt(vec2 uv) {
    return normalize(unproject(uv, 1.0) - unproject(uv, 0.0));
}

// Screen position of a camera-relative point; z is 0 if it's behind the camera
vec3 project(vec3 p) {
    vec4 c = ViewProj * vec4(p, 1.0);
    if (c.w <= 0.0) {
        return vec3(0.5, 0.5, 0.0);
    }
    return vec3(c.xy / c.w * 0.5 + 0.5, 1.0);
}

vec3 scene(vec2 uv) {
    return texture(DiffuseSampler, clamp(uv, vec2(0.0005), vec2(0.9995))).rgb;
}

// How close a ray from the camera comes to the segment a..b; t gets how far along the ray that is
float raySegment(vec3 rd, vec3 a, vec3 b, out float t) {
    vec3 ba = b - a;
    float baba = dot(ba, ba);
    float bard = dot(ba, rd);
    float baoa = dot(ba, -a);
    float rdoa = dot(rd, -a);
    float denom = baba - bard * bard;
    float s = denom > 1e-6 ? saturate((baoa - bard * rdoa) / denom) : 0.0;
    vec3 q = a + ba * s;
    t = max(dot(q, rd), 0.0);
    return length(rd * t - q);
}

// The amulets' three colours round a loop of 3
vec3 gem(float u) {
    u = mod(u, 3.0);
    vec3 a = u < 1.0 ? RUBY : u < 2.0 ? EMERALD : SAPPHIRE;
    vec3 b = u < 1.0 ? EMERALD : u < 2.0 ? SAPPHIRE : RUBY;
    return mix(a, b, smoothstep(0.2, 0.8, fract(u)));
}

// ---- The heavens
// Directions are measured from the pole: theta out from it, phi round it.

vec3 poleAxis;
vec3 poleSide;
vec3 poleUp;

vec3 starColour(float h) {
    if (h < 0.06) return RUBY;
    if (h < 0.12) return EMERALD;
    if (h < 0.18) return SAPPHIRE;
    return mix(vec3(0.72, 0.8, 1.0), vec3(1.0, 0.9, 0.78), fract(h * 7.31));
}

// The stars, turned rot round the pole, each trailing span radians of its path behind it. They sit in rings round the
// pole, one per cell along each ring, so a pixel only has to look ahead along its own ring for the heads whose trails
// reach back over it
vec3 stars(float theta, float phi, float rot, float span, float pixel) {
    float ring = floor(theta / PI * STAR_RINGS);
    float mid = (ring + 0.5) / STAR_RINGS * PI;
    float cells = max(3.0, floor(STAR_RINGS * 2.0 * sin(mid)));
    float cellW = TAU / cells;
    float p = mod(phi - rot, TAU);
    float c0 = floor(p / cellW);
    float steps = min(ceil(span / cellW), 9.0);
    float w = pixel * 0.9;
    vec3 col = vec3(0.0);
    for (int i = 0; i < 10; i++) {
        float fi = float(i);
        if (fi > steps) {
            break;
        }
        float c = c0 + fi;
        vec2 id = vec2(ring, mod(c, cells));
        float h = hash12(id + 0.5);
        if (h > 0.42) {
            continue;
        }
        float head = (c + 0.15 + 0.7 * hash12(id + 3.7)) * cellW;
        float at = (ring + 0.2 + 0.6 * hash12(id + 7.1)) / STAR_RINGS * PI;
        float back = head - p;
        float along = back < 0.0 ? -back : max(back - span, 0.0);
        float d = length(vec2(along * max(sin(at), 0.02), theta - at));
        float mag = h / 0.42;
        // The head burns brightest; its trail is fainter, and fades towards where the star was
        float trail = back <= 0.0 ? 1.0 : 0.2 + 0.5 * (1.0 - saturate(back / max(span, 1e-4)));
        col += starColour(hash12(id + 11.3)) * exp(-sqr(d / w)) * (0.2 + 1.5 * mag * mag * mag) * trail;
    }
    return col;
}

// The aurora: a curtain round the pole with a sharp, folding lower edge, its rays streaming in towards the pole, green
// at the edge, then blue, then red nearest the pole
vec3 corona(float theta, float phi, float t, float lower) {
    vec2 round1 = vec2(cos(phi), sin(phi));
    float edge = lower + 0.06 * sin(phi * 3.0 + t * 0.4) + 0.08 * (vnoise3(vec3(round1 * 1.3, t * 0.25)) - 0.5);
    float inside = edge - theta;
    if (inside < -0.06 || theta < 0.01) {
        return vec3(0.0);
    }
    float body = inside < 0.0 ? exp(-sqr(inside / 0.018)) : exp(-inside * 2.4);
    float r1 = vnoise3(vec3(round1 * 3.8, t * 0.5 + theta * 0.6));
    float r2 = vnoise3(vec3(round1 * 9.5 + 4.1, t * 0.9 - theta * 1.5));
    float rays = 0.2 + 0.8 * sqr(r1) + 0.7 * sqr(sqr(r2));
    vec3 hue = mix(EMERALD, mix(SAPPHIRE, RUBY, smoothstep(0.2, 0.6, inside)), smoothstep(0.02, 0.25, inside));
    return hue * body * rays * smoothstep(0.02, 0.3, theta);
}

// The sky over the rite; light gets what glows in it
vec3 heavens(vec2 uv, vec3 rd, float pixel, out vec3 light) {
    light = vec3(0.0);
    float night = Heavens.x;
    float t = Pulse.w;

    poleAxis = normalize(Pole);
    vec3 ref = abs(poleAxis.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    poleSide = normalize(cross(ref, poleAxis));
    poleUp = cross(poleAxis, poleSide);
    float theta = acos(clamp(dot(rd, poleAxis), -1.0, 1.0));
    float phi = atan(dot(rd, poleUp), dot(rd, poleSide));

    // The birth's ring: the sky bends round it as it passes, and behind it the night has lifted
    vec2 suv = uv;
    float front = Eye.z;
    if (front >= 0.0) {
        float k = 0.035 + 0.05 * front;
        float d = theta - front;
        if (abs(d) < k * 3.0) {
            vec3 away = rd - poleAxis * dot(rd, poleAxis);
            float bend = d / k * exp(-sqr(d / k)) * 0.08 * (1.0 - front / 2.8);
            vec3 s = project(normalize(rd + normalize(away + 1e-5) * bend) * 1000.0);
            if (s.z > 0.5 && texture(DepthSampler, s.xy).r > 0.999999) {
                suv = s.xy;
            }
        }
        night *= smoothstep(front - 0.35, front, theta);
        float strength = 1.8 * (1.0 - smoothstep(0.4, 2.6, front));
        light += (vec3(1.0, 0.15, 0.25) * exp(-sqr((d + 0.4 * k) / k)) + vec3(0.2, 1.0, 0.4) * exp(-sqr(d / k))
                + vec3(0.25, 0.35, 1.0) * exp(-sqr((d - 0.4 * k) / k)) + PALE * exp(-sqr(d / (k * 0.3))) * 0.6) * strength;
    }
    vec3 base = scene(suv);

    // Night: the sky drained of day, darkest overhead, the horizon left glowing all round as in an eclipse
    float high = smoothstep(-0.1, 0.45, rd.y);
    vec3 dark = base * vec3(0.16, 0.14, 0.26) + vec3(0.004, 0.003, 0.016) + mix(RUNE, MAGENTA, 0.3) * 0.05 * (1.0 - high);
    base = mix(base, dark, night * (0.7 + 0.3 * high));

    if (night > 0.001) {
        // Near the pole the stars are drawn round into it
        float swirl = Eye.y * exp(-theta * 2.5);
        light += stars(theta, phi - swirl, Heavens.y, Heavens.z, pixel) * night * smoothstep(-0.05, 0.1, rd.y);
    }
    if (Heavens.w > 0.001) {
        light += corona(theta, phi, t, Extra.x) * Heavens.w * (1.0 - 0.6 * Eye.w) * smoothstep(-0.02, 0.12, rd.y);
    }
    // The light at the pole, where the eye is; then the whole sky blown white at the birth
    light += (PALE * exp(-theta / 0.035) * 1.2 + mix(RUNE, PALE, 0.3) * exp(-theta / 0.2) * 0.35) * Eye.x;
    light += PALE * Eye.w * (exp(-theta / 0.5) * 1.4 + 0.25);
    return base;
}

// ---- The sigil on the ground

float rune(vec2 g, float id) {
    float h = hash11(id * 13.7 + 1.3);
    float d = segment(g, vec2(0.5, 0.12), vec2(0.5, 0.88));
    if (fract(h * 2.0) > 0.5) d = min(d, segment(g, vec2(0.22, 0.8), vec2(0.78, 0.8)));
    if (fract(h * 4.0) > 0.5) d = min(d, segment(g, vec2(0.5, 0.5), vec2(0.8, 0.28)));
    if (fract(h * 8.0) > 0.5) d = min(d, segment(g, vec2(0.2, 0.3), vec2(0.5, 0.5)));
    if (fract(h * 16.0) > 0.5) d = min(d, abs(length(g - vec2(0.5, 0.36)) - 0.14));
    if (fract(h * 32.0) > 0.5) d = min(d, segment(g, vec2(0.25, 0.12), vec2(0.75, 0.12)));
    return d;
}

// A line of half-width w at distance d, as (core, halo); aa is a pixel. Lines too thin to see dim rather than thicken
vec2 glowLine(float d, float w, float aa) {
    float core = (1.0 - smoothstep(w, w + aa, d)) * min(1.0, 2.0 * w / max(aa, 1e-6) + 0.3);
    return vec2(core, exp(-sqr(d / (w * 3.0 + aa * 2.0))));
}

vec2 runeBand(vec2 c, float r0, float r1, float count, float spin, float aa) {
    float r = length(c);
    if (r < r0 || r > r1) {
        return vec2(0.0);
    }
    float cell = (atan(c.y, c.x) / TAU + spin) * count;
    float id = mod(floor(cell), count);
    float wide = TAU * r / count / (r1 - r0);
    vec2 g = vec2((fract(cell) - 0.5) * wide + 0.5, (r - r0) / (r1 - r0));
    return glowLine(rune(g, id) * (r1 - r0), 0.004, aa);
}

vec2 ringLine(float r, float at, float w, float aa) {
    return glowLine(abs(r - at), w, aa);
}

vec2 starPolygon(vec2 c, float radius, float points, float skip, float spin, float w, float aa) {
    float d = 1e3;
    for (int i = 0; i < 8; i++) {
        if (float(i) >= points) {
            break;
        }
        float a0 = float(i) * TAU / points + spin;
        float a1 = (float(i) + skip) * TAU / points + spin;
        d = min(d, segment(c, radius * vec2(cos(a0), sin(a0)), radius * vec2(cos(a1), sin(a1))));
    }
    return glowLine(d, w, aa);
}

// How much of a line drawn round the sigil the pen has laid down (progress 0..1, going round from the north), and
// the bright tip of the pen as it goes
vec2 pen(vec2 c, float progress) {
    float a = fract(atan(c.x, -c.y) / TAU + 1.0);
    float drawn = 1.0 - smoothstep(progress - 0.004, progress, a);
    float tip = progress < 1.0 ? exp(-sqr((a - progress) * 60.0)) : 0.0;
    return vec2(drawn, tip);
}

// The sigil's light at c (in units of its radius): each of its six parts drawn round in turn as a circle opens
vec3 sigil(vec2 c, float level, float merge, float charge, float t, float aa) {
    float r = length(c);
    if (r > 1.08 || level < 0.001) {
        return vec3(0.0);
    }
    vec3 ink = mix(RUNE, PALE, 0.25 + 0.5 * charge);
    vec3 light = vec3(0.0);
    vec2 part;
    vec2 p;

    p = pen(c, saturate(level));
    part = ringLine(r, 1.0, 0.006, aa) + ringLine(r, 0.965, 0.003, aa);
    light += ink * (part.x * 1.2 + part.y * 0.3) * p.x + PALE * p.y * part.y * 2.0;

    p = pen(c, saturate(level - 1.0));
    part = runeBand(c, 0.8, 0.94, 40.0, t * 0.012, aa);
    light += ink * (part.x * 1.2 + part.y * 0.3) * p.x + PALE * p.y * part.y * 2.0;

    p = pen(c, saturate(level - 2.0));
    part = ringLine(r, 0.775, 0.004, aa) + ringLine(r, 0.75, 0.0025, aa);
    light += ink * (part.x * 1.2 + part.y * 0.3) * p.x + PALE * p.y * part.y * 2.0;

    p = pen(c, saturate(level - 3.0));
    part = starPolygon(c, 0.75, 6.0, 2.0, t * 0.03, 0.004, aa);
    light += ink * (part.x * 1.2 + part.y * 0.3) * p.x + PALE * p.y * part.y * 2.0;

    // Three rings, one per amulet, overlapping round the middle; they close in until they're one, burning white
    p = pen(c, saturate(level - 4.0));
    for (int i = 0; i < 3; i++) {
        float a = float(i) * TAU / 3.0 + 1.5708 - t * 0.02;
        vec2 centre = vec2(cos(a), sin(a)) * 0.27 * (1.0 - merge);
        vec2 ring = ringLine(length(c - centre), 0.3, 0.005, aa);
        vec3 hue = mix(i == 0 ? RUBY : i == 1 ? EMERALD : SAPPHIRE, PALE, merge * 0.7);
        light += hue * (ring.x * 1.3 + ring.y * 0.4) * p.x + PALE * p.y * ring.y * 2.0;
    }

    p = pen(c, saturate(level - 5.0));
    part = runeBand(c, 0.11, 0.19, 12.0, -t * 0.04, aa) + ringLine(r, 0.1, 0.004, aa);
    light += ink * (part.x * 1.2 + part.y * 0.3) * p.x + PALE * p.y * part.y * 2.0;

    float flicker = 0.88 + 0.12 * sin(t * 9.0 + r * 4.0);
    return light * flicker;
}

// What the rite does to the land at p (lit by the scene's own colour, col): light added, and the scene's colour lit
vec3 ground(vec3 p, vec3 n, vec3 rd, float pixel, inout vec3 col) {
    vec3 light = vec3(0.0);
    vec3 q = p - Obelisk;
    float r = length(q.xz);
    float dist = length(p);
    float t = Pulse.w;

    // The sigil, on whatever faces up near the obelisk's foot
    if (r < SIGIL * 1.1 && abs(q.y) < 4.0) {
        float upward = smoothstep(0.55, 0.85, abs(n.y)) * (1.0 - smoothstep(1.5, 4.0, abs(q.y)));
        float blocks = pixel * dist / max(abs(rd.y), 0.15);
        light += sigil(q.xz / SIGIL, Ground.x, Ground.y, Extra.z, t, blocks / SIGIL) * upward * Extra.w;
    }

    // The beam's light on the land round it, falling off with distance and turned from by faces that look away
    if (Ground.z > 0.001) {
        vec3 heart = Obelisk + vec3(0.0, 4.5, 0.0);
        vec3 to = heart - p;
        float d = length(to);
        float facing = 0.25 + 0.75 * max(dot(n, to / max(d, 1e-3)), 0.0);
        float lit = Ground.z * facing / (1.0 + sqr(d / 4.5));
        vec3 hue = mix(RUNE, PALE, 0.4 + 0.5 * Extra.z);
        col += col * hue * lit * 2.2;
        light += hue * lit * 0.08;
    }

    // The birth's ring of light, racing out over the land in its colours
    if (Pulse.y > 0.001 && abs(q.y) < 8.0) {
        float d = r - Pulse.x;
        float k = 0.8 + Pulse.x * 0.05;
        vec3 ring = vec3(1.0, 0.2, 0.3) * exp(-sqr((d + 0.5 * k) / k)) + vec3(0.25, 1.0, 0.45) * exp(-sqr(d / k))
                + vec3(0.3, 0.4, 1.0) * exp(-sqr((d - 0.5 * k) / k));
        float height = 1.0 - smoothstep(2.0, 8.0, abs(q.y));
        light += ring * Pulse.y * height * 1.4;
        col += col * PALE * exp(-sqr(d / (k * 3.0))) * Pulse.y * height * 2.0;
    }
    return light;
}

void main() {
    vec2 uv = texCoord;
    float depth = texture(DepthSampler, uv).r;
    bool sky = depth > 0.999999;
    vec3 rd = rayAt(uv);
    float pixel = length(rayAt(uv + vec2(0.0, 1.0 / OutSize.y)) - rd);
    vec3 p = sky ? rd * 1e5 : unproject(uv, depth);
    float sceneT = sky ? 1e9 : length(p);
    float alpha = texture(DiffuseSampler, uv).a;
    // The face's normal, turned towards the camera; worked out here, where every pixel takes the same path
    vec3 n = cross(dFdx(p), dFdy(p));
    n = dot(n, n) > 1e-12 ? normalize(n) : vec3(0.0, 1.0, 0.0);
    n = dot(n, p) > 0.0 ? -n : n;

    // The air shimmers round the beam
    vec2 suv = uv;
    float heat = Pulse.z;
    if (heat > 0.001) {
        float along;
        float d = raySegment(rd, BeamTop, BeamBottom, along);
        if (along < sceneT) {
            float k = (1.0 - smoothstep(0.0, 1.5 + 4.0 * heat, d)) * heat;
            vec2 wobble = vec2(vnoise2(uv * 40.0 + vec2(0.0, Pulse.w * 4.0)), vnoise2(uv * 40.0 + vec2(5.2, Pulse.w * 4.3))) - 0.5;
            suv += wobble * k * 0.01;
        }
    }

    vec3 col;
    vec3 light;
    if (sky) {
        col = heavens(suv, rd, pixel, light);
    } else {
        col = scene(suv);
        light = ground(p, n, rd, pixel, col);
    }

    // Under the rite the world drains of colour and dims; its own light shines out of the dark
    float gloom = Ground.w;
    col = mix(col, lum(col) * vec3(0.78, 0.72, 1.0), gloom * 0.65);
    col *= 1.0 - gloom * 0.45;
    fragColor = vec4(col + light, alpha);
}
