package com.amuletmod.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({LivingEntityRenderer.class})
public interface LivingEntityRendererInvoker {
   @Invoker("setupRotations")
   void amuletmod$setupRotations(LivingEntity var1, PoseStack var2, float var3, float var4, float var5, float var6);

   @Invoker("scale")
   void amuletmod$scale(LivingEntity var1, PoseStack var2, float var3);

   @Invoker("getBob")
   float amuletmod$getBob(LivingEntity var1, float var2);
}
