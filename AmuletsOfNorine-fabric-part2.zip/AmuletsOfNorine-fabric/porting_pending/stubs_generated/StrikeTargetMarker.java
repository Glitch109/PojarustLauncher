package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.strike.StrikeTarget;
import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.client.renderer.LateBuffers;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.mojang.math.Axis;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/StrikeTargetMarker.java and is ported in the client phase. */
public final class StrikeTargetMarker {
   public static void update(@Nullable StrikeTarget newTarget) {  }
}
