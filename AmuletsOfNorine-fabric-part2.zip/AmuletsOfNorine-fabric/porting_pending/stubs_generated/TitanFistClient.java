package com.amuletmod.client;

import com.amuletmod.amulet.ability.titan.Stance;
import com.amuletmod.entity.TitanFistEntity;
import com.amuletmod.util.Easing;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/TitanFistClient.java and is ported in the client phase. */
public final class TitanFistClient {
   public static void tick(TitanFistEntity fist) {  }
}
