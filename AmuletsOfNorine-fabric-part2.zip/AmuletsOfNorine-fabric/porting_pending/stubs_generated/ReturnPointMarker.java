package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.recall.ReturnPoint;
import com.amuletmod.client.renderer.LateBuffers;
import com.mojang.math.Axis;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ReturnPointMarker.java and is ported in the client phase. */
public final class ReturnPointMarker {
   public static void update(@Nullable ReturnPoint newPoint, boolean justSet) {  }
}
