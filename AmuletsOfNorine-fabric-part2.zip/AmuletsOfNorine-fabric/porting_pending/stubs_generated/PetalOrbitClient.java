package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.sylvan.PetalOrbit;
import com.amuletmod.amulet.ability.sylvan.PetalSwarms;
import com.amuletmod.client.renderer.GlowBatch;
import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.amuletmod.util.Easing;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap.Entry;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/PetalOrbitClient.java and is ported in the client phase. */
public final class PetalOrbitClient {
   public static void update(int entityId, int[] colors, int[] petals) {  }
}
