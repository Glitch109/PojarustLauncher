package com.amuletmod.client;

import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.client.renderer.LateBuffers;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.amuletmod.entity.TitanBladeEntity;
import com.amuletmod.entity.TitanSlashEntity;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/TitanBladeClient.java and is ported in the client phase. */
public final class TitanBladeClient {
   public static void fired(TitanBladeEntity blade) {  }
   public static void tickBlade(TitanBladeEntity blade) {  }
   public static void tickSlash(TitanSlashEntity slash) {  }
}
