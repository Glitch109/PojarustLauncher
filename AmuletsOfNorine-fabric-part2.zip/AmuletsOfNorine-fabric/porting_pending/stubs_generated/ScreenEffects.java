package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ScreenEffects.java and is ported in the client phase. */
public final class ScreenEffects {
   public static void startRewind(int durationTicks) {  }
}
