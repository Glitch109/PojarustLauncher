package com.amuletmod.client;

import com.amuletmod.entity.PageStormEntity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/TempestClient.java and is ported in the client phase. */
public final class TempestClient {
   public static void broke(int casterId) {  }
   public static void building(int casterId, float build) {  }
   public static void started(PageStormEntity storm) {  }
}
