package com.amuletmod.client;

import com.amuletmod.seal.SealBarrierBlock;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.world.level.block.state.BlockState;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/SealCaptureClient.java and is ported in the client phase. */
public final class SealCaptureClient {
   public static void shrink(int entityId, float scale, float height) {  }
}
