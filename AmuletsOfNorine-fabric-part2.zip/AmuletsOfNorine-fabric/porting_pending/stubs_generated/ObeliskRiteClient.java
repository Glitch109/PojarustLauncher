package com.amuletmod.client;

import com.amuletmod.client.renderer.RunicObeliskRenderer;
import com.amuletmod.obelisk.ObeliskRite;
import com.amuletmod.obelisk.RunicObeliskBlock;
import com.amuletmod.obelisk.RunicObeliskBlockEntity;
import com.amuletmod.util.Easing;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ObeliskRiteClient.java and is ported in the client phase. */
public final class ObeliskRiteClient {
   public static void tick(RunicObeliskBlockEntity obelisk) {  }
}
