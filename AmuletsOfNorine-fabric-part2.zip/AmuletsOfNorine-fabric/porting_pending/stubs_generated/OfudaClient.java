package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.librarian.Kanji;
import com.amuletmod.entity.OfudaEntity;
import com.amuletmod.util.Easing;
import com.mojang.math.Axis;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import org.jetbrains.annotations.Nullable;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/OfudaClient.java and is ported in the client phase. */
public final class OfudaClient {
   public static void strike(int writerId, int k) {  }
   public static void writing(OfudaEntity ofuda) {  }
}
