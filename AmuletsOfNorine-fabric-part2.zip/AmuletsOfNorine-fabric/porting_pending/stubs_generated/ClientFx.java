package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.librarian.PageLook;
import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.client.renderer.LateBuffers;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.amuletmod.client.renderer.SealRenderer;
import com.amuletmod.client.renderer.UnderworldHandRenderer;
import com.amuletmod.network.FxPacket;
import com.amuletmod.util.Easing;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ClientFx.java and is ported in the client phase. */
public final class ClientFx {
   public static void play(FxPacket.Kind kind, Vec3 at, Vec3 to, float size) {  }
}
