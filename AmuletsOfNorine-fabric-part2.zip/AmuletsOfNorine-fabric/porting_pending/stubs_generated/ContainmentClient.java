package com.amuletmod.client;

import com.amuletmod.client.renderer.SubspaceWalls;
import com.amuletmod.entity.ContainmentEntity;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ContainmentClient.java and is ported in the client phase. */
public final class ContainmentClient {
   public static void tick(ContainmentEntity walls) {  }
}
