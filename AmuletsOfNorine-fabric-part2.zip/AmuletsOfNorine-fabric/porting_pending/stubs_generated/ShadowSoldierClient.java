package com.amuletmod.client;

import com.amuletmod.client.renderer.AuraDraw;
import com.amuletmod.client.renderer.GlowBatch;
import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.amuletmod.client.renderer.TintedBuffers;
import com.amuletmod.mixin.client.LivingEntityRendererInvoker;
import com.amuletmod.util.Easing;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ShadowSoldierClient.java and is ported in the client phase. */
public final class ShadowSoldierClient {
   public static void add(int entityId, int age) {  }
}
