package com.amuletmod.client;

import com.amuletmod.entity.BarrierEntity;
import com.amuletmod.registry.ModSounds;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/BarrierHum.java and is ported in the client phase. */
public final class BarrierHum {
   public static void start(BarrierEntity barrier) {  }
}
