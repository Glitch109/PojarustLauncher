package com.amuletmod.client;

import com.amuletmod.amulet.Amulets;
import com.amuletmod.amulet.ability.librarian.PaperCutsAbility;
import com.amuletmod.amulet.ability.librarian.Tome;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/PaperCutsClient.java and is ported in the client phase. */
public final class PaperCutsClient {
   public static void flung(int throwerId) {  }
   public static void impactFrame(int throwerId) {  }
}
