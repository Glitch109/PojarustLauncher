package com.amuletmod.client;

import net.minecraft.world.phys.Vec3;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/RootedClient.java and is ported in the client phase. */
public final class RootedClient {
   public static void hold(int victimId) {  }
}
