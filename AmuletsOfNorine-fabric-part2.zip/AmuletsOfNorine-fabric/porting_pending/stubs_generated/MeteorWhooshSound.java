package com.amuletmod.client;

import com.amuletmod.entity.SeekingMeteorEntity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/MeteorWhooshSound.java and is ported in the client phase. */
public final class MeteorWhooshSound {
   public static void follow(SeekingMeteorEntity meteor) {  }
}
