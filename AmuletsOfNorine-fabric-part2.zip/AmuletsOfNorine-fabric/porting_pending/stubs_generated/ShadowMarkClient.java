package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.renderer.LateBuffers;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.mojang.math.Axis;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/ShadowMarkClient.java and is ported in the client phase. */
public final class ShadowMarkClient {
   public static void update(int entityId) {  }
}
