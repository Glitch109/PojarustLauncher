package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.Amulets;
import com.amuletmod.amulet.ability.titan.BladeMode;
import com.amuletmod.amulet.ability.titan.Stance;
import com.amuletmod.amulet.ability.titan.TitanBlades;
import com.amuletmod.amulet.ability.titan.TitanBladesAbility;
import com.amuletmod.amulet.ability.titan.TitanFistsAbility;
import com.amuletmod.amulet.ability.titan.TitanSync;
import com.amuletmod.client.renderer.TitanFistRenderer;
import com.amuletmod.network.TitanBladePacket;
import com.amuletmod.network.TitanHudPacket;
import com.amuletmod.network.TitanPunchPacket;
import com.amuletmod.util.Easing;
import com.mojang.math.Axis;
import java.util.Arrays;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/TitanHud.java and is ported in the client phase. */
public final class TitanHud {
   public static void state(TitanHudPacket packet) {  }
}
