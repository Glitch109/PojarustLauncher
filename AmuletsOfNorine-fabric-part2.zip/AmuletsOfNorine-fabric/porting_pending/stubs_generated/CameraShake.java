package com.amuletmod.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/CameraShake.java and is ported in the client phase. */
public final class CameraShake {
   public static void from(Vec3 source, float maxDegrees, double range, int durationTicks) {  }
}
