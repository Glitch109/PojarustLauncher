package com.amuletmod.client;

import com.amuletmod.entity.MeteorVolleyEntity;
import com.amuletmod.util.Easing;

/** TEMPORARY no-op stub. The real implementation is in porting_pending/client/MeteorVolleyClient.java and is ported in the client phase. */
public final class MeteorVolleyClient {
   public static void tick(MeteorVolleyEntity volley) {  }
}
