package com.amuletmod.client;

import com.amuletmod.amulet.ActiveAbility;
import com.mojang.blaze3d.platform.InputConstants.Type;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.settings.KeyConflictContext;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class ModKeyMappings {
   public static final String CATEGORY = "key.categories.amuletmod";
   private static final int[] DEFAULT_KEYS = new int[]{66, 78, 77};
   public static final KeyMapping[] ABILITY_KEYS = new KeyMapping[3];

   private ModKeyMappings() {
   }

   @SubscribeEvent
   public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
      for (KeyMapping key : ABILITY_KEYS) {
         event.register(key);
      }
   }

   static {
      for (int slot = 0; slot < ABILITY_KEYS.length; slot++) {
         ABILITY_KEYS[slot] = new KeyMapping(
            ActiveAbility.keyMappingName(slot), KeyConflictContext.IN_GAME, Type.KEYSYM, DEFAULT_KEYS[slot], "key.categories.amuletmod"
         );
      }
   }
}
