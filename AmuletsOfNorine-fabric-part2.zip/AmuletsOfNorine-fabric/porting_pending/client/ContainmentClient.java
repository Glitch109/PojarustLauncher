package com.amuletmod.client;

import com.amuletmod.client.renderer.SubspaceWalls;
import com.amuletmod.entity.ContainmentEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class ContainmentClient {
   private static final double SPARK_RANGE = 14.0;
   private static long lastThud;

   private ContainmentClient() {
   }

   public static void tick(ContainmentEntity walls) {
      Minecraft minecraft = Minecraft.getInstance();
      LocalPlayer player = minecraft.player;
      if (player != null) {
         if (!walls.isHolding()) {
            walls.holdsLocalPlayer = false;
         } else {
            AABB bounds = walls.walls(0.0F);
            sparks(walls, bounds, player);
            voidSounds(walls, bounds, player);
            if (player.isSpectator()) {
               walls.holdsLocalPlayer = false;
            } else {
               if (!walls.holdsLocalPlayer) {
                  if (!bounds.contains(player.getBoundingBox().getCenter())) {
                     return;
                  }

                  walls.holdsLocalPlayer = true;
               }

               Vec3 back = ContainmentEntity.correction(player.getBoundingBox(), bounds);
               if (!(back.lengthSqr() < 1.0E-8)) {
                  Entity moved = player.getRootVehicle();
                  moved.setPos(moved.getX() + back.x, moved.getY() + back.y, moved.getZ() + back.z);
                  Vec3 motion = moved.getDeltaMovement();
                  moved.setDeltaMovement(back.x != 0.0 ? 0.0 : motion.x, back.y != 0.0 ? 0.0 : motion.y, back.z != 0.0 ? 0.0 : motion.z);
                  long now = player.level().getGameTime();
                  if (now - lastThud >= 8L) {
                     lastThud = now;
                     player.level()
                        .playLocalSound(player.getX(), player.getY(), player.getZ(), SoundEvents.AMETHYST_BLOCK_HIT, SoundSource.PLAYERS, 0.7F, 0.6F, false);
                  }
               }
            }
         }
      }
   }

   private static void voidSounds(ContainmentEntity walls, AABB bounds, LocalPlayer player) {
      if (!walls.isSpreading() && SubspaceWalls.shown()) {
         int t = Math.round(walls.heldFor(0.0F)) - 14;
         int last = 116;
         if (t >= 1 && t <= last) {
            Vec3 eye = player.getEyePosition();
            double x = Mth.clamp(eye.x, bounds.minX, bounds.maxX);
            double y = Mth.clamp(eye.y, bounds.minY, bounds.maxY);
            double z = Mth.clamp(eye.z, bounds.minZ, bounds.maxZ);
            if (t == last) {
               player.level().playLocalSound(x, y, z, SoundEvents.END_PORTAL_SPAWN, SoundSource.PLAYERS, 0.8F, 0.8F, false);
            } else {
               int count = SubspaceWalls.tileCount(walls.reach(0.0F));
               float span = 110.0F;
               int started = Math.round(count * SubspaceWalls.turned(t / span)) - Math.round(count * SubspaceWalls.turned((t - 1) / span));
               if (started > 0 && (started <= 1 || t % 2 == 0)) {
                  player.level()
                     .playLocalSound(
                        x,
                        y,
                        z,
                        SoundEvents.END_PORTAL_FRAME_FILL,
                        SoundSource.PLAYERS,
                        Math.min(0.3F + 0.05F * started, 0.8F),
                        0.8F + 0.5F * t / span + player.getRandom().nextFloat() * 0.1F,
                        false
                     );
               }
            }
         }
      }
   }

   private static void sparks(ContainmentEntity walls, AABB bounds, LocalPlayer player) {
      RandomSource random = player.getRandom();
      Vec3 eye = player.getEyePosition();
      double[] mins = new double[]{bounds.minX, bounds.minY, bounds.minZ};
      double[] maxs = new double[]{bounds.maxX, bounds.maxY, bounds.maxZ};
      double[] at = new double[]{eye.x, eye.y, eye.z};

      for (int axis = 0; axis < 3; axis++) {
         for (int side = 0; side < 2; side++) {
            double wall = side == 0 ? mins[axis] : maxs[axis];
            if (!(Math.abs(at[axis] - wall) > 14.0) && random.nextInt(walls.isSpreading() ? 1 : 3) == 0) {
               double[] point = new double[3];
               boolean onWall = true;

               for (int other = 0; other < 3; other++) {
                  point[other] = other == axis ? wall : at[other] + (random.nextDouble() * 2.0 - 1.0) * 14.0;
                  onWall &= other == axis || point[other] >= mins[other] && point[other] <= maxs[other];
               }

               if (onWall) {
                  player.level()
                     .addParticle(random.nextInt(4) == 0 ? ParticleTypes.END_ROD : ParticleTypes.ENCHANT, point[0], point[1], point[2], 0.0, 0.0, 0.0);
               }
            }
         }
      }
   }
}
