package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.rift.RiftKind;
import com.amuletmod.amulet.ability.strike.StrikeTimeline;
import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.client.renderer.LateBuffers;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.amuletmod.client.renderer.RiftRenderer;
import com.amuletmod.client.renderer.SkyCracks;
import com.amuletmod.network.GodStrikePacket;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance.Attenuation;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class GodStrikeClient {
   private static final ResourceLocation[] CIRCLES = new ResourceLocation[]{
      AmuletMod.id("textures/misc/strike_circle_outer.png"),
      AmuletMod.id("textures/misc/strike_circle_middle.png"),
      AmuletMod.id("textures/misc/strike_circle_inner.png")
   };
   private static final ResourceLocation RETICLE = AmuletMod.id("textures/misc/strike_reticle.png");
   private static final float[][] CIRCLE_COLORS = new float[][]{{0.7F, 0.38F, 1.0F}, {1.0F, 0.45F, 0.92F}, {0.9F, 0.8F, 1.0F}};
   private static final float[] CORE = new float[]{1.0F, 0.95F, 1.0F};
   private static final float[] MAGENTA = new float[]{1.0F, 0.42F, 0.95F};
   private static final float[] VIOLET = new float[]{0.6F, 0.25F, 1.0F};
   private static final float RIFT_SCALE = 5.5F;
   private static final double PARTICLE_RANGE = 256.0;
   private static final double QUAKE_RANGE = 500.0;
   private static final float QUAKE_MAX_DEGREES = 12.0F;
   private static final float QUAKE_EDGE_DEGREES = 0.5F;
   private static final int SHOCKWAVE_TICKS = 26;
   private static final double SHATTER_NEAR = 500.0;
   private static final double SHATTER_FAR = 900.0;
   private static final double SCREEN_NEAR = 250.0;
   private static final double SCREEN_FAR = 700.0;
   private static final int PILLARS = 5;
   private static final float[] PILLAR_RINGS = new float[]{0.95F, 0.65F, 0.35F};
   private static final int FLASH_DELAY = 4;
   private static final Map<Integer, GodStrikeClient.Strike> STRIKES = new LinkedHashMap<>();
   private static final GodStrikePost.Look LOOK = new GodStrikePost.Look();
   @Nullable
   private static ClientLevel level;
   private static float flash;
   private static float heldFlash;
   private static int heldFlashTicks;

   private GodStrikeClient() {
   }

   public static void start(GodStrikePacket packet) {
      ClientLevel current = Minecraft.getInstance().level;
      if (current != null && current.dimension() == packet.dimension()) {
         if (current != level) {
            STRIKES.clear();
            level = current;
         }

         STRIKES.putIfAbsent(packet.id(), new GodStrikeClient.Strike(packet));
      }
   }

   private static float awaken(float age) {
      float open = 0.0F;

      for (int i = 0; i < StrikeTimeline.CIRCLE_RADII.length; i++) {
         open += Easing.smoothstep(0.0F, 1.0F, (age - 10.0F - i * 20) / 34.0F);
      }

      return open * (1.0F - Easing.smoothstep(304.0F, 344.0F, age));
   }

   private static float broken(float age) {
      return age < 94.0F ? 0.0F : 1.0F - Easing.smoothstep(358.0F, 406.0F, age);
   }

   private static float reach(float age) {
      return age < 94.0F ? 0.0F : Easing.outCubic((age - 94.0F) / 14.0F);
   }

   private static float kick(float age, float at, float ticks) {
      if (age < at) {
         return 0.0F;
      } else {
         float left = Math.max(0.0F, 1.0F - (age - at) / ticks);
         return left * left;
      }
   }

   private static float heat(float age) {
      if (age < 112.0F) {
         return 0.0F;
      } else {
         return age < 304.0F ? 0.25F + 0.45F * StrikeTimeline.charge(age) : 1.0F - Easing.smoothstep(350.0F, 368.0F, age);
      }
   }

   private static float charging(float age) {
      return age < 304.0F ? StrikeTimeline.charge(age) : 0.0F;
   }

   private static float nearness(double distance, double near, double far) {
      return 1.0F - Easing.smoothstep((float)near, (float)far, (float)distance);
   }

   private static float nearness(GodStrikeClient.Strike strike, double near, double far) {
      LocalPlayer player = Minecraft.getInstance().player;
      return player == null ? 0.0F : nearness(player.position().distanceTo(strike.target), near, far);
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft.level != level) {
         STRIKES.clear();
         level = minecraft.level;
         flash = 0.0F;
         heldFlashTicks = 0;
      }

      if (level != null && !minecraft.isPaused()) {
         flash = Math.max(0.0F, flash - 0.035F);
         if (heldFlashTicks > 0 && --heldFlashTicks == 0) {
            flash = Math.max(flash, heldFlash);
         }

         Iterator<GodStrikeClient.Strike> it = STRIKES.values().iterator();

         while (it.hasNext()) {
            GodStrikeClient.Strike strike = it.next();
            strike.age++;
            cues(strike, level);
            particles(strike, level);
            if (strike.age > 700) {
               it.remove();
            }
         }
      }
   }

   private static void cues(GodStrikeClient.Strike strike, ClientLevel level) {
      int age = strike.age;
      Vec3 source = strike.source;
      Vec3 target = strike.target;
      float near = nearness(strike, 250.0, 700.0);
      if (age == 1) {
         sound(source, SoundEvents.WARDEN_SONIC_CHARGE, 1.0F, 0.5F, 0);
         sound(source, SoundEvents.BELL_BLOCK, 1.0F, 0.5F, 0);
         sound(target, SoundEvents.BEACON_ACTIVATE, 0.8F, 0.5F, 0);
      }

      for (int i = 0; i < StrikeTimeline.CIRCLE_RADII.length; i++) {
         if (age == 10 + i * 20) {
            sound(source, SoundEvents.BEACON_POWER_SELECT, 1.0F, 0.5F + 0.15F * i, 0);
            sound(source, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.0F, 0.5F + 0.2F * i, 0);
            sound(source, SoundEvents.ILLUSIONER_PREPARE_MIRROR, 0.8F, 0.6F + 0.2F * i, 0);
            sound(target, SoundEvents.RESPAWN_ANCHOR_SET_SPAWN, 0.6F + 0.2F * i, 0.5F + 0.15F * i, 0);
            if (i >= 1) {
               sound(target, (SoundEvent)SoundEvents.TRIDENT_THUNDER.value(), 0.4F + 0.3F * i, 0.5F, 0);
            }

            if (i >= 2) {
               sound(target, SoundEvents.WARDEN_EMERGE, 1.0F, 0.6F, 0);
            }

            CameraShake.from(target, 0.5F + 0.35F * i, 220.0, 12 + 4 * i);
            ImpactFrames.punch(-0.025F * (i + 1) * near);
         }
      }

      for (int ix = 0; ix < strike.pillars.length; ix++) {
         if (strike.pillars[ix] == null && age >= 10 + ix * 20) {
            strike.pillars[ix] = raisePillars(strike, ix, level);
         }
      }

      if (age == 82) {
         sound(source, SoundEvents.PORTAL_TRIGGER, 1.0F, 0.5F, 0);
      }

      if (age == 94) {
         sound(source, SoundEvents.END_PORTAL_SPAWN, 1.0F, 0.7F, 0);
         sound(source, SoundEvents.GLASS_BREAK, 1.0F, 0.4F, 0);
         sound(source, SoundEvents.ENDER_DRAGON_GROWL, 0.6F, 0.5F, 0);

         for (int ixx = 1; ixx <= 4; ixx++) {
            sound(source, SoundEvents.GLASS_BREAK, 1.0F - 0.12F * ixx, 0.4F + 0.15F * ixx, ixx * 3);
         }

         sound(source, SoundEvents.AMETHYST_CLUSTER_BREAK, 1.0F, 0.5F, 2);
         CameraShake.from(target, 1.4F, 250.0, 18);
         ImpactFrames.punch(0.12F * near);
      }

      if (age == 112) {
         sound(target, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.0F, 0.5F, 0);
         sound(target, SoundEvents.BEACON_ACTIVATE, 1.0F, 0.7F, 0);
         CameraShake.from(target, 1.2F, 200.0, 16);
         if (strike.entry != null) {
            sound(strike.entry, SoundEvents.LAVA_EXTINGUISH, 1.0F, 0.5F, 0);
            sound(strike.entry, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 0.6F, 0.6F, 0);
         }
      }

      if (age > 112 && age < 294) {
         float charge = StrikeTimeline.charge(age);
         if (age % 20 == 0) {
            sound(target, SoundEvents.BEACON_AMBIENT, 1.0F, 0.5F + 1.2F * charge, 0);
         }

         if (age % 40 == 0) {
            sound(target, SoundEvents.RESPAWN_ANCHOR_CHARGE, 1.0F, 0.5F + charge, 0);
         }

         if (age % 10 == 0) {
            CameraShake.from(target, 0.3F + 1.2F * charge, 160.0, 14);
         }
      }

      if (age >= 240 && age < 304) {
         ImpactFrames.focus(0.07F * (age - 240) / 64.0F * near);
      }

      if (age == 254) {
         sound(target, SoundEvents.WARDEN_SONIC_CHARGE, 1.0F, 0.9F, 0);
      }

      if (age == 304) {
         impact(strike);
      }

      if (age == 362) {
         sound(source, SoundEvents.BEACON_DEACTIVATE, 1.0F, 0.5F, 0);
         sound(source, SoundEvents.CHORUS_FRUIT_TELEPORT, 1.0F, 0.4F, 0);
      }

      if (age == 358) {
         sound(source, SoundEvents.ILLUSIONER_MIRROR_MOVE, 1.0F, 0.5F, 0);
      }

      if (age == 372) {
         sound(source, SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 0.5F, 0);
      }
   }

   private static void impact(GodStrikeClient.Strike strike) {
      LocalPlayer player = Minecraft.getInstance().player;
      if (player != null) {
         Vec3 target = strike.target;
         double distance = player.position().distanceTo(target);
         int delay = (int)(distance / 34.0);
         sound(target, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.0F, 0.7F, 0);
         sound(target, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 1.0F, 0.45F, delay);
         sound(target, SoundEvents.LIGHTNING_BOLT_THUNDER, 1.0F, 0.5F, delay);
         sound(target, SoundEvents.WARDEN_SONIC_BOOM, 1.0F, 0.6F, delay);
         sound(target, SoundEvents.DRAGON_FIREBALL_EXPLODE, 1.0F, 0.5F, delay);
         sound(target, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 1.0F, 0.3F, delay + 10);
         if (strike.entry != null) {
            sound(strike.entry, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 1.0F, 0.5F, (int)(player.position().distanceTo(strike.entry) / 34.0));
         }

         float whiteout = (float)Mth.clamp(1.0 - (distance - 60.0) / 380.0, 0.0, 1.0);
         if (impactFrames(nearness(distance, 250.0, 700.0))) {
            heldFlash = heldFlashTicks > 0 ? Math.max(heldFlash, whiteout) : whiteout;
            heldFlashTicks = 4;
         } else {
            flash = Math.max(flash, whiteout);
         }

         ImpactFrames.punch(-0.18F * nearness(distance, 250.0, 700.0));
         double proximity = 1.0 - distance / 500.0;
         if (proximity > 0.0) {
            float degrees = (float)(0.5 + 11.5 * Math.pow(proximity, 1.3));
            CameraShake.quake(degrees * 0.35F, 6, 0);
            CameraShake.quake(degrees, (int)(30.0 + 70.0 * proximity), delay);
         }
      }
   }

   private static boolean impactFrames(float near) {
      return near > 0.25F && GodStrikePost.available() && !(Boolean)Minecraft.getInstance().options.hideLightningFlash().get();
   }

   private static void sound(Vec3 at, SoundEvent sound, float volume, float pitch, int delayTicks) {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft.player != null) {
         double distance = minecraft.player.position().distanceTo(at);
         float scaled = volume * (float)Mth.clamp(1.0 - (distance - 120.0) / 800.0, 0.25, 1.0);
         SimpleSoundInstance instance = new SimpleSoundInstance(
            sound.getLocation(), SoundSource.PLAYERS, scaled, pitch, RandomSource.create(), false, 0, Attenuation.NONE, at.x, at.y, at.z, false
         );
         if (delayTicks > 0) {
            minecraft.getSoundManager().playDelayed(instance, delayTicks);
         } else {
            minecraft.getSoundManager().play(instance);
         }
      }
   }

   private static Vec3[] raisePillars(GodStrikeClient.Strike strike, int circle, ClientLevel level) {
      RandomSource random = RandomSource.create(strike.id * 31L + circle);
      double offset = random.nextDouble() * (float) (Math.PI * 2);
      double distance = strike.radius * PILLAR_RINGS[circle];
      Vec3[] bases = new Vec3[5];

      for (int i = 0; i < 5; i++) {
         double angle = offset + i * (float) (Math.PI * 2) / 5.0F;
         bases[i] = ground(level, strike.target.add(Math.cos(angle) * distance, 0.0, Math.sin(angle) * distance));
      }

      return bases;
   }

   private static Vec3 ground(ClientLevel level, Vec3 at) {
      MutableBlockPos pos = BlockPos.containing(at.x, at.y + 6.0, at.z).mutable();
      boolean roomAbove = false;
      int i = 0;

      while (i < 18) {
         boolean solid = level.getBlockState(pos).isSolid();
         if (solid && roomAbove) {
            return new Vec3(at.x, pos.getY() + 1.0, at.z);
         }

         roomAbove = !solid;
         i++;
         pos.move(0, -1, 0);
      }

      return at;
   }

   private static void particles(GodStrikeClient.Strike strike, ClientLevel level) {
      LocalPlayer player = Minecraft.getInstance().player;
      if (player != null) {
         if (strike.entry != null && player.position().distanceToSqr(strike.entry) < 65536.0) {
            entryParticles(strike, level, strike.entry);
         }

         if (!(player.position().distanceToSqr(strike.target) > 65536.0)) {
            RandomSource random = level.random;
            Vec3 target = strike.target;
            int age = strike.age;
            float awaken = awaken(age);
            if (awaken > 0.01F && age < 304) {
               for (int i = 0; i < 1 + (int)(awaken * 2.0F); i++) {
                  particle(
                     level,
                     ParticleTypes.END_ROD,
                     ringPoint(random, target, Math.sqrt(random.nextDouble()) * strike.radius, 0.3),
                     0.0,
                     0.02 + 0.03 * awaken,
                     0.0
                  );
               }

               if (awaken > 1.0F) {
                  particle(
                     level, ParticleTypes.REVERSE_PORTAL, ringPoint(random, target, random.nextDouble() * strike.radius * 0.7, 0.2), 0.0, 0.1 * awaken, 0.0
                  );
                  BlockState ground = level.getBlockState(BlockPos.containing(target.x, target.y - 0.5, target.z));
                  if (random.nextFloat() < (awaken - 1.0F) * 0.6F && !ground.isAir() && ground.getRenderShape() != RenderShape.INVISIBLE) {
                     particle(
                        level,
                        new BlockParticleOption(ParticleTypes.BLOCK, ground),
                        ringPoint(random, target, random.nextDouble() * strike.radius * 0.5, 0.2),
                        0.0,
                        0.25 + 0.2 * awaken,
                        0.0
                     );
                  }
               }

               if (awaken > 2.0F && random.nextFloat() < 0.6F) {
                  particle(
                     level,
                     ParticleTypes.ELECTRIC_SPARK,
                     ringPoint(random, target, random.nextDouble() * strike.radius * 0.4, 0.3),
                     random.nextGaussian() * 0.2,
                     0.2,
                     random.nextGaussian() * 0.2
                  );
               }
            }

            if (age > 112 && age < 304) {
               float charge = StrikeTimeline.charge(age);
               int count = 1 + (int)(charge * 4.0F);

               for (int i = 0; i < count; i++) {
                  Vec3 ground = ringPoint(random, target, 1.0 + random.nextDouble() * 8.0, 0.1);
                  particle(level, ParticleTypes.REVERSE_PORTAL, ground, 0.0, 0.12 + 0.25 * charge, 0.0);
                  Vec3 far = ringPoint(random, target, 4.0 + random.nextDouble() * 8.0, random.nextDouble() * 5.0);
                  Vec3 pull = target.subtract(far).scale(0.06);
                  particle(level, ParticleTypes.END_ROD, far, pull.x, pull.y, pull.z);
               }

               for (int i = 0; i < 2; i++) {
                  particle(
                     level,
                     ParticleTypes.ELECTRIC_SPARK,
                     target.add(0.0, 0.2, 0.0),
                     random.nextGaussian() * 0.35,
                     random.nextDouble() * 0.4,
                     random.nextGaussian() * 0.35
                  );
               }

               BlockState ground = level.getBlockState(BlockPos.containing(target.x, target.y - 0.5, target.z));
               if (random.nextBoolean() && !ground.isAir() && ground.getRenderShape() != RenderShape.INVISIBLE) {
                  particle(
                     level,
                     new BlockParticleOption(ParticleTypes.BLOCK, ground),
                     ringPoint(random, target, random.nextDouble() * 3.0, 0.1),
                     0.0,
                     0.3 + 0.4 * charge,
                     0.0
                  );
               }
            }

            if (age == 304) {
               for (int i = 0; i < 4; i++) {
                  particle(level, ParticleTypes.FLASH, ringPoint(random, target, random.nextDouble() * 6.0, 2.0), 0.0, 0.0, 0.0);
               }

               for (int i = 0; i < 8; i++) {
                  particle(level, ParticleTypes.EXPLOSION_EMITTER, ringPoint(random, target, random.nextDouble() * strike.radius * 0.6, 1.0), 0.0, 0.0, 0.0);
               }

               for (int i = 0; i < 150; i++) {
                  double angle = random.nextDouble() * (float) (Math.PI * 2);
                  double speed = 0.8 + random.nextDouble();
                  Vec3 out = new Vec3(Math.cos(angle), 0.0, Math.sin(angle));
                  particle(level, ParticleTypes.LARGE_SMOKE, target.add(out.scale(2.0)).add(0.0, 1.0, 0.0), out.x * speed, 0.05, out.z * speed);
                  particle(level, ParticleTypes.FLAME, target.add(out).add(0.0, 0.5, 0.0), out.x * speed * 0.8, 0.2, out.z * speed * 0.8);
               }

               for (int i = 0; i < 120; i++) {
                  particle(level, ParticleTypes.LAVA, ringPoint(random, target, random.nextDouble() * 5.0, 0.5), 0.0, 0.0, 0.0);
               }

               for (int i = 0; i < 40; i++) {
                  particle(
                     level,
                     ParticleTypes.CAMPFIRE_SIGNAL_SMOKE,
                     ringPoint(random, target, random.nextDouble() * 4.0, 1.0),
                     0.0,
                     0.1 + random.nextDouble() * 0.2,
                     0.0
                  );
               }
            }

            if (age > 304) {
               float fade = 1.0F - (age - 304) / 396.0F;
               double crater = strike.radius;
               if (random.nextFloat() < fade * 2.0F) {
                  particle(
                     level,
                     ParticleTypes.CAMPFIRE_SIGNAL_SMOKE,
                     ringPoint(random, target, random.nextDouble() * crater * 0.5, -random.nextDouble() * crater * 0.25),
                     0.0,
                     0.08,
                     0.0
                  );
               }

               for (int i = 0; i < (int)(10.0F * fade); i++) {
                  particle(level, ParticleTypes.ASH, ringPoint(random, target, random.nextDouble() * 50.0, 5.0 + random.nextDouble() * 25.0), 0.0, 0.0, 0.0);
               }

               if (random.nextFloat() < fade * 0.6F) {
                  particle(level, ParticleTypes.LAVA, ringPoint(random, target, random.nextDouble() * crater * 0.3, -crater * 0.3), 0.0, 0.0, 0.0);
               }

               for (int i = 0; i < (int)(3.0F * fade); i++) {
                  particle(
                     level,
                     ParticleTypes.FLAME,
                     ringPoint(random, target, random.nextDouble() * crater * 0.6, -random.nextDouble() * crater * 0.2),
                     0.0,
                     0.03,
                     0.0
                  );
               }
            }
         }
      }
   }

   private static void entryParticles(GodStrikeClient.Strike strike, ClientLevel level, Vec3 entry) {
      RandomSource random = level.random;
      int age = strike.age;
      if (age > 112 && age < 350) {
         float heat = heat(age);
         particle(level, ParticleTypes.LAVA, ringPoint(random, entry, random.nextDouble() * 1.5, 0.2), 0.0, 0.0, 0.0);
         if (random.nextFloat() < heat) {
            particle(
               level,
               ParticleTypes.LARGE_SMOKE,
               ringPoint(random, entry, random.nextDouble() * 2.0, 0.3),
               random.nextGaussian() * 0.05,
               0.15 + 0.2 * heat,
               random.nextGaussian() * 0.05
            );
         }

         for (int i = 0; i < 2; i++) {
            particle(
               level,
               ParticleTypes.ELECTRIC_SPARK,
               entry.add(0.0, 0.3, 0.0),
               random.nextGaussian() * 0.4,
               random.nextDouble() * 0.6,
               random.nextGaussian() * 0.4
            );
         }
      }

      if (age == 304) {
         for (int i = 0; i < 3; i++) {
            particle(level, ParticleTypes.EXPLOSION_EMITTER, ringPoint(random, entry, random.nextDouble() * 3.0, 0.5), 0.0, 0.0, 0.0);
         }

         particle(level, ParticleTypes.FLASH, entry.add(0.0, 1.0, 0.0), 0.0, 0.0, 0.0);

         for (int i = 0; i < 80; i++) {
            particle(
               level,
               ParticleTypes.FLAME,
               ringPoint(random, entry, random.nextDouble() * 1.5, 0.3),
               random.nextGaussian() * 0.15,
               0.6 + random.nextDouble() * 0.8,
               random.nextGaussian() * 0.15
            );
         }

         for (int i = 0; i < 30; i++) {
            particle(
               level, ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, ringPoint(random, entry, random.nextDouble() * 2.0, 0.5), 0.0, 0.2 + random.nextDouble() * 0.2, 0.0
            );
         }
      }
   }

   private static Vec3 ringPoint(RandomSource random, Vec3 center, double distance, double height) {
      double angle = random.nextDouble() * (float) (Math.PI * 2);
      return center.add(Math.cos(angle) * distance, height, Math.sin(angle) * distance);
   }

   private static void particle(ClientLevel level, ParticleOptions particle, Vec3 at, double dx, double dy, double dz) {
      level.addParticle(particle, true, at.x, at.y, at.z, dx, dy, dz);
   }

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      if (event.getStage() == Stage.AFTER_PARTICLES && !STRIKES.isEmpty()) {
         float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
         Camera camera = event.getCamera();
         BufferSource buffers = LateBuffers.get();
         GodStrikeClient.Strike nearest = nearest(camera.getPosition());
         if (nearest != null) {
            float age = nearest.age + partialTick;
            Matrix4f pose = event.getPoseStack().last().pose();
            if (GodStrikePost.available()) {
               GodStrikePost.apply(new Matrix4f(event.getModelViewMatrix()).mul(pose), event.getProjectionMatrix(), look(nearest, age, camera.getPosition()));
            } else {
               double distance = camera.getPosition().distanceTo(nearest.target);
               SkyCracks.render(
                  buffers,
                  pose,
                  nearest.source.subtract(camera.getPosition()).toVector3f(),
                  Minecraft.getInstance().gameRenderer.getRenderDistance() * 1.5F,
                  nearest.id,
                  broken(age) * nearness(distance, 500.0, 900.0),
                  reach(age),
                  age / 20.0F
               );
            }
         }

         for (GodStrikeClient.Strike strike : STRIKES.values()) {
            float age = strike.age + partialTick;
            if (age <= 420.0F) {
               render(strike, age, event.getPoseStack(), camera, buffers);
            }
         }
      }
   }

   @Nullable
   private static GodStrikeClient.Strike nearest(Vec3 camera) {
      GodStrikeClient.Strike nearest = null;
      double best = Double.MAX_VALUE;

      for (GodStrikeClient.Strike strike : STRIKES.values()) {
         double distance = camera.distanceToSqr(strike.target);
         if (strike.age <= 420 && distance < best) {
            nearest = strike;
            best = distance;
         }
      }

      return nearest;
   }

   private static GodStrikePost.Look look(GodStrikeClient.Strike strike, float age, Vec3 camera) {
      double distance = camera.distanceTo(strike.target);
      float near = nearness(distance, 250.0, 700.0);
      float broken = broken(age);
      float charge = charging(age);
      float awaken = awaken(age);
      GodStrikePost.Look look = LOOK;
      look.target.set((float)(strike.target.x - camera.x), (float)(strike.target.y - camera.y), (float)(strike.target.z - camera.z));
      look.rift.set((float)(strike.source.x - camera.x), (float)(strike.source.y - camera.y), (float)(strike.source.z - camera.z));
      Vec3 entry = strike.entry != null ? strike.entry : strike.target;
      look.entry.set((float)(entry.x - camera.x), (float)(entry.y - camera.y), (float)(entry.z - camera.z));
      look.awaken = awaken;
      look.radius = strike.radius;
      look.charge = charge;
      look.time = age / 20.0F;
      look.broken = broken * nearness(distance, 500.0, 900.0);
      look.reach = reach(age);
      look.jolt = Math.min(1.0F, kick(age, 94.0F, 30.0F) + kick(age, 304.0F, 40.0F));
      look.fallen = (0.04F + 0.22F * charge + (age >= 304.0F ? 0.14F : 0.0F)) * broken;
      look.seed = strike.seed();
      look.heat = heat(age);
      look.gloom = Math.min(1.0F, 0.1F * awaken + 0.3F * broken + 0.25F * charge) * near;
      float aberration = 0.0F;

      for (int i = 0; i < StrikeTimeline.CIRCLE_RADII.length; i++) {
         aberration += (0.25F + 0.2F * i) * kick(age, 10 + i * 20, 20.0F);
      }

      aberration += 1.6F * kick(age, 94.0F, 30.0F) + 2.5F * kick(age, 304.0F, 45.0F);
      if (age > 104.0F && age < 304.0F) {
         aberration += 0.1F + 0.5F * charge * charge;
      }

      look.aberration = aberration * near;
      look.vignette = Math.min(1.0F, look.gloom * 0.9F + (0.5F * kick(age, 94.0F, 30.0F) + 0.4F * kick(age, 304.0F, 40.0F)) * near);
      look.impactFrame = 0.0F;
      look.impactKind = 0.0F;
      if (impactFrames(near)) {
         float tear = age - 94.0F;
         float hit = age - 304.0F;
         if (tear >= 0.0F && tear < 4.0F) {
            look.impactFrame = tear < 2.0F ? 1.0F : 1.0F - (tear - 2.0F) / 2.0F;
            look.impactKind = 1.0F;
         } else if (hit >= 0.0F && hit < 5.0F) {
            look.impactFrame = hit < 3.0F ? 1.0F : 1.0F - (hit - 4.0F + 1.0F) / 2.0F;
            look.impactKind = 2.0F;
         }
      }

      return look;
   }

   private static void render(GodStrikeClient.Strike strike, float age, PoseStack poseStack, Camera camera, BufferSource buffers) {
      Vec3 view = camera.getPosition();
      Vec3 target = strike.target;
      Vector3f eye = new Vector3f((float)(view.x - target.x), (float)(view.y - target.y), (float)(view.z - target.z));
      Vector3f source = strike.source.subtract(target).toVector3f();
      poseStack.pushPose();
      poseStack.translate(target.x - view.x, target.y - view.y, target.z - view.z);
      renderRift(strike, age, poseStack, buffers, source);
      renderCircles(strike, age, poseStack, buffers);
      renderPillars(strike, age, poseStack, buffers, eye);
      renderBeam(strike, age, poseStack, buffers, camera, source, eye);
      renderEntry(strike, age, poseStack, buffers, camera);
      renderGround(strike, age, poseStack, buffers, camera, eye);
      poseStack.popPose();
   }

   private static void renderRift(GodStrikeClient.Strike strike, float age, PoseStack poseStack, BufferSource buffers, Vector3f source) {
      float seam = riftSeam(age);
      float open = riftOpen(age);
      if (!(seam <= 0.001F) || !(open <= 0.001F)) {
         int seed = strike.id * 7919;
         poseStack.pushPose();
         poseStack.translate(source.x(), source.y(), source.z());
         poseStack.mulPose(strike.facing);
         poseStack.scale(5.5F, 5.5F, 5.5F);
         poseStack.translate(0.0F, -1.6F, 0.0F);
         float[] outline = RiftRenderer.outline(seed, open, seam, age);
         Matrix4f pose = poseStack.last().pose();
         if (open > 0.01F) {
            RiftRenderer.endWindow(buffers, pose, poseStack.last(), outline);
            RiftRenderer.flushEndWindow(buffers);
         }

         RiftRenderer.light(buffers.getBuffer(ModRenderTypes.GLOW), pose, RiftKind.END, outline, open, seam, age, age - 94.0F, seed);
         buffers.endBatch(ModRenderTypes.GLOW);
         poseStack.popPose();
      }
   }

   private static float riftSeam(float age) {
      if (age < 82.0F) {
         return 0.0F;
      } else {
         float closing = (age - 362.0F) / 16.0F;
         return closing > 0.0F ? 1.0F - Easing.smoothstep(0.55F, 1.0F, closing) : Easing.smoothstep(0.0F, 1.0F, (age - 82.0F) / 12.0F);
      }
   }

   private static float riftOpen(float age) {
      float opening = (age - 94.0F) / 16.0F;
      if (opening <= 0.0F) {
         return 0.0F;
      } else {
         float open = opening >= 1.0F ? 1.0F : Easing.outBack(opening);
         float closing = (age - 362.0F) / 16.0F;
         return closing <= 0.0F ? open : open * (1.0F - Easing.smoothstep(0.0F, 0.65F, closing));
      }
   }

   private static void renderCircles(GodStrikeClient.Strike strike, float age, PoseStack poseStack, BufferSource buffers) {
      float flare = age > 304.0F && age < 334.0F ? 1.0F + 1.5F * (1.0F - (age - 304.0F) / 30.0F) : 1.0F;

      for (int i = 0; i < CIRCLES.length; i++) {
         float open = StrikeTimeline.circleOpen(i, age);
         if (!(open <= 0.002F)) {
            float along = strike.length - StrikeTimeline.CIRCLE_OFFSETS[i];
            float spin = (i % 2 == 0 ? 1.0F : -1.0F) * (age * (0.5F + 0.35F * i) + 240.0F * (1.0F - Math.min(open, 1.0F)));
            float brightness = Math.min(open, 1.0F) * (0.8F + 0.2F * Mth.sin(age * 0.12F + i * 2.0F)) * flare;
            float[] color = CIRCLE_COLORS[i];
            float radius = StrikeTimeline.CIRCLE_RADII[i] * open;
            poseStack.pushPose();
            poseStack.translate(strike.lineOfFire.x * along, strike.lineOfFire.y * along, strike.lineOfFire.z * along);
            poseStack.mulPose(strike.facing);
            poseStack.mulPose(Axis.ZP.rotationDegrees(spin));
            RenderType type = ModRenderTypes.skyGlow(CIRCLES[i]);
            texturedQuad(buffers.getBuffer(type), poseStack.last().pose(), radius, false, color[0] * brightness, color[1] * brightness, color[2] * brightness);
            buffers.endBatch(type);
            poseStack.popPose();
         }
      }
   }

   private static void renderPillars(GodStrikeClient.Strike strike, float age, PoseStack poseStack, BufferSource buffers, Vector3f eye) {
      if (!(age > 310.0F)) {
         VertexConsumer consumer = buffers.getBuffer(ModRenderTypes.GLOW);
         Matrix4f pose = poseStack.last().pose();
         float fade = age < 304.0F ? 1.0F : 1.0F - (age - 304.0F) / 6.0F;
         float charge = charging(age);

         for (int i = 0; i < strike.pillars.length; i++) {
            Vec3[] bases = strike.pillars[i];
            if (bases != null) {
               float rise = Easing.outCubic((age - 10.0F - i * 20) / 14.0F);
               float height = (30.0F + 18.0F * i) * rise * (1.0F + 0.4F * charge);
               float width = (0.3F + 0.12F * i) * (1.0F + 0.5F * charge);

               for (int j = 0; j < bases.length; j++) {
                  Vec3 base = bases[j];
                  Vector3f from = new Vector3f((float)(base.x - strike.target.x), (float)(base.y - strike.target.y), (float)(base.z - strike.target.z));
                  Vector3f[] points = new Vector3f[9];

                  for (int k = 0; k < points.length; k++) {
                     points[k] = new Vector3f(from).add(0.0F, height * k / (points.length - 1), 0.0F);
                  }

                  float flicker = (0.75F + 0.25F * Mth.sin(age * 0.9F + j * 1.7F + i)) * fade;
                  GlowDraw.taperedRibbon(consumer, pose, points, eye, width, CORE[0], CORE[1], CORE[2], 0.85F * flicker);
                  GlowDraw.taperedRibbon(consumer, pose, points, eye, width * 5.0F, MAGENTA[0], MAGENTA[1], MAGENTA[2], 0.3F * flicker);
                  poseStack.pushPose();
                  poseStack.translate(from.x(), from.y(), from.z());
                  GlowDraw.ring(
                     consumer, poseStack.last().pose(), 0.1F, 0.0F, width * 8.0F, 16, MAGENTA[0], MAGENTA[1], MAGENTA[2], 0.5F * flicker * rise, 0.0F
                  );
                  poseStack.popPose();
               }
            }
         }

         buffers.endBatch(ModRenderTypes.GLOW);
      }
   }

   private static void renderBeam(
      GodStrikeClient.Strike strike, float age, PoseStack poseStack, BufferSource buffers, Camera camera, Vector3f source, Vector3f eye
   ) {
      if (!(age < 104.0F) && !(age > 368.0F)) {
         Matrix4f pose = poseStack.last().pose();
         Vector3f ground = new Vector3f();
         VertexConsumer consumer = buffers.getBuffer(ModRenderTypes.GLOW);
         if (age < 304.0F) {
            float reach = StrikeTimeline.beamReach(age);
            Vector3f end = new Vector3f(source).lerp(ground, reach);
            float charge = StrikeTimeline.charge(age);
            float width = 0.22F + 0.9F * charge + 0.07F * Mth.sin(age * 1.7F);
            float flicker = 0.85F + 0.15F * Mth.sin(age * 3.1F);
            GlowDraw.beam(consumer, pose, source, end, eye, width, 40, CORE[0], CORE[1], CORE[2], flicker);
            GlowDraw.beam(consumer, pose, source, end, eye, width * 3.0F, 40, MAGENTA[0], MAGENTA[1], MAGENTA[2], 0.5F * flicker);
            GlowDraw.beam(consumer, pose, source, end, eye, width * 9.0F, 40, VIOLET[0], VIOLET[1], VIOLET[2], 0.16F * flicker);
            if (reach >= 1.0F) {
               billboard(poseStack, camera, 0.0F, () -> {
                  Matrix4f flare = poseStack.last().pose();
                  GlowDraw.starburst(consumer, flare, 2.0F + 6.0F * charge, 0.12F, CORE[0], CORE[1], CORE[2], 0.8F * flicker);
                  GlowDraw.starburst(consumer, flare, 3.0F + 5.0F * charge, 0.8F, MAGENTA[0], MAGENTA[1], MAGENTA[2], 0.35F * flicker);
               });
            }
         } else {
            float fade = 1.0F - Easing.smoothstep(350.0F, 368.0F, age);
            float width = 7.5F * Easing.outBack((age - 304.0F) / 5.0F) * (1.0F + 0.06F * Mth.sin(age * 2.1F)) * (0.35F + 0.65F * fade);
            GlowDraw.beam(consumer, pose, source, ground, eye, width * 0.45F, 40, CORE[0], CORE[1], CORE[2], fade);
            GlowDraw.beam(consumer, pose, source, ground, eye, width, 40, MAGENTA[0], MAGENTA[1], MAGENTA[2], 0.8F * fade);
            GlowDraw.beam(consumer, pose, source, ground, eye, width * 2.1F, 40, VIOLET[0], VIOLET[1], VIOLET[2], 0.35F * fade);
            GlowDraw.beam(consumer, pose, source, ground, eye, width * 4.2F, 40, VIOLET[0], VIOLET[1], VIOLET[2], 0.12F * fade);

            for (int strand = 0; strand < 2; strand++) {
               GlowDraw.ribbon(
                  consumer,
                  pose,
                  helix(strike, source, width * 0.8F, age * 0.6F + strand * (float) Math.PI),
                  eye,
                  0.5F + width * 0.05F,
                  CORE[0],
                  CORE[1],
                  CORE[2],
                  0.7F * fade
               );
            }
         }

         buffers.endBatch(ModRenderTypes.GLOW);
      }
   }

   private static Vector3f[] helix(GodStrikeClient.Strike strike, Vector3f source, float radius, float phase) {
      int count = 120;
      float turns = source.length() / 5.0F;
      Vector3f[] points = new Vector3f[count + 1];

      for (int i = 0; i <= count; i++) {
         float t = (float)i / count;
         float angle = t * turns + phase;
         points[i] = new Vector3f(source)
            .mul(1.0F - t)
            .add(new Vector3f(strike.across).mul(Mth.cos(angle) * radius))
            .add(new Vector3f(strike.up).mul(Mth.sin(angle) * radius));
      }

      return points;
   }

   private static void renderEntry(GodStrikeClient.Strike strike, float age, PoseStack poseStack, BufferSource buffers, Camera camera) {
      Vec3 entry = strike.entry;
      float heat = heat(age);
      if (entry != null && !(heat <= 0.001F)) {
         VertexConsumer consumer = buffers.getBuffer(ModRenderTypes.GLOW);
         float flicker = 0.85F + 0.15F * Mth.sin(age * 2.7F);
         poseStack.pushPose();
         poseStack.translate(entry.x - strike.target.x, entry.y - strike.target.y, entry.z - strike.target.z);
         Matrix4f pose = poseStack.last().pose();
         float molten = 2.0F + 4.0F * heat;
         GlowDraw.ring(consumer, pose, 0.15F, 0.0F, molten, 32, CORE[0], CORE[1], CORE[2], 0.9F * heat * flicker, 0.0F);
         GlowDraw.ring(consumer, pose, 0.15F, molten * 0.6F, molten, 32, MAGENTA[0], MAGENTA[1], MAGENTA[2], 0.0F, 0.6F * heat * flicker);
         GlowDraw.ring(consumer, pose, 0.15F, molten, molten * 1.6F, 32, MAGENTA[0], MAGENTA[1], MAGENTA[2], 0.6F * heat * flicker, 0.0F);
         billboard(poseStack, camera, 0.5F, () -> {
            Matrix4f flare = poseStack.last().pose();
            GlowDraw.starburst(consumer, flare, 3.0F + 5.0F * heat, 0.12F, CORE[0], CORE[1], CORE[2], 0.8F * heat * flicker);
            GlowDraw.starburst(consumer, flare, 4.0F + 6.0F * heat, 0.8F, MAGENTA[0], MAGENTA[1], MAGENTA[2], 0.35F * heat * flicker);
         });
         poseStack.popPose();
         buffers.endBatch(ModRenderTypes.GLOW);
      }
   }

   private static void renderGround(GodStrikeClient.Strike strike, float age, PoseStack poseStack, BufferSource buffers, Camera camera, Vector3f eye) {
      if (age > 94.0F && age < 308.0F) {
         float charge = StrikeTimeline.charge(age);
         float appear = Mth.clamp((age - 94.0F) / 20.0F, 0.0F, 1.0F);
         float brightness = appear * (0.7F + 0.3F * Mth.sin(age * 0.4F)) * (0.6F + 0.8F * charge);
         poseStack.pushPose();
         poseStack.translate(0.0F, 0.15F, 0.0F);
         poseStack.mulPose(Axis.YP.rotationDegrees(age * 1.8F));
         RenderType type = ModRenderTypes.skyGlow(RETICLE);
         texturedQuad(
            buffers.getBuffer(type),
            poseStack.last().pose(),
            (5.0F + 11.0F * charge) * Easing.outBack(appear),
            true,
            1.0F * brightness,
            0.4F * brightness,
            0.9F * brightness
         );
         buffers.endBatch(type);
         poseStack.popPose();
      }

      float since = age - 304.0F;
      if (!(since < 0.0F) && !(since > 26.0F)) {
         float radius = strike.radius;
         VertexConsumer consumer = buffers.getBuffer(ModRenderTypes.GLOW);
         Matrix4f pose = poseStack.last().pose();
         float wave = radius * 2.1F * Easing.outCubic(since / 26.0F);
         float waveAlpha = 0.9F * (1.0F - since / 26.0F);
         float waveWidth = Mth.lerp(since / 26.0F, 4.0F, 1.0F);
         GlowDraw.ring(consumer, pose, 0.6F, Math.max(0.0F, wave - waveWidth), wave, 96, MAGENTA[0], MAGENTA[1], MAGENTA[2], 0.0F, waveAlpha);
         GlowDraw.ring(consumer, pose, 0.6F, wave, wave + waveWidth * 0.5F, 96, CORE[0], CORE[1], CORE[2], waveAlpha, 0.0F);
         if (since < 16.0F) {
            float domeRadius = radius * 0.85F * Easing.outCubic(since / 9.0F);
            float domeAlpha = 0.6F * (1.0F - since / 16.0F);
            float ex = eye.x();
            float ey = eye.y();
            float ez = eye.z();
            GlowDraw.glowSphere(consumer, pose, domeRadius, 0.0F, (float) (Math.PI / 2), 40, 12, MAGENTA[0], MAGENTA[1], MAGENTA[2], (nx, ny, nz) -> {
               float px = ex - nx * domeRadius;
               float py = ey - ny * domeRadius;
               float pz = ez - nz * domeRadius;
               float length = Mth.sqrt(px * px + py * py + pz * pz);
               float facing = length < 1.0E-4F ? 1.0F : Math.abs(nx * px + ny * py + nz * pz) / length;
               return domeAlpha * (0.25F + 0.75F * (1.0F - facing));
            });
         }

         if (since < 12.0F) {
            float strength = 1.0F - since / 12.0F;
            billboard(poseStack, camera, 2.0F, () -> {
               Matrix4f flare = poseStack.last().pose();
               GlowDraw.starburst(consumer, flare, 12.0F + 70.0F * (1.0F - strength), 0.06F, CORE[0], CORE[1], CORE[2], strength);
               GlowDraw.starburst(consumer, flare, 20.0F + 40.0F * (1.0F - strength), 0.9F, MAGENTA[0], MAGENTA[1], MAGENTA[2], 0.6F * strength);
            });
         }

         buffers.endBatch(ModRenderTypes.GLOW);
      }
   }

   private static void billboard(PoseStack poseStack, Camera camera, float height, Runnable draw) {
      poseStack.pushPose();
      poseStack.translate(0.0F, height, 0.0F);
      poseStack.mulPose(camera.rotation());
      draw.run();
      poseStack.popPose();
   }

   private static void texturedQuad(VertexConsumer consumer, Matrix4f pose, float radius, boolean flat, float r, float g, float b) {
      float[][] corners = new float[][]{{-1.0F, -1.0F, 0.0F, 0.0F}, {-1.0F, 1.0F, 0.0F, 1.0F}, {1.0F, 1.0F, 1.0F, 1.0F}, {1.0F, -1.0F, 1.0F, 0.0F}};

      for (float[] corner : corners) {
         float x = corner[0] * radius;
         float y = corner[1] * radius;
         consumer.addVertex(pose, x, flat ? 0.0F : y, flat ? y : 0.0F)
            .setUv(corner[2], corner[3])
            .setColor(Mth.clamp(r, 0.0F, 1.0F), Mth.clamp(g, 0.0F, 1.0F), Mth.clamp(b, 0.0F, 1.0F), 1.0F);
      }
   }

   @SubscribeEvent
   public static void onRenderGui(net.neoforged.neoforge.client.event.RenderGuiEvent.Post event) {
      if (!(flash <= 0.001F)) {
         GuiGraphics graphics = event.getGuiGraphics();
         int alpha = (int)(flash * flash * 235.0F);
         graphics.fill(0, 0, graphics.guiWidth(), graphics.guiHeight(), alpha << 24 | 16183039);
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      STRIKES.clear();
      level = null;
      flash = 0.0F;
      heldFlashTicks = 0;
   }

   private static final class Strike {
      final int id;
      final Vec3 target;
      final Vec3 source;
      final Vec3 lineOfFire;
      final float length;
      final float radius;
      final Quaternionf facing;
      final Vector3f across;
      final Vector3f up;
      final Vec3[][] pillars = new Vec3[StrikeTimeline.CIRCLE_RADII.length][];
      @Nullable
      final Vec3 entry;
      int age;

      Strike(GodStrikePacket packet) {
         this.id = packet.id();
         this.target = packet.target();
         this.source = packet.source();
         this.entry = packet.entry();
         Vec3 rise = this.source.subtract(this.target);
         this.length = (float)rise.length();
         this.lineOfFire = rise.normalize();
         this.radius = packet.radius();
         this.age = packet.age();
         Vector3f axis = this.lineOfFire.toVector3f().normalize();
         this.up = new Vector3f(0.0F, 1.0F, 0.0F).sub(new Vector3f(axis).mul(axis.y())).normalize();
         this.across = new Vector3f(this.up).cross(axis).normalize();
         this.facing = new Quaternionf()
            .setFromNormalized(
               new Matrix3f(this.across.x(), this.across.y(), this.across.z(), this.up.x(), this.up.y(), this.up.z(), axis.x(), axis.y(), axis.z())
            );
      }

      float seed() {
         return this.id * 0.618034F % 1.0F * 50.0F;
      }
   }
}
