package com.amuletmod.client;

import com.amuletmod.client.renderer.AbsorbedBlockRenderer;
import com.amuletmod.client.renderer.AmuletCurioRenderer;
import com.amuletmod.client.renderer.AmuletModels;
import com.amuletmod.client.renderer.BarrierRenderer;
import com.amuletmod.client.renderer.BlockHoleRenderer;
import com.amuletmod.client.renderer.ChainBindRenderer;
import com.amuletmod.client.renderer.ContainmentRenderer;
import com.amuletmod.client.renderer.HellhoundRenderer;
import com.amuletmod.client.renderer.IceSpikeRenderer;
import com.amuletmod.client.renderer.JewelersBenchRenderer;
import com.amuletmod.client.renderer.MeteorModel;
import com.amuletmod.client.renderer.MeteorRenderer;
import com.amuletmod.client.renderer.MeteorVolleyRenderer;
import com.amuletmod.client.renderer.OfudaRenderer;
import com.amuletmod.client.renderer.PageBindRenderer;
import com.amuletmod.client.renderer.PageRenderer;
import com.amuletmod.client.renderer.PageStormRenderer;
import com.amuletmod.client.renderer.PetalRenderer;
import com.amuletmod.client.renderer.RiftRenderer;
import com.amuletmod.client.renderer.RockArmorLayer;
import com.amuletmod.client.renderer.RockShellRenderer;
import com.amuletmod.client.renderer.RootsRenderer;
import com.amuletmod.client.renderer.RunicObeliskRenderer;
import com.amuletmod.client.renderer.SealCaptureRenderer;
import com.amuletmod.client.renderer.SealCoreRenderer;
import com.amuletmod.client.renderer.SealRenderer;
import com.amuletmod.client.renderer.SeismicWaveRenderer;
import com.amuletmod.client.renderer.ShadowPlayerRenderer;
import com.amuletmod.client.renderer.StormCloudRenderer;
import com.amuletmod.client.renderer.SubspaceWalls;
import com.amuletmod.client.renderer.TimeFieldRenderer;
import com.amuletmod.client.renderer.TitanBladeRenderer;
import com.amuletmod.client.renderer.TitanFistModel;
import com.amuletmod.client.renderer.TitanFistRenderer;
import com.amuletmod.client.renderer.TitanFlameLayer;
import com.amuletmod.client.renderer.TitanSlashRenderer;
import com.amuletmod.client.renderer.UnderworldHandModel;
import com.amuletmod.client.renderer.UnderworldHandRenderer;
import com.amuletmod.client.screen.JewelersBenchScreen;
import com.amuletmod.client.screen.RunicObeliskScreen;
import com.amuletmod.registry.ModBlockEntities;
import com.amuletmod.registry.ModEntities;
import com.amuletmod.registry.ModMenus;
import net.minecraft.client.renderer.entity.BeeRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.PlayerSkin.Model;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.RegisterItemDecorationsEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent.AddLayers;
import net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterLayerDefinitions;
import net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterRenderers;
import top.theillusivec4.curios.api.client.CuriosRendererRegistry;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class ModClientSetup {
   private ModClientSetup() {
   }

   @SubscribeEvent
   public static void onRegisterMenuScreens(RegisterMenuScreensEvent event) {
      event.register((MenuType)ModMenus.JEWELERS_BENCH.get(), JewelersBenchScreen::new);
      event.register((MenuType)ModMenus.RUNIC_OBELISK.get(), RunicObeliskScreen::new);
   }

   @SubscribeEvent
   public static void onClientSetup(FMLClientSetupEvent event) {
      AmuletModels.amulets().forEach(amulet -> CuriosRendererRegistry.register(amulet, () -> AmuletCurioRenderer.INSTANCE));
   }

   @SubscribeEvent
   public static void onRegisterRenderers(RegisterRenderers event) {
      event.registerEntityRenderer((EntityType)ModEntities.METEOR.get(), MeteorRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.SEEKING_METEOR.get(), MeteorRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.METEOR_VOLLEY.get(), MeteorVolleyRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.BLOCK_HOLE.get(), BlockHoleRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.ABSORBED_BLOCK.get(), AbsorbedBlockRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.RIFT.get(), RiftRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.BARRIER.get(), BarrierRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.ICE_SPIKE.get(), IceSpikeRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.TIME_FIELD.get(), TimeFieldRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.PETAL.get(), PetalRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.MONARCH_BEE.get(), BeeRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.ROOTS.get(), RootsRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.HELLHOUND.get(), HellhoundRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.UNDERWORLD_HAND.get(), UnderworldHandRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.ROCK_SHELL.get(), RockShellRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.SEISMIC_WAVE.get(), SeismicWaveRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.STORM_CLOUD.get(), StormCloudRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.CHAIN_BIND.get(), ChainBindRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.SHADOW_PLAYER.get(), ShadowPlayerRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.PAGE.get(), PageRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.PAGE_BIND.get(), PageBindRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.OFUDA.get(), OfudaRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.PAGE_STORM.get(), PageStormRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.SEAL.get(), SealRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.CONTAINMENT.get(), ContainmentRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.SEAL_CAPTURE.get(), SealCaptureRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.SEAL_CORE.get(), SealCoreRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.TITAN_FIST.get(), TitanFistRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.TITAN_SLASH.get(), TitanSlashRenderer::new);
      event.registerEntityRenderer((EntityType)ModEntities.TITAN_BLADE.get(), TitanBladeRenderer::new);
      event.registerBlockEntityRenderer((BlockEntityType)ModBlockEntities.JEWELERS_BENCH.get(), JewelersBenchRenderer::new);
      event.registerBlockEntityRenderer((BlockEntityType)ModBlockEntities.RUNIC_OBELISK.get(), RunicObeliskRenderer::new);
   }

   @SubscribeEvent
   public static void onRegisterLayers(RegisterLayerDefinitions event) {
      event.registerLayerDefinition(MeteorModel.LAYER, MeteorModel::createLayer);
      event.registerLayerDefinition(HellhoundRenderer.LAYER, HellhoundRenderer::createLayer);
      event.registerLayerDefinition(UnderworldHandModel.LAYER, UnderworldHandModel::createLayer);
      event.registerLayerDefinition(TitanFistModel.LAYER, TitanFistModel::createLayer);
      event.registerLayerDefinition(TitanFistModel.LEFT_LAYER, TitanFistModel::createLeftLayer);
   }

   @SubscribeEvent
   public static void onRegisterItemDecorations(RegisterItemDecorationsEvent event) {
      event.register(Items.BOOK, PaperCutsClient.WEAR_BAR);
      event.register(Items.ENCHANTED_BOOK, PaperCutsClient.WEAR_BAR);
   }

   @SubscribeEvent
   public static void onRegisterShaders(RegisterShadersEvent event) {
      GodStrikePost.onRegisterShaders(event);
      ObeliskRitePost.onRegisterShaders(event);
      SubspaceWalls.onRegisterShaders(event);
   }

   @SubscribeEvent
   public static void onAddLayers(AddLayers event) {
      for (Model skin : event.getSkins()) {
         if (event.getSkin(skin) instanceof PlayerRenderer renderer) {
            renderer.addLayer(new RockArmorLayer(renderer, event.getContext().getBlockRenderDispatcher()));
            renderer.addLayer(new TitanFlameLayer(renderer));
         }
      }
   }
}
