package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.sovereign.AuraSight;
import com.amuletmod.client.renderer.AuraDraw;
import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.GlStateManager.DestFactor;
import com.mojang.blaze3d.platform.GlStateManager.SourceFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexSorting;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import com.mojang.math.Axis;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance.Attenuation;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.RenderGuiEvent.Pre;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLCapabilities;
import org.lwjgl.system.MemoryUtil;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class AuraVisionClient {
   private static final int FADE_TICKS = 14;
   private static final float PULSE_SPEED = 2.0F;
   private static final double RANGE = 64.0;
   private static final int FLASH_TICKS = 8;
   private static final float HIDDEN = 0.25F;
   private static final float COVER = 0.45F;
   private static final float[] GREY = new float[]{0.68F, 0.72F, 0.82F};
   private static final float[] LUMA = new float[]{0.299F, 0.587F, 0.114F};
   private static final int[] CHANNELS = new int[]{6403, 6404, 6405};
   private static final float VIGNETTE = 0.65F;
   private static final ResourceLocation VIGNETTE_TEXTURE = ResourceLocation.fromNamespaceAndPath("minecraft", "textures/misc/vignette.png");
   private static final double[] SIGHT_POINTS = new double[]{0.5, 0.92, 1.3};
   private static final int[] RANK_COLORS = new int[]{10395294, 8191130, 5232895, 5999871, 11693055, 16766282, 16747069, 16731501};
   private static final Map<Integer, AuraVisionClient.Power> POWERS = new HashMap<>();
   private static final Matrix4f PROJECTION = new Matrix4f();
   private static final Matrix4f VIEW = new Matrix4f();
   private static float viewYaw;
   private static float viewPitch;
   private static float viewRoll;
   private static boolean framed;
   @Nullable
   private static TextureTarget frameCopy;
   private static boolean copyChecked;
   private static boolean copyFailed;
   @Nullable
   private static Boolean swizzling;
   @Nullable
   private static AuraVisionClient.Hum hum;
   @Nullable
   private static ClientLevel level;
   private static boolean active;
   private static float fade;
   private static float fadeO;
   private static int pulseAge = -1;
   private static int ticks;

   private AuraVisionClient() {
   }

   public static void update(boolean on, int[] ids, float[] powers) {
      Minecraft minecraft = Minecraft.getInstance();
      if (on && !active) {
         pulseAge = 0;
         play(SoundEvents.BEACON_ACTIVATE, 1.6F, 0.7F);
         play(SoundEvents.AMETHYST_BLOCK_RESONATE, 0.7F, 1.0F);
         play(SoundEvents.ILLUSIONER_PREPARE_BLINDNESS, 1.2F, 0.6F);
         if (hum == null || hum.isStopped()) {
            hum = new AuraVisionClient.Hum();
            minecraft.getSoundManager().play(hum);
         }
      } else if (!on && active) {
         play(SoundEvents.BEACON_DEACTIVATE, 1.6F, 0.6F);
         play(SoundEvents.AMETHYST_BLOCK_CHIME, 0.6F, 0.8F);
      }

      active = on;
      if (on) {
         Map<Integer, AuraVisionClient.Power> fresh = new HashMap<>();

         for (int i = 0; i < ids.length; i++) {
            AuraVisionClient.Power power = POWERS.get(ids[i]);
            if (power == null) {
               power = new AuraVisionClient.Power();
               power.shown = powers[i];
            }

            power.target = powers[i];
            fresh.put(ids[i], power);
         }

         POWERS.clear();
         POWERS.putAll(fresh);
      }
   }

   private static void play(SoundEvent sound, float pitch, float volume) {
      Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(sound, pitch, volume));
   }

   private static float strength(float power) {
      return 1.0F - (float)Math.exp(-power / 220.0F);
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      Minecraft minecraft = Minecraft.getInstance();
      if (!minecraft.isPaused()) {
         if (minecraft.level != level) {
            POWERS.clear();
            level = minecraft.level;
         }

         fadeO = fade;
         fade = Mth.clamp(fade + (active ? 1.0F : -1.0F) / 14.0F, 0.0F, 1.0F);
         if (pulseAge >= 0 && ++pulseAge * 2.0F > 80.0) {
            pulseAge = -1;
         }

         for (AuraVisionClient.Power power : POWERS.values()) {
            power.shown = power.shown + (power.target - power.shown) * 0.15F;
            power.appear = Math.min(1.0F, power.appear + 0.1F);
         }

         if (!active && fade <= 0.0F) {
            POWERS.clear();
         } else if (level != null) {
            checkSight(minecraft, level);
         }

         ticks++;
      }
   }

   private static void checkSight(Minecraft minecraft, ClientLevel world) {
      Entity viewer = minecraft.getCameraEntity();
      if (viewer != null) {
         Vec3 eye = minecraft.gameRenderer.getMainCamera().getPosition();

         for (Entry<Integer, AuraVisionClient.Power> entry : POWERS.entrySet()) {
            AuraVisionClient.Power power = entry.getValue();
            if (power.seen < 0.0F || (entry.getKey() + ticks) % 3 == 0) {
               Entity entity = world.getEntity(entry.getKey());
               power.inSight = entity == null || entity == viewer || inSight(world, viewer, eye, entity);
            }

            float target = power.inSight ? 1.0F : 0.0F;
            power.seen = power.seen < 0.0F ? target : power.seen + (target - power.seen) * 0.3F;
         }
      }
   }

   private static boolean inSight(ClientLevel world, Entity viewer, Vec3 eye, Entity entity) {
      Vec3 feet = entity.position();

      for (double part : SIGHT_POINTS) {
         Vec3 point = feet.add(0.0, entity.getBbHeight() * part, 0.0);
         if (point.distanceToSqr(eye) < 1.0 || world.clip(new ClipContext(eye, point, Block.VISUAL, Fluid.NONE, viewer)).getType() == Type.MISS) {
            return true;
         }
      }

      return false;
   }

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      if (event.getStage() == Stage.AFTER_LEVEL && (active || !(fade <= 0.0F))) {
         PROJECTION.set(event.getProjectionMatrix());
         Camera camera = event.getCamera();
         viewYaw = camera.getYRot();
         viewPitch = camera.getXRot();
         viewRoll = camera.getRoll();
         framed = true;
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public static void onRenderGui(Pre event) {
      if (framed) {
         framed = false;
         event.getGuiGraphics().flush();
         paint(event.getPartialTick().getGameTimeDeltaPartialTick(false), event.getGuiGraphics());
      }
   }

   @SubscribeEvent
   public static void onRenderFrameStart(net.neoforged.neoforge.client.event.RenderFrameEvent.Pre event) {
      framed = false;
   }

   @SubscribeEvent
   public static void onRenderFrame(net.neoforged.neoforge.client.event.RenderFrameEvent.Post event) {
      Minecraft minecraft = Minecraft.getInstance();
      if (framed && minecraft.options.hideGui && minecraft.screen == null) {
         minecraft.getMainRenderTarget().bindWrite(true);
         paint(event.getPartialTick().getGameTimeDeltaPartialTick(false), null);
      }

      framed = false;
   }

   private static void paint(float partialTick, @Nullable GuiGraphics gui) {
      Minecraft minecraft = Minecraft.getInstance();
      float amount = Easing.smoothstep(0.0F, 1.0F, Mth.lerp(partialTick, fadeO, fade));
      if (!(amount <= 0.001F) && minecraft.level != null) {
         Matrix4f projection = new Matrix4f(RenderSystem.getProjectionMatrix());
         VertexSorting sorting = RenderSystem.getVertexSorting();
         Matrix4fStack modelView = RenderSystem.getModelViewStack();
         modelView.pushMatrix();
         modelView.identity();
         RenderSystem.applyModelViewMatrix();
         RenderSystem.disableDepthTest();
         RenderSystem.depthMask(false);
         RenderSystem.disableCull();
         RenderSystem.colorMask(true, true, true, false);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.enableBlend();

         List<AuraVisionClient.Aura> auras;
         try {
            greyWorld(minecraft.getMainRenderTarget(), amount, partialTick);
            auras = paintAuras(minecraft, amount, partialTick);
         } finally {
            RenderSystem.colorMask(true, true, true, true);
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
            RenderSystem.enableCull();
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            modelView.popMatrix();
            RenderSystem.applyModelViewMatrix();
            RenderSystem.setProjectionMatrix(projection, sorting);
         }

         if (gui != null) {
            label(minecraft, gui, auras);
            badge(minecraft, gui, amount);
         }
      }
   }

   private static void greyWorld(RenderTarget main, float amount, float partialTick) {
      RenderSystem.setProjectionMatrix(new Matrix4f(), VertexSorting.ORTHOGRAPHIC_Z);
      int copy = swizzles() ? copyFrame(main) : -1;
      if (copy != -1) {
         RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
         RenderSystem.setShaderTexture(0, copy);
         RenderSystem.disableBlend();
         swizzle(copy, 6403, 6404, 6405);
         float keep = 1.0F - amount;
         screenQuad(keep, keep, keep);
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(SourceFactor.ONE, DestFactor.ONE);

         for (int i = 0; i < 3; i++) {
            swizzle(copy, CHANNELS[i], CHANNELS[i], CHANNELS[i]);
            float share = LUMA[i] * amount;
            screenQuad(share * GREY[0], share * GREY[1], share * GREY[2]);
         }

         swizzle(copy, 6403, 6404, 6405);
      } else {
         RenderSystem.setShader(GameRenderer::getPositionColorShader);
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(SourceFactor.ZERO, DestFactor.SRC_COLOR);
         flatQuad(Mth.lerp(amount, 1.0F, GREY[0] * 0.75F), Mth.lerp(amount, 1.0F, GREY[1] * 0.75F), Mth.lerp(amount, 1.0F, GREY[2] * 0.75F));
      }

      RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
      RenderSystem.setShaderTexture(0, VIGNETTE_TEXTURE);
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(SourceFactor.ZERO, DestFactor.ONE_MINUS_SRC_COLOR);
      float vignette = 0.65F * amount;
      screenQuad(vignette, vignette, vignette);
      if (pulseAge >= 0 && pulseAge < 8) {
         float flash = 1.0F - (pulseAge + partialTick) / 8.0F;
         flash *= flash * 0.55F;
         RenderSystem.setShader(GameRenderer::getPositionColorShader);
         RenderSystem.blendFunc(SourceFactor.ONE, DestFactor.ONE);
         flatQuad(0.45F * flash, 0.35F * flash, 0.75F * flash);
      }
   }

   private static boolean swizzles() {
      if (swizzling == null) {
         GLCapabilities capabilities = GL.getCapabilities();
         swizzling = capabilities.OpenGL33 || capabilities.GL_ARB_texture_swizzle;
         if (!swizzling) {
            AmuletMod.LOGGER.warn("Aura Sight: texture swizzling unsupported, the world will be dimmed instead of greyed");
         }
      }

      return swizzling;
   }

   private static int copyFrame(RenderTarget main) {
      if (copyFailed) {
         return -1;
      } else {
         if (frameCopy == null || frameCopy.width != main.width || frameCopy.height != main.height) {
            if (frameCopy != null) {
               frameCopy.destroyBuffers();
            }

            frameCopy = new TextureTarget(main.width, main.height, false, Minecraft.ON_OSX);
            copyChecked = false;
         }

         GlStateManager._glBindFramebuffer(36008, main.frameBufferId);
         RenderSystem.activeTexture(33984);
         RenderSystem.bindTexture(frameCopy.getColorTextureId());
         GlStateManager._glCopyTexSubImage2D(3553, 0, 0, 0, 0, 0, main.width, main.height);
         if (!copyChecked) {
            copyChecked = true;
            copyFailed = !copyMatches(main, frameCopy);
            if (copyFailed) {
               AmuletMod.LOGGER.warn("Aura Sight: couldn't copy the frame, the world will be dimmed instead of greyed");
            }
         }

         main.bindWrite(true);
         return copyFailed ? -1 : frameCopy.getColorTextureId();
      }
   }

   private static boolean copyMatches(RenderTarget main, RenderTarget copy) {
      ByteBuffer original = MemoryUtil.memAlloc(4);
      ByteBuffer copied = MemoryUtil.memAlloc(4);

      try {
         int x = main.width / 2;
         int y = main.height / 2;
         GlStateManager._glBindFramebuffer(36008, main.frameBufferId);
         GL11.glReadPixels(x, y, 1, 1, 6408, 5121, original);
         GlStateManager._glBindFramebuffer(36008, copy.frameBufferId);
         GL11.glReadPixels(x, y, 1, 1, 6408, 5121, copied);

         for (int i = 0; i < 3; i++) {
            if (Math.abs((original.get(i) & 255) - (copied.get(i) & 255)) > 2) {
               return false;
            }
         }

         return true;
      } finally {
         MemoryUtil.memFree(original);
         MemoryUtil.memFree(copied);
      }
   }

   private static void swizzle(int texture, int red, int green, int blue) {
      RenderSystem.activeTexture(33984);
      RenderSystem.bindTexture(texture);
      GlStateManager._texParameter(3553, 36418, red);
      GlStateManager._texParameter(3553, 36419, green);
      GlStateManager._texParameter(3553, 36420, blue);
      GlStateManager._texParameter(3553, 36421, 1);
   }

   private static void draw(BufferBuilder builder) {
      MeshData mesh = builder.build();
      if (mesh != null) {
         BufferUploader.drawWithShader(mesh);
      }
   }

   private static void screenQuad(float r, float g, float b) {
      BufferBuilder builder = Tesselator.getInstance().begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
      builder.addVertex(-1.0F, -1.0F, 0.0F).setUv(0.0F, 0.0F).setColor(r, g, b, 1.0F);
      builder.addVertex(1.0F, -1.0F, 0.0F).setUv(1.0F, 0.0F).setColor(r, g, b, 1.0F);
      builder.addVertex(1.0F, 1.0F, 0.0F).setUv(1.0F, 1.0F).setColor(r, g, b, 1.0F);
      builder.addVertex(-1.0F, 1.0F, 0.0F).setUv(0.0F, 1.0F).setColor(r, g, b, 1.0F);
      draw(builder);
   }

   private static void flatQuad(float r, float g, float b) {
      BufferBuilder builder = Tesselator.getInstance().begin(Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
      builder.addVertex(-1.0F, -1.0F, 0.0F).setColor(r, g, b, 1.0F);
      builder.addVertex(1.0F, -1.0F, 0.0F).setColor(r, g, b, 1.0F);
      builder.addVertex(1.0F, 1.0F, 0.0F).setColor(r, g, b, 1.0F);
      builder.addVertex(-1.0F, 1.0F, 0.0F).setColor(r, g, b, 1.0F);
      draw(builder);
   }

   private static List<AuraVisionClient.Aura> paintAuras(Minecraft minecraft, float amount, float partialTick) {
      ClientLevel world = minecraft.level;
      Camera camera = minecraft.gameRenderer.getMainCamera();
      Vec3 view = camera.getPosition();
      float time = ClientClock.time(partialTick);
      float pulse = pulseAge < 0 ? Float.MAX_VALUE : (pulseAge + partialTick) * 2.0F;
      Vec3 self = minecraft.player == null ? view : minecraft.player.getPosition(partialTick);
      PoseStack poseStack = new PoseStack();
      poseStack.mulPose(Axis.ZP.rotationDegrees(viewRoll));
      poseStack.mulPose(Axis.XP.rotationDegrees(viewPitch));
      poseStack.mulPose(Axis.YP.rotationDegrees(viewYaw + 180.0F));
      VIEW.set(poseStack.last().pose());
      Frustum frustum = new Frustum(VIEW, PROJECTION);
      frustum.prepare(view.x, view.y, view.z);
      List<AuraVisionClient.Aura> auras = new ArrayList<>();

      for (Entry<Integer, AuraVisionClient.Power> entry : POWERS.entrySet()) {
         if (world.getEntity(entry.getKey()) instanceof LivingEntity living
            && living.isAlive()
            && (living != minecraft.getCameraEntity() || !minecraft.options.getCameraType().isFirstPerson())) {
            AuraVisionClient.Power power = entry.getValue();
            Vec3 at = living.getPosition(partialTick);
            double distance = at.distanceTo(view);
            float strength = strength(power.shown);
            float spread = AuraDraw.baseRadius(living.getBbWidth(), strength) * (1.2F + 2.4F * strength) + 1.0F;
            float top = AuraDraw.reach(living.getBbHeight(), strength) * 1.4F + 4.0F;
            if (frustum.isVisible(new AABB(at.x - spread, at.y - 0.5, at.z - spread, at.x + spread, at.y + top, at.z + spread))) {
               float revealed = Easing.smoothstep(-3.0F, 0.0F, pulse - (float)at.distanceTo(self));
               float faraway = 1.0F - Easing.smoothstep(48.0F, 64.0F, (float)distance);
               float seen = 0.25F + 0.75F * Math.max(0.0F, power.seen);
               float brightness = amount * revealed * faraway * power.appear * seen;
               if (brightness > 0.01F) {
                  auras.add(new AuraVisionClient.Aura(living, at, strength, brightness, distance));
               }
            }
         }
      }

      if (auras.isEmpty() && pulseAge < 0) {
         return auras;
      } else {
         RenderSystem.setProjectionMatrix(PROJECTION, VertexSorting.DISTANCE_TO_ORIGIN);
         RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
         RenderSystem.setShaderTexture(0, AuraDraw.FLAME);
         RenderSystem.blendFunc(SourceFactor.ZERO, DestFactor.ONE_MINUS_SRC_COLOR);
         BufferBuilder builder = Tesselator.getInstance().begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);

         for (AuraVisionClient.Aura aura : auras) {
            drawAura(builder, poseStack, view, aura, time, AuraDraw.WHITE, aura.brightness() * 0.45F);
         }

         draw(builder);
         RenderSystem.blendFunc(SourceFactor.ONE, DestFactor.ONE);
         builder = Tesselator.getInstance().begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);

         for (AuraVisionClient.Aura aura : auras) {
            drawAura(builder, poseStack, view, aura, time, AuraDraw.AURORA, aura.brightness());
         }

         draw(builder);
         RenderSystem.setShaderTexture(0, AuraDraw.GLOW);
         builder = Tesselator.getInstance().begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
         Vector3f left = camera.getLeftVector();
         Vector3f up = camera.getUpVector();
         float[] color = new float[3];

         for (AuraVisionClient.Aura aura : auras) {
            LivingEntity entity = aura.entity();
            AuraDraw.palette(AuraDraw.AURORA, time * 0.01F + entity.getId() * 0.37F, color);
            poseStack.pushPose();
            poseStack.translate(aura.at().x - view.x, aura.at().y - view.y, aura.at().z - view.z);
            Matrix4f pose = poseStack.last().pose();
            float glow = aura.brightness() * (0.14F + 0.26F * aura.strength());
            float halfWidth = entity.getBbWidth() * 0.9F + 0.3F + aura.strength() * 0.8F;
            float halfHeight = entity.getBbHeight() * 0.7F + 0.3F + aura.strength() * 0.8F;
            billboard(builder, pose, entity.getBbHeight() * 0.5F, left, up, halfWidth, halfHeight, color[0] * glow, color[1] * glow, color[2] * glow);
            float pool = aura.brightness() * (0.2F + 0.35F * aura.strength());
            AuraDraw.pool(builder, pose, AuraDraw.baseRadius(entity.getBbWidth(), aura.strength()) * 1.9F, color[0] * pool, color[1] * pool, color[2] * pool);
            poseStack.popPose();
         }

         draw(builder);
         if (pulseAge >= 0) {
            renderPulse(poseStack, view, self, pulse, amount);
         }

         return auras;
      }
   }

   private static void drawAura(
      VertexConsumer consumer, PoseStack poseStack, Vec3 view, AuraVisionClient.Aura aura, float time, float[][] colors, float brightness
   ) {
      LivingEntity entity = aura.entity();
      float strength = aura.strength();
      float detail = aura.distance() < 16.0 ? 1.0F : (aura.distance() < 32.0 ? 0.7F : 0.45F);
      int tongues = Math.max(4, Math.round((9.0F + 27.0F * strength) * detail));
      int segments = detail >= 0.7F ? 8 : 5;
      poseStack.pushPose();
      poseStack.translate(aura.at().x - view.x, aura.at().y - view.y, aura.at().z - view.z);
      Matrix4f pose = poseStack.last().pose();
      Vector3f eye = view.subtract(aura.at()).toVector3f();
      AuraDraw.flames(
         consumer,
         pose,
         eye,
         entity.getBbWidth(),
         entity.getBbHeight(),
         strength,
         time,
         entity.getId(),
         tongues,
         segments,
         brightness * (0.35F + 0.45F * strength),
         colors,
         0.6F + 2.4F * strength,
         true
      );
      AuraDraw.curtains(consumer, pose, entity.getBbWidth(), entity.getBbHeight(), strength, time, entity.getId(), brightness, colors);
      poseStack.popPose();
   }

   private static void billboard(
      VertexConsumer consumer, Matrix4f pose, float y, Vector3f left, Vector3f up, float halfWidth, float halfHeight, float r, float g, float b
   ) {
      float lx = left.x() * halfWidth;
      float ly = left.y() * halfWidth;
      float lz = left.z() * halfWidth;
      float ux = up.x() * halfHeight;
      float uy = up.y() * halfHeight;
      float uz = up.z() * halfHeight;
      r = Mth.clamp(r, 0.0F, 1.0F);
      g = Mth.clamp(g, 0.0F, 1.0F);
      b = Mth.clamp(b, 0.0F, 1.0F);
      consumer.addVertex(pose, lx - ux, y + ly - uy, lz - uz).setUv(0.0F, 1.0F).setColor(r, g, b, 1.0F);
      consumer.addVertex(pose, -lx - ux, y - ly - uy, -lz - uz).setUv(1.0F, 1.0F).setColor(r, g, b, 1.0F);
      consumer.addVertex(pose, -lx + ux, y - ly + uy, -lz + uz).setUv(1.0F, 0.0F).setColor(r, g, b, 1.0F);
      consumer.addVertex(pose, lx + ux, y + ly + uy, lz + uz).setUv(0.0F, 0.0F).setColor(r, g, b, 1.0F);
   }

   private static void renderPulse(PoseStack poseStack, Vec3 view, Vec3 self, float radius, float amount) {
      float fade = amount * (1.0F - Mth.clamp(radius / 80.0F, 0.0F, 1.0F));
      if (!(fade <= 0.01F)) {
         RenderSystem.setShader(GameRenderer::getPositionColorShader);
         RenderSystem.blendFunc(SourceFactor.SRC_ALPHA, DestFactor.ONE);
         BufferBuilder builder = Tesselator.getInstance().begin(Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
         poseStack.pushPose();
         poseStack.translate(self.x - view.x, self.y - view.y, self.z - view.z);
         Matrix4f pose = poseStack.last().pose();
         GlowDraw.ring(builder, pose, 0.1F, Math.max(0.0F, radius - 2.5F), radius, 96, 0.2F, 0.9F, 0.9F, 0.0F, 0.5F * fade);
         GlowDraw.ring(builder, pose, 0.1F, radius, radius + 0.6F, 96, 0.7F, 0.6F, 1.0F, 0.5F * fade, 0.0F);
         GlowDraw.band(builder, pose, radius, 2.5F, 96, 0.3F, 0.8F, 1.0F, 0.2F * fade);
         poseStack.popPose();
         draw(builder);
      }
   }

   @Nullable
   private static AuraVisionClient.Aura pickLabel(Camera camera, List<AuraVisionClient.Aura> auras) {
      Vec3 view = camera.getPosition();
      Vec3 look = new Vec3(camera.getLookVector());
      AuraVisionClient.Aura best = null;
      double bestFacing = 0.9965;

      for (AuraVisionClient.Aura aura : auras) {
         LivingEntity entity = aura.entity();
         if (entity != Minecraft.getInstance().getCameraEntity()) {
            Vec3 middle = aura.at().add(0.0, entity.getBbHeight() * 0.5, 0.0);
            double facing = middle.subtract(view).normalize().dot(look);
            if (facing > bestFacing) {
               bestFacing = facing;
               best = aura;
            }
         }
      }

      return best;
   }

   private static void label(Minecraft minecraft, GuiGraphics gui, List<AuraVisionClient.Aura> auras) {
      Camera camera = minecraft.gameRenderer.getMainCamera();
      AuraVisionClient.Aura aura = pickLabel(camera, auras);
      if (aura != null) {
         AuraVisionClient.Power power = POWERS.get(aura.entity().getId());
         if (power != null) {
            Vec3 view = camera.getPosition();
            Vector4f point = new Vector4f(
               (float)(aura.at().x - view.x), (float)(aura.at().y - view.y) + aura.entity().getBbHeight() + 0.5F, (float)(aura.at().z - view.z), 1.0F
            );
            VIEW.transform(point);
            PROJECTION.transform(point);
            if (!(point.w() <= 0.05F)) {
               float x = (point.x() / point.w() * 0.5F + 0.5F) * gui.guiWidth();
               float y = (0.5F - point.y() / point.w() * 0.5F) * gui.guiHeight();
               int rank = AuraSight.rank(power.shown);
               int alpha = Mth.clamp((int)(aura.brightness() * 255.0F), 16, 255) << 24;
               Component title = Component.translatable("aura.amuletmod.rank", new Object[]{AuraSight.rankName(rank)});
               Component detail = Component.translatable("aura.amuletmod.power", new Object[]{Math.round(power.shown)});
               Font font = minecraft.font;
               PoseStack pose = gui.pose();
               pose.pushPose();
               pose.translate(x, y, 0.0F);
               pose.pushPose();
               pose.scale(2.0F, 2.0F, 1.0F);
               gui.drawString(font, title.getVisualOrderText(), -font.width(title) / 2.0F, -10.0F, alpha | RANK_COLORS[rank], true);
               pose.popPose();
               gui.drawString(font, detail.getVisualOrderText(), -font.width(detail) / 2.0F, 2.0F, alpha | 14211304, true);
               pose.popPose();
            }
         }
      }
   }

   private static void badge(Minecraft minecraft, GuiGraphics gui, float amount) {
      AuraVisionClient.Power power = minecraft.player == null ? null : POWERS.get(minecraft.player.getId());
      if (power != null) {
         int rank = AuraSight.rank(power.shown);
         int alpha = Mth.clamp((int)(amount * 255.0F), 16, 255) << 24;
         Component caption = Component.translatable("aura.amuletmod.yours");
         Component title = Component.translatable("aura.amuletmod.rank", new Object[]{AuraSight.rankName(rank)});
         Component detail = Component.translatable("aura.amuletmod.power", new Object[]{Math.round(power.shown)});
         Font font = minecraft.font;
         float scale = 1.5F;
         int right = gui.guiWidth() - 8;
         int bottom = gui.guiHeight() - 8;
         int width = (int)Math.max((float)Math.max(font.width(caption), font.width(detail)), font.width(title) * scale);
         gui.fill(right - width - 5, bottom - 37, right + 4, bottom + 3, (int)(amount * 112.0F) << 24);
         gui.drawString(font, caption.getVisualOrderText(), right - font.width(caption), bottom - 33, alpha | 10132144, true);
         PoseStack pose = gui.pose();
         pose.pushPose();
         pose.translate(right, bottom - 22, 0.0F);
         pose.scale(scale, scale, 1.0F);
         gui.drawString(font, title.getVisualOrderText(), -font.width(title), 0.0F, alpha | RANK_COLORS[rank], true);
         pose.popPose();
         gui.drawString(font, detail.getVisualOrderText(), right - font.width(detail), bottom - 8, alpha | 14211304, true);
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      active = false;
      fadeO = 0.0F;
      fade = 0.0F;
      pulseAge = -1;
      framed = false;
      POWERS.clear();
      if (frameCopy != null) {
         frameCopy.destroyBuffers();
         frameCopy = null;
      }

      copyChecked = false;
      copyFailed = false;
   }

   private record Aura(LivingEntity entity, Vec3 at, float strength, float brightness, double distance) {
   }

   private static final class Hum extends AbstractTickableSoundInstance {
      Hum() {
         super(SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, SoundInstance.createUnseededRandom());
         this.looping = true;
         this.delay = 0;
         this.relative = true;
         this.attenuation = Attenuation.NONE;
         this.volume = 0.01F;
         this.pitch = 1.35F;
      }

      public void tick() {
         this.volume = Math.max(0.01F, 0.16F * AuraVisionClient.fade);
         if (!AuraVisionClient.active && AuraVisionClient.fade <= 0.0F) {
            this.stop();
         }
      }
   }

   private static final class Power {
      float shown;
      float target;
      float appear;
      float seen = -1.0F;
      boolean inSight;
   }
}
