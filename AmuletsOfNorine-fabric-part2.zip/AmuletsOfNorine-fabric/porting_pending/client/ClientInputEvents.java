package com.amuletmod.client;

import com.amuletmod.network.ActivateAbilityPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class ClientInputEvents {
   private ClientInputEvents() {
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      if (Minecraft.getInstance().player != null) {
         for (int slot = 0; slot < ModKeyMappings.ABILITY_KEYS.length; slot++) {
            while (ModKeyMappings.ABILITY_KEYS[slot].consumeClick()) {
               PacketDistributor.sendToServer(new ActivateAbilityPacket(slot), new CustomPacketPayload[0]);
            }
         }
      }
   }
}
