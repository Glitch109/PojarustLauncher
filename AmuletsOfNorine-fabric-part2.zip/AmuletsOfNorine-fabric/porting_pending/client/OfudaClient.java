package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.librarian.Kanji;
import com.amuletmod.entity.OfudaEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.platform.GlStateManager.DestFactor;
import com.mojang.blaze3d.platform.GlStateManager.SourceFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.RenderGuiEvent.Post;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class OfudaClient {
   public static final ResourceLocation SLIP = AmuletMod.id("textures/misc/ofuda.png");
   public static final ResourceLocation KANJI = AmuletMod.id("textures/misc/kanji.png");
   private static final ResourceLocation GLOW = AmuletMod.id("textures/misc/soft_glow.png");
   private static final int SLIP_WIDTH = 40;
   private static final int SLIP_HEIGHT = 104;
   private static final int KANJI_Y = -8;
   private static final int SEAL_Y = 40;
   private static final float[] INK = new float[]{0.1F, 0.08F, 0.06F};
   @Nullable
   private static OfudaEntity writing;

   private OfudaClient() {
   }

   private static boolean isLocalPlayer(int entityId) {
      LocalPlayer player = Minecraft.getInstance().player;
      return player != null && player.getId() == entityId;
   }

   public static void writing(OfudaEntity ofuda) {
      if (isLocalPlayer(ofuda.casterId())) {
         writing = ofuda;
      }
   }

   public static void strike(int writerId, int k) {
      if (isLocalPlayer(writerId)) {
         CameraShake.quake(0.4F + 0.35F * k, 4, 0);
         ImpactFrames.punch(0.02F + 0.025F * k);
         if (k == 2) {
            ImpactFrames.flash(0.3F);
         }
      }
   }

   @SubscribeEvent
   public static void onRenderGui(Post event) {
      OfudaEntity ofuda = writing;
      if (ofuda != null) {
         if (!ofuda.isRemoved() && ofuda.phase() == OfudaEntity.Phase.WRITING) {
            float age = ofuda.tickCount + event.getPartialTick().getGameTimeDeltaPartialTick(false);
            if (age < 36.0F) {
               draw(event.getGuiGraphics(), ofuda, age);
            }
         } else {
            writing = null;
         }
      }
   }

   private static void draw(GuiGraphics graphics, OfudaEntity ofuda, float age) {
      PoseStack pose = graphics.pose();
      int width = graphics.guiWidth();
      int screenHeight = graphics.guiHeight();
      float height = Math.min(screenHeight * 0.6F, width * 0.55F * 104.0F / 40.0F);
      float texel = height / 104.0F;
      int last = 2;
      Kanji drawn = ofuda.drawn();
      float unfurl = Mth.clamp(age / 5.0F, 0.0F, 1.0F);
      float fold = Mth.clamp((age - 29.0F) / 7.0F, 0.0F, 1.0F);
      float shrink = 1.0F - fold * fold;
      float sinceDrawn = age - OfudaEntity.strikesAt(last);
      float shakeX = 0.0F;
      float shakeY = 0.0F;

      for (int k = 0; k <= 3; k++) {
         float since = age - (k < 3 ? OfudaEntity.strikesAt(k) : 24);
         if (!(since < 0.0F) && !(since >= 5.0F)) {
            float amplitude = (k == last ? 6.0F : (k == 3 ? 2.0F : 3.5F)) * (1.0F - since / 5.0F);
            shakeX += amplitude * Mth.sin(age * 37.0F + k * 11.0F);
            shakeY += amplitude * Mth.cos(age * 29.0F + k * 7.0F);
         }
      }

      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      pose.pushPose();
      pose.translate(width / 2.0F + shakeX, screenHeight / 2.0F + shakeY, 0.0F);
      pose.mulPose(Axis.ZP.rotationDegrees(fold * 35.0F - (1.0F - unfurl) * 8.0F));
      pose.scale(texel * shrink * Mth.lerp(unfurl, 0.8F, 1.0F), texel * shrink * Math.max(0.0F, Easing.outBack(unfurl)), 1.0F);
      if (sinceDrawn >= 0.0F) {
         glow(graphics, 0.0F, 0.0F, 150.0F, drawn, Mth.clamp(sinceDrawn / 3.0F, 0.0F, 1.0F) * (0.3F + 0.08F * Mth.sin(age * 0.6F)));
      }

      graphics.setColor(1.0F, 1.0F, 1.0F, unfurl);
      graphics.blit(SLIP, -20, -52, 40, 104, 0.0F, 0.0F, 40, 104, 64, 128);

      for (int kx = 0; kx < 3; kx++) {
         if (age >= OfudaEntity.strikesAt(kx)) {
            spatter(graphics, ofuda.getId() * 31L + kx, unfurl);
         }
      }

      if (sinceDrawn >= 0.0F && sinceDrawn < 9.0F) {
         float t = sinceDrawn / 9.0F;
         int color = alpha(1.0F - t) | drawn.rgb();
         float reach = 18.0F + 70.0F * Easing.outCubic(t);

         for (int i = 0; i < 12; i++) {
            pose.pushPose();
            pose.translate(0.0F, -8.0F, 0.0F);
            pose.mulPose(Axis.ZP.rotationDegrees(i * 30.0F + 15.0F * (i % 2)));
            graphics.fill(-1, 16, 1, Mth.ceil(reach * (i % 2 == 0 ? 1.0F : 0.7F)), color);
            pose.popPose();
         }
      }

      for (int kxx = 0; kxx < 3; kxx++) {
         kanji(graphics, ofuda, kxx, age, unfurl);
      }

      if (age >= 24.0F) {
         float stamp = Mth.clamp((age - 24.0F) / 2.5F, 0.0F, 1.0F);
         float scale = 2.2F - 1.2F * Easing.outCubic(stamp);
         pose.pushPose();
         pose.translate(0.0F, 40.0F, 0.0F);
         pose.scale(scale, scale, 1.0F);
         graphics.setColor(1.0F, 1.0F, 1.0F, stamp);
         graphics.blit(SLIP, -6, -6, 12, 12, 44.0F, 0.0F, 12, 12, 64, 128);
         pose.popPose();
      }

      pose.popPose();
      if (fold > 0.0F) {
         float swell = Mth.sin(fold * (float) Math.PI);
         float fade = 1.0F - Mth.clamp((fold - 0.75F) / 0.25F, 0.0F, 1.0F) * 0.6F;
         pose.pushPose();
         pose.translate(width / 2.0F, screenHeight / 2.0F, 0.0F);
         glow(graphics, 0.0F, 0.0F, height * (0.2F + 0.6F * swell), drawn, Math.min(1.0F, fold * 2.5F) * fade);
         glowWhite(graphics, height * (0.08F + 0.25F * swell), Math.min(1.0F, fold * 3.0F) * fade);
         pose.popPose();
      }

      if (sinceDrawn >= 0.0F) {
         float shown = Mth.clamp(sinceDrawn / 4.0F, 0.0F, 1.0F) * (1.0F - fold);
         if (shown > 0.05F) {
            Component text = Component.translatable(drawn.translationKey());
            LivingEntity target = ofuda.target();
            if (target != null && !isLocalPlayer(target.getId())) {
               text = Component.translatable("gui.amuletmod.ofuda.for", new Object[]{text, target.getDisplayName()});
            }

            graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
            graphics.drawCenteredString(
               Minecraft.getInstance().font, text, width / 2, Mth.floor(screenHeight / 2.0F + height / 2.0F + 6.0F), alpha(shown) | drawn.rgb()
            );
         }
      }

      graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
   }

   private static void kanji(GuiGraphics graphics, OfudaEntity ofuda, int k, float age, float paper) {
      int strike = OfudaEntity.strikesAt(k);
      float start = strike - 4;
      if (!(age < start)) {
         boolean drawn = k == 2;
         float fall = Mth.clamp((age - start) / 4.0F, 0.0F, 1.0F);
         float scale = 1.0F + 3.5F * (1.0F - fall * fall * fall);
         float alpha = (0.2F + 0.8F * fall) * paper;
         if (!drawn) {
            float leave = Mth.clamp((age - (OfudaEntity.strikesAt(k + 1) - 4)) / 3.0F, 0.0F, 1.0F);
            if (leave >= 1.0F) {
               return;
            }

            alpha *= 1.0F - leave;
            scale *= 1.0F + 0.3F * leave;
         }

         Kanji kanji = ofuda.kanji(k);
         float since = age - strike;
         if (since >= 0.0F && since < 6.0F) {
            glow(graphics, 0.0F, -8.0F, (drawn ? 120.0F : 80.0F) * (1.0F + since * 0.1F), kanji, (1.0F - since / 6.0F) * (drawn ? 1.0F : 0.7F));
         }

         PoseStack pose = graphics.pose();
         pose.pushPose();
         pose.translate(0.0F, -8.0F, 0.0F);
         pose.scale(scale, scale, 1.0F);
         graphics.setColor(INK[0], INK[1], INK[2], alpha);
         graphics.blit(KANJI, -16, -16, 32, 32, 48.0F * kanji.ordinal(), 0.0F, 48, 48, 192, 48);
         if (drawn && since >= 0.0F) {
            float pulse = Mth.clamp(since / 2.0F, 0.0F, 1.0F) * (0.65F + 0.25F * Mth.sin(age * 0.7F));
            RenderSystem.blendFunc(SourceFactor.SRC_ALPHA, DestFactor.ONE);
            graphics.setColor(kanji.r(), kanji.g(), kanji.b(), pulse * paper);
            graphics.blit(KANJI, -16, -16, 32, 32, 48.0F * kanji.ordinal(), 0.0F, 48, 48, 192, 48);
            RenderSystem.defaultBlendFunc();
         }

         pose.popPose();
      }
   }

   private static void spatter(GuiGraphics graphics, long seed, float paper) {
      RandomSource random = RandomSource.create(seed);
      int color = alpha(0.85F * paper) | 1709072;

      for (int i = 0; i < 6; i++) {
         int x = random.nextInt(28) - 20 + 6;
         int y = -34 + random.nextInt(56);
         int size = 1 + random.nextInt(2);
         graphics.fill(x, y, x + size, y + size, color);
      }
   }

   private static void glow(GuiGraphics graphics, float x, float y, float size, Kanji kanji, float alpha) {
      if (!(alpha <= 0.01F)) {
         RenderSystem.blendFunc(SourceFactor.SRC_ALPHA, DestFactor.ONE);
         graphics.setColor(kanji.r(), kanji.g(), kanji.b(), Math.min(1.0F, alpha));
         softGlow(graphics, x, y, size);
         RenderSystem.defaultBlendFunc();
      }
   }

   private static void glowWhite(GuiGraphics graphics, float size, float alpha) {
      if (!(alpha <= 0.01F)) {
         RenderSystem.blendFunc(SourceFactor.SRC_ALPHA, DestFactor.ONE);
         graphics.setColor(1.0F, 1.0F, 1.0F, Math.min(1.0F, alpha));
         softGlow(graphics, 0.0F, 0.0F, size);
         RenderSystem.defaultBlendFunc();
      }
   }

   private static void softGlow(GuiGraphics graphics, float x, float y, float size) {
      PoseStack pose = graphics.pose();
      pose.pushPose();
      pose.translate(x, y, 0.0F);
      pose.scale(size / 64.0F, size / 64.0F, 1.0F);
      graphics.blit(GLOW, -32, -32, 64, 64, 0.0F, 0.0F, 64, 64, 64, 64);
      pose.popPose();
   }

   private static int alpha(float alpha) {
      return Mth.clamp((int)(alpha * 255.0F), 5, 255) << 24;
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      writing = null;
   }
}
