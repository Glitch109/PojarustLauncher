package com.amuletmod.client;

import com.amuletmod.entity.SeekingMeteorEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;

public class MeteorWhooshSound extends AbstractTickableSoundInstance {
   private final SeekingMeteorEntity meteor;

   private MeteorWhooshSound(SeekingMeteorEntity meteor) {
      super(SoundEvents.ELYTRA_FLYING, SoundSource.PLAYERS, SoundInstance.createUnseededRandom());
      this.meteor = meteor;
      this.looping = true;
      this.delay = 0;
      this.volume = 0.3F;
      this.pitch = 0.6F;
      this.x = meteor.getX();
      this.y = meteor.getY();
      this.z = meteor.getZ();
   }

   public static void follow(SeekingMeteorEntity meteor) {
      Minecraft.getInstance().getSoundManager().play(new MeteorWhooshSound(meteor));
   }

   public void tick() {
      if (this.meteor.isRemoved()) {
         this.stop();
      } else {
         this.x = this.meteor.getX();
         this.y = this.meteor.getY();
         this.z = this.meteor.getZ();
         float speed = (float)(this.meteor.getDeltaMovement().length() / 3.0);
         this.volume = 0.2F + 0.6F * Mth.clamp(speed, 0.0F, 1.0F);
         this.pitch = 0.5F + 0.6F * speed;
      }
   }
}
