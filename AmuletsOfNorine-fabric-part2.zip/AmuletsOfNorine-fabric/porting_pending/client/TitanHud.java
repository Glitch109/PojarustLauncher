package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.Amulets;
import com.amuletmod.amulet.ability.titan.BladeMode;
import com.amuletmod.amulet.ability.titan.Stance;
import com.amuletmod.amulet.ability.titan.TitanBlades;
import com.amuletmod.amulet.ability.titan.TitanBladesAbility;
import com.amuletmod.amulet.ability.titan.TitanFistsAbility;
import com.amuletmod.amulet.ability.titan.TitanSync;
import com.amuletmod.client.renderer.TitanFistRenderer;
import com.amuletmod.network.TitanBladePacket;
import com.amuletmod.network.TitanHudPacket;
import com.amuletmod.network.TitanPunchPacket;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.platform.GlStateManager.DestFactor;
import com.mojang.blaze3d.platform.GlStateManager.SourceFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.Arrays;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.InputEvent.InteractionKeyMappingTriggered;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class TitanHud {
   private static final ResourceLocation GLYPHS = AmuletMod.id("textures/misc/titan_stances.png");
   private static final ResourceLocation INK = AmuletMod.id("textures/misc/titan_ink.png");
   private static final int GLYPH_COUNT = 6;
   private static final float[] GOLD = TitanFistRenderer.GOLD;
   public static final float[] BLUE = new float[]{0.45F, 0.74F, 1.0F};
   private static final float[] GREY = new float[]{0.72F, 0.72F, 0.78F};
   private static final int SHOW_TICKS = 20;
   private static final int LEAVE_TICK = 11;
   private static final int MARK = 11;
   private static final int MARK_X = 9;
   private static final int MARK_Y = -5;
   private static boolean attackHeld;
   private static long lastClick = -1L;
   private static long lastCut = -4611686018427387904L;
   @Nullable
   private static Stance fists;
   @Nullable
   private static BladeMode blades;
   private static int marked = -1;
   private static int shown = -1;
   private static long shownAt;
   private static final long[] RECHARGING_SINCE = new long[5];
   private static final long[] READY_AT = new long[5];
   private static int cuts;
   private static long comboUntil;
   private static int swords;
   private static long windowUntil;

   private TitanHud() {
   }

   @SubscribeEvent
   public static void onClickInput(InteractionKeyMappingTriggered event) {
      if (event.isAttack() && event.getHand() == InteractionHand.MAIN_HAND && !attackHeld) {
         LocalPlayer player = Minecraft.getInstance().player;
         long now = ClientClock.ticks();
         if (player != null && !player.isSpectator() && now != lastClick) {
            ItemStack held = player.getMainHandItem();
            if (held.isEmpty()) {
               if (fists != null && Amulets.<TitanFistsAbility>find(player, TitanFistsAbility.class) != null) {
                  lastClick = now;
                  PacketDistributor.sendToServer(new TitanPunchPacket(player.getYRot(), player.getXRot()), new CustomPacketPayload[0]);
               }
            } else if (blades != null && TitanBlades.isSword(held)) {
               Amulets.Found<TitanBladesAbility> found = Amulets.find(player, TitanBladesAbility.class);
               if (found != null && bladeReady(found.ability(), now)) {
                  lastClick = now;
                  if (blades == BladeMode.SLASH) {
                     lastCut = now;
                  }

                  PacketDistributor.sendToServer(new TitanBladePacket(player.getYRot(), player.getXRot()), new CustomPacketPayload[0]);
                  event.setCanceled(true);
                  event.setSwingHand(true);
               }
            }
         }
      }
   }

   private static boolean bladeReady(TitanBladesAbility ability, long now) {
      if (blades == BladeMode.SLASH) {
         return READY_AT[3] <= now && now - lastCut >= ability.cutTicks();
      } else {
         return windowUntil > now ? swords < ability.stormBlades() : swords == 0 && READY_AT[4] <= now;
      }
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      Minecraft minecraft = Minecraft.getInstance();
      attackHeld = minecraft.options.keyAttack.isDown();
      LocalPlayer player = minecraft.player;
      marked = -1;
      if (player != null && !player.isSpectator()) {
         ItemStack held = player.getMainHandItem();
         if (held.isEmpty() && fists != null && Amulets.<TitanFistsAbility>find(player, TitanFistsAbility.class) != null) {
            marked = fists.ordinal();
         } else if (blades != null && TitanBlades.isSword(held) && Amulets.<TitanBladesAbility>find(player, TitanBladesAbility.class) != null) {
            marked = TitanSync.glyph(blades);
         }
      }
   }

   @Nullable
   public static Stance fists() {
      return fists;
   }

   @Nullable
   public static BladeMode blades() {
      return blades;
   }

   public static void state(TitanHudPacket packet) {
      fists = Stance.fromCode(packet.fists());
      blades = BladeMode.fromCode(packet.blades());
      long now = ClientClock.ticks();
      int[] readyIn = packet.readyIn();

      for (int i = 0; i < READY_AT.length && i < readyIn.length; i++) {
         if (now + readyIn[i] > READY_AT[i] + 1L) {
            RECHARGING_SINCE[i] = now;
         }

         READY_AT[i] = now + readyIn[i];
      }

      cuts = packet.cuts();
      comboUntil = now + packet.comboLeft();
      swords = packet.swords();
      windowUntil = now + packet.windowLeft();
      if (packet.glyph() >= 0) {
         shown = packet.glyph();
         shownAt = now;
         CameraShake.quake(packet.glyph() == 5 ? 0.15F : 0.35F, 4, 0);
      }
   }

   @SubscribeEvent
   public static void onRenderGui(net.neoforged.neoforge.client.event.RenderGuiEvent.Post event) {
      GuiGraphics graphics = event.getGuiGraphics();
      float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
      float x = graphics.guiWidth() / 2.0F;
      float y = graphics.guiHeight() / 2.0F;
      float showing = shown < 0 ? -1.0F : ClientClock.since(shownAt, partialTick);
      if (showing > 20.0F || Minecraft.getInstance().player == null) {
         shown = -1;
      }

      if (shown >= 0 || marked >= 0) {
         RenderSystem.enableBlend();
         if (shown >= 0) {
            glyph(graphics, shown, showing, x, y);
         } else {
            mark(graphics, marked, x + 9.0F, y + -5.0F, partialTick);
            if (marked == 3) {
               combo(graphics, x + 9.0F, y + -5.0F + 5.5F + 3.0F, partialTick);
            } else if (marked == 4) {
               storm(graphics, x + 9.0F, y + -5.0F, partialTick);
            }
         }

         graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableBlend();
      }
   }

   private static float[] tint(int glyph) {
      return glyph == 5 ? GREY : (glyph >= 3 ? BLUE : GOLD);
   }

   private static void glyph(GuiGraphics graphics, int glyph, float age, float x, float y) {
      PoseStack pose = graphics.pose();
      float[] tint = tint(glyph);
      boolean off = glyph == 5;
      float slam = Easing.outBack(Mth.clamp(age / 3.0F, 0.0F, 1.0F));
      float leave = Easing.smoothstep(11.0F, 20.0F, age);
      float gx = off ? x : Mth.lerp(leave, x, x + 9.0F);
      float gy = off ? y - 22.0F : Mth.lerp(leave, y - 22.0F, y + -5.0F);
      float glyphSize = off ? 30.0F * (2.2F - 1.2F * slam) * (1.0F - 0.3F * leave) : Mth.lerp(leave, 30.0F * (2.2F - 1.2F * slam), 11.0F);
      float alpha = off ? 1.0F - leave : 1.0F;
      float backdrop = Mth.clamp(age / 2.0F, 0.0F, 1.0F) * (1.0F - Easing.smoothstep(8.0F, 14.0F, age));
      if (backdrop > 0.01F) {
         pose.pushPose();
         pose.translate(x, y - 22.0F, 0.0F);
         pose.mulPose(Axis.ZP.rotationDegrees(glyph * 117.0F + age * 2.0F));
         float ink = 0.6F + 0.4F * Easing.outCubic(Mth.clamp(age / 3.0F, 0.0F, 1.0F));
         pose.scale(ink, ink, 1.0F);
         graphics.setColor(1.0F, 1.0F, 1.0F, 0.8F * backdrop);
         graphics.blit(INK, -36, -36, 72, 72, 0.0F, 0.0F, 64, 64, 64, 64);
         pose.popPose();
         RenderSystem.blendFunc(SourceFactor.SRC_ALPHA, DestFactor.ONE);
         pose.pushPose();
         pose.translate(x, y - 22.0F, 0.0F);
         pose.mulPose(Axis.ZP.rotationDegrees(age * (off ? -9.0F : 9.0F)));
         float ring = 1.5F - 0.5F * slam;
         pose.scale(ring, ring, 1.0F);
         graphics.setColor(tint[0], tint[1], tint[2], backdrop * (off ? 0.5F : 1.0F));
         graphics.blit(TitanFistRenderer.CIRCLE, -30, -30, 60, 60, 0.0F, 0.0F, 256, 256, 256, 256);
         pose.popPose();
         RenderSystem.defaultBlendFunc();
      }

      drawGlyph(graphics, glyph, gx, gy, glyphSize, alpha);
      float flash = Math.max(0.0F, 1.0F - Math.abs(age - 3.0F) / 3.0F);
      if (flash > 0.01F) {
         RenderSystem.blendFunc(SourceFactor.SRC_ALPHA, DestFactor.ONE);
         drawGlyph(graphics, glyph, gx, gy, glyphSize, flash * alpha);
         RenderSystem.defaultBlendFunc();
      }
   }

   private static void mark(GuiGraphics graphics, int glyph, float x, float y, float partialTick) {
      long now = ClientClock.ticks();
      float left = (float)(READY_AT[glyph] - now) - partialTick;
      if (left <= 0.0F) {
         float since = -left;
         float pulse = since < 8.0F ? 1.0F - since / 8.0F : 0.0F;
         drawGlyph(graphics, glyph, x, y, 11.0F * (1.0F + 0.35F * pulse), 0.75F);
         if (pulse > 0.0F) {
            RenderSystem.blendFunc(SourceFactor.SRC_ALPHA, DestFactor.ONE);
            drawGlyph(graphics, glyph, x, y, 11.0F * (1.0F + 0.35F * pulse), pulse);
            RenderSystem.defaultBlendFunc();
         }
      } else {
         float total = Math.max(1.0F, (float)(READY_AT[glyph] - RECHARGING_SINCE[glyph]));
         float filled = 1.0F - left / total;
         graphics.setColor(0.35F, 0.35F, 0.4F, 0.5F);
         drawGlyph(graphics, glyph, x, y, 11.0F, 1.0F);
         int top = Mth.floor(y - 5.5F);
         int bottom = Mth.ceil(y + 5.5F);
         graphics.enableScissor(Mth.floor(x - 11.0F), Mth.ceil(bottom - (bottom - top) * filled), Mth.ceil(x + 11.0F), bottom);
         drawGlyph(graphics, glyph, x, y, 11.0F, 0.55F);
         graphics.disableScissor();
      }
   }

   private static void combo(GuiGraphics graphics, float x, float y, float partialTick) {
      float left = (float)(comboUntil - ClientClock.ticks()) - partialTick;
      int lit = left > 0.0F ? cuts : 0;

      for (int i = 0; i < 3; i++) {
         int px = Mth.floor(x + (i - 1) * 4.0F) - 1;
         int py = Mth.floor(y);
         boolean on = i < lit;
         graphics.fill(px, py, px + 2, py + 2, on ? -16288 : 1613770816);
         if (on && left < 6.0F) {
            graphics.fill(px, py, px + 2, py + 2, Integer.MIN_VALUE);
         }
      }
   }

   private static void storm(GuiGraphics graphics, float x, float y, float partialTick) {
      if (swords > 0) {
         Minecraft minecraft = Minecraft.getInstance();
         graphics.drawString(minecraft.font, Integer.toString(swords), Mth.floor(x + 5.5F + 2.0F), Mth.floor(y - 4.0F), -6302465, true);
         LocalPlayer player = minecraft.player;
         Amulets.Found<TitanBladesAbility> found = player == null ? null : Amulets.find(player, TitanBladesAbility.class);
         float left = (float)(windowUntil - ClientClock.ticks()) - partialTick;
         if (found != null && !(left <= 0.0F)) {
            float share = Mth.clamp(left / found.ability().stormWindow(), 0.0F, 1.0F);
            int bx = Mth.floor(x - 5.5F);
            int by = Mth.floor(y + 5.5F + 3.0F);
            graphics.fill(bx, by, bx + 11, by + 1, 1613770816);
            graphics.fill(bx, by, bx + Math.round(11.0F * share), by + 1, -8600321);
         }
      }
   }

   private static void drawGlyph(GuiGraphics graphics, int glyph, float x, float y, float size, float alpha) {
      if (alpha < 1.0F) {
         graphics.setColor(1.0F, 1.0F, 1.0F, alpha);
      }

      PoseStack pose = graphics.pose();
      pose.pushPose();
      pose.translate(x, y, 0.0F);
      pose.scale(size / 64.0F, size / 64.0F, 1.0F);
      graphics.blit(GLYPHS, -32, -32, 64, 64, 64.0F * glyph, 0.0F, 64, 64, 384, 64);
      pose.popPose();
      graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      shown = -1;
      marked = -1;
      fists = null;
      blades = null;
      swords = 0;
      cuts = 0;
      windowUntil = 0L;
      comboUntil = 0L;
      lastClick = -1L;
      lastCut = -4611686018427387904L;
      Arrays.fill(READY_AT, 0L);
      Arrays.fill(RECHARGING_SINCE, 0L);
   }
}
