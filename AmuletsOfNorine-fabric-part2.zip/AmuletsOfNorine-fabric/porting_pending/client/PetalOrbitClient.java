package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.sylvan.PetalOrbit;
import com.amuletmod.amulet.ability.sylvan.PetalSwarms;
import com.amuletmod.client.renderer.GlowBatch;
import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap.Entry;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import net.neoforged.neoforge.event.level.LevelEvent.Unload;
import org.joml.Matrix4f;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class PetalOrbitClient {
   public static final ResourceLocation PETAL = AmuletMod.id("textures/entity/petal.png");
   private static final int BLOOM_TICKS = 12;
   private static final float PETAL_BASE = 0.03F;
   private static final float PETAL_LENGTH = 0.3F;
   private static final float PETAL_HALF_WIDTH = 0.09F;
   private static final Int2ObjectMap<PetalOrbitClient.Swarm> SWARMS = new Int2ObjectOpenHashMap();

   private PetalOrbitClient() {
   }

   public static void update(int entityId, int[] colors, int[] petals) {
      ClientLevel level = Minecraft.getInstance().level;
      if (level != null) {
         PetalOrbitClient.Swarm swarm = (PetalOrbitClient.Swarm)SWARMS.computeIfAbsent(entityId, id -> new PetalOrbitClient.Swarm());
         boolean any = false;

         for (int slot = 0; slot < 5; slot++) {
            if (swarm.petals[slot] == 0 && petals[slot] > 0) {
               swarm.bloomStart[slot] = level.getGameTime();
            }

            swarm.colors[slot] = colors[slot];
            swarm.petals[slot] = petals[slot];
            any |= petals[slot] > 0;
         }

         if (!any) {
            SWARMS.remove(entityId);
         }
      }
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      Minecraft minecraft = Minecraft.getInstance();
      ClientLevel level = minecraft.level;
      if (level != null && !minecraft.isPaused() && !SWARMS.isEmpty()) {
         double time = level.getGameTime();
         ObjectIterator var5 = SWARMS.int2ObjectEntrySet().iterator();

         while (var5.hasNext()) {
            Entry<PetalOrbitClient.Swarm> entry = (Entry<PetalOrbitClient.Swarm>)var5.next();
            Entity owner = level.getEntity(entry.getIntKey());
            if (owner != null && !owner.isInvisible()) {
               Vec3 center = PetalOrbit.center(owner, owner.getX(), owner.getY(), owner.getZ());
               PetalOrbitClient.Swarm swarm = (PetalOrbitClient.Swarm)entry.getValue();

               for (int slot = 0; slot < 5; slot++) {
                  if (swarm.petals[slot] > 0 && level.random.nextInt(8) == 0) {
                     Vec3 at = PetalOrbit.blossom(center, slot, time);
                     level.addParticle(
                        new DustParticleOptions(PetalSwarms.rgb(swarm.colors[slot]), 0.5F),
                        at.x + level.random.nextGaussian() * 0.12,
                        at.y + level.random.nextGaussian() * 0.12,
                        at.z + level.random.nextGaussian() * 0.12,
                        0.0,
                        -0.02,
                        0.0
                     );
                  }
               }
            }
         }
      }
   }

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      ClientLevel level = Minecraft.getInstance().level;
      if (event.getStage() == Stage.AFTER_ENTITIES && level != null && !SWARMS.isEmpty()) {
         float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
         double time = (float)level.getGameTime() + partialTick;
         Camera camera = event.getCamera();
         Vec3 view = camera.getPosition();
         PoseStack poseStack = event.getPoseStack();
         BufferSource buffers = Minecraft.getInstance().renderBuffers().bufferSource();
         RenderType type = RenderType.entityCutoutNoCull(PETAL);
         VertexConsumer consumer = buffers.getBuffer(type);
         Player viewer = Minecraft.getInstance().player;
         ObjectIterator var12 = SWARMS.int2ObjectEntrySet().iterator();

         while (var12.hasNext()) {
            Entry<PetalOrbitClient.Swarm> entry = (Entry<PetalOrbitClient.Swarm>)var12.next();
            Entity owner = level.getEntity(entry.getIntKey());
            if (owner != null && (viewer == null || !owner.isInvisibleTo(viewer))) {
               Vec3 feet = owner.getPosition(partialTick);
               Vec3 center = PetalOrbit.center(owner, feet.x, feet.y, feet.z);
               PetalOrbitClient.Swarm swarm = (PetalOrbitClient.Swarm)entry.getValue();

               for (int slot = 0; slot < 5; slot++) {
                  if (swarm.petals[slot] > 0) {
                     float bloom = Easing.outBack(Mth.clamp((float)(time - swarm.bloomStart[slot]) / 12.0F, 0.0F, 1.0F));
                     int color = swarm.colors[slot];
                     float r = (color >> 16 & 0xFF) / 255.0F;
                     float g = (color >> 8 & 0xFF) / 255.0F;
                     float b = (color & 0xFF) / 255.0F;
                     Vec3 blossom = PetalOrbit.blossom(center, slot, time);
                     Vec3 normal = PetalOrbit.normal(slot, time);
                     poseStack.pushPose();
                     poseStack.translate(blossom.x - view.x, blossom.y - view.y, blossom.z - view.z);
                     Matrix4f pose = poseStack.last().pose();
                     Pose normalMatrix = poseStack.last();

                     for (int petal = 0; petal < swarm.petals[slot]; petal++) {
                        petal(consumer, pose, normalMatrix, PetalOrbit.petalDirection(slot, petal, time), normal, bloom, r, g, b);
                     }

                     float glow = 0.3F * Mth.clamp(bloom, 0.0F, 1.0F);
                     poseStack.mulPose(camera.rotation());
                     GlowBatch.add(
                        ModRenderTypes.GLOW,
                        poseStack,
                        (glowConsumer, glowPose, glowNormal) -> GlowDraw.starburst(glowConsumer, glowPose, 0.55F, 0.45F, r, g, b, glow)
                     );
                     poseStack.popPose();
                  }
               }
            }
         }

         buffers.endBatch(type);
      }
   }

   private static void petal(VertexConsumer consumer, Matrix4f pose, Pose normalMatrix, Vec3 along, Vec3 normal, float bloom, float r, float g, float b) {
      Vec3 side = normal.cross(along).scale(0.09F * bloom);
      Vec3 base = along.scale(0.03F * bloom);
      Vec3 tip = along.scale(0.33F * bloom);
      float nx = (float)normal.x;
      float ny = (float)normal.y;
      float nz = (float)normal.z;
      vertex(consumer, pose, normalMatrix, base.subtract(side), 0.0F, 1.0F, r, g, b, nx, ny, nz);
      vertex(consumer, pose, normalMatrix, base.add(side), 1.0F, 1.0F, r, g, b, nx, ny, nz);
      vertex(consumer, pose, normalMatrix, tip.add(side), 1.0F, 0.0F, r, g, b, nx, ny, nz);
      vertex(consumer, pose, normalMatrix, tip.subtract(side), 0.0F, 0.0F, r, g, b, nx, ny, nz);
   }

   private static void vertex(
      VertexConsumer consumer, Matrix4f pose, Pose normalMatrix, Vec3 at, float u, float v, float r, float g, float b, float nx, float ny, float nz
   ) {
      consumer.addVertex(pose, (float)at.x, (float)at.y, (float)at.z)
         .setColor(r, g, b, 1.0F)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(normalMatrix, nx, ny, nz);
   }

   @SubscribeEvent
   public static void onLevelUnload(Unload event) {
      if (event.getLevel().isClientSide()) {
         SWARMS.clear();
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      SWARMS.clear();
   }

   private static final class Swarm {
      final int[] colors = new int[5];
      final int[] petals = new int[5];
      final long[] bloomStart = new long[5];
   }
}
