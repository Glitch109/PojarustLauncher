package com.amuletmod.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.ViewportEvent.ComputeCameraAngles;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class CameraShake {
   private static final List<CameraShake.Pending> PENDING = new ArrayList<>();
   private static float strength;
   private static int duration;
   private static int remaining;

   private CameraShake() {
   }

   public static void from(Vec3 source, float maxDegrees, double range, int durationTicks) {
      LocalPlayer player = Minecraft.getInstance().player;
      if (player != null) {
         double distance = player.position().distanceTo(source);
         if (!(distance >= range)) {
            start(maxDegrees * (float)(1.0 - distance / range), durationTicks);
         }
      }
   }

   public static void quake(float degrees, int durationTicks, int delayTicks) {
      if (delayTicks <= 0) {
         start(degrees, durationTicks);
      } else {
         PENDING.add(new CameraShake.Pending(delayTicks, degrees, durationTicks));
      }
   }

   private static void start(float degrees, int durationTicks) {
      float current = remaining > 0 ? strength * remaining / duration : 0.0F;
      if (!(degrees < current) && durationTicks > 0) {
         strength = degrees;
         remaining = durationTicks;
         duration = durationTicks;
      }
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      if (!Minecraft.getInstance().isPaused()) {
         if (remaining > 0) {
            remaining--;
         }

         if (!PENDING.isEmpty()) {
            List<CameraShake.Pending> due = new ArrayList<>();

            for (int i = 0; i < PENDING.size(); i++) {
               CameraShake.Pending pending = PENDING.get(i);
               if (pending.delay() <= 1) {
                  due.add(pending);
               } else {
                  PENDING.set(i, new CameraShake.Pending(pending.delay() - 1, pending.degrees(), pending.duration()));
               }
            }

            PENDING.removeAll(due);
            due.forEach(pendingx -> start(pendingx.degrees(), pendingx.duration()));
         }
      }
   }

   @SubscribeEvent
   public static void onComputeCameraAngles(ComputeCameraAngles event) {
      if (remaining > 0 && Minecraft.getInstance().level != null) {
         float partialTick = (float)event.getPartialTick();
         float fade = Math.max(0.0F, (remaining - partialTick) / duration);
         float amount = strength * fade * fade;
         float t = ClientClock.time(partialTick);
         event.setYaw(event.getYaw() + amount * (Mth.sin(t * 1.9F) * 0.7F + Mth.sin(t * 4.3F) * 0.3F));
         event.setPitch(event.getPitch() + amount * (Mth.sin(t * 2.3F + 1.3F) * 0.7F + Mth.sin(t * 5.1F) * 0.3F));
         event.setRoll(event.getRoll() + amount * 0.6F * Mth.sin(t * 3.1F + 0.7F));
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      PENDING.clear();
      remaining = 0;
   }

   private record Pending(int delay, float degrees, int duration) {
   }
}
