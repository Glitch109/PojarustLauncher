package com.amuletmod.client;

import com.amuletmod.client.renderer.AuraDraw;
import com.amuletmod.client.renderer.GlowBatch;
import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.amuletmod.client.renderer.TintedBuffers;
import com.amuletmod.mixin.client.LivingEntityRendererInvoker;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.IllagerModel;
import net.minecraft.client.model.VillagerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.RenderLivingEvent.Pre;
import net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent;
import org.joml.Matrix4f;
import org.joml.Vector3f;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class ShadowSoldierClient {
   private static final float[] BODY = new float[]{0.1F, 0.08F, 0.17F};
   private static final float[] GLOWING = new float[]{0.7F, 0.5F, 1.0F};
   private static final float[] EYE = new float[]{0.6F, 0.7F, 1.0F};
   private static final float[] EYE_HALO = new float[]{0.45F, 0.25F, 1.0F};
   private static final Map<Integer, Long> SOLDIERS = new HashMap<>();
   private static boolean rendering;

   private ShadowSoldierClient() {
   }

   public static void add(int entityId, int age) {
      if (Minecraft.getInstance().level != null) {
         SOLDIERS.put(entityId, ClientClock.ticks() - age);
      }
   }

   @SubscribeEvent
   public static void onRenderLiving(Pre<?, ?> event) {
      if (!rendering && !SOLDIERS.isEmpty()) {
         LivingEntity entity = event.getEntity();
         Long since = SOLDIERS.get(entity.getId());
         ClientLevel level = Minecraft.getInstance().level;
         if (since != null && level != null) {
            event.setCanceled(true);
            float partialTick = event.getPartialTick();
            float age = ClientClock.since(since, partialTick);
            float risen = Easing.outCubic(age / 24.0F);
            PoseStack poseStack = event.getPoseStack();
            LivingEntityRenderer<LivingEntity, EntityModel<LivingEntity>> renderer = event.getRenderer();
            poseStack.pushPose();
            poseStack.translate(0.0F, -(1.0F - risen) * (entity.getBbHeight() + 0.1F), 0.0F);
            rendering = true;

            try {
               renderer.render(
                  entity,
                  Mth.lerp(partialTick, entity.yRotO, entity.getYRot()),
                  partialTick,
                  poseStack,
                  new TintedBuffers(event.getMultiBufferSource(), BODY, GLOWING),
                  event.getPackedLight()
               );
               if (!entity.isBaby() && !entity.isInvisible()) {
                  eyes(renderer, entity, poseStack, partialTick, risen);
               }
            } finally {
               rendering = false;
            }

            poseStack.popPose();
            flames(entity, poseStack, partialTick, ClientClock.time(partialTick), risen);
         }
      }
   }

   private static void eyes(
      LivingEntityRenderer<LivingEntity, EntityModel<LivingEntity>> renderer, LivingEntity entity, PoseStack poseStack, float partialTick, float risen
   ) {
      EntityModel<LivingEntity> model = renderer.getModel();
      ModelPart head;
      float eyeY;
      if (model instanceof HumanoidModel<?> humanoid) {
         head = humanoid.head;
         eyeY = -3.6F;
      } else if (model instanceof IllagerModel<?> illager) {
         head = illager.getHead();
         eyeY = -5.4F;
      } else {
         if (!(model instanceof VillagerModel<?> villager)) {
            return;
         }

         head = villager.getHead();
         eyeY = -5.4F;
      }

      if (head.visible) {
         LivingEntityRendererInvoker invoker = (LivingEntityRendererInvoker)renderer;
         float bodyYaw = Mth.rotLerp(partialTick, entity.yBodyRotO, entity.yBodyRot);
         float scale = entity.getScale();
         poseStack.pushPose();
         poseStack.scale(scale, scale, scale);
         invoker.amuletmod$setupRotations(entity, poseStack, invoker.amuletmod$getBob(entity, partialTick), bodyYaw, partialTick, scale);
         poseStack.scale(-1.0F, -1.0F, 1.0F);
         invoker.amuletmod$scale(entity, poseStack, partialTick);
         poseStack.translate(0.0F, -1.501F, 0.0F);
         head.translateAndRotate(poseStack);
         float flicker = (0.85F + 0.15F * Mth.sin((entity.tickCount + partialTick) * 0.4F + entity.getId())) * risen;
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            for (float side : new float[]{-2.0F, 2.0F}) {
               float x = side / 16.0F;
               float y = eyeY / 16.0F;
               float z = -0.255F;
               eyeQuad(consumer, pose, x, y, z, 0.05F, 0.03125F, EYE[0], EYE[1], EYE[2], flicker);
               poseHalo(consumer, pose, x, y, z - 0.005F, 0.15F, flicker * 0.6F);
            }
         });
         poseStack.popPose();
      }
   }

   private static void eyeQuad(
      VertexConsumer consumer, Matrix4f pose, float x, float y, float z, float halfWidth, float halfHeight, float r, float g, float b, float alpha
   ) {
      GlowDraw.vertex(consumer, pose, x - halfWidth, y - halfHeight, z, r, g, b, alpha);
      GlowDraw.vertex(consumer, pose, x + halfWidth, y - halfHeight, z, r, g, b, alpha);
      GlowDraw.vertex(consumer, pose, x + halfWidth, y + halfHeight, z, r, g, b, alpha);
      GlowDraw.vertex(consumer, pose, x - halfWidth, y + halfHeight, z, r, g, b, alpha);
   }

   private static void poseHalo(VertexConsumer consumer, Matrix4f pose, float x, float y, float z, float size, float alpha) {
      Matrix4f at = new Matrix4f(pose).translate(x, y, z);
      GlowDraw.starburst(consumer, at, size, 0.55F, EYE_HALO[0], EYE_HALO[1], EYE_HALO[2], alpha);
   }

   private static void flames(LivingEntity entity, PoseStack poseStack, float partialTick, float time, float risen) {
      if (!entity.isInvisible()) {
         Vec3 camera = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
         Vector3f eye = camera.subtract(entity.getPosition(partialTick)).toVector3f();
         float width = entity.getBbWidth();
         float height = entity.getBbHeight() * (0.4F + 0.5F * risen);
         int seed = entity.getId();
         int tongues = 5 + Math.min(6, (int)(width * 4.0F));
         GlowBatch.add(
            ModRenderTypes.shade(AuraDraw.FLAME),
            poseStack,
            (consumer, pose, normal) -> AuraDraw.flames(
               consumer, pose, eye, width * 0.8F, height * 0.85F, 0.08F, time, seed, tongues, 6, 0.75F * risen, AuraDraw.SMOKE, 0.5F, false
            )
         );
         GlowBatch.add(
            ModRenderTypes.skyGlow(AuraDraw.FLAME),
            poseStack,
            (consumer, pose, normal) -> AuraDraw.flames(
               consumer, pose, eye, width * 0.9F, height * 0.9F, 0.1F, time * 1.15F, seed * 31 + 7, tongues - 2, 6, 0.4F * risen, AuraDraw.SHADOW, 0.6F, true
            )
         );
      }
   }

   @SubscribeEvent
   public static void onEntityLeave(EntityLeaveLevelEvent event) {
      if (event.getLevel().isClientSide) {
         SOLDIERS.remove(event.getEntity().getId());
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      SOLDIERS.clear();
   }
}
