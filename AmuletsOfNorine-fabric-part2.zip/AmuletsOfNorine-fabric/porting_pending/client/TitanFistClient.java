package com.amuletmod.client;

import com.amuletmod.amulet.ability.titan.Stance;
import com.amuletmod.entity.TitanFistEntity;
import com.amuletmod.util.Easing;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public final class TitanFistClient {
   private static final DustParticleOptions GOLD_DUST = new DustParticleOptions(new Vector3f(1.0F, 0.76F, 0.3F), 1.3F);

   private TitanFistClient() {
   }

   public static void tick(TitanFistEntity fist) {
      ClientLevel level = (ClientLevel)fist.level();
      RandomSource random = level.random;
      int age = fist.tickCount;
      Vec3 position = fist.position();
      Stance stance = fist.stance();
      int impact = fist.impactTick();
      float width = fist.width();
      if (age < impact && fist.circleScale(age) > 0.1F && stance != Stance.JAB) {
         Vec3 circle = position.add(fist.circleCenter(position));

         for (int i = 0; i < 3; i++) {
            double angle = random.nextDouble() * (float) (Math.PI * 2);
            double r = fist.circleScale(age) * (1.1 + random.nextDouble() * 0.5);
            Vec3 at = circle.add(Math.cos(angle) * r, 0.0, Math.sin(angle) * r);
            Vec3 in = circle.subtract(at).scale(0.12);
            level.addParticle(ParticleTypes.LARGE_SMOKE, at.x, at.y, at.z, in.x - in.z * 0.6, 0.0, in.z + in.x * 0.6);
         }

         if (stance == Stance.UPPERCUT && age >= 2) {
            rumble(level, random, position, fist.circleScale(age));
         }
      }

      if (fist.thrown(age) && fist.dissolving(age) < 0.5F) {
         Vec3 heading = fist.heading(position);
         Vec3 wrist = position.add(fist.knuckles(age, position)).subtract(heading.scale(width * 1.1));

         for (int i = 0; i < 2; i++) {
            level.addParticle(
               ParticleTypes.SQUID_INK,
               wrist.x + spread(random, width * 0.4),
               wrist.y + spread(random, width * 0.4),
               wrist.z + spread(random, width * 0.4),
               -heading.x * 0.04,
               -heading.y * 0.04,
               -heading.z * 0.04
            );
         }

         if (random.nextInt(2) == 0) {
            level.addParticle(
               GOLD_DUST, wrist.x + spread(random, width * 0.6), wrist.y + spread(random, width * 0.6), wrist.z + spread(random, width * 0.6), 0.0, 0.02, 0.0
            );
         }
      }

      if (age == impact) {
         impact(fist, level, random, position);
      }

      if (stance == Stance.CRUSH && age > impact && age <= impact + 10) {
         waveDust(fist, level, random, position, age - impact);
      }

      float dissolving = fist.dissolving(age);
      if (dissolving > 0.0F && dissolving < 1.0F) {
         Vec3 heading = fist.heading(position);
         Vec3 middle = position.add(fist.knuckles(age, position)).subtract(heading.scale(width * 0.5));

         for (int i = 0; i < 4; i++) {
            level.addParticle(
               random.nextInt(3) == 0 ? ParticleTypes.SQUID_INK : ParticleTypes.LARGE_SMOKE,
               middle.x + spread(random, width * 0.6),
               middle.y + spread(random, width * 0.6),
               middle.z + spread(random, width * 0.6),
               spread(random, 0.03),
               0.03 + random.nextDouble() * 0.03,
               spread(random, 0.03)
            );
         }
      }
   }

   private static void impact(TitanFistEntity fist, ClientLevel level, RandomSource random, Vec3 position) {
      float width = fist.width();
      Vec3 heading = fist.heading(position);
      switch (fist.stance()) {
         case JAB:
            Vec3 at = position;
            burst(level, random, ParticleTypes.CRIT, position, 14, width * 0.3, 0.5);
            burst(level, random, GOLD_DUST, position, 8, width * 0.4, 0.15);

            for (int i = 0; i < 10; i++) {
               level.addParticle(
                  ParticleTypes.SQUID_INK,
                  at.x,
                  at.y,
                  at.z,
                  -heading.x * 0.15 + spread(random, 0.15),
                  -heading.y * 0.15 + spread(random, 0.15),
                  -heading.z * 0.15 + spread(random, 0.15)
               );
            }

            BlockState wall = blockAt(level, at.add(heading.scale(0.35)));
            if (wall != null) {
               burst(level, random, new BlockParticleOption(ParticleTypes.BLOCK, wall), at, 16, width * 0.3, 0.25);
            }

            CameraShake.from(at, 0.55F, 14.0, 5);
            break;
         case CRUSH:
            BlockState ground = blockAt(level, position.subtract(0.0, 0.2, 0.0));
            if (ground != null) {
               for (int i = 0; i < 48; i++) {
                  double angle = random.nextDouble() * (float) (Math.PI * 2);
                  double r = random.nextDouble() * width;
                  level.addParticle(
                     new BlockParticleOption(ParticleTypes.BLOCK, ground),
                     position.x + Math.cos(angle) * r,
                     position.y + 0.1,
                     position.z + Math.sin(angle) * r,
                     Math.cos(angle) * 0.4,
                     0.3 + random.nextDouble() * 0.5,
                     Math.sin(angle) * 0.4
                  );
               }
            }

            for (int i = 0; i < 3; i++) {
               level.addParticle(
                  ParticleTypes.EXPLOSION, position.x + spread(random, width), position.y + 0.5, position.z + spread(random, width), 0.0, 0.0, 0.0
               );
            }

            burst(level, random, ParticleTypes.SQUID_INK, position.add(0.0, 0.5, 0.0), 18, width * 0.5, 0.3);
            burst(level, random, GOLD_DUST, position.add(0.0, 0.5, 0.0), 14, width * 0.6, 0.2);
            CameraShake.from(position, 1.4F, 24.0, 10);
            nearbyPunch(position, 14.0, 0.025F);
            break;
         case UPPERCUT:
            BlockState ground = blockAt(level, position.subtract(0.0, 0.2, 0.0));
            if (ground != null) {
               for (int i = 0; i < 36; i++) {
                  double angle = random.nextDouble() * (float) (Math.PI * 2);
                  double r = random.nextDouble() * width * 0.6;
                  level.addParticle(
                     new BlockParticleOption(ParticleTypes.BLOCK, ground),
                     position.x + Math.cos(angle) * r,
                     position.y + 0.1,
                     position.z + Math.sin(angle) * r,
                     Math.cos(angle) * 0.15,
                     0.6 + random.nextDouble() * 0.6,
                     Math.sin(angle) * 0.15
                  );
               }
            }

            level.addParticle(ParticleTypes.EXPLOSION, position.x, position.y + 0.6, position.z, 0.0, 0.0, 0.0);
            Vec3 at = position.add(fist.knuckles(fist.impactTick(), position));
            burst(level, random, ParticleTypes.SQUID_INK, at, 14, width * 0.4, 0.3);
            burst(level, random, ParticleTypes.CRIT, at, 16, width * 0.4, 0.6);
            burst(level, random, GOLD_DUST, at, 10, width * 0.5, 0.2);
            CameraShake.from(position, 1.0F, 18.0, 8);
            nearbyPunch(position, 10.0, 0.018F);
      }
   }

   private static void rumble(ClientLevel level, RandomSource random, Vec3 position, float radius) {
      BlockState ground = blockAt(level, position.subtract(0.0, 0.2, 0.0));
      if (ground != null) {
         for (int i = 0; i < 3; i++) {
            double angle = random.nextDouble() * (float) (Math.PI * 2);
            double r = random.nextDouble() * radius;
            level.addParticle(
               new BlockParticleOption(ParticleTypes.BLOCK, ground),
               position.x + Math.cos(angle) * r,
               position.y + 0.05,
               position.z + Math.sin(angle) * r,
               0.0,
               0.15 + random.nextDouble() * 0.15,
               0.0
            );
         }
      }
   }

   private static void waveDust(TitanFistEntity fist, ClientLevel level, RandomSource random, Vec3 position, int since) {
      double radius = fist.wave() * Easing.outCubic(since / 10.0F);
      int count = 10 + (int)(radius * 4.0);

      for (int i = 0; i < count; i++) {
         double angle = random.nextDouble() * (float) (Math.PI * 2);
         double x = position.x + Math.cos(angle) * radius;
         double z = position.z + Math.sin(angle) * radius;
         BlockState ground = blockAt(level, new Vec3(x, position.y - 0.2, z));
         ParticleOptions dust = (ParticleOptions)(ground != null && random.nextInt(2) == 0
            ? new BlockParticleOption(ParticleTypes.BLOCK, ground)
            : ParticleTypes.POOF);
         level.addParticle(dust, x, position.y + 0.1, z, Math.cos(angle) * 0.12, 0.12 + random.nextDouble() * 0.12, Math.sin(angle) * 0.12);
      }
   }

   static void burst(ClientLevel level, RandomSource random, ParticleOptions particle, Vec3 at, int count, double spread, double speed) {
      for (int i = 0; i < count; i++) {
         level.addParticle(
            particle,
            at.x + spread(random, spread),
            at.y + spread(random, spread),
            at.z + spread(random, spread),
            spread(random, speed),
            spread(random, speed),
            spread(random, speed)
         );
      }
   }

   private static void nearbyPunch(Vec3 at, double range, float strength) {
      LocalPlayer player = Minecraft.getInstance().player;
      if (player != null && player.position().distanceTo(at) < range) {
         ImpactFrames.punch(strength);
      }
   }

   @Nullable
   static BlockState blockAt(ClientLevel level, Vec3 at) {
      BlockState state = level.getBlockState(BlockPos.containing(at));
      return !state.isAir() && state.getRenderShape() != RenderShape.INVISIBLE ? state : null;
   }

   static double spread(RandomSource random, double size) {
      return (random.nextDouble() - 0.5) * 2.0 * size;
   }
}
