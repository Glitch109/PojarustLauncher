package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.titan.TitanBlades;
import com.amuletmod.client.renderer.GlowBatch;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.HumanoidModel.ArmPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelPart.Cube;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.ClientHooks;
import net.neoforged.neoforge.client.event.RenderArmEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class TitanHands {
   public static final ResourceLocation FLAME = AmuletMod.id("textures/misc/titan_flame.png");
   private static final int FRAMES = 8;
   public static final float[] GOLD_FIRE = new float[]{1.0F, 0.7F, 0.24F};
   public static final float[] BLUE_FIRE = new float[]{0.36F, 0.66F, 1.0F};
   private static final float INFLATE = 0.6F;
   private static final float REACH = 9.0F;
   private static final float GRIP = 0.1875F;
   private static final RandomSource RANDOM = RandomSource.create();
   private static final Map<UUID, int[]> STATES = new HashMap<>();

   private TitanHands() {
   }

   public static void state(UUID player, int fists, int blades) {
      if (fists < 0 && blades < 0) {
         STATES.remove(player);
      } else {
         STATES.put(player, new int[]{fists, blades});
      }
   }

   @Nullable
   public static float[] fire(Player player) {
      int[] state = STATES.get(player.getUUID());
      if (state == null || player.isSpectator()) {
         return null;
      } else if (state[1] >= 0 && TitanBlades.isSword(player.getMainHandItem())) {
         return BLUE_FIRE;
      } else {
         return state[0] >= 0 ? GOLD_FIRE : null;
      }
   }

   public static void armSleeve(PoseStack poseStack, MultiBufferSource buffers, ModelPart arm, float[] colour, float time, boolean deferGlow) {
      Cube cube = arm.getRandomCube(RANDOM);
      float x0 = (cube.minX - 0.6F) / 16.0F;
      float x1 = (cube.maxX + 0.6F) / 16.0F;
      float z0 = (cube.minZ - 0.6F) / 16.0F;
      float z1 = (cube.maxZ + 0.6F) / 16.0F;
      float base = (cube.maxY + 0.4F) / 16.0F;
      float tips = (cube.maxY - 9.0F) / 16.0F;
      sleeve(poseStack, buffers, x0, x1, z0, z1, base, tips, colour, time, deferGlow);
   }

   private static void gripSleeve(PoseStack poseStack, MultiBufferSource buffers, float[] colour, float time) {
      poseStack.pushPose();
      poseStack.translate(0.1875F, 0.1875F, 0.5F);
      poseStack.mulPose(Axis.ZP.rotationDegrees(-45.0F));
      float half = 0.09375F;
      sleeve(poseStack, buffers, -half, half, -half, half, -0.15625F, 0.3125F, colour, time, false);
      poseStack.popPose();
   }

   private static void sleeve(
      PoseStack poseStack,
      MultiBufferSource buffers,
      float x0,
      float x1,
      float z0,
      float z1,
      float base,
      float tips,
      float[] colour,
      float time,
      boolean deferGlow
   ) {
      Pose pose = poseStack.last();
      sleeveFaces(buffers.getBuffer(ModRenderTypes.phantom(FLAME)), pose.pose(), pose, x0, x1, z0, z1, base, tips, colour[0], colour[1], colour[2], 0.92F, time);
      float r = colour[0] * 0.55F;
      float g = colour[1] * 0.55F;
      float b = colour[2] * 0.55F;
      if (deferGlow) {
         GlowBatch.add(
            ModRenderTypes.glowTextured(FLAME),
            poseStack,
            (consumer, matrix, normal) -> sleeveFaces(consumer, matrix, normal, x0, x1, z0, z1, base, tips, r, g, b, 1.0F, time)
         );
      } else {
         sleeveFaces(buffers.getBuffer(ModRenderTypes.glowTextured(FLAME)), pose.pose(), pose, x0, x1, z0, z1, base, tips, r, g, b, 1.0F, time);
      }
   }

   private static void sleeveFaces(
      VertexConsumer consumer,
      Matrix4f pose,
      Pose normal,
      float x0,
      float x1,
      float z0,
      float z1,
      float base,
      float tips,
      float r,
      float g,
      float b,
      float a,
      float time
   ) {
      int frame = Math.floorMod((int)(time / 2.0F), 8);
      float v0 = frame / 8.0F;
      float v1 = (frame + 1) / 8.0F;
      float height = Math.abs(base - tips);
      float[][] sides = new float[][]{{x0, z0, x1, z0, 0.0F, -1.0F}, {x1, z0, x1, z1, 1.0F, 0.0F}, {x1, z1, x0, z1, 0.0F, 1.0F}, {x0, z1, x0, z0, -1.0F, 0.0F}};
      float u = 0.0F;

      for (float[] side : sides) {
         float span = (Math.abs(side[2] - side[0]) + Math.abs(side[3] - side[1])) / height;
         vertex(consumer, pose, normal, side[0], tips, side[1], r, g, b, a, u, v0, side[4], side[5]);
         vertex(consumer, pose, normal, side[2], tips, side[3], r, g, b, a, u + span, v0, side[4], side[5]);
         vertex(consumer, pose, normal, side[2], base, side[3], r, g, b, a, u + span, v1, side[4], side[5]);
         vertex(consumer, pose, normal, side[0], base, side[1], r, g, b, a, u, v1, side[4], side[5]);
         u += span;
      }

      float capTop = v1 - 0.0234375F;
      float capBottom = v1 - 0.00390625F;
      vertex(consumer, pose, normal, x0, base, z0, r, g, b, a, 0.0F, capTop, 0.0F, 0.0F);
      vertex(consumer, pose, normal, x1, base, z0, r, g, b, a, 1.0F, capTop, 0.0F, 0.0F);
      vertex(consumer, pose, normal, x1, base, z1, r, g, b, a, 1.0F, capBottom, 0.0F, 0.0F);
      vertex(consumer, pose, normal, x0, base, z1, r, g, b, a, 0.0F, capBottom, 0.0F, 0.0F);
   }

   private static void vertex(
      VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float y, float z, float r, float g, float b, float a, float u, float v, float nx, float nz
   ) {
      consumer.addVertex(pose, x, y, z)
         .setColor(r, g, b, a)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(normal, nx, nx == 0.0F && nz == 0.0F ? 1.0F : 0.0F, nz);
   }

   @SubscribeEvent
   public static void onRenderArm(RenderArmEvent event) {
      AbstractClientPlayer player = event.getPlayer();
      float[] colour = fire(player);
      if (colour != null && !player.isInvisible()) {
         if (Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(player) instanceof PlayerRenderer renderer) {
            PlayerModel var7 = (PlayerModel)renderer.getModel();
            ModelPart arm = event.getArm() == HumanoidArm.RIGHT ? var7.rightArm : var7.leftArm;
            var7.attackTime = 0.0F;
            var7.crouching = false;
            var7.swimAmount = 0.0F;
            var7.rightArmPose = ArmPose.EMPTY;
            var7.leftArmPose = ArmPose.EMPTY;
            var7.setupAnim(player, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
            arm.xRot = 0.0F;
            PoseStack poseStack = event.getPoseStack();
            poseStack.pushPose();
            arm.translateAndRotate(poseStack);
            armSleeve(
               poseStack,
               event.getMultiBufferSource(),
               arm,
               colour,
               ClientClock.time(Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(true)),
               false
            );
            poseStack.popPose();
         }
      }
   }

   @SubscribeEvent
   public static void onRenderHand(RenderHandEvent event) {
      if (event.getHand() == InteractionHand.MAIN_HAND) {
         Minecraft minecraft = Minecraft.getInstance();
         LocalPlayer player = minecraft.player;
         ItemStack stack = event.getItemStack();
         if (player != null
            && !player.isInvisible()
            && !player.isUsingItem()
            && !player.isAutoSpinAttack()
            && fire(player) == BLUE_FIRE
            && TitanBlades.isSword(stack)) {
            boolean right = player.getMainArm() == HumanoidArm.RIGHT;
            int side = right ? 1 : -1;
            float swing = event.getSwingProgress();
            float equip = event.getEquipProgress();
            float swingRoot = Mth.sqrt(swing);
            PoseStack poseStack = event.getPoseStack();
            poseStack.pushPose();
            poseStack.translate(
               side * -0.4F * Mth.sin(swingRoot * (float) Math.PI), 0.2F * Mth.sin(swingRoot * (float) (Math.PI * 2)), -0.2F * Mth.sin(swing * (float) Math.PI)
            );
            poseStack.translate(side * 0.56F, -0.52F + equip * -0.6F, -0.72F);
            float lift = Mth.sin(swing * swing * (float) Math.PI);
            poseStack.mulPose(Axis.YP.rotationDegrees(side * (45.0F + lift * -20.0F)));
            float arc = Mth.sin(swingRoot * (float) Math.PI);
            poseStack.mulPose(Axis.ZP.rotationDegrees(side * arc * -20.0F));
            poseStack.mulPose(Axis.XP.rotationDegrees(arc * -80.0F));
            poseStack.mulPose(Axis.YP.rotationDegrees(side * -45.0F));
            ItemDisplayContext context = right ? ItemDisplayContext.FIRST_PERSON_RIGHT_HAND : ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
            BakedModel model = minecraft.getItemRenderer().getModel(stack, player.level(), player, player.getId() + context.ordinal());
            ClientHooks.handleCameraTransforms(poseStack, model, context, !right);
            poseStack.translate(-0.5F, -0.5F, -0.5F);
            gripSleeve(poseStack, event.getMultiBufferSource(), BLUE_FIRE, ClientClock.time(event.getPartialTick()));
            poseStack.popPose();
         }
      }
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      Minecraft minecraft = Minecraft.getInstance();
      ClientLevel level = minecraft.level;
      if (level != null && !STATES.isEmpty() && !minecraft.isPaused()) {
         LocalPlayer self = minecraft.player;

         for (Player player : level.players()) {
            float[] colour = fire(player);
            if (colour != null
               && !player.isInvisible()
               && (player.tickCount + player.getId()) % 3 == 0
               && (player != self || !minecraft.options.getCameraType().isFirstPerson())
               && (self == null || !(player.distanceToSqr(self) > 1024.0))) {
               float yaw = player.yBodyRot * (float) (Math.PI / 180.0);
               double rightX = -Mth.cos(yaw);
               double rightZ = -Mth.sin(yaw);
               double y = player.getY() + (player.isCrouching() ? 0.55 : 0.7);

               for (int hand = -1; hand <= 1; hand += 2) {
                  double x = player.getX() + rightX * 0.37 * hand + (level.random.nextDouble() - 0.5) * 0.15;
                  double z = player.getZ() + rightZ * 0.37 * hand + (level.random.nextDouble() - 0.5) * 0.15;
                  level.addParticle(colour == BLUE_FIRE ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.SMALL_FLAME, x, y, z, 0.0, 0.015, 0.0);
               }
            }
         }
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      STATES.clear();
   }
}
