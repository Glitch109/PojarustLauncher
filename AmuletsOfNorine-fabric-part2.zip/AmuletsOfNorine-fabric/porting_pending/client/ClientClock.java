package com.amuletmod.client;

import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent.Pre;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class ClientClock {
   private static final long WRAP = 24000L;
   private static long ticks;

   private ClientClock() {
   }

   public static long ticks() {
      return ticks;
   }

   public static float since(long start, float partialTick) {
      return (float)(ticks - start) + partialTick;
   }

   public static float time(float partialTick) {
      return (float)(ticks % 24000L) + partialTick;
   }

   @SubscribeEvent
   public static void onClientTick(Pre event) {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft.level != null && !minecraft.isPaused() && minecraft.level.tickRateManager().runsNormally()) {
         ticks++;
      }
   }
}
