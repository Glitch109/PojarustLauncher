package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.slf4j.Logger;

public final class GodStrikePost {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final ResourceLocation WORLD = AmuletMod.id("god_strike_world");
   private static final ResourceLocation LENS = AmuletMod.id("god_strike_lens");
   @Nullable
   private static ShaderInstance world;
   @Nullable
   private static ShaderInstance lens;
   @Nullable
   private static TextureTarget scratch;

   private GodStrikePost() {
   }

   public static void onRegisterShaders(RegisterShadersEvent event) {
      world = null;
      lens = null;

      try {
         event.registerShader(new ShaderInstance(event.getResourceProvider(), WORLD, DefaultVertexFormat.POSITION_TEX), shader -> world = shader);
         event.registerShader(new ShaderInstance(event.getResourceProvider(), LENS, DefaultVertexFormat.POSITION_TEX), shader -> lens = shader);
      } catch (IOException var2) {
         LOGGER.warn("The God Strike's screen effects are off: {}", var2.getMessage());
         world = null;
         lens = null;
      }
   }

   public static boolean available() {
      return world != null && lens != null && !ShaderPacks.inUse();
   }

   public static void apply(Matrix4f view, Matrix4f projection, GodStrikePost.Look look) {
      ShaderInstance world = GodStrikePost.world;
      ShaderInstance lens = GodStrikePost.lens;
      if (world != null && lens != null && look.visible()) {
         Minecraft minecraft = Minecraft.getInstance();
         RenderTarget main = minecraft.getMainRenderTarget();
         if (scratch == null) {
            scratch = new TextureTarget(main.width, main.height, false, Minecraft.ON_OSX);
            scratch.setFilterMode(9729);
         } else if (scratch.width != main.width || scratch.height != main.height) {
            scratch.resize(main.width, main.height, Minecraft.ON_OSX);
         }

         Matrix4f viewProjection = new Matrix4f(projection).mul(view);
         world.safeGetUniform("ViewProj").set(viewProjection);
         world.safeGetUniform("InvViewProj").set(new Matrix4f(viewProjection).invert());
         world.safeGetUniform("Target").set(look.target);
         world.safeGetUniform("Rift").set(look.rift);
         world.safeGetUniform("Entry").set(look.entry);
         world.safeGetUniform("Awaken").set(look.awaken, look.radius, look.charge, look.time);
         world.safeGetUniform("Shatter").set(look.broken, look.reach, look.jolt, look.fallen);
         world.safeGetUniform("Grade").set(look.gloom, 0.0F, look.seed, look.heat);
         world.safeGetUniform("OutSize").set(main.width, main.height);
         world.setSampler("DiffuseSampler", main.getColorTextureId());
         world.setSampler("DepthSampler", main.getDepthTextureId());
         Vector4f rift = viewProjection.transform(new Vector4f(look.rift, 1.0F));
         boolean ahead = rift.w > 0.0F;
         lens.safeGetUniform("Lens").set(look.aberration, look.impactFrame, look.impactKind, look.time);
         lens.safeGetUniform("Tint").set(0.3F, 0.16F, 0.5F, look.vignette);
         lens.safeGetUniform("Focus").set(ahead ? rift.x / rift.w * 0.5F + 0.5F : 0.5F, ahead ? rift.y / rift.w * 0.5F + 0.5F : 0.5F, ahead ? 1.0F : 0.0F);
         lens.safeGetUniform("OutSize").set(main.width, main.height);
         lens.setSampler("DiffuseSampler", scratch.getColorTextureId());
         RenderSystem.disableDepthTest();
         RenderSystem.depthMask(false);
         RenderSystem.disableBlend();
         RenderSystem.disableCull();
         RenderSystem.colorMask(true, true, true, true);
         scratch.bindWrite(true);
         fullScreen(world);
         main.bindWrite(true);
         RenderSystem.colorMask(true, true, true, false);
         fullScreen(lens);
         RenderSystem.colorMask(true, true, true, true);
         RenderTarget particles = minecraft.levelRenderer.getParticlesTarget();
         if (Minecraft.useShaderTransparency() && particles != null) {
            particles.bindWrite(false);
         } else {
            main.bindWrite(false);
         }

         RenderSystem.enableCull();
         RenderSystem.depthMask(true);
         RenderSystem.enableDepthTest();
      }
   }

   private static void fullScreen(ShaderInstance shader) {
      BufferBuilder builder = Tesselator.getInstance().begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
      builder.addVertex(-1.0F, -1.0F, 0.0F).setUv(0.0F, 0.0F);
      builder.addVertex(1.0F, -1.0F, 0.0F).setUv(1.0F, 0.0F);
      builder.addVertex(1.0F, 1.0F, 0.0F).setUv(1.0F, 1.0F);
      builder.addVertex(-1.0F, 1.0F, 0.0F).setUv(0.0F, 1.0F);
      shader.apply();
      RenderSystem.disableBlend();
      BufferUploader.draw(builder.buildOrThrow());
      shader.clear();
   }

   public static final class Look {
      public final Vector3f target = new Vector3f();
      public final Vector3f rift = new Vector3f();
      public final Vector3f entry = new Vector3f();
      public float awaken;
      public float radius;
      public float charge;
      public float time;
      public float broken;
      public float reach;
      public float jolt;
      public float fallen;
      public float gloom;
      public float seed;
      public float heat;
      public float aberration;
      public float vignette;
      public float impactFrame;
      public float impactKind;

      public boolean visible() {
         return this.awaken > 0.001F
            || this.broken > 0.001F
            || this.gloom > 0.001F
            || this.heat > 0.001F
            || this.aberration > 0.001F
            || this.vignette > 0.001F
            || this.impactFrame > 0.001F;
      }
   }
}
