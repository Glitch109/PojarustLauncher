package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.librarian.PageLook;
import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.client.renderer.LateBuffers;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.amuletmod.client.renderer.SealRenderer;
import com.amuletmod.client.renderer.UnderworldHandRenderer;
import com.amuletmod.network.FxPacket;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.platform.GlStateManager.DestFactor;
import com.mojang.blaze3d.platform.GlStateManager.SourceFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.RenderGuiEvent.Pre;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import org.joml.Matrix4f;
import org.joml.Vector3f;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class ClientFx {
   private static final ResourceLocation VIGNETTE = ResourceLocation.fromNamespaceAndPath("minecraft", "textures/misc/vignette.png");
   private static final Vector3f GOLD = new Vector3f(1.0F, 0.82F, 0.3F);
   private static final Vector3f VIOLET = new Vector3f(0.45F, 0.15F, 0.75F);
   private static final Vector3f DEEP_VIOLET = new Vector3f(0.25F, 0.05F, 0.45F);
   private static final ResourceLocation EXTRACT_CIRCLE = AmuletMod.id("textures/misc/binding_circle.png");
   private static final float[] VIOLET_HALO = new float[]{0.55F, 0.2F, 1.0F};
   private static final float[] VIOLET_CORE = new float[]{0.9F, 0.75F, 1.0F};
   private static final float[] BLUE_HALO = new float[]{0.4F, 0.6F, 1.0F};
   private static final float[] BLUE_CORE = new float[]{0.9F, 0.95F, 1.0F};
   private static final int EXTRACT_CRACKS = 7;
   private static final ClientFx.Vignette HELL = new ClientFx.Vignette(0.25F, 0.95F, 0.95F, 6, 14, 50);
   private static final ClientFx.Vignette SHOCK = new ClientFx.Vignette(0.85F, 0.55F, 0.05F, 2, 2, 12);
   private static final ClientFx.Vignette SHADOW = new ClientFx.Vignette(0.6F, 0.95F, 0.4F, 3, 6, 24);
   private static final ClientFx.Vignette METEOR_LOCK = new ClientFx.Vignette(0.12F, 0.6F, 0.7F, 4, 6, 26);
   private static final ClientFx.Vignette SEALED = new ClientFx.Vignette(0.1F, 0.92F, 0.55F, 4, 16, 44);
   private static final int[][] BOX_EDGES = new int[][]{{0, 1}, {1, 3}, {3, 2}, {2, 0}, {4, 5}, {5, 7}, {7, 6}, {6, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
   private static final float[] BURN_LOSS = new float[]{0.1F, 0.55F, 0.9F};
   private static final List<ClientFx.Active> ACTIVE = new ArrayList<>();
   private static ClientFx.Vignette vignette = HELL;
   private static int vignetteAge = -1;

   private ClientFx() {
   }

   private static int duration(FxPacket.Kind kind) {
      return switch (kind) {
         case FIREBALL -> 10;
         case HOUND_SUMMON, MONARCH_CALL -> 26;
         case KNELL -> 40;
         case BOLT -> 7;
         case DASH -> 10;
         case SHADOW_VANISH -> 12;
         case SHADOW_REVEAL -> 14;
         case SHADOW_EXTRACT -> 48;
         case SHADOW_POOL -> 44;
         case SHADOW_DISSOLVE -> 22;
         case ARISE -> 32;
         case METEOR_BLAST -> 16;
         case PAGE_CUT -> 6;
         case SEAL_RELEASE -> 24;
         case HELL_VIGNETTE, SHOCK_VIGNETTE, SHADOW_VIGNETTE, METEOR_LOCK, METEOR_IMPACT, METEOR_HIT, SEAL_FLASH, SEAL_VIGNETTE -> 0;
      };
   }

   public static void play(FxPacket.Kind kind, Vec3 at, Vec3 to, float size) {
      ClientLevel level = Minecraft.getInstance().level;
      if (level != null) {
         switch (kind) {
            case HELL_VIGNETTE:
               startVignette(HELL);
               break;
            case SHOCK_VIGNETTE:
               startVignette(SHOCK);
               break;
            case SHADOW_VIGNETTE:
               startVignette(SHADOW);
               break;
            case METEOR_LOCK:
               startVignette(METEOR_LOCK);
               break;
            case METEOR_IMPACT:
               meteorImpact(size);
               break;
            case METEOR_HIT:
               meteorHit(at, size);
               break;
            case SEAL_FLASH:
               ImpactFrames.flash(1.0F);
               ImpactFrames.punch(-0.08F);
               CameraShake.quake(1.6F, 14, 0);
               break;
            case SEAL_VIGNETTE:
               startVignette(SEALED);
               ImpactFrames.flash(0.5F);
               ImpactFrames.punch(0.06F);
         }

         if (duration(kind) > 0) {
            RandomSource random = level.random;
            int entity = -1;
            if (kind == FxPacket.Kind.SHADOW_EXTRACT) {
               Player killer = level.getNearestPlayer(to.x, to.y, to.z, 3.0, false);
               if (killer != null) {
                  entity = killer.getId();
               }
            }

            ACTIVE.add(new ClientFx.Active(kind, at, to, size, ClientClock.ticks(), random.nextLong(), entity));
            switch (kind) {
               case FIREBALL:
                  CameraShake.from(at, 0.6F, 12.0, 6);
                  break;
               case HOUND_SUMMON:
                  CameraShake.from(at, 0.7F, 14.0, 8);
                  break;
               case MONARCH_CALL:
                  for (int i = 0; i < 40; i++) {
                     double angle = random.nextDouble() * (float) (Math.PI * 2);
                     double radius = 0.8 + random.nextDouble() * 2.5;
                     level.addParticle(
                        new DustParticleOptions(GOLD, 0.8F),
                        at.x + Math.cos(angle) * radius,
                        at.y + random.nextDouble() * 2.0,
                        at.z + Math.sin(angle) * radius,
                        0.0,
                        0.0,
                        0.0
                     );
                  }

                  for (int i = 0; i < 12; i++) {
                     level.addParticle(
                        ParticleTypes.CHERRY_LEAVES,
                        at.x + random.nextGaussian() * 2.0,
                        at.y + 2.5 + random.nextDouble(),
                        at.z + random.nextGaussian() * 2.0,
                        0.0,
                        0.0,
                        0.0
                     );
                  }
                  break;
               case KNELL:
                  CameraShake.from(at, 1.4F, 24.0, 24);

                  for (int i = 0; i < 48; i++) {
                     double angle = i * (float) (Math.PI * 2) / 48.0;
                     level.addParticle(
                        ParticleTypes.SOUL_FIRE_FLAME,
                        at.x + Math.cos(angle) * 1.5,
                        at.y + 0.1,
                        at.z + Math.sin(angle) * 1.5,
                        Math.cos(angle) * 0.35,
                        0.02,
                        Math.sin(angle) * 0.35
                     );
                  }
                  break;
               case BOLT:
                  CameraShake.from(to, 0.5F, 14.0, 4);
                  break;
               case DASH:
                  CameraShake.from(to, 0.4F, 8.0, 4);
                  break;
               case SHADOW_VANISH:
                  for (int i = 0; i < 24; i++) {
                     double angle = random.nextDouble() * (float) (Math.PI * 2);
                     double radius = 0.9 + random.nextDouble() * 0.6;
                     double x = Math.cos(angle) * radius;
                     double z = Math.sin(angle) * radius;
                     double y = random.nextDouble() * size;
                     level.addParticle(new DustParticleOptions(VIOLET, 1.0F), at.x + x, at.y + y, at.z + z, 0.0, 0.0, 0.0);
                     level.addParticle(ParticleTypes.REVERSE_PORTAL, at.x + x, at.y + y, at.z + z, -x * 0.08, 0.0, -z * 0.08);
                  }
                  break;
               case SHADOW_REVEAL:
                  for (int i = 0; i < 20; i++) {
                     double angle = random.nextDouble() * (float) (Math.PI * 2);
                     level.addParticle(ParticleTypes.SMOKE, at.x, at.y + random.nextDouble() * size, at.z, Math.cos(angle) * 0.08, 0.01, Math.sin(angle) * 0.08);
                     level.addParticle(
                        new DustParticleOptions(VIOLET, 1.0F),
                        at.x + Math.cos(angle) * 0.3,
                        at.y + random.nextDouble() * size,
                        at.z + Math.sin(angle) * 0.3,
                        0.0,
                        0.0,
                        0.0
                     );
                  }
                  break;
               case SHADOW_EXTRACT:
                  double radius = extractRadius(size);

                  for (int i = 0; i < 16; i++) {
                     level.addParticle(
                        ParticleTypes.SMOKE,
                        at.x + random.nextGaussian() * 0.25,
                        at.y + size * (0.3 + random.nextDouble() * 0.5),
                        at.z + random.nextGaussian() * 0.25,
                        0.0,
                        0.04,
                        0.0
                     );
                     double angle = i * (float) (Math.PI * 2) / 16.0;
                     level.addParticle(
                        new DustParticleOptions(VIOLET, 1.2F), at.x + Math.cos(angle) * radius, at.y + 0.1, at.z + Math.sin(angle) * radius, 0.0, 0.0, 0.0
                     );
                  }
                  break;
               case SHADOW_POOL:
                  double radius = Math.max(0.7, size * 0.9 + 0.3);

                  for (int i = 0; i < 20; i++) {
                     double angle = random.nextDouble() * (float) (Math.PI * 2);
                     double r = radius * Math.sqrt(random.nextDouble());
                     level.addParticle(
                        ParticleTypes.SQUID_INK,
                        at.x + Math.cos(angle) * r,
                        at.y + 0.05,
                        at.z + Math.sin(angle) * r,
                        0.0,
                        0.03 + random.nextDouble() * 0.05,
                        0.0
                     );
                  }
                  break;
               case SHADOW_DISSOLVE:
                  for (int i = 0; i < 26; i++) {
                     double angle = random.nextDouble() * (float) (Math.PI * 2);
                     double y = random.nextDouble() * size;
                     level.addParticle(
                        ParticleTypes.LARGE_SMOKE,
                        at.x + Math.cos(angle) * 0.3,
                        at.y + y,
                        at.z + Math.sin(angle) * 0.3,
                        Math.cos(angle) * 0.03,
                        0.05,
                        Math.sin(angle) * 0.03
                     );
                     level.addParticle(
                        new DustParticleOptions(VIOLET, 1.3F), at.x + Math.cos(angle) * 0.4, at.y + y, at.z + Math.sin(angle) * 0.4, 0.0, 0.0, 0.0
                     );
                  }
                  break;
               case ARISE:
                  CameraShake.from(at, 1.1F, 20.0, 16);

                  for (int i = 0; i < 60; i++) {
                     double angle = i * (float) (Math.PI * 2) / 60.0;
                     level.addParticle(
                        ParticleTypes.REVERSE_PORTAL,
                        at.x + Math.cos(angle) * 1.2,
                        at.y + 0.1,
                        at.z + Math.sin(angle) * 1.2,
                        Math.cos(angle) * 0.4,
                        0.02,
                        Math.sin(angle) * 0.4
                     );
                  }
                  break;
               case METEOR_BLAST:
                  meteorBlast(level, random, at, size);
               case PAGE_CUT:
               default:
                  break;
               case SEAL_RELEASE:
                  CameraShake.from(at, 0.8F, 14.0, 8);

                  for (int i = 0; i < 28; i++) {
                     Vec3 out = new Vec3(random.nextGaussian(), random.nextGaussian() * 0.6, random.nextGaussian()).normalize();
                     level.addParticle(ParticleTypes.END_ROD, at.x, at.y + size * 0.5, at.z, out.x * 0.16, out.y * 0.16, out.z * 0.16);
                  }
            }
         }
      }
   }

   private static void meteorBlast(ClientLevel level, RandomSource random, Vec3 at, float radius) {
      CameraShake.from(at, 1.8F, 28.0, 10);

      for (int i = 0; i < 3; i++) {
         level.addParticle(
            ParticleTypes.EXPLOSION,
            true,
            at.x + random.nextGaussian() * 0.4,
            at.y + random.nextGaussian() * 0.3,
            at.z + random.nextGaussian() * 0.4,
            0.0,
            0.0,
            0.0
         );
      }

      for (int i = 0; i < 40; i++) {
         Vec3 out = new Vec3(random.nextGaussian(), Math.abs(random.nextGaussian()) * 0.8, random.nextGaussian()).normalize();
         double speed = (0.12 + random.nextDouble() * 0.3) * radius / 2.5;
         level.addParticle(
            i % 3 == 0 ? ParticleTypes.SMALL_FLAME : ParticleTypes.FLAME,
            i < 12,
            at.x + out.x * 0.3,
            at.y + out.y * 0.3,
            at.z + out.z * 0.3,
            out.x * speed,
            out.y * speed,
            out.z * speed
         );
      }

      for (int i = 0; i < 8; i++) {
         level.addParticle(ParticleTypes.LAVA, true, at.x, at.y, at.z, 0.0, 0.0, 0.0);
      }

      for (int i = 0; i < 12; i++) {
         double angle = random.nextDouble() * (float) (Math.PI * 2);
         double r = radius * 0.5 * random.nextDouble();
         level.addParticle(
            ParticleTypes.LARGE_SMOKE,
            at.x + Math.cos(angle) * r,
            at.y + random.nextDouble() * 0.5,
            at.z + Math.sin(angle) * r,
            Math.cos(angle) * 0.06,
            0.04 + random.nextDouble() * 0.04,
            Math.sin(angle) * 0.06
         );
      }

      level.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, true, at.x, at.y + 0.3, at.z, 0.0, 0.04, 0.0);
   }

   private static void meteorBlastGlow(VertexConsumer glow, PoseStack poseStack, Camera camera, float radius, float age, float t) {
      Matrix4f pose = poseStack.last().pose();
      float swell = Easing.outCubic(Mth.clamp(age / 5.0F, 0.0F, 1.0F));
      float fade = (1.0F - t) * (1.0F - t);
      float core = 1.0F - Easing.smoothstep(0.0F, 6.0F, age);
      GlowDraw.glowSphere(
         glow, pose, radius * (0.3F + 0.6F * swell), (float) (-Math.PI / 2), (float) (Math.PI / 2), 16, 8, 1.0F, 0.38F, 0.07F, (nx, ny, nz) -> 0.6F * fade
      );
      GlowDraw.glowSphere(
         glow, pose, radius * (0.15F + 0.3F * swell), (float) (-Math.PI / 2), (float) (Math.PI / 2), 12, 6, 1.0F, 0.85F, 0.55F, (nx, ny, nz) -> 0.95F * core
      );
      if (age < 5.0F) {
         float star = 1.0F - age / 5.0F;
         poseStack.pushPose();
         poseStack.mulPose(camera.rotation());
         poseStack.mulPose(Axis.ZP.rotationDegrees(22.5F));
         GlowDraw.starburst(glow, poseStack.last().pose(), radius * (1.1F + 0.9F * (1.0F - star)), 0.28F, 1.0F, 0.8F, 0.5F, star);
         GlowDraw.starburst(glow, poseStack.last().pose(), radius * 0.55F, 0.4F, 1.0F, 0.95F, 0.85F, star);
         poseStack.popPose();
      }

      float reach = radius * (0.3F + 1.9F * Easing.outCubic(t));
      float alpha = 0.7F * (1.0F - t);
      GlowDraw.ring(glow, pose, 0.05F, Math.max(0.0F, reach - 0.9F), reach, 48, 1.0F, 0.32F, 0.06F, 0.0F, alpha);
      GlowDraw.ring(glow, pose, 0.05F, reach, reach + 0.25F, 48, 1.0F, 0.7F, 0.35F, alpha, 0.0F);
      GlowDraw.band(glow, pose, reach * 0.92F, 0.7F * (1.0F - t), 48, 1.0F, 0.4F, 0.1F, alpha * 0.45F);
   }

   private static void sealRelease(VertexConsumer glow, PoseStack poseStack, Camera camera, Vector3f eye, float height, float age, float t) {
      Matrix4f pose = poseStack.last().pose();
      float[] seal = SealRenderer.GLOW;
      float[] pale = SealRenderer.PALE;
      float open = Easing.outCubic(Mth.clamp(age / 9.0F, 0.0F, 1.0F));
      float fade = 1.0F - Easing.smoothstep(5.0F, 16.0F, age);
      float w = Mth.lerp(open, 0.2F, 0.9F + height * 0.15F);
      float h = Mth.lerp(open, 0.2F, height * 0.5F + 0.5F);
      if (fade > 0.0F) {
         Vector3f[] corners = new Vector3f[8];

         for (int i = 0; i < 8; i++) {
            corners[i] = new Vector3f((i & 1) == 0 ? -w : w, height * 0.5F + ((i & 4) == 0 ? -h : h), (i & 2) == 0 ? -w : w);
         }

         for (int[] edge : BOX_EDGES) {
            GlowDraw.beam(glow, pose, corners[edge[0]], corners[edge[1]], eye, 0.09F, 4, seal[0], seal[1], seal[2], 0.6F * fade);
            GlowDraw.beam(glow, pose, corners[edge[0]], corners[edge[1]], eye, 0.03F, 4, pale[0], pale[1], pale[2], fade);
         }
      }

      float ring = 0.4F + 2.4F * Easing.outCubic(t);
      float alpha = 0.7F * (1.0F - t);
      GlowDraw.ring(glow, pose, 0.06F, Math.max(0.0F, ring - 0.9F), ring, 40, seal[0], seal[1], seal[2], 0.0F, alpha);
      GlowDraw.ring(glow, pose, 0.06F, ring, ring + 0.2F, 40, pale[0], pale[1], pale[2], alpha, 0.0F);
      GlowDraw.band(glow, pose, ring, 0.6F * (1.0F - t), 40, seal[0], seal[1], seal[2], alpha * 0.4F);
      float flash = Math.max(0.0F, 1.0F - age / 6.0F);
      if (!(flash <= 0.0F)) {
         poseStack.pushPose();
         poseStack.translate(0.0F, height * 0.5F, 0.0F);
         GlowDraw.glowSphere(
            glow,
            poseStack.last().pose(),
            0.3F + 1.1F * (1.0F - flash),
            (float) (-Math.PI / 2),
            (float) (Math.PI / 2),
            14,
            7,
            pale[0],
            pale[1],
            pale[2],
            (nx, ny, nz) -> 0.7F * flash * flash
         );
         poseStack.mulPose(camera.rotation());
         poseStack.mulPose(Axis.ZP.rotationDegrees(22.5F));
         GlowDraw.starburst(glow, poseStack.last().pose(), 1.4F + 1.2F * (1.0F - flash), 0.3F, seal[0], seal[1], seal[2], flash);
         GlowDraw.starburst(glow, poseStack.last().pose(), 0.7F, 0.4F, pale[0], pale[1], pale[2], flash);
         poseStack.popPose();
      }
   }

   private static void pageCut(VertexConsumer glow, Matrix4f pose, Vector3f eye, ClientFx.Active fx, float t) {
      Vec3 along = fx.to().subtract(fx.at());
      Vec3 path = along.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 0.0, 1.0) : along.normalize();
      Vec3 side = path.cross(new Vec3(0.0, 1.0, 0.0));
      side = side.lengthSqr() < 1.0E-4 ? new Vec3(1.0, 0.0, 0.0) : side.normalize();
      Vec3 bend = path.cross(side);
      double roll = (fx.seed() & 1023L) / 1023.0 * Math.PI;
      Vec3 across = side.scale(Math.cos(roll)).add(bend.scale(Math.sin(roll)));
      Vec3 inward = path.cross(across);
      PageLook look = PageLook.byId((int)fx.size());
      float radius = 0.55F * (0.55F + 0.45F * Easing.outCubic(t));
      float fade = (1.0F - t) * (1.0F - t);

      for (int half = -1; half <= 1; half += 2) {
         Vector3f[] points = new Vector3f[7];

         for (int j = 0; j < points.length; j++) {
            double angle = half * j / (points.length - 1.0) * 1.15;
            points[j] = across.scale(Math.sin(angle) * radius).add(inward.scale((1.0 - Math.cos(angle)) * radius * 0.6)).toVector3f();
         }

         GlowDraw.taperedRibbon(glow, pose, points, eye, 0.13F * fade + 0.02F, look.r(), look.g(), look.b(), 0.75F * fade);
         GlowDraw.taperedRibbon(glow, pose, points, eye, 0.05F * fade + 0.01F, 1.0F, 1.0F, 1.0F, 0.9F * fade);
      }
   }

   private static void meteorImpact(float strength) {
      ImpactFrames.punch(0.03F + 0.1F * strength);
      ImpactFrames.flash(0.35F + 0.5F * strength);
      CameraShake.quake(1.2F + 2.2F * strength, 10, 0);
      float burn = 0.5F + 0.5F * strength;
      startVignette(new ClientFx.Vignette(BURN_LOSS[0] * burn, BURN_LOSS[1] * burn, BURN_LOSS[2] * burn, 1, 3, 18));
   }

   private static void meteorHit(Vec3 at, float strength) {
      ImpactFrames.punch(0.02F + 0.035F * strength);
      CameraShake.quake(0.4F + 0.5F * strength, 6, 0);
      Player player = Minecraft.getInstance().player;
      if (player != null && player.position().distanceTo(at) > 24.0) {
         Minecraft.getInstance()
            .getSoundManager()
            .play(SimpleSoundInstance.forUI((SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 0.6F, 0.15F + 0.2F * strength));
      }
   }

   private static void startVignette(ClientFx.Vignette kind) {
      vignette = kind;
      vignetteAge = 0;
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      Minecraft minecraft = Minecraft.getInstance();
      if (!minecraft.isPaused()) {
         if (minecraft.level == null) {
            ACTIVE.clear();
            vignetteAge = -1;
         } else {
            long now = ClientClock.ticks();
            ACTIVE.removeIf(fxx -> now - fxx.start() > duration(fxx.kind()));

            for (ClientFx.Active fx : ACTIVE) {
               if (fx.kind() == FxPacket.Kind.SHADOW_EXTRACT) {
                  extractionTick(minecraft, fx, (int)(now - fx.start()));
               }
            }

            if (vignetteAge >= 0 && ++vignetteAge > vignette.rise() + vignette.hold() + vignette.fall()) {
               vignetteAge = -1;
            }
         }
      }
   }

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      ClientLevel level = Minecraft.getInstance().level;
      if (event.getStage() == Stage.AFTER_PARTICLES && level != null && !ACTIVE.isEmpty()) {
         float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
         Camera camera = event.getCamera();
         Vec3 view = camera.getPosition();
         PoseStack poseStack = event.getPoseStack();
         BufferSource buffers = LateBuffers.get();
         VertexConsumer shade = buffers.getBuffer(ModRenderTypes.SHADE_FLAT);

         for (ClientFx.Active fx : ACTIVE) {
            if (fx.kind() == FxPacket.Kind.SHADOW_POOL || fx.kind() == FxPacket.Kind.ARISE || fx.kind() == FxPacket.Kind.SHADOW_EXTRACT) {
               float age = ClientClock.since(fx.start(), partialTick);
               poseStack.pushPose();
               poseStack.translate(fx.at().x - view.x, fx.at().y - view.y, fx.at().z - view.z);
               Matrix4f pose = poseStack.last().pose();
               if (fx.kind() == FxPacket.Kind.SHADOW_EXTRACT) {
                  extractionShade(shade, pose, fx, age);
               } else if (fx.kind() == FxPacket.Kind.SHADOW_POOL) {
                  float radius = poolRadius(fx.size(), age);
                  float dark = 0.85F * (1.0F - Easing.smoothstep(30.0F, 44.0F, age));
                  GlowDraw.ring(shade, pose, 0.03F, 0.0F, radius, 28, 0.02F, 0.0F, 0.05F, dark, dark);
                  GlowDraw.ring(shade, pose, 0.03F, radius, radius * 1.35F, 28, 0.02F, 0.0F, 0.05F, dark, 0.0F);
               } else {
                  float t = Mth.clamp(age / duration(fx.kind()), 0.0F, 1.0F);
                  float reach = fx.size() * Easing.outCubic(t);
                  float dark = 0.55F * (1.0F - t);
                  GlowDraw.ring(shade, pose, 0.04F, Math.max(0.0F, reach - 3.0F), reach, 64, 0.02F, 0.0F, 0.05F, 0.0F, dark);
                  GlowDraw.ring(shade, pose, 0.04F, reach, reach + 0.6F, 64, 0.02F, 0.0F, 0.05F, dark, 0.0F);
               }

               poseStack.popPose();
            }
         }

         buffers.endBatch(ModRenderTypes.SHADE_FLAT);
         VertexConsumer glow = buffers.getBuffer(ModRenderTypes.GLOW);

         for (ClientFx.Active fxx : ACTIVE) {
            float age = ClientClock.since(fxx.start(), partialTick);
            float t = Mth.clamp(age / duration(fxx.kind()), 0.0F, 1.0F);
            poseStack.pushPose();
            poseStack.translate(fxx.at().x - view.x, fxx.at().y - view.y, fxx.at().z - view.z);
            Matrix4f pose = poseStack.last().pose();
            Vector3f eye = view.subtract(fxx.at()).toVector3f();
            switch (fxx.kind()) {
               case FIREBALL: {
                  float fade = (1.0F - t) * (1.0F - t);
                  float radius = fxx.size() * (0.4F + 1.4F * Easing.outCubic(t));
                  GlowDraw.glowSphere(glow, pose, radius, (float) (-Math.PI / 2), (float) (Math.PI / 2), 16, 8, 1.0F, 0.45F, 0.1F, (nx, ny, nz) -> 0.5F * fade);
                  GlowDraw.glowSphere(
                     glow,
                     pose,
                     radius * 0.55F,
                     (float) (-Math.PI / 2),
                     (float) (Math.PI / 2),
                     12,
                     6,
                     1.0F,
                     0.85F,
                     0.45F,
                     (nx, ny, nz) -> 0.7F * fade * (1.0F - t)
                  );
                  GlowDraw.ring(glow, pose, -0.4F, radius * 0.8F, radius * 1.6F, 32, 1.0F, 0.4F, 0.1F, 0.5F * fade, 0.0F);
                  break;
               }
               case HOUND_SUMMON:
                  float open = Easing.outBack(Mth.clamp(age / 6.0F, 0.0F, 1.0F)) * (1.0F - Mth.clamp((age - 18.0F) / 8.0F, 0.0F, 1.0F));
                  poseStack.translate(0.0F, 0.8F * open, 0.0F);
                  GlowDraw.band(glow, poseStack.last().pose(), 0.7F * open, 0.9F * open, 24, 1.0F, 0.35F, 0.05F, 0.6F * open);
                  GlowDraw.band(glow, poseStack.last().pose(), 0.35F * open, 1.2F * open, 16, 1.0F, 0.7F, 0.2F, 0.5F * open);
                  break;
               case MONARCH_CALL:
                  for (int wave = 0; wave < 2; wave++) {
                     float waveT = Mth.clamp((age - wave * 5.0F) / (duration(fxx.kind()) - 5.0F), 0.0F, 1.0F);
                     if (!(waveT <= 0.0F)) {
                        float radiusx = fxx.size() * Easing.outCubic(waveT);
                        float alphax = 0.55F * (1.0F - waveT);
                        GlowDraw.ring(glow, pose, 0.15F, Math.max(0.0F, radiusx - 1.4F), radiusx, 64, 1.0F, 0.8F, 0.3F, 0.0F, alphax);
                        GlowDraw.ring(glow, pose, 0.15F, radiusx, radiusx + 0.3F, 64, 1.0F, 0.9F, 0.5F, alphax, 0.0F);
                     }
                  }
                  break;
               case KNELL: {
                  float radius = fxx.size() * Easing.outCubic(t);
                  float alpha = 0.6F * (1.0F - t);
                  GlowDraw.ring(glow, pose, 0.1F, Math.max(0.0F, radius - 2.0F), radius, 72, 0.9F, 0.08F, 0.04F, 0.0F, alpha);
                  GlowDraw.ring(glow, pose, 0.1F, radius, radius + 0.4F, 72, 1.0F, 0.3F, 0.1F, alpha, 0.0F);
                  GlowDraw.band(glow, pose, radius, 0.8F * (1.0F - t), 72, 0.9F, 0.1F, 0.05F, alpha * 0.6F);
                  break;
               }
               case BOLT: {
                  float fade = 1.0F - t * t;
                  lightning(glow, pose, eye, fxx.to().subtract(fxx.at()), fxx.seed() + (long)(age / 2.0F), 1.0F, 0.26F, fade);
                  GlowDraw.glowSphere(
                     glow, pose, 1.4F, (float) (-Math.PI / 2), (float) (Math.PI / 2), 12, 6, 0.6F, 0.75F, 1.0F, (nx, ny, nz) -> 0.35F * (1.0F - t)
                  );
                  poseStack.pushPose();
                  Vec3 hit = fxx.to().subtract(fxx.at());
                  poseStack.translate(hit.x, hit.y, hit.z);
                  float flash = Mth.clamp(1.0F - age / 4.0F, 0.0F, 1.0F);
                  GlowDraw.glowSphere(
                     glow,
                     poseStack.last().pose(),
                     0.4F + 0.6F * (1.0F - flash),
                     (float) (-Math.PI / 2),
                     (float) (Math.PI / 2),
                     12,
                     6,
                     0.8F,
                     0.9F,
                     1.0F,
                     (nx, ny, nz) -> 0.8F * flash
                  );
                  poseStack.popPose();
                  break;
               }
               case DASH: {
                  float fade = (1.0F - t) * (1.0F - t);
                  lightning(glow, pose, eye, fxx.to().subtract(fxx.at()), fxx.seed() + (long)(age / 2.0F), 0.45F, 0.3F, fade);
                  lightning(glow, pose, eye, fxx.to().subtract(fxx.at()), fxx.seed() * 31L + (long)(age / 3.0F), 0.8F, 0.12F, fade * 0.6F);
                  break;
               }
               case SHADOW_VANISH:
                  shadowWisps(glow, pose, eye, fxx.size(), age, 1.2F * (1.0F - Easing.outCubic(t)) + 0.1F, 0.6F * (1.0F - t * t), true);
                  break;
               case SHADOW_REVEAL:
                  shadowWisps(glow, pose, eye, fxx.size(), age, 0.15F + 1.1F * Easing.outCubic(t), 0.6F * Mth.sin(t * (float) Math.PI), false);
                  break;
               case SHADOW_EXTRACT:
                  extractionGlow(glow, poseStack, eye, fxx, age, partialTick, level);
                  break;
               case SHADOW_POOL: {
                  float radius = poolRadius(fxx.size(), age);
                  float rim = 0.5F * (1.0F - Easing.smoothstep(26.0F, 44.0F, age));
                  GlowDraw.ring(glow, pose, 0.05F, radius * 0.85F, radius, 28, 0.45F, 0.15F, 0.85F, 0.0F, rim);
                  GlowDraw.ring(glow, pose, 0.05F, radius, radius * 1.12F, 28, 0.45F, 0.15F, 0.85F, rim, 0.0F);
                  if (age < 30.0F) {
                     shadowWisps(glow, pose, eye, fxx.size() * 2.2F, age, radius * 0.7F, 0.35F * (1.0F - age / 30.0F), false);
                  }
                  break;
               }
               case SHADOW_DISSOLVE:
                  shadowWisps(glow, pose, eye, fxx.size(), age, 0.2F + 1.0F * Easing.outCubic(t), 0.55F * (1.0F - t), false);
                  break;
               case ARISE: {
                  float reach = fxx.size() * Easing.outCubic(t);
                  float alpha = 0.6F * (1.0F - t);
                  GlowDraw.ring(glow, pose, 0.08F, Math.max(0.0F, reach - 0.8F), reach, 64, 0.5F, 0.15F, 0.95F, 0.0F, alpha);
                  GlowDraw.ring(glow, pose, 0.08F, reach, reach + 0.3F, 64, 0.7F, 0.4F, 1.0F, alpha, 0.0F);
                  GlowDraw.band(glow, pose, reach, 0.9F * (1.0F - t), 64, 0.45F, 0.12F, 0.85F, alpha * 0.5F);
                  break;
               }
               case METEOR_BLAST:
                  meteorBlastGlow(glow, poseStack, camera, fxx.size(), age, t);
                  break;
               case PAGE_CUT:
                  pageCut(glow, pose, eye, fxx, t);
                  break;
               case SEAL_RELEASE:
                  sealRelease(glow, poseStack, camera, eye, fxx.size(), age, t);
            }

            poseStack.popPose();
         }

         buffers.endBatch(ModRenderTypes.GLOW);
         RenderType circles = ModRenderTypes.glowTextured(UnderworldHandRenderer.HELL_CIRCLE);
         VertexConsumer circle = buffers.getBuffer(circles);

         for (ClientFx.Active fxx : ACTIVE) {
            float age = ClientClock.since(fxx.start(), partialTick);
            float radius;
            float fade;
            if (fxx.kind() == FxPacket.Kind.HOUND_SUMMON) {
               radius = 1.4F * Easing.outBack(Mth.clamp(age / 6.0F, 0.0F, 1.0F));
               fade = 1.0F - Mth.clamp((age - 16.0F) / 10.0F, 0.0F, 1.0F);
            } else {
               if (fxx.kind() != FxPacket.Kind.KNELL) {
                  continue;
               }

               radius = 3.5F * Easing.outBack(Mth.clamp(age / 8.0F, 0.0F, 1.0F));
               fade = 1.0F - Mth.clamp((age - 24.0F) / 16.0F, 0.0F, 1.0F);
            }

            poseStack.pushPose();
            poseStack.translate(fxx.at().x - view.x, fxx.at().y - view.y + 0.04, fxx.at().z - view.z);
            poseStack.mulPose(Axis.YP.rotationDegrees(age * 3.0F));
            Matrix4f pose = poseStack.last().pose();
            Pose normal = poseStack.last();
            float r = 1.0F * fade;
            float g = (fxx.kind() == FxPacket.Kind.KNELL ? 0.15F : 0.4F) * fade;
            float b = 0.06F * fade;
            GlowDraw.texVertex(circle, pose, normal, -radius, 0.0F, -radius, r, g, b, 0.0F, 0.0F);
            GlowDraw.texVertex(circle, pose, normal, -radius, 0.0F, radius, r, g, b, 0.0F, 1.0F);
            GlowDraw.texVertex(circle, pose, normal, radius, 0.0F, radius, r, g, b, 1.0F, 1.0F);
            GlowDraw.texVertex(circle, pose, normal, radius, 0.0F, -radius, r, g, b, 1.0F, 0.0F);
            poseStack.popPose();
         }

         buffers.endBatch(circles);
         RenderType runes = ModRenderTypes.glowTextured(EXTRACT_CIRCLE);
         VertexConsumer rune = buffers.getBuffer(runes);

         for (ClientFx.Active fxx : ACTIVE) {
            if (fxx.kind() == FxPacket.Kind.SHADOW_EXTRACT) {
               float age = ClientClock.since(fxx.start(), partialTick);
               float open = Easing.outBack(Mth.clamp(age / 7.0F, 0.0F, 1.0F));
               float fade = 1.0F - Easing.smoothstep(30.0F, 46.0F, age);
               float charge = 0.75F + 0.35F * Easing.smoothstep(3.0F, 8.0F, age) * (1.0F - Easing.smoothstep(20.0F, 26.0F, age));
               float radius = extractRadius(fxx.size()) * open;

               for (int ring = 0; ring < 2; ring++) {
                  float size = ring == 0 ? radius : radius * 0.62F;
                  float spin = ring == 0 ? age * 4.0F : -age * 7.0F;
                  float light = fade * charge * (ring == 0 ? 1.0F : 0.8F);
                  poseStack.pushPose();
                  poseStack.translate(fxx.at().x - view.x, fxx.at().y - view.y + 0.05 + ring * 0.01, fxx.at().z - view.z);
                  poseStack.mulPose(Axis.YP.rotationDegrees(spin));
                  Matrix4f pose = poseStack.last().pose();
                  Pose normal = poseStack.last();
                  float r = 0.62F * light;
                  float g = 0.28F * light;
                  float b = 1.0F * light;
                  GlowDraw.texVertex(rune, pose, normal, -size, 0.0F, -size, r, g, b, 0.0F, 0.0F);
                  GlowDraw.texVertex(rune, pose, normal, -size, 0.0F, size, r, g, b, 0.0F, 1.0F);
                  GlowDraw.texVertex(rune, pose, normal, size, 0.0F, size, r, g, b, 1.0F, 1.0F);
                  GlowDraw.texVertex(rune, pose, normal, size, 0.0F, -size, r, g, b, 1.0F, 0.0F);
                  poseStack.popPose();
               }
            }
         }

         buffers.endBatch(runes);
      }
   }

   private static void lightning(VertexConsumer consumer, Matrix4f pose, Vector3f eye, Vec3 to, long seed, float jitter, float width, float alpha) {
      lightning(consumer, pose, eye, to, seed, jitter, width, alpha, BLUE_HALO, BLUE_CORE);
   }

   private static void lightning(
      VertexConsumer consumer, Matrix4f pose, Vector3f eye, Vec3 to, long seed, float jitter, float width, float alpha, float[] halo, float[] core
   ) {
      RandomSource random = RandomSource.create(seed);
      Vector3f[] main = jagged(random, new Vector3f(), to.toVector3f(), jitter);
      strand(consumer, pose, eye, main, width, alpha, halo, core);

      for (int fork = 0; fork < 2 && main.length > 3; fork++) {
         Vector3f from = main[1 + random.nextInt(main.length - 2)];
         Vector3f direction = to.toVector3f().normalize().add(random.nextFloat() - 0.5F, random.nextFloat() - 0.5F, random.nextFloat() - 0.5F);
         Vector3f end = new Vector3f(direction).normalize((float)to.length() * (0.15F + random.nextFloat() * 0.2F)).add(from);
         strand(consumer, pose, eye, jagged(random, from, end, jitter), width * 0.5F, alpha * 0.7F, halo, core);
      }
   }

   private static void strand(VertexConsumer consumer, Matrix4f pose, Vector3f eye, Vector3f[] points, float width, float alpha, float[] halo, float[] core) {
      GlowDraw.ribbon(consumer, pose, points, eye, width, halo[0], halo[1], halo[2], 0.55F * alpha);
      GlowDraw.ribbon(consumer, pose, points, eye, width * 0.3F, core[0], core[1], core[2], alpha);
   }

   private static Vector3f[] jagged(RandomSource random, Vector3f from, Vector3f to, float jitter) {
      Vector3f span = new Vector3f(to).sub(from);
      float length = span.length();
      int segments = Math.max(4, (int)(length / 0.7F));
      Vector3f direction = new Vector3f(span).normalize();
      Vector3f side = Math.abs(direction.y) > 0.9F ? new Vector3f(1.0F, 0.0F, 0.0F) : new Vector3f(0.0F, 1.0F, 0.0F);
      side.cross(direction).normalize();
      Vector3f other = new Vector3f(direction).cross(side).normalize();
      float amplitude = Math.min(1.2F, length * 0.07F) * jitter;
      Vector3f[] points = new Vector3f[segments + 1];

      for (int k = 0; k <= segments; k++) {
         float along = (float)k / segments;
         float envelope = Mth.sin(along * (float) Math.PI) * amplitude;
         points[k] = new Vector3f(span)
            .mul(along)
            .add(from)
            .add(new Vector3f(side).mul((random.nextFloat() - 0.5F) * 2.0F * envelope))
            .add(new Vector3f(other).mul((random.nextFloat() - 0.5F) * 2.0F * envelope));
      }

      return points;
   }

   private static float poolRadius(float width, float age) {
      float full = Math.max(0.7F, width * 0.9F + 0.3F);
      return full * Easing.outCubic(age / 6.0F) * (1.0F - 0.6F * Easing.smoothstep(30.0F, 44.0F, age));
   }

   private static float extractRadius(float height) {
      return Mth.clamp(0.7F + height * 0.45F, 1.3F, 4.0F);
   }

   private static float soulHeight(float height, float age) {
      return Mth.lerp(Easing.smoothstep(10.0F, 22.0F, age), height * 0.5F, height + 0.9F);
   }

   private static Vector3f killerChest(ClientFx.Active fx, float partialTick, ClientLevel level) {
      Entity killer = fx.entity() < 0 ? null : level.getEntity(fx.entity());
      Vec3 chest = killer == null ? fx.to() : killer.getPosition(partialTick).add(0.0, killer.getBbHeight() * 0.6, 0.0);
      return chest.subtract(fx.at()).toVector3f();
   }

   private static Vector3f[][] cracks(ClientFx.Active fx) {
      RandomSource random = RandomSource.create(fx.seed());
      float radius = extractRadius(fx.size());
      Vector3f[][] cracks = new Vector3f[14][];

      for (int i = 0; i < 7; i++) {
         float angle = (i + random.nextFloat() * 0.6F) * (float) (Math.PI * 2) / 7.0F;
         float length = radius * (1.1F + random.nextFloat() * 0.9F);
         cracks[i * 2] = crack(random, angle, radius * 0.25F, length, 7);
         Vector3f fork = cracks[i * 2][2];
         float forkAngle = (float)Math.atan2(fork.z, fork.x) + (random.nextBoolean() ? 0.6F : -0.6F);
         cracks[i * 2 + 1] = crack(random, forkAngle, (float)Math.sqrt(fork.x * fork.x + fork.z * fork.z), length * 0.45F, 4);
      }

      return cracks;
   }

   private static Vector3f[] crack(RandomSource random, float angle, float from, float length, int segments) {
      Vector3f[] points = new Vector3f[segments + 1];

      for (int k = 0; k <= segments; k++) {
         float r = from + length * k / segments;
         points[k] = new Vector3f(Mth.cos(angle) * r, 0.06F, Mth.sin(angle) * r);
         angle += (random.nextFloat() - 0.5F) * 0.55F;
      }

      return points;
   }

   private static void groundStrip(
      VertexConsumer consumer, Matrix4f pose, Vector3f[] points, float grown, float halfWidth, float r, float g, float b, float alpha
   ) {
      float reach = grown * (points.length - 1);
      int last = Math.min(points.length - 1, (int)Math.ceil(reach));
      if (last >= 1 && !(alpha <= 0.0F)) {
         Vector3f[] shown = new Vector3f[last + 1];

         for (int k = 0; k <= last; k++) {
            shown[k] = k < reach ? points[k] : new Vector3f(points[k - 1]).lerp(points[k], reach - (k - 1));
         }

         for (int k = 0; k < last; k++) {
            Vector3f p0 = shown[k];
            Vector3f p1 = shown[k + 1];
            float dx = p1.x - p0.x;
            float dz = p1.z - p0.z;
            float length = Math.max(1.0E-4F, Mth.sqrt(dx * dx + dz * dz));
            float w0 = halfWidth * (1.0F - (float)k / (points.length - 1));
            float w1 = halfWidth * (1.0F - (float)(k + 1) / (points.length - 1));
            float sx = -dz / length;
            float sz = dx / length;

            for (float sign : new float[]{-1.0F, 1.0F}) {
               GlowDraw.vertex(consumer, pose, p0.x, p0.y, p0.z, r, g, b, alpha);
               GlowDraw.vertex(consumer, pose, p1.x, p1.y, p1.z, r, g, b, alpha);
               GlowDraw.vertex(consumer, pose, p1.x + sx * w1 * sign, p1.y, p1.z + sz * w1 * sign, r, g, b, 0.0F);
               GlowDraw.vertex(consumer, pose, p0.x + sx * w0 * sign, p0.y, p0.z + sz * w0 * sign, r, g, b, 0.0F);
            }
         }
      }
   }

   private static float cracksGrown(float age) {
      return Easing.outCubic(Mth.clamp((age - 2.0F) / 12.0F, 0.0F, 1.0F));
   }

   private static float cracksFade(float age) {
      return 1.0F - Easing.smoothstep(28.0F, 44.0F, age);
   }

   private static void extractionShade(VertexConsumer shade, Matrix4f pose, ClientFx.Active fx, float age) {
      float radius = extractRadius(fx.size()) * Easing.outCubic(Mth.clamp(age / 7.0F, 0.0F, 1.0F));
      float dark = 0.7F * (1.0F - Easing.smoothstep(30.0F, 46.0F, age));
      GlowDraw.ring(shade, pose, 0.04F, 0.0F, radius, 32, 0.02F, 0.0F, 0.04F, dark, dark * 0.8F);
      GlowDraw.ring(shade, pose, 0.04F, radius, radius * 1.25F, 32, 0.02F, 0.0F, 0.04F, dark * 0.8F, 0.0F);
      float grown = cracksGrown(age);
      float fade = cracksFade(age);

      for (Vector3f[] crack : cracks(fx)) {
         groundStrip(shade, pose, crack, grown, 0.2F, 0.01F, 0.0F, 0.02F, 0.9F * fade);
      }
   }

   private static void extractionGlow(
      VertexConsumer glow, PoseStack poseStack, Vector3f eye, ClientFx.Active fx, float age, float partialTick, ClientLevel level
   ) {
      Matrix4f pose = poseStack.last().pose();
      float height = fx.size();
      float radius = extractRadius(height);
      int launch = 22;
      int arrive = 38;
      float grown = cracksGrown(age);
      float fade = cracksFade(age);
      Vector3f[][] cracks = cracks(fx);

      for (int i = 0; i < cracks.length; i++) {
         float flicker = 0.75F + 0.25F * Mth.sin(age * 1.7F + i * 2.3F);
         groundStrip(glow, pose, cracks[i], grown, 0.09F, 0.6F, 0.2F, 1.0F, 0.9F * fade * flicker);
      }

      if (age >= 4.0F && age < launch + 2.0F) {
         long step = (long)(age / 2.0F);
         RandomSource random = RandomSource.create(fx.seed() * 31L + step);
         float strength = 1.0F - Easing.smoothstep(launch - 4.0F, launch + 2.0F, age);

         for (int arc = 0; arc < 3; arc++) {
            if (!(random.nextFloat() > 0.8F)) {
               float angle = random.nextFloat() * (float) (Math.PI * 2);
               Vector3f from = new Vector3f(Mth.cos(angle) * radius * 0.9F, 0.08F, Mth.sin(angle) * radius * 0.9F);
               Vector3f to = arc < 2
                  ? new Vector3f((random.nextFloat() - 0.5F) * 0.4F, height * (0.3F + random.nextFloat() * 0.5F), (random.nextFloat() - 0.5F) * 0.4F)
                  : new Vector3f(Mth.cos(angle + 2.2F) * radius * 0.9F, 0.08F, Mth.sin(angle + 2.2F) * radius * 0.9F);
               poseStack.pushPose();
               poseStack.translate(from.x, from.y, from.z);
               lightning(
                  glow,
                  poseStack.last().pose(),
                  new Vector3f(eye).sub(from),
                  new Vec3(to.sub(from, new Vector3f())),
                  random.nextLong(),
                  0.9F,
                  0.16F,
                  strength,
                  VIOLET_HALO,
                  VIOLET_CORE
               );
               poseStack.popPose();
            }
         }
      }

      float pillar = Easing.smoothstep(6.0F, 12.0F, age) * (1.0F - Easing.smoothstep(launch - 2.0F, launch + 4.0F, age));
      if (pillar > 0.0F) {
         poseStack.pushPose();
         poseStack.translate(0.0F, height * 0.5F, 0.0F);
         GlowDraw.band(glow, poseStack.last().pose(), radius * 0.35F, height * 0.7F + 0.6F, 32, 0.5F, 0.15F, 0.95F, 0.35F * pillar);
         poseStack.popPose();
         shadowWisps(glow, pose, eye, height + 0.9F, age, 0.15F + radius * 0.3F * (1.0F - Easing.smoothstep(10.0F, 22.0F, age)), 0.5F * pillar, true);
      }

      Vector3f soul = new Vector3f(0.0F, soulHeight(height, age), 0.0F);
      if (age >= 8.0F && age < arrive) {
         float gathered = Easing.smoothstep(8.0F, 20.0F, age);
         float size = (0.1F + 0.22F * gathered) * (1.0F + 0.12F * Mth.sin(age * 2.1F));
         if (age >= launch) {
            float t = Easing.smoothstep(0.0F, 1.0F, (age - launch) / (arrive - launch));
            Vector3f chest = killerChest(fx, partialTick, level);
            Vector3f control = new Vector3f(soul).lerp(chest, 0.5F).add(0.0F, 2.0F + soul.distance(chest) * 0.15F, 0.0F);
            Vector3f[] points = new Vector3f[14];
            float tail = Math.max(0.0F, t - 0.3F);

            for (int i = 0; i < points.length; i++) {
               points[i] = bezier(soul, control, chest, Mth.lerp((float)i / (points.length - 1), tail, t));
            }

            GlowDraw.ribbon(glow, pose, points, eye, 0.22F, 0.45F, 0.12F, 0.9F, 0.7F);
            GlowDraw.ribbon(glow, pose, points, eye, 0.07F, 0.85F, 0.7F, 1.0F, 0.95F);
            soul = points[points.length - 1];
         }

         poseStack.pushPose();
         poseStack.translate(soul.x, soul.y, soul.z);
         GlowDraw.glowSphere(
            glow,
            poseStack.last().pose(),
            size * 2.2F,
            (float) (-Math.PI / 2),
            (float) (Math.PI / 2),
            12,
            6,
            0.45F,
            0.12F,
            0.9F,
            (nx, ny, nz) -> 0.35F * gathered
         );
         GlowDraw.glowSphere(
            glow, poseStack.last().pose(), size, (float) (-Math.PI / 2), (float) (Math.PI / 2), 10, 5, 0.9F, 0.75F, 1.0F, (nx, ny, nz) -> 0.9F * gathered
         );
         poseStack.popPose();
      }

      if (age >= arrive) {
         float t = Mth.clamp((age - arrive) / 10.0F, 0.0F, 1.0F);
         Vector3f chest = killerChest(fx, partialTick, level);
         Entity killer = fx.entity() < 0 ? null : level.getEntity(fx.entity());
         float feet = killer == null ? chest.y - 1.1F : chest.y - killer.getBbHeight() * 0.6F;
         poseStack.pushPose();
         poseStack.translate(chest.x, feet, chest.z);
         Matrix4f at = poseStack.last().pose();
         float ring = 0.3F + 1.6F * Easing.outCubic(t);
         float light = 0.7F * (1.0F - t);
         GlowDraw.ring(glow, at, 0.08F, Math.max(0.0F, ring - 0.6F), ring, 32, 0.5F, 0.15F, 0.95F, 0.0F, light);
         GlowDraw.ring(glow, at, 0.08F, ring, ring + 0.2F, 32, 0.75F, 0.5F, 1.0F, light, 0.0F);
         GlowDraw.band(glow, at, ring * 0.8F, 1.2F * (1.0F - t), 32, 0.5F, 0.15F, 0.95F, 0.3F * (1.0F - t));
         poseStack.popPose();
         if (killer != Minecraft.getInstance().getCameraEntity() || !Minecraft.getInstance().options.getCameraType().isFirstPerson()) {
            poseStack.pushPose();
            poseStack.translate(chest.x, chest.y, chest.z);
            GlowDraw.glowSphere(
               glow,
               poseStack.last().pose(),
               0.3F + 0.5F * t,
               (float) (-Math.PI / 2),
               (float) (Math.PI / 2),
               12,
               6,
               0.8F,
               0.6F,
               1.0F,
               (nx, ny, nz) -> 0.6F * (1.0F - t) * (1.0F - t)
            );
            poseStack.popPose();
         }
      }
   }

   private static Vector3f bezier(Vector3f from, Vector3f control, Vector3f to, float s) {
      float u = 1.0F - s;
      return new Vector3f(from).mul(u * u).add(new Vector3f(control).mul(2.0F * u * s)).add(new Vector3f(to).mul(s * s));
   }

   private static void extractionTick(Minecraft minecraft, ClientFx.Active fx, int age) {
      ClientLevel level = minecraft.level;
      RandomSource random = level.random;
      Vec3 at = fx.at();
      float radius = extractRadius(fx.size());
      if (age >= 2 && age <= 12) {
         for (int i = 0; i < 3; i++) {
            double angle = random.nextDouble() * (float) (Math.PI * 2);
            double r = radius * (0.4 + random.nextDouble() * 1.2);
            level.addParticle(new DustParticleOptions(DEEP_VIOLET, 0.9F), at.x + Math.cos(angle) * r, at.y + 0.1, at.z + Math.sin(angle) * r, 0.0, 0.0, 0.0);
            level.addParticle(ParticleTypes.SMOKE, at.x + Math.cos(angle) * r, at.y + 0.05, at.z + Math.sin(angle) * r, 0.0, 0.03, 0.0);
         }
      }

      if (age >= 8 && age < 22) {
         double y = at.y + soulHeight(fx.size(), age);

         for (int i = 0; i < 3; i++) {
            double angle = random.nextDouble() * (float) (Math.PI * 2);
            double dx = Math.cos(angle) * 1.2;
            double dz = Math.sin(angle) * 1.2;
            double dy = (random.nextDouble() - 0.5) * 1.2;
            level.addParticle(ParticleTypes.REVERSE_PORTAL, at.x + dx, y + dy, at.z + dz, -dx * 0.12, -dy * 0.12, -dz * 0.12);
         }
      }

      if (age == 38) {
         Entity killer = fx.entity() < 0 ? null : level.getEntity(fx.entity());
         Vec3 chest = killer == null ? fx.to() : killer.position().add(0.0, killer.getBbHeight() * 0.6, 0.0);

         for (int i = 0; i < 24; i++) {
            double angle = random.nextDouble() * (float) (Math.PI * 2);
            level.addParticle(
               ParticleTypes.REVERSE_PORTAL, chest.x, chest.y + (random.nextDouble() - 0.5), chest.z, Math.cos(angle) * 0.3, 0.05, Math.sin(angle) * 0.3
            );
            level.addParticle(
               new DustParticleOptions(VIOLET, 1.1F),
               chest.x + Math.cos(angle) * 0.6,
               chest.y + (random.nextDouble() - 0.5) * 1.2,
               chest.z + Math.sin(angle) * 0.6,
               0.0,
               0.0,
               0.0
            );
         }

         if (killer != null && killer == minecraft.player) {
            CameraShake.quake(0.8F, 8, 0);
            startVignette(SHADOW);
         }
      }
   }

   private static void shadowWisps(VertexConsumer consumer, Matrix4f pose, Vector3f eye, float height, float age, float radius, float alpha, boolean inward) {
      if (!(alpha <= 0.0F)) {
         for (int wisp = 0; wisp < 5; wisp++) {
            Vector3f[] points = new Vector3f[10];

            for (int k = 0; k < points.length; k++) {
               float along = (float)k / (points.length - 1);
               float angle = wisp * (float) (Math.PI * 2) / 5.0F + age * (inward ? 0.35F : -0.3F) + along * 2.4F;
               float r = radius * (0.7F + 0.3F * along);
               points[k] = new Vector3f(Mth.cos(angle) * r, along * height * 1.1F, Mth.sin(angle) * r);
            }

            GlowDraw.ribbon(consumer, pose, points, eye, 0.12F, 0.45F, 0.12F, 0.8F, alpha);
         }

         GlowDraw.ring(consumer, pose, 0.05F, Math.max(0.0F, radius - 0.5F), radius, 32, 0.4F, 0.1F, 0.7F, 0.0F, alpha * 0.8F);
         GlowDraw.ring(consumer, pose, 0.05F, radius, radius + 0.2F, 32, 0.4F, 0.1F, 0.7F, alpha * 0.8F, 0.0F);
      }
   }

   @SubscribeEvent
   public static void onRenderGui(Pre event) {
      if (vignetteAge >= 0) {
         ClientFx.Vignette kind = vignette;
         float age = vignetteAge + event.getPartialTick().getGameTimeDeltaPartialTick(false);
         float strength = Easing.smoothstep(0.0F, 1.0F, Mth.clamp(age / kind.rise(), 0.0F, 1.0F))
            * (1.0F - Easing.smoothstep(0.0F, 1.0F, Mth.clamp((age - kind.rise() - kind.hold()) / kind.fall(), 0.0F, 1.0F)));
         if (!(strength <= 0.0F)) {
            GuiGraphics graphics = event.getGuiGraphics();
            int width = graphics.guiWidth();
            int height = graphics.guiHeight();
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.enableBlend();
            RenderSystem.blendFuncSeparate(SourceFactor.ZERO, DestFactor.ONE_MINUS_SRC_COLOR, SourceFactor.ONE, DestFactor.ZERO);
            graphics.setColor(kind.lossR() * strength, kind.lossG() * strength, kind.lossB() * strength, 1.0F);
            graphics.blit(VIGNETTE, 0, 0, -90, 0.0F, 0.0F, width, height, width, height);
            graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
         }
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      ACTIVE.clear();
      vignetteAge = -1;
   }

   private record Active(FxPacket.Kind kind, Vec3 at, Vec3 to, float size, long start, long seed, int entity) {
   }

   private record Vignette(float lossR, float lossG, float lossB, int rise, int hold, int fall) {
   }
}
