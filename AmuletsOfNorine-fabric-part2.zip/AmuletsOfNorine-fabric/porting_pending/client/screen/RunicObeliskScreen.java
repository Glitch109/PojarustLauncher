package com.amuletmod.client.screen;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.AbilityOrigin;
import com.amuletmod.amulet.ActiveAbility;
import com.amuletmod.amulet.AmuletItem;
import com.amuletmod.amulet.Fusion;
import com.amuletmod.amulet.FusionChoice;
import com.amuletmod.obelisk.ObeliskRite;
import com.amuletmod.obelisk.RunicObeliskMenu;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public class RunicObeliskScreen extends AbstractContainerScreen<RunicObeliskMenu> {
   private static final ResourceLocation TEXTURE = AmuletMod.id("textures/gui/runic_obelisk.png");
   private static final int[] CHOICE_X = new int[]{36, 52, 68};
   private static final int CHOICE_SIZE = 14;
   private static final int CHOICE_U = 176;
   private static final int CHOICE_V = 0;
   private static final int PLAQUE_X = 89;
   private static final int PLAQUE_WIDTH = 78;
   private static final int BEGIN_X = 12;
   private static final int BEGIN_Y = 101;
   private static final int BEGIN_W = 84;
   private static final int BEGIN_H = 18;
   private static final int BEGIN_U = 0;
   private static final int BEGIN_V = 224;
   private static final int COST_X = 101;
   private static final int COST_Y = 103;
   private static final String[] NUMERALS = new String[]{"I", "II", "III"};
   private static final float SMALL = 0.75F;
   private static final int TITLE_COLOR = 15254855;
   private static final int LABEL_COLOR = 12103392;
   private static final int TEXT_COLOR = 15657210;
   private static final int DIM_COLOR = 9077910;
   private static final int SNEAK_COLOR = 14267482;
   private static final int PICKED_TEXT = 3811848;
   private static final int COST_OK = 8453920;
   private static final int COST_SHORT = 16733525;
   @Nullable
   private Component problem;

   public RunicObeliskScreen(RunicObeliskMenu menu, Inventory inventory, Component title) {
      super(menu, inventory, title);
      this.imageWidth = 176;
      this.imageHeight = 220;
      this.titleLabelY = 8;
      this.inventoryLabelY = 127;
   }

   private List<FusionChoice> choices(int niche) {
      ItemStack stack = ((RunicObeliskMenu)this.menu).inputs().get(niche);
      return stack.getItem() instanceof AmuletItem amulet ? amulet.fusionChoices(stack) : List.of();
   }

   @Nullable
   private Component findProblem() {
      Fusion.Problem problem = Fusion.problem(((RunicObeliskMenu)this.menu).inputs(), ((RunicObeliskMenu)this.menu).picks());
      if (problem != null) {
         return Component.translatable(problem.key);
      } else if (!((RunicObeliskMenu)this.menu).output().isEmpty()) {
         return Component.translatable("gui.amuletmod.obelisk.take_paragon");
      } else {
         Player player = this.minecraft.player;
         int cost = Fusion.cost(((RunicObeliskMenu)this.menu).inputs(), ((RunicObeliskMenu)this.menu).picks()).total();
         if (player != null && !player.getAbilities().instabuild && player.experienceLevel < cost) {
            return Component.translatable("gui.amuletmod.obelisk.levels", new Object[]{cost});
         } else {
            return this.minecraft.level != null && !ObeliskRite.skyClear(this.minecraft.level, ((RunicObeliskMenu)this.menu).pos())
               ? Component.translatable("gui.amuletmod.obelisk.blocked")
               : null;
         }
      }
   }

   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      this.problem = this.findProblem();
      super.render(graphics, mouseX, mouseY, partialTick);
      this.renderTooltip(graphics, mouseX, mouseY);

      for (int niche = 0; niche < 3; niche++) {
         List<FusionChoice> choices = this.choices(niche);

         for (int i = 0; i < choices.size(); i++) {
            if (this.isHovering(CHOICE_X[i], RunicObeliskMenu.NICHE_Y[niche] + 1, 14, 14, mouseX, mouseY)) {
               graphics.renderComponentTooltip(this.font, describe(choices.get(i)), mouseX, mouseY);
            }
         }

         int pick = ((RunicObeliskMenu)this.menu).pick(niche);
         if (pick >= 0 && pick < choices.size() && this.isHovering(87, RunicObeliskMenu.NICHE_Y[niche] - 1, 80, 18, mouseX, mouseY)) {
            graphics.renderComponentTooltip(this.font, describe(choices.get(pick)), mouseX, mouseY);
         }
      }

      if (this.isHovering(99, 101, 46, 18, mouseX, mouseY)) {
         graphics.renderComponentTooltip(this.font, this.costLines(), mouseX, mouseY);
      }

      if (this.isHovering(12, 101, 84, 18, mouseX, mouseY)) {
         List<Component> lines = new ArrayList<>();
         if (this.problem != null) {
            lines.add(this.problem.copy().withStyle(ChatFormatting.RED));
         } else {
            lines.add(Component.translatable("gui.amuletmod.obelisk.begin_hint").withStyle(ChatFormatting.LIGHT_PURPLE));
            lines.add(Component.translatable("gui.amuletmod.obelisk.passives_hint").withStyle(ChatFormatting.GRAY));
            lines.add(
               Component.translatable("gui.amuletmod.obelisk.no_return").withStyle(new ChatFormatting[]{ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC})
            );
         }

         graphics.renderComponentTooltip(this.font, lines, mouseX, mouseY);
      }
   }

   private List<Component> costLines() {
      Fusion.Cost cost = Fusion.cost(((RunicObeliskMenu)this.menu).inputs(), ((RunicObeliskMenu)this.menu).picks());
      List<Component> lines = new ArrayList<>();
      lines.add(Component.translatable("gui.amuletmod.obelisk.levels_cost", new Object[]{cost.total()}).withStyle(ChatFormatting.GREEN));
      lines.add(Component.translatable("gui.amuletmod.obelisk.cost_base", new Object[]{20}).withStyle(ChatFormatting.GRAY));
      lines.add(Component.translatable("gui.amuletmod.obelisk.cost_powers", new Object[]{cost.powers()}).withStyle(ChatFormatting.GRAY));
      lines.add(Component.translatable("gui.amuletmod.obelisk.cost_chains", new Object[]{cost.chains()}).withStyle(ChatFormatting.GRAY));
      if (cost.paragons() > 0) {
         lines.add(Component.translatable("gui.amuletmod.obelisk.cost_paragons", new Object[]{cost.paragons()}).withStyle(ChatFormatting.GRAY));
      }

      return lines;
   }

   private static List<Component> describe(FusionChoice choice) {
      List<Component> lines = new ArrayList<>();
      ability(lines, Component.empty(), choice.ability());
      if (choice.sneak() != null) {
         ability(lines, Component.translatable("gui.amuletmod.obelisk.sneak"), choice.sneak());
      }

      return lines;
   }

   private static void ability(List<Component> lines, Component prefix, AbilityOrigin origin) {
      ActiveAbility ability = origin.ability();
      lines.add(prefix.copy().withStyle(ChatFormatting.GOLD).append(ability.description().copy().withStyle(ChatFormatting.YELLOW)));
      if (ability.cooldownTicks() > 0) {
         lines.add(Component.translatable("tooltip.amuletmod.cooldown", new Object[]{ability.cooldownTicks() / 20}).withStyle(ChatFormatting.DARK_GRAY));
      }
   }

   protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
      int x = this.leftPos;
      int y = this.topPos;
      graphics.blit(TEXTURE, x, y, 0, 0, this.imageWidth, this.imageHeight);

      for (int niche = 0; niche < 3; niche++) {
         int count = this.choices(niche).size();
         int pick = ((RunicObeliskMenu)this.menu).pick(niche);

         for (int i = 0; i < CHOICE_X.length; i++) {
            int bx = CHOICE_X[i];
            int by = RunicObeliskMenu.NICHE_Y[niche] + 1;
            int sprite = i >= count ? 3 : (i == pick ? 2 : (this.isHovering(bx, by, 14, 14, mouseX, mouseY) ? 1 : 0));
            graphics.blit(TEXTURE, x + bx, y + by, 176 + sprite * 14, 0, 14, 14);
         }
      }

      int sprite = this.problem != null ? 2 : (this.isHovering(12, 101, 84, 18, mouseX, mouseY) ? 1 : 0);
      graphics.blit(TEXTURE, x + 12, y + 101, 0 + sprite * 84, 224, 84, 18);
      if (!((RunicObeliskMenu)this.menu).output().isEmpty()) {
         int glow = (int)(70.0 + 60.0 * Math.sin(System.currentTimeMillis() / 220.0));
         graphics.renderOutline(x + 151 - 5, y + 104 - 5, 26, 26, glow << 24 | 13081599);
      }
   }

   protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
      graphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 15254855, false);
      graphics.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY, 12103392, false);

      for (int niche = 0; niche < 3; niche++) {
         List<FusionChoice> choices = this.choices(niche);
         int pick = ((RunicObeliskMenu)this.menu).pick(niche);
         int rowY = RunicObeliskMenu.NICHE_Y[niche];

         for (int i = 0; i < CHOICE_X.length; i++) {
            int color = i >= choices.size() ? 9077910 : (i == pick ? 3811848 : 15657210);
            graphics.drawString(this.font, NUMERALS[i], CHOICE_X[i] + (14 - this.font.width(NUMERALS[i]) + 1) / 2, rowY + 4, color, false);
         }

         if (choices.isEmpty()) {
            this.small(graphics, Component.translatable("gui.amuletmod.obelisk.empty_niche"), 89, rowY + 5, 9077910);
         } else if (pick >= 0 && pick < choices.size()) {
            FusionChoice choice = choices.get(pick);
            this.small(graphics, FusionChoice.name(choice.ability().ability()), 89, rowY + 2, 15657210);
            Component second = (Component)(choice.sneak() != null
               ? Component.translatable("gui.amuletmod.obelisk.sneak").append(FusionChoice.name(choice.sneak().ability()))
               : ((RunicObeliskMenu)this.menu).inputs().get(niche).getHoverName());
            this.small(graphics, second, 89, rowY + 9, choice.sneak() != null ? 14267482 : 9077910);
         }
      }

      Component begin = Component.translatable("gui.amuletmod.obelisk.begin");
      graphics.drawString(this.font, begin, 12 + (84 - this.font.width(begin)) / 2, 106, this.problem != null ? 9077910 : 15657210, true);
      Player player = this.minecraft.player;
      int cost = Fusion.cost(((RunicObeliskMenu)this.menu).inputs(), ((RunicObeliskMenu)this.menu).picks()).total();
      boolean affordable = player == null || player.getAbilities().instabuild || player.experienceLevel >= cost;
      this.small(graphics, Component.translatable("gui.amuletmod.obelisk.cost"), 101, 103, 12103392);
      this.small(graphics, Component.translatable("gui.amuletmod.obelisk.levels_cost", new Object[]{cost}), 101, 111, affordable ? 8453920 : 16733525);
   }

   private void small(GuiGraphics graphics, Component text, int x, int y, int color) {
      int width = 104;
      FormattedCharSequence line = this.font.width(text) > width
         ? FormattedCharSequence.composite(
            (FormattedCharSequence)this.font.split(text, width - this.font.width("...")).get(0), Component.literal("...").getVisualOrderText()
         )
         : text.getVisualOrderText();
      graphics.pose().pushPose();
      graphics.pose().translate(x, y, 0.0F);
      graphics.pose().scale(0.75F, 0.75F, 1.0F);
      graphics.drawString(this.font, line, 0, 0, color, false);
      graphics.pose().popPose();
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (button == 0) {
         for (int niche = 0; niche < 3; niche++) {
            int count = this.choices(niche).size();

            for (int i = 0; i < count; i++) {
               if (this.isHovering(CHOICE_X[i], RunicObeliskMenu.NICHE_Y[niche] + 1, 14, 14, mouseX, mouseY)) {
                  return this.press(niche * 3 + i);
               }
            }
         }

         if (this.problem == null && this.isHovering(12, 101, 84, 18, mouseX, mouseY)) {
            return this.press(9);
         }
      }

      return super.mouseClicked(mouseX, mouseY, button);
   }

   private boolean press(int id) {
      if (this.minecraft.gameMode == null) {
         return false;
      } else {
         this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         this.minecraft.gameMode.handleInventoryButtonClick(((RunicObeliskMenu)this.menu).containerId, id);
         return true;
      }
   }
}
