package com.amuletmod.client.screen;

import com.amuletmod.AmuletMod;
import com.amuletmod.bench.JewelersBenchMenu;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Inventory;

public class JewelersBenchScreen extends AbstractContainerScreen<JewelersBenchMenu> {
   private static final ResourceLocation TEXTURE = AmuletMod.id("textures/gui/jewelers_bench.png");
   public static final int BAR_X = 97;
   public static final int BAR_Y = 38;
   public static final int BAR_W = 36;
   public static final int BAR_H = 10;
   public static final int BAR_U = 176;
   public static final int BAR_V = 0;
   private static final int SPARKLE_X = 34;
   private static final int SPARKLE_Y = 14;
   private static final int SPARKLE_W = 60;
   private static final int SPARKLE_H = 58;
   private static final int SPARKLE_COUNT = 6;
   private static final long SPARKLE_LIFE_MS = 600L;
   private static final int TITLE_COLOR = 15391664;
   private static final int INVENTORY_LABEL_COLOR = 3876374;

   public JewelersBenchScreen(JewelersBenchMenu menu, Inventory inventory, Component title) {
      super(menu, inventory, title);
      this.imageWidth = 176;
      this.imageHeight = 166;
      this.inventoryLabelY = 74;
   }

   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      super.render(graphics, mouseX, mouseY, partialTick);
      this.renderTooltip(graphics, mouseX, mouseY);
      if (((JewelersBenchMenu)this.menu).maxProgress() > 0 && this.isHovering(97, 38, 36, 10, mouseX, mouseY)) {
         graphics.renderTooltip(
            this.font,
            Component.translatable(
               "gui.amuletmod.jewelers_bench.progress", new Object[]{Math.round(((JewelersBenchMenu)this.menu).progressFraction() * 100.0F)}
            ),
            mouseX,
            mouseY
         );
      }
   }

   protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
      graphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 15391664, false);
      graphics.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY, 3876374, false);
   }

   protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
      int x = this.leftPos;
      int y = this.topPos;
      graphics.blit(TEXTURE, x, y, 0, 0, this.imageWidth, this.imageHeight);
      float progress = ((JewelersBenchMenu)this.menu).progressFraction();
      if (!(progress <= 0.0F)) {
         long now = Util.getMillis();
         int filled = Math.max(1, Math.round(36.0F * progress));
         graphics.blit(TEXTURE, x + 97, y + 38, 176, 0, filled, 10);
         int band = (int)(now / 18L % 52L) - 8;
         int bandStart = Math.max(0, band);
         int bandEnd = Math.min(filled, band + 5);
         if (bandEnd > bandStart) {
            graphics.fill(x + 97 + bandStart, y + 38 + 1, x + 97 + bandEnd, y + 38 + 10 - 1, 1442840575);
         }

         graphics.fill(x + 97 + filled - 1, y + 38, x + 97 + filled, y + 38 + 10, -1056964609);
         renderSparkles(graphics, x, y, now);
         int glow = (int)(70.0 + 60.0 * Math.sin(now / 180.0));
         graphics.renderOutline(x + 142 - 6, y + 35 - 6, 28, 28, glow << 24 | 16765803);
      }
   }

   private static void renderSparkles(GuiGraphics graphics, int x, int y, long now) {
      for (int i = 0; i < 6; i++) {
         long t = now + i * 137L;
         float age = (float)(t % 600L) / 600.0F;
         RandomSource random = RandomSource.create(t / 600L * 31L + i);
         int sx = x + 34 + random.nextInt(60);
         int sy = y + 14 + random.nextInt(58);
         int alpha = (int)(255.0 * Math.sin(age * Math.PI));
         int color = alpha << 24 | (random.nextBoolean() ? 16777215 : 16765803);
         graphics.fill(sx, sy, sx + 1, sy + 1, color);
         if (age > 0.25F && age < 0.75F) {
            graphics.fill(sx - 1, sy, sx + 2, sy + 1, color);
            graphics.fill(sx, sy - 1, sx + 1, sy + 2, color);
         }
      }
   }
}
