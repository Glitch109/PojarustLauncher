package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.ClientClock;
import com.amuletmod.client.ObeliskRitePost;
import com.amuletmod.obelisk.ObeliskRite;
import com.amuletmod.obelisk.RunicObeliskBlock;
import com.amuletmod.obelisk.RunicObeliskBlockEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class RunicObeliskRenderer implements BlockEntityRenderer<RunicObeliskBlockEntity> {
   private static final ResourceLocation CIRCLE = AmuletMod.id("textures/misc/fusion_circle.png");
   private static final ResourceLocation RUNES = AmuletMod.id("textures/misc/runic_obelisk_glow.png");
   private static final int[][] RUNE_ROWS = new int[][]{{6, 0}, {12, 0}, {20, 1}, {26, 1}, {34, 2}, {40, 2}};
   private static final int[] SEGMENT_HALF_WIDTH = new int[]{6, 5, 4};
   private static final int GLOW_COLUMNS = 6;
   private static final int GLOW_ROWS = 3;
   private static final int FACES = 3;
   private static final Vector3f HANG = new Vector3f(8.0F, 15.3F, 8.0F);
   private static final Vector3f MIDDLE = new Vector3f(8.0F, 8.5F, 8.0F);
   private static final float NICHE_SCALE = 0.38F;
   private static final float CIRCLE_SIZE = 0.95F;
   private static final float CROWN_SIZE = 1.9F;
   private static final float EYE_RADIUS = 9.0F;
   private static final int EYE_ARMS = 6;
   private static final float[] HALO_RADII = new float[]{4.8F, 6.0F, 7.2F};
   public static final float[][] GEMS = new float[][]{{1.0F, 0.35F, 0.47F}, {0.35F, 0.94F, 0.63F}, {0.3F, 0.48F, 1.0F}};
   public static final float[] PALE = new float[]{0.88F, 0.78F, 1.0F};
   private static final float[] VIOLET = new float[]{0.62F, 0.38F, 1.0F};
   private static final float[] RUNE = new float[]{0.72F, 0.45F, 1.0F};
   private static final float[] WHITE = new float[]{1.0F, 0.97F, 1.0F};
   private final ItemRenderer itemRenderer;

   public RunicObeliskRenderer(Context context) {
      this.itemRenderer = context.getItemRenderer();
   }

   public boolean shouldRenderOffScreen(RunicObeliskBlockEntity obelisk) {
      return obelisk.riteUnderway();
   }

   public int getViewDistance() {
      return 160;
   }

   private static float turn(Direction facing) {
      return 180.0F - facing.toYRot();
   }

   public static Vec3 toWorld(BlockPos base, Direction facing, Vector3f at) {
      Vector3f turned = new Vector3f(at).sub(0.5F, 0.0F, 0.5F).rotateY(turn(facing) * (float) (Math.PI / 180.0)).add(0.5F, 0.0F, 0.5F);
      return new Vec3(base.getX() + turned.x, base.getY() + turned.y, base.getZ() + turned.z);
   }

   private static Vector3f camera(BlockPos base, Direction facing) {
      Vec3 camera = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
      return new Vector3f((float)(camera.x - base.getX()) - 0.5F, (float)(camera.y - base.getY()), (float)(camera.z - base.getZ()) - 0.5F)
         .rotateY(-turn(facing) * (float) (Math.PI / 180.0))
         .add(0.5F, 0.0F, 0.5F);
   }

   public static Vector3f peg(int niche) {
      float[] peg = ObeliskRite.PEGS[niche];
      return new Vector3f(peg[0] / 16.0F, peg[1] / 16.0F, peg[2] / 16.0F);
   }

   public static Vector3f core() {
      return new Vector3f(0.5F, 4.6625F, 0.5F);
   }

   public static Vector3f flight(int niche, float t) {
      Vector3f start = peg(niche).add(0.0F, -0.22F, 0.0F);
      float out = Easing.outCubic(Mth.clamp((t - 262.0F) / 30.0F, 0.0F, 1.0F));
      Vector3f p = start.add(0.0F, 0.12F * out, -0.55F * out);
      float launch = 292.0F;
      if (t <= launch) {
         return p;
      } else {
         float u = Mth.clamp((t - launch) / (420.0F - launch), 0.0F, 1.0F);
         float dx = p.x - 0.5F;
         float dz = p.z - 0.5F;
         float r0 = Mth.sqrt(dx * dx + dz * dz);
         float a0 = (float)Mth.atan2(dz, dx);
         float r = (r0 + (1.7F - r0) * Easing.smoothstep(0.0F, 0.25F, u)) * (1.0F - Easing.smoothstep(0.35F, 1.0F, u));
         float a = a0 + niche * (float) (Math.PI * 2) / 3.0F * Easing.smoothstep(0.0F, 0.3F, u) + (float) (Math.PI * 3) * (float)Math.pow(u, 1.6);
         float h = Mth.lerp(Easing.smoothstep(0.1F, 1.0F, u), p.y, 4.6625F);
         return new Vector3f(0.5F + r * Mth.cos(a), h, 0.5F + r * Mth.sin(a));
      }
   }

   public static Vector3f circleCenter(int k, float t) {
      float angle = (k * 60.0F + 0.35F * t + 0.0045F * t * t) * (float) (Math.PI / 180.0);
      float implode = ObeliskRite.implode(t);
      float radius = 4.2F * (1.0F - 0.18F * Easing.smoothstep(262.0F, 420.0F, t)) * (1.0F - 0.7F * implode);
      return new Vector3f(0.5F + radius * Mth.cos(angle), 1.9F + 0.15F * Mth.sin(t * 0.06F + k * 1.1F) + 1.2F * implode, 0.5F + radius * Mth.sin(angle));
   }

   public AABB getRenderBoundingBox(RunicObeliskBlockEntity obelisk) {
      return obelisk.renderBounds();
   }

   public void render(RunicObeliskBlockEntity obelisk, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight, int packedOverlay) {
      Level level = obelisk.getLevel();
      if (level != null) {
         Direction facing = (Direction)obelisk.getBlockState().getValue(RunicObeliskBlock.FACING);
         float t = obelisk.riteAge(partialTick);
         float time = ClientClock.time(partialTick);
         poseStack.pushPose();
         poseStack.translate(0.5F, 0.0F, 0.5F);
         poseStack.mulPose(Axis.YP.rotationDegrees(turn(facing)));
         poseStack.translate(-0.5F, 0.0F, -0.5F);
         Vector3f camera = camera(obelisk.getBlockPos(), facing);
         this.amulets(obelisk, level, t, poseStack, buffers, packedLight, camera);
         runes(obelisk, t, time, poseStack);
         if (t >= 0.0F) {
            if (!ObeliskRitePost.available()) {
               sigil(t, poseStack);
            }

            circles(t, poseStack, camera);
            eye(t, poseStack, camera);
            halos(t, poseStack, camera);
            pillars(t, poseStack, camera);
            beam(t, poseStack, camera);
            column(t, poseStack, camera);
            core(t, poseStack, facing, camera);
         }

         poseStack.popPose();
      }
   }

   private void amulets(RunicObeliskBlockEntity obelisk, Level level, float t, PoseStack poseStack, MultiBufferSource buffers, int light, Vector3f camera) {
      boolean rite = t >= 0.0F;

      for (int niche = 0; niche < 3; niche++) {
         ItemStack stack = obelisk.displayed(niche);
         if (!stack.isEmpty() && (!rite || !(t >= 420.0F))) {
            if (rite && !(t < 262.0F)) {
               float launch = 292.0F;
               float u = Mth.clamp((t - launch) / (420.0F - launch), 0.0F, 1.0F);
               float scale = u < 0.3F ? Mth.lerp(u / 0.3F, 0.38F, 0.55F) : Mth.lerp((u - 0.3F) / 0.7F, 0.55F, 0.28F);
               float spin = t <= launch ? 0.0F : 792.0F * (float)Math.pow(u, 1.5);
               this.item(poseStack, buffers, level, stack, flight(niche, t), MIDDLE, spin, scale, light);
               if (t > launch) {
                  trail(niche, t, launch, poseStack, camera);
               }
            } else {
               this.item(poseStack, buffers, level, stack, peg(niche), HANG, 0.0F, 0.38F, light);
            }
         }
      }

      if (rite && t > 368.8F && t < 420.0F) {
         arcs(t, poseStack, camera);
      }

      ItemStack paragon = obelisk.displayed(3);
      if (!paragon.isEmpty()) {
         Vector3f rest = peg(1);
         if (!obelisk.displayed(1).isEmpty() && !rite) {
            rest.add(0.0F, 0.0F, -0.4F);
         }

         if (!rite || t >= 516.0F) {
            this.item(poseStack, buffers, level, paragon, rest, HANG, 0.0F, 0.38F, light);
         } else if (!(t < 450.0F)) {
            float appear = Easing.outBack(Mth.clamp((t - 450.0F) / 10.0F, 0.0F, 1.0F));
            float settle = Easing.smoothstep(472.0F, 516.0F, t);
            Vector3f born = core().add(0.0F, 0.25F, 0.0F);
            Vector3f at = born.lerp(rest, settle);
            float spin = (t - 450.0F) * 5.0F * (1.0F - settle);
            this.item(poseStack, buffers, level, paragon, at, HANG, spin, Mth.lerp(settle, 0.55F * appear, 0.38F), light);
         }
      }
   }

   private void item(
      PoseStack poseStack, MultiBufferSource buffers, Level level, ItemStack stack, Vector3f at, Vector3f anchor, float spin, float scale, int light
   ) {
      if (!(scale <= 0.001F)) {
         poseStack.pushPose();
         poseStack.translate(at.x, at.y, at.z);
         poseStack.mulPose(Axis.YP.rotationDegrees(180.0F + spin));
         poseStack.scale(scale, scale, scale);
         poseStack.translate(0.5F - anchor.x / 16.0F, 0.5F - anchor.y / 16.0F, 0.5F - anchor.z / 16.0F);
         this.itemRenderer
            .render(
               stack, ItemDisplayContext.NONE, false, poseStack, buffers, light, OverlayTexture.NO_OVERLAY, this.itemRenderer.getModel(stack, level, null, 0)
            );
         poseStack.popPose();
      }
   }

   private static void trail(int niche, float t, float launch, PoseStack poseStack, Vector3f camera) {
      float[] gem = GEMS[niche];
      Vector3f[] points = new Vector3f[18];

      for (int j = 0; j < points.length; j++) {
         points[j] = flight(niche, Math.max(launch, t - j * 1.3F));
      }

      float alpha = 0.75F * Easing.smoothstep(launch, launch + 20.0F, t);
      GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
         GlowDraw.taperedRibbon(consumer, pose, points, camera, 0.2F, gem[0], gem[1], gem[2], alpha);
         GlowDraw.taperedRibbon(consumer, pose, points, camera, 0.05F, WHITE[0], WHITE[1], WHITE[2], alpha);
      });
   }

   private static void arcs(float t, PoseStack poseStack, Vector3f camera) {
      float strength = Easing.smoothstep(0.6F, 1.0F, (t - 262.0F - 30.0F) / 128.0F);
      List<Vector3f[]> bolts = new ArrayList<>();

      for (int k = 0; k < 3; k++) {
         bolts.add(jagged(flight(k, t), flight((k + 1) % 3, t), 7, 0.12F, (int)(t / 2.0F) * 7 + k));
      }

      GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
         for (Vector3f[] bolt : bolts) {
            GlowDraw.ribbon(consumer, pose, bolt, camera, 0.05F, PALE[0], PALE[1], PALE[2], 0.8F * strength);
         }
      });
   }

   private static void runes(RunicObeliskBlockEntity obelisk, float t, float time, PoseStack poseStack) {
      boolean waiting = !obelisk.displayed(0).isEmpty() || !obelisk.displayed(1).isEmpty() || !obelisk.displayed(2).isEmpty();
      boolean paragon = !obelisk.displayed(3).isEmpty();
      if (!(t < 0.0F) || waiting || paragon) {
         float[] levels = new float[RUNE_ROWS.length];
         boolean any = false;

         for (int row = 0; row < RUNE_ROWS.length; row++) {
            levels[row] = runeLevel(t, row, time, waiting);
            any |= levels[row] > 0.01F;
         }

         if (any) {
            GlowBatch.add(ModRenderTypes.glowTextured(RUNES), poseStack, (consumer, pose, normal) -> {
               for (int face = 0; face < 3; face++) {
                  for (int rowx = 0; rowx < RUNE_ROWS.length; rowx++) {
                     glyph(consumer, pose, normal, face, rowx, levels[rowx]);
                  }
               }
            });
         }
      }
   }

   private static float runeLevel(float t, int row, float time, boolean waiting) {
      if (t < 0.0F) {
         return (waiting ? 0.16F : 0.1F) * (0.7F + 0.3F * Mth.sin(time * 0.05F + row * 0.7F));
      } else {
         int fromTop = RUNE_ROWS.length - 1 - row;
         float lit = t - (ObeliskRite.strikes() + fromTop * 3);
         if (lit < 0.0F) {
            float flicker = 0.6F + 0.4F * Mth.sin(t * 0.9F + row * 2.3F) * Mth.sin(t * 0.37F + row);
            return (0.1F + 0.2F * Easing.smoothstep(0.0F, ObeliskRite.strikes(), t)) * flicker;
         } else {
            float ignite = Math.max(0.0F, 1.0F - lit / 8.0F) * 0.9F;
            float wave = Math.max(0.0F, Mth.sin(t * 0.22F - row * 0.9F));
            float drained = Easing.smoothstep(420.0F + row * 3.0F, 444.0F + row, t) * (t < 450.0F ? 0.75F : 0.0F);
            float level = (0.8F + 0.25F * wave + 0.35F * ObeliskRite.charge(t) + ignite) * (1.0F - drained);
            if (t >= 450.0F) {
               float flash = Math.max(0.0F, 1.0F - (t - 450.0F) / 6.0F) * 1.2F;
               level = Mth.lerp(Easing.smoothstep(450.0F, 540.0F, t), level + flash, 0.14F);
            }

            return level;
         }
      }
   }

   private static void glyph(VertexConsumer consumer, Matrix4f pose, Pose normal, int face, int row, float level) {
      int glyph = face * RUNE_ROWS.length + row;
      float u0 = glyph % 6 / 6.0F;
      float u1 = u0 + 0.16666667F;
      float v0 = glyph / 6 / 3.0F;
      float v1 = v0 + 0.33333334F;
      float white = Mth.clamp((level - 1.0F) * 0.5F, 0.0F, 1.0F);
      float r = Mth.lerp(white, RUNE[0], 1.0F) * level;
      float g = Mth.lerp(white, RUNE[1], 1.0F) * level;
      float b = Mth.lerp(white, RUNE[2], 1.0F) * level;
      float plane = (8 + SEGMENT_HALF_WIDTH[RUNE_ROWS[row][1]] + 0.03F) / 16.0F;
      float top = (RUNE_ROWS[row][0] + 5) / 16.0F;
      float bottom = (RUNE_ROWS[row][0] - 1) / 16.0F;
      float near = 0.3125F;
      float far = 0.6875F;

      float[][] corners = switch (face) {
         case 0 -> new float[][]{{plane, top, far}, {plane, top, near}, {plane, bottom, near}, {plane, bottom, far}};
         case 1 -> new float[][]{{near, top, plane}, {far, top, plane}, {far, bottom, plane}, {near, bottom, plane}};
         default -> new float[][]{{1.0F - plane, top, near}, {1.0F - plane, top, far}, {1.0F - plane, bottom, far}, {1.0F - plane, bottom, near}};
      };
      float[][] uv = new float[][]{{u0, v0}, {u1, v0}, {u1, v1}, {u0, v1}};

      for (int i = 0; i < 4; i++) {
         GlowDraw.texVertex(consumer, pose, normal, corners[i][0], corners[i][1], corners[i][2], r, g, b, uv[i][0], uv[i][1]);
      }
   }

   private static void circles(float t, PoseStack poseStack, Vector3f camera) {
      float charge = ObeliskRite.charge(t);
      float burst = Mth.clamp((t - 450.0F) / 12.0F, 0.0F, 1.0F);
      if (!(burst >= 1.0F)) {
         float flare = t >= 450.0F ? 1.0F - burst : 0.0F;
         float implode = ObeliskRite.implode(t);
         float tint = Easing.smoothstep(ObeliskRite.strikes(), ObeliskRite.strikes() + 30.0F, t);
         float pale = 0.7F * ObeliskRite.merge(t);
         List<RunicObeliskRenderer.Disc> discs = new ArrayList<>();
         List<Vector3f[]> tendrils = new ArrayList<>();
         Vector3f heart = new Vector3f(0.5F, 2.8F, 0.5F);

         for (int k = 0; k < 6; k++) {
            float open = (t - ObeliskRite.circleOpens(k)) / 10.0F;
            if (!(open <= 0.0F)) {
               float size = 0.95F * Easing.outBack(Math.min(1.0F, open)) * (1.0F + 0.8F * burst) * (1.0F - 0.55F * implode);
               Vector3f at = circleCenter(k, t);
               Vector3f facing = new Vector3f(heart).sub(at).normalize();
               float spin = (k % 2 == 0 ? 1.0F : -1.0F) * t * (2.5F + 0.02F * t) * (float) (Math.PI / 180.0);
               float light = (0.7F + 0.15F * Mth.sin(t * 0.3F + k)) * (0.6F + 0.4F * charge) * (1.0F - burst) + flare;
               float[] gem = GEMS[k % 3];
               float[] hue = new float[3];

               for (int c = 0; c < 3; c++) {
                  hue[c] = Mth.lerp(pale, Mth.lerp(tint, VIOLET[c], gem[c]), PALE[c]);
               }

               addDisc(discs, at, facing, size, spin, light, hue, flare);
               if (t >= ObeliskRite.strikes() && t < 420.0F) {
                  tendrils.add(jagged(at, new Vector3f(0.5F, at.y + 0.2F, 0.5F), 8, 0.25F, (int)(t / 2.0F) * 13 + k));
               }
            }
         }

         float crownOpen = (t - 112.0F) / 14.0F;
         if (crownOpen > 0.0F) {
            float size = 1.9F * Easing.outBack(Math.min(1.0F, crownOpen)) * (1.0F + 0.6F * burst) * (1.0F - 0.6F * implode);
            float light = (0.8F + 0.2F * Mth.sin(t * 0.2F)) * (0.7F + 0.5F * charge) * (1.0F - burst) + flare;
            float[] hue = new float[]{Mth.lerp(charge, VIOLET[0], PALE[0]), Mth.lerp(charge, VIOLET[1], PALE[1]), Mth.lerp(charge, VIOLET[2], PALE[2])};
            addDisc(discs, new Vector3f(0.5F, 5.7625F, 0.5F), new Vector3f(0.0F, -1.0F, 0.0F), size, t * 1.2F * (float) (Math.PI / 180.0), light, hue, flare);
         }

         if (!discs.isEmpty()) {
            GlowBatch.add(ModRenderTypes.skyGlow(CIRCLE), poseStack, (consumer, pose, normal) -> {
               for (RunicObeliskRenderer.Disc cx : discs) {
                  GlowDraw.disc(consumer, pose, cx.at(), cx.facing(), cx.size() * 1.3F, -cx.spin() * 0.3F, cx.r() * 0.3F, cx.g() * 0.3F, cx.b() * 0.3F);
                  GlowDraw.disc(consumer, pose, cx.at(), cx.facing(), cx.size(), cx.spin(), cx.r(), cx.g(), cx.b());
                  Vector3f inner = new Vector3f(cx.facing()).mul(0.03F).add(cx.at());
                  GlowDraw.disc(consumer, pose, inner, cx.facing(), cx.size() * 0.5F, -cx.spin() * 1.8F, cx.r() * 0.85F, cx.g() * 0.85F, cx.b() * 0.85F);
               }
            });
            float pulse = 0.45F + 0.25F * Mth.sin(t * 0.5F);
            GlowBatch.add(
               ModRenderTypes.GLOW,
               poseStack,
               (consumer, pose, normal) -> {
                  for (RunicObeliskRenderer.Disc cx : discs) {
                     GlowDraw.glowSphere(
                        consumer,
                        new Matrix4f(pose).translate(cx.at()),
                        0.18F + 0.12F * charge,
                        (float) (-Math.PI / 2),
                        (float) (Math.PI / 2),
                        10,
                        5,
                        PALE[0],
                        PALE[1],
                        PALE[2],
                        (nx, ny, nz) -> 0.35F * Math.min(1.0F, cx.r())
                     );
                  }

                  for (Vector3f[] tendril : tendrils) {
                     GlowDraw.ribbon(consumer, pose, tendril, camera, 0.035F, PALE[0], PALE[1], PALE[2], pulse);
                  }
               }
            );
         }
      }
   }

   private static void addDisc(
      List<RunicObeliskRenderer.Disc> discs, Vector3f at, Vector3f facing, float size, float spin, float light, float[] hue, float flare
   ) {
      float r = Mth.lerp(flare, hue[0], 1.0F) * light;
      float g = Mth.lerp(flare, hue[1], 1.0F) * light;
      float b = Mth.lerp(flare, hue[2], 1.0F) * light;
      discs.add(new RunicObeliskRenderer.Disc(at, facing, size, spin, r, g, b));
   }

   private static void sigil(float t, PoseStack poseStack) {
      float drawn = ObeliskRite.sigil(t) / 6.0F;
      float after = Easing.smoothstep(450.0F, 530.0F, t);
      if (!(drawn <= 0.001F) && !(after >= 1.0F)) {
         float charge = ObeliskRite.charge(t);
         float flare = Math.max(0.0F, 1.0F - Math.abs(t - 450.0F) / 10.0F) * (t >= 450.0F ? 1.0F : 0.0F);
         float light = (drawn * (0.55F + 0.45F * charge) * (1.0F - 0.5F * ObeliskRite.implode(t)) + 1.5F * flare) * (1.0F - after);
         float size = 9.0F * (0.35F + 0.65F * Easing.outCubic(drawn));
         float r = Mth.lerp(charge, VIOLET[0], PALE[0]) * light;
         float g = Mth.lerp(charge, VIOLET[1], PALE[1]) * light;
         float b = Mth.lerp(charge, VIOLET[2], PALE[2]) * light;
         Vector3f at = new Vector3f(0.5F, 0.04F, 0.5F);
         Vector3f up = new Vector3f(0.0F, 1.0F, 0.0F);
         GlowBatch.add(ModRenderTypes.skyGlow(CIRCLE), poseStack, (consumer, pose, normal) -> {
            GlowDraw.disc(consumer, pose, at, up, size, t * 0.4F * (float) (Math.PI / 180.0), r, g, b);
            GlowDraw.disc(consumer, pose, at, up, size * 0.45F, -t * 0.9F * (float) (Math.PI / 180.0), r, g, b);
         });
      }
   }

   private static void eye(float t, PoseStack poseStack, Vector3f camera) {
      if (!(t < 140.0F) && !(t >= 450.0F)) {
         float since = t - 140.0F;
         float open = Easing.outCubic(since / 32.0F);
         float implode = ObeliskRite.implode(t);
         float scale = open * (1.0F - implode);
         if (!(scale <= 0.01F)) {
            float charge = ObeliskRite.charge(t);
            float spin = since * 0.025F + since * since * 8.0E-5F + implode * 6.0F;
            float light = (0.7F + 0.5F * charge) * (0.85F + 0.15F * Mth.sin(t * 0.4F));
            List<Vector3f[]> arms = new ArrayList<>();

            for (int arm = 0; arm < 6; arm++) {
               Vector3f[] points = new Vector3f[26];

               for (int j = 0; j < points.length; j++) {
                  float s = j / (points.length - 1.0F);
                  float r = 9.0F * scale * (0.08F + 0.92F * s);
                  float a = spin * (1.0F + 1.5F * (1.0F - s)) + arm * (float) (Math.PI * 2) / 6.0F + 2.8F * s;
                  points[j] = new Vector3f(0.5F + r * Mth.cos(a), 16.5625F + 0.3F * s * Mth.sin(s * 6.0F + t * 0.1F + arm), 0.5F + r * Mth.sin(a));
               }

               arms.add(points);
            }

            GlowBatch.add(
               ModRenderTypes.GLOW,
               poseStack,
               (consumer, pose, normal) -> {
                  for (int armx = 0; armx < arms.size(); armx++) {
                     float[] gem = GEMS[armx % 3];
                     GlowDraw.taperedRibbon(consumer, pose, arms.get(armx), camera, 0.9F * scale, gem[0], gem[1], gem[2], 0.5F * light);
                     GlowDraw.taperedRibbon(consumer, pose, arms.get(armx), camera, 0.2F * scale, WHITE[0], WHITE[1], WHITE[2], 0.7F * light);
                  }

                  Matrix4f centred = new Matrix4f(pose).translate(0.5F, 0.0F, 0.5F);
                  GlowDraw.ring(consumer, centred, 16.5125F, 0.0F, 10.8F * scale, 48, VIOLET[0], VIOLET[1], VIOLET[2], 0.25F * light, 0.0F);
                  GlowDraw.ring(consumer, centred, 16.5625F, 1.3F * scale, 1.9F * scale, 32, WHITE[0], WHITE[1], WHITE[2], 0.0F, 0.8F * light);
                  GlowDraw.ring(consumer, centred, 16.5625F, 1.9F * scale, 2.6F * scale, 32, PALE[0], PALE[1], PALE[2], 0.8F * light, 0.0F);
                  Matrix4f middle = new Matrix4f(pose).translate(0.5F, 16.5625F, 0.5F);
                  GlowDraw.glowSphere(
                     consumer,
                     middle,
                     (0.5F + 0.4F * charge) * scale,
                     (float) (-Math.PI / 2),
                     (float) (Math.PI / 2),
                     12,
                     6,
                     WHITE[0],
                     WHITE[1],
                     WHITE[2],
                     (nx, ny, nz) -> 0.85F
                  );
               }
            );
         }
      }
   }

   private static void halos(float t, PoseStack poseStack, Vector3f camera) {
      if (!(t < 148.0F) && !(t >= 450.0F)) {
         float merge = ObeliskRite.merge(t);
         float implode = ObeliskRite.implode(t);
         float charge = ObeliskRite.charge(t);
         float flash = Math.max(0.0F, 1.0F - Math.abs(t - 420.0F) / 8.0F);
         List<Vector3f[]> rings = new ArrayList<>();
         List<Vector3f[]> beads = new ArrayList<>();
         List<float[]> colours = new ArrayList<>();

         for (int h = 0; h < 3; h++) {
            float open = (t - ObeliskRite.haloOpens(h)) / 16.0F;
            if (!(open <= 0.0F)) {
               float radius = Mth.lerp(merge, HALO_RADII[h], 6.0F) * Easing.outBack(Math.min(1.0F, open)) * (1.0F - implode);
               if (!(radius < 0.05F)) {
                  float tilt = (0.45F + 0.2F * h) * (1.0F - merge);
                  float lean = h * (float) (Math.PI * 2) / 3.0F + t * 0.012F * (h + 1);
                  float spin = (h % 2 == 0 ? 1.0F : -1.0F) * t * (0.03F + 0.015F * h) * (1.0F + 2.0F * charge);
                  Vector3f centre = new Vector3f(0.5F, 10.0625F + 0.5F * Mth.sin(t * 0.05F + h * 2.0F) * (1.0F - merge), 0.5F);
                  Vector3f axis = new Vector3f(Mth.sin(tilt) * Mth.cos(lean), Mth.cos(tilt), Mth.sin(tilt) * Mth.sin(lean));
                  Vector3f u = new Vector3f(axis).cross(0.0F, 0.0F, 1.0F);
                  if (u.lengthSquared() < 1.0E-4F) {
                     u.set(1.0F, 0.0F, 0.0F);
                  }

                  u.normalize();
                  Vector3f v = new Vector3f(axis).cross(u).normalize();
                  Vector3f[] ring = new Vector3f[65];

                  for (int i = 0; i < ring.length; i++) {
                     ring[i] = onRing(centre, u, v, radius, i / (ring.length - 1.0F) * (float) (Math.PI * 2));
                  }

                  rings.add(ring);

                  for (int bead = 0; bead < 6; bead++) {
                     Vector3f[] arc = new Vector3f[4];

                     for (int i = 0; i < arc.length; i++) {
                        arc[i] = onRing(centre, u, v, radius, spin + bead * (float) (Math.PI * 2) / 6.0F + (i - 1.5F) * 0.05F);
                     }

                     beads.add(arc);
                  }

                  float[] gem = GEMS[h];
                  float light = Math.min(1.0F, open) * (0.75F + 0.25F * Mth.sin(t * 0.3F + h)) + flash;
                  colours.add(
                     new float[]{
                        Mth.lerp(merge * 0.8F, gem[0], PALE[0]) * light,
                        Mth.lerp(merge * 0.8F, gem[1], PALE[1]) * light,
                        Mth.lerp(merge * 0.8F, gem[2], PALE[2]) * light
                     }
                  );
               }
            }
         }

         if (!rings.isEmpty()) {
            GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
               for (int ix = 0; ix < rings.size(); ix++) {
                  float[] c = colours.get(ix);
                  GlowDraw.ribbon(consumer, pose, rings.get(ix), camera, 0.09F, c[0], c[1], c[2], 0.9F);
                  GlowDraw.ribbon(consumer, pose, rings.get(ix), camera, 0.4F, c[0], c[1], c[2], 0.2F);

                  for (int bead = 0; bead < 6; bead++) {
                     GlowDraw.ribbon(consumer, pose, beads.get(ix * 6 + bead), camera, 0.18F, WHITE[0], WHITE[1], WHITE[2], 0.9F);
                  }
               }
            });
         }
      }
   }

   private static Vector3f onRing(Vector3f centre, Vector3f u, Vector3f v, float radius, float angle) {
      return new Vector3f(u).mul(radius * Mth.cos(angle)).add(new Vector3f(v).mul(radius * Mth.sin(angle))).add(centre);
   }

   private static void pillars(float t, PoseStack poseStack, Vector3f camera) {
      if (!(t < ObeliskRite.strikes()) && !(t >= 450.0F)) {
         float fade = 1.0F - 0.85F * ObeliskRite.implode(t);
         float pale = 0.6F * ObeliskRite.merge(t);
         List<Vector3f[]> beams = new ArrayList<>();
         List<float[]> colours = new ArrayList<>();

         for (int k = 0; k < 6; k++) {
            float rise = (t - ObeliskRite.pillarRises(k)) / 10.0F;
            if (!(rise <= 0.0F)) {
               Vector3f foot = circleCenter(k, t);
               float angle = (float)Mth.atan2(foot.z - 0.5F, foot.x - 0.5F);
               Vector3f top = new Vector3f(0.5F + 2.2F * Mth.cos(angle), 16.5625F, 0.5F + 2.2F * Mth.sin(angle));
               Vector3f end = new Vector3f(foot).lerp(top, Easing.outCubic(Math.min(1.0F, rise)));
               Vector3f[] points = new Vector3f[10];

               for (int i = 0; i < points.length; i++) {
                  points[i] = new Vector3f(foot).lerp(end, i / (points.length - 1.0F));
               }

               beams.add(points);
               float[] gem = GEMS[k % 3];
               float light = (0.8F + 0.2F * Mth.sin(t * 0.9F + k * 1.7F)) * fade;
               colours.add(new float[]{Mth.lerp(pale, gem[0], PALE[0]), Mth.lerp(pale, gem[1], PALE[1]), Mth.lerp(pale, gem[2], PALE[2]), light});
            }
         }

         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            for (int i = 0; i < beams.size(); i++) {
               float[] c = colours.get(i);
               GlowDraw.ribbon(consumer, pose, beams.get(i), camera, 0.07F, WHITE[0], WHITE[1], WHITE[2], 0.8F * c[3]);
               GlowDraw.ribbon(consumer, pose, beams.get(i), camera, 0.32F, c[0], c[1], c[2], 0.32F * c[3]);
            }
         });
      }
   }

   private static void beam(float t, PoseStack poseStack, Vector3f camera) {
      if (!(t < 190.0F) && !(t >= 450.0F)) {
         float fall = Mth.clamp((t - 190.0F) / 5.0F, 0.0F, 1.0F);
         Vector3f from = new Vector3f(0.5F, 16.5625F, 0.5F);
         Vector3f to = new Vector3f(0.5F, Mth.lerp(fall, 16.5625F, 3.5625F), 0.5F);
         float charge = ObeliskRite.charge(t);
         float thin = t >= 420.0F ? (0.3F + 0.15F * Mth.sin(t * 2.3F)) * (1.0F - 0.6F * ObeliskRite.implode(t)) : 1.0F;
         float pulse = (1.0F + 0.12F * Mth.sin(t * 0.7F) + 0.06F * Mth.sin(t * 1.9F)) * thin * (0.85F + 0.35F * charge);
         float strike = Mth.clamp((t - ObeliskRite.strikes()) / 10.0F, 0.0F, 1.0F);
         List<Vector3f[]> helices = new ArrayList<>();
         if (fall >= 1.0F) {
            for (int h = 0; h < 3; h++) {
               Vector3f[] points = new Vector3f[40];

               for (int i = 0; i < points.length; i++) {
                  float v = i / (points.length - 1.0F);
                  float a = h * (float) (Math.PI * 2) / 3.0F + v * 14.0F - t * (0.35F + 0.3F * charge);
                  float radius = 0.38F * thin;
                  points[i] = new Vector3f(0.5F + radius * Mth.cos(a), Mth.lerp(v, 16.5625F, 3.5625F), 0.5F + radius * Mth.sin(a));
               }

               helices.add(points);
            }
         }

         GlowBatch.add(
            ModRenderTypes.GLOW,
            poseStack,
            (consumer, pose, normal) -> {
               GlowDraw.beam(consumer, pose, from, to, camera, 1.0F * pulse, 12, VIOLET[0], VIOLET[1], VIOLET[2], 0.14F);
               GlowDraw.beam(consumer, pose, from, to, camera, 0.45F * pulse, 12, PALE[0], PALE[1], PALE[2], 0.4F);
               GlowDraw.beam(consumer, pose, from, to, camera, 0.14F * pulse, 12, 1.0F, 1.0F, 1.0F, 0.95F);

               for (int hx = 0; hx < helices.size(); hx++) {
                  GlowDraw.ribbon(consumer, pose, helices.get(hx), camera, 0.07F, GEMS[hx][0], GEMS[hx][1], GEMS[hx][2], 0.6F * thin);
               }

               if (fall >= 1.0F) {
                  Matrix4f tip = new Matrix4f(pose).translate(0.5F, 3.5625F, 0.5F);
                  GlowDraw.glowSphere(
                     consumer,
                     tip,
                     0.3F + 0.06F * Mth.sin(t * 1.3F),
                     (float) (-Math.PI / 2),
                     (float) (Math.PI / 2),
                     12,
                     6,
                     1.0F,
                     0.9F,
                     1.0F,
                     (nx, ny, nz) -> 0.55F * thin
                  );
                  if (strike < 1.0F) {
                     GlowDraw.glowSphere(
                        consumer,
                        tip,
                        0.3F + 2.4F * Easing.outCubic(strike),
                        (float) (-Math.PI / 2),
                        (float) (Math.PI / 2),
                        16,
                        8,
                        PALE[0],
                        PALE[1],
                        PALE[2],
                        (nx, ny, nz) -> 0.9F * (1.0F - strike)
                     );
                  }
               }
            }
         );
      }
   }

   private static void column(float t, PoseStack poseStack, Vector3f camera) {
      float since = t - 450.0F;
      if (!(since < 0.0F) && !(since > 44.0F)) {
         float fade = 1.0F - Easing.smoothstep(6.0F, 44.0F, since);
         float width = 2.6F * Easing.outBack(since / 5.0F) * (0.35F + 0.65F * fade) * (1.0F + 0.05F * Mth.sin(t * 2.1F));
         float top = 24.6625F + 100.0F * Easing.outCubic(since / 8.0F);
         Vector3f from = new Vector3f(0.5F, 4.6625F, 0.5F);
         Vector3f to = new Vector3f(0.5F, top, 0.5F);
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            GlowDraw.beam(consumer, pose, from, to, camera, width * 0.4F, 30, WHITE[0], WHITE[1], WHITE[2], fade);
            GlowDraw.beam(consumer, pose, from, to, camera, width, 30, PALE[0], PALE[1], PALE[2], 0.6F * fade);
            GlowDraw.beam(consumer, pose, from, to, camera, width * 2.2F, 30, VIOLET[0], VIOLET[1], VIOLET[2], 0.2F * fade);
         });
      }
   }

   private static void core(float t, PoseStack poseStack, Direction facing, Vector3f camera) {
      if (!(t < 380.0F) && !(t > 500.0F)) {
         float grow = Easing.smoothstep(380.0F, 420.0F, t);
         float flash = Math.max(0.0F, 1.0F - Math.abs(t - 420.0F) / 6.0F);
         float implode = Easing.smoothstep(420.0F, 448.0F, t);
         float radius = t < 450.0F ? (0.12F + 0.4F * grow) * (1.0F - 0.8F * implode) + 0.9F * flash : 0.0F;
         float birth = t >= 450.0F ? t - 450.0F : -1.0F;
         Camera view = Minecraft.getInstance().gameRenderer.getMainCamera();
         List<Vector3f[]> streaks = new ArrayList<>();
         if (t > 420.0F && t < 450.0F) {
            for (int i = 0; i < 24; i++) {
               float u = (t * 0.06F + hash(i * 41 + 7)) % 1.0F;
               Vector3f out = new Vector3f(hash(i * 13 + 1) - 0.5F, (hash(i * 29 + 5) - 0.5F) * 0.7F, hash(i * 7 + 3) - 0.5F).normalize();
               float far = 9.0F * (1.0F - u) * (1.0F - u);
               float near = Math.max(0.0F, far - 1.5F - 2.0F * implode);
               streaks.add(new Vector3f[]{new Vector3f(out).mul(near), new Vector3f(out).mul((near + far) * 0.5F), new Vector3f(out).mul(far)});
            }
         }

         Vector3f eye = new Vector3f(camera).sub(0.5F, 4.6625F, 0.5F);
         poseStack.pushPose();
         poseStack.translate(0.5F, 4.6625F, 0.5F);
         GlowBatch.add(
            ModRenderTypes.GLOW,
            poseStack,
            (consumer, pose, normal) -> {
               if (radius > 0.0F) {
                  GlowDraw.glowSphere(consumer, pose, radius, (float) (-Math.PI / 2), (float) (Math.PI / 2), 14, 7, 1.0F, 0.95F, 1.0F, (nx, ny, nz) -> 0.8F);
                  GlowDraw.glowSphere(
                     consumer,
                     pose,
                     radius * 2.2F,
                     (float) (-Math.PI / 2),
                     (float) (Math.PI / 2),
                     14,
                     7,
                     VIOLET[0],
                     VIOLET[1],
                     VIOLET[2],
                     (nx, ny, nz) -> 0.25F
                  );
               }

               for (Vector3f[] streak : streaks) {
                  GlowDraw.taperedRibbon(consumer, pose, streak, eye, 0.06F, WHITE[0], WHITE[1], WHITE[2], 0.7F * implode + 0.2F);
               }

               if (birth >= 0.0F && birth < 10.0F) {
                  GlowDraw.glowSphere(
                     consumer,
                     pose,
                     0.3F + 3.5F * Easing.outCubic(birth / 10.0F),
                     (float) (-Math.PI / 2),
                     (float) (Math.PI / 2),
                     18,
                     9,
                     1.0F,
                     0.95F,
                     1.0F,
                     (nx, ny, nz) -> 0.9F * (1.0F - birth / 10.0F)
                  );
               }

               if (birth >= 0.0F && birth < 14.0F) {
                  GlowDraw.ring(
                     consumer,
                     pose,
                     0.0F,
                     9.0F * Easing.outCubic(birth / 14.0F) - 0.8F,
                     9.0F * Easing.outCubic(birth / 14.0F),
                     64,
                     PALE[0],
                     PALE[1],
                     PALE[2],
                     0.0F,
                     0.9F * (1.0F - birth / 14.0F)
                  );
               }

               if (birth >= 0.0F && birth < 28.0F) {
                  float r = 18.0F * Easing.outCubic(birth / 28.0F);
                  float a = 0.85F * (1.0F - birth / 28.0F);

                  for (int c = 0; c < 3; c++) {
                     float back = (2 - c) * 0.45F;
                     GlowDraw.ring(consumer, pose, -4.6025F, Math.max(0.0F, r - back - 1.0F), r - back - 0.3F, 64, GEMS[c][0], GEMS[c][1], GEMS[c][2], 0.0F, a);
                     GlowDraw.ring(consumer, pose, -4.6025F, r - back - 0.3F, r - back, 64, GEMS[c][0], GEMS[c][1], GEMS[c][2], a, 0.0F);
                  }

                  GlowDraw.ring(consumer, pose, -4.5924997F, r - 0.2F, r + 0.25F, 64, WHITE[0], WHITE[1], WHITE[2], a, 0.0F);
               }

               if (birth >= 0.0F && birth < 30.0F) {
                  float r = 6.0F + 40.0F * Easing.outCubic(birth / 30.0F);
                  float a = 0.9F * (1.0F - birth / 30.0F);
                  GlowDraw.ring(consumer, pose, 5.4F, Math.max(0.0F, r - 2.5F), r, 96, PALE[0], PALE[1], PALE[2], 0.0F, a);
                  GlowDraw.ring(consumer, pose, 5.4F, r, r + 0.6F, 96, WHITE[0], WHITE[1], WHITE[2], a, 0.0F);
               }

               for (int h = 0; h < 3; h++) {
                  float since = birth - 4.0F - h * 5.0F;
                  if (!(since < 0.0F) && !(since > 40.0F)) {
                     float u = since / 40.0F;
                     float r = 1.0F + 4.0F * Easing.outCubic(u);
                     float a = 0.8F * (1.0F - u) * (1.0F - u);
                     Matrix4f rising = new Matrix4f(pose).translate(0.0F, 10.0F * Easing.outCubic(u), 0.0F);
                     GlowDraw.band(consumer, rising, r, 0.12F + 0.2F * u, 48, GEMS[h][0], GEMS[h][1], GEMS[h][2], a);
                  }
               }
            }
         );
         float star = t < 450.0F ? (0.6F + 1.4F * grow) * (1.0F - 0.6F * implode) + 2.0F * flash : 2.2F * Math.max(0.0F, 1.0F - birth / 30.0F);
         if (star > 0.01F) {
            poseStack.mulPose(Axis.YP.rotationDegrees(-turn(facing)));
            poseStack.mulPose(view.rotation());
            poseStack.mulPose(Axis.ZP.rotationDegrees(t * 2.0F));
            GlowBatch.add(
               ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> GlowDraw.starburst(consumer, pose, star, 0.35F, PALE[0], PALE[1], PALE[2], 0.85F)
            );
         }

         poseStack.popPose();
      }
   }

   private static Vector3f[] jagged(Vector3f from, Vector3f to, int segments, float spread, int seed) {
      Vector3f[] points = new Vector3f[segments + 1];

      for (int i = 0; i <= segments; i++) {
         Vector3f p = new Vector3f(from).lerp(to, (float)i / segments);
         if (i > 0 && i < segments) {
            p.add((hash(seed * 131 + i * 3) - 0.5F) * spread, (hash(seed * 131 + i * 3 + 1) - 0.5F) * spread, (hash(seed * 131 + i * 3 + 2) - 0.5F) * spread);
         }

         points[i] = p;
      }

      return points;
   }

   private static float hash(int x) {
      x = x ^ 61 ^ x >>> 16;
      x *= 9;
      x ^= x >>> 4;
      x *= 668265261;
      x ^= x >>> 15;
      return (x & 16777215) / 1.6777216E7F;
   }

   private record Disc(Vector3f at, Vector3f facing, float size, float spin, float r, float g, float b) {
   }
}
