package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.PageStormEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.model.BookModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.EnchantTableRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class PageStormRenderer extends EntityRenderer<PageStormEntity> {
   private static final ResourceLocation PAGE = AmuletMod.id("textures/entity/page.png");
   private static final ResourceLocation CIRCLE = AmuletMod.id("textures/misc/library_circle.png");
   private static final float PAGE_HALF_WIDTH = 0.13F;
   private static final float PAGE_HALF_HEIGHT = 0.17F;
   private static final float U0 = 0.125F;
   private static final float U1 = 0.875F;
   private static final float LEAN = (float) (Math.PI * 2.0 / 9.0);
   private static final float[] PURPLE = new float[]{0.62F, 0.38F, 1.0F};
   private static final float[] GOLD = new float[]{1.0F, 0.82F, 0.4F};
   private static final float[] PAPER_LIGHT = new float[]{1.0F, 0.9F, 0.68F};
   private static final Vector3f UP = new Vector3f(0.0F, 1.0F, 0.0F);
   private static final Vector3f FORWARD = new Vector3f(0.0F, 0.0F, 1.0F);
   private static final int TRAIL = 3;
   private final BookModel book;

   public PageStormRenderer(Context context) {
      super(context);
      this.book = new BookModel(context.bakeLayer(ModelLayers.BOOK));
   }

   public void render(PageStormEntity storm, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float age = storm.tickCount + partialTick;
      Vec3 at = storm.getPosition(partialTick);
      Vec3 center = storm.center(partialTick);
      float charge = PageStormEntity.charge(age);
      int collapsed = storm.collapsedAt();
      float ended = collapsed >= 0 ? Mth.clamp((age - collapsed) / 15.0F, 0.0F, 1.0F) : Mth.clamp((age - 240.0F) / 20.0F, 0.0F, 1.0F);
      float[] color = mix(PURPLE, GOLD, charge * charge);
      Vector3f eye = this.entityRenderDispatcher.camera.getPosition().subtract(center).toVector3f();
      poseStack.pushPose();
      Vec3 offset = center.subtract(at);
      poseStack.translate(offset.x, offset.y, offset.z);
      circles(poseStack, age, charge, ended, color);
      this.books(storm, poseStack, buffers, age, center, color, eye);
      pages(storm, poseStack, buffers, age, center, partialTick, charge, eye);
      if (collapsed < 0) {
         this.climax(poseStack, age, charge, ended, color);
      }

      poseStack.popPose();
      super.render(storm, entityYaw, partialTick, poseStack, buffers, packedLight);
   }

   private static void circles(PoseStack poseStack, float age, float charge, float ended, float[] color) {
      float open = Easing.outCubic(Mth.clamp(age / 20.0F, 0.0F, 1.0F));
      float radius = 7.0F * open * (1.0F + 0.35F * ended);
      float bright = (0.35F + 0.65F * charge) * (1.0F - ended);
      if (!(bright <= 0.01F) && !(radius <= 0.01F)) {
         float spin = PageStormEntity.spin(age) * 0.12F;
         float crown = Mth.clamp((charge - 0.7F) / 0.3F, 0.0F, 1.0F) * (1.0F - ended);
         GlowBatch.add(
            ModRenderTypes.skyGlow(CIRCLE),
            poseStack,
            (consumer, pose, normal) -> {
               Vector3f up = new Vector3f(0.0F, 1.0F, 0.0F);
               GlowDraw.disc(consumer, pose, new Vector3f(0.0F, 0.06F, 0.0F), up, radius, spin, color[0] * bright, color[1] * bright, color[2] * bright);
               GlowDraw.disc(consumer, pose, new Vector3f(0.0F, 0.08F, 0.0F), up, radius * 0.42F, -spin * 2.5F, bright, bright * 0.95F, bright * 0.8F);
               if (crown > 0.0F) {
                  GlowDraw.disc(
                     consumer,
                     pose,
                     new Vector3f(0.0F, 4.8F, 0.0F),
                     up,
                     3.2F * Easing.outBack(crown),
                     spin * 3.0F,
                     GOLD[0] * crown,
                     GOLD[1] * crown,
                     GOLD[2] * crown
                  );
               }
            }
         );
      }
   }

   private void books(PageStormEntity storm, PoseStack poseStack, MultiBufferSource buffers, float age, Vec3 center, float[] color, Vector3f eye) {
      PageStormEntity.Book[] books = storm.books();
      List<Vector3f[]> trails = new ArrayList<>();
      List<Vector3f> bursts = new ArrayList<>();
      List<Float> burstStrength = new ArrayList<>();

      for (int b = 0; b < books.length; b++) {
         float sinceBurst = age - books[b].arrival();
         if (sinceBurst >= 0.0F && sinceBurst < 5.0F && storm.collapsedAt() < 0) {
            bursts.add(storm.burstPoint(b).toVector3f());
            burstStrength.add(1.0F - sinceBurst / 5.0F);
         }

         Vec3 at = storm.bookPosition(b, age, center);
         if (at != null) {
            Vec3 before = storm.bookPosition(b, age - 0.5F, center);
            Vec3 heading = before == null ? new Vec3(1.0, 0.0, 0.0) : at.subtract(before);
            Vec3 local = at.subtract(center);
            int light = LevelRenderer.getLightColor(storm.level(), BlockPos.containing(at));
            poseStack.pushPose();
            poseStack.translate(local.x, local.y, local.z);
            poseStack.mulPose(Axis.YP.rotation((float)(-Mth.atan2(heading.z, heading.x))));
            poseStack.mulPose(Axis.ZP.rotationDegrees(80.0F));
            poseStack.scale(1.2F, 1.2F, 1.2F);
            float flip = age * 0.06F + b * 0.37F;
            this.book
               .setupAnim(
                  age,
                  Mth.clamp(Mth.frac(flip + 0.25F) * 1.6F - 0.3F, 0.0F, 1.0F),
                  Mth.clamp(Mth.frac(flip + 0.75F) * 1.6F - 0.3F, 0.0F, 1.0F),
                  0.55F + 0.45F * Mth.sin(age * 0.9F + b)
               );
            VertexConsumer consumer = EnchantTableRenderer.BOOK_LOCATION.buffer(buffers, RenderType::entitySolid);
            this.book.renderToBuffer(poseStack, consumer, light, OverlayTexture.NO_OVERLAY);
            poseStack.popPose();
            Vector3f[] trail = new Vector3f[5];
            trail[0] = local.toVector3f();
            int n = 1;

            for (int k = 1; k <= 4; k++) {
               Vec3 past = storm.bookPosition(b, age - k * 1.5F, center);
               if (past == null) {
                  break;
               }

               trail[n++] = past.subtract(center).toVector3f();
            }

            if (n > 2) {
               trails.add(Arrays.copyOf(trail, n));
            }
         }
      }

      if (!trails.isEmpty()) {
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumerx, pose, normal) -> {
            for (Vector3f[] trailx : trails) {
               GlowDraw.taperedRibbon(consumerx, pose, trailx, eye, 0.25F, color[0], color[1], color[2], 0.45F);
            }
         });
      }

      for (int i = 0; i < bursts.size(); i++) {
         Vector3f burst = bursts.get(i);
         float strength = burstStrength.get(i);
         poseStack.pushPose();
         poseStack.translate(burst.x(), burst.y(), burst.z());
         poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumerx, pose, normal) -> {
            GlowDraw.starburst(consumerx, pose, 1.4F * (1.6F - strength), 0.3F, PURPLE[0], PURPLE[1], PURPLE[2], strength);
            GlowDraw.starburst(consumerx, pose, 0.6F, 0.45F, 1.0F, 1.0F, 1.0F, strength);
         });
         poseStack.popPose();
      }
   }

   private static void pages(
      PageStormEntity storm, PoseStack poseStack, MultiBufferSource buffers, float age, Vec3 center, float partialTick, float charge, Vector3f eye
   ) {
      int count = storm.pages();
      if (count != 0) {
         VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(PAGE));
         Pose flat = poseStack.last().copy();
         boolean loosed = age >= 240.0F;
         List<Vector3f[]> trails = new ArrayList<>();

         for (int i = 0; i < count; i++) {
            Vec3 at = storm.pagePosition(i, age, center, partialTick);
            float scale = at == null ? 0.0F : storm.pageScale(i, age);
            if (!(scale <= 0.01F)) {
               Vector3f local = at.subtract(center).toVector3f();
               Vector3f[] trail = new Vector3f[4];
               trail[0] = local;
               int n = 1;

               for (int k = 1; k <= 3; k++) {
                  Vec3 past = storm.pagePosition(i, age - k, center, partialTick);
                  if (past == null) {
                     break;
                  }

                  trail[n++] = past.subtract(center).toVector3f();
               }

               Vector3f heading = n > 1 ? new Vector3f(local).sub(trail[1]) : new Vector3f(-local.z(), 0.0F, local.x());
               if (heading.lengthSquared() < 1.0E-6F) {
                  heading.set(1.0F, 0.0F, 0.0F);
               }

               heading.normalize();
               if (n > 2) {
                  trails.add(Arrays.copyOf(trail, n));
               }

               Vector3f lift = new Vector3f(UP).sub(new Vector3f(heading).mul(heading.dot(UP)));
               if (lift.lengthSquared() < 1.0E-4F) {
                  lift.set(1.0F, 0.0F, 0.0F);
               }

               lift.normalize();
               Vector3f facing = new Vector3f(heading)
                  .mul(Mth.cos((float) (Math.PI * 2.0 / 9.0)))
                  .add(lift.mul(Mth.sin((float) (Math.PI * 2.0 / 9.0))))
                  .normalize();
               float spin = (age * (12.0F + 40.0F * charge) + i * 37.0F) * (float) (Math.PI / 180.0);
               poseStack.pushPose();
               poseStack.translate(local.x(), local.y(), local.z());
               poseStack.mulPose(new Quaternionf().rotationTo(FORWARD, facing).rotateZ(spin));
               poseStack.scale(scale, scale, scale);
               Matrix4f pose = poseStack.last().pose();
               pageVertex(consumer, pose, flat, -0.13F, -0.17F, 0.125F, 1.0F);
               pageVertex(consumer, pose, flat, 0.13F, -0.17F, 0.875F, 1.0F);
               pageVertex(consumer, pose, flat, 0.13F, 0.17F, 0.875F, 0.0F);
               pageVertex(consumer, pose, flat, -0.13F, 0.17F, 0.125F, 0.0F);
               poseStack.popPose();
            }
         }

         if (!trails.isEmpty()) {
            float alpha = loosed ? 0.55F : 0.1F + 0.4F * charge;
            float width = loosed ? 0.12F : 0.06F + 0.06F * charge;
            GlowBatch.add(ModRenderTypes.GLOW, poseStack, (glow, posex, normal) -> {
               for (Vector3f[] trailx : trails) {
                  GlowDraw.taperedRibbon(glow, posex, trailx, eye, width, PAPER_LIGHT[0], PAPER_LIGHT[1], PAPER_LIGHT[2], alpha);
               }
            });
         }
      }
   }

   private void climax(PoseStack poseStack, float age, float charge, float ended, float[] color) {
      float build = Mth.clamp((charge - 0.6F) / 0.4F, 0.0F, 1.0F) * (1.0F - ended);
      if (build > 0.0F) {
         GlowBatch.add(
            ModRenderTypes.GLOW,
            poseStack,
            (glow, pose, normal) -> {
               for (int k = 0; k < 3; k++) {
                  float y = 0.9F + 1.3F * k;
                  float radius = (5.2F - 0.6F * k) * (1.0F - 0.25F * build);
                  float pulse = 0.6F + 0.4F * Mth.sin(age * 0.5F + k * 2.0F);
                  Matrix4f ring = new Matrix4f(pose).translate(0.0F, y, 0.0F);
                  GlowDraw.band(glow, ring, radius, 0.25F + 0.2F * build, 48, color[0], color[1], color[2], 0.3F * build * pulse);
               }

               GlowDraw.glowSphere(
                  glow, pose, 1.4F * build, (float) (-Math.PI / 2), (float) (Math.PI / 2), 16, 8, GOLD[0], GOLD[1], GOLD[2], (nx, ny, nz) -> 0.25F * build
               );
            }
         );
      }

      float since = age - 240.0F;
      if (!(since < 0.0F) && !(since > 14.0F)) {
         float t = since / 14.0F;
         float fade = (1.0F - t) * (1.0F - t);
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (glow, pose, normal) -> {
            float reach = 2.0F + 16.0F * Easing.outCubic(t);
            GlowDraw.ring(glow, pose, 0.1F, Math.max(0.0F, reach - 2.5F), reach, 64, GOLD[0], GOLD[1], GOLD[2], 0.0F, 0.8F * fade);
            GlowDraw.ring(glow, pose, 0.1F, reach, reach + 0.5F, 64, 1.0F, 1.0F, 1.0F, 0.8F * fade, 0.0F);
            GlowDraw.band(glow, pose, reach * 0.95F, 1.2F * fade, 64, PURPLE[0], PURPLE[1], PURPLE[2], 0.5F * fade);
         });
         if (since < 6.0F) {
            float flash = 1.0F - since / 6.0F;
            poseStack.pushPose();
            poseStack.translate(0.0F, 1.5F, 0.0F);
            poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
            GlowBatch.add(ModRenderTypes.GLOW, poseStack, (glow, pose, normal) -> {
               GlowDraw.starburst(glow, pose, 6.0F * (1.5F - flash), 0.25F, GOLD[0], GOLD[1], GOLD[2], flash);
               GlowDraw.starburst(glow, pose, 2.5F, 0.4F, 1.0F, 1.0F, 1.0F, flash);
            });
            poseStack.popPose();
         }
      }
   }

   private static float[] mix(float[] from, float[] to, float t) {
      return new float[]{Mth.lerp(t, from[0], to[0]), Mth.lerp(t, from[1], to[1]), Mth.lerp(t, from[2], to[2])};
   }

   private static void pageVertex(VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float y, float u, float v) {
      consumer.addVertex(pose, x, y, 0.0F)
         .setColor(1.0F, 1.0F, 1.0F, 1.0F)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(normal, 0.0F, 1.0F, 0.0F);
   }

   public ResourceLocation getTextureLocation(PageStormEntity storm) {
      return PAGE;
   }
}
