package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.StormCloudEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import java.util.Arrays;
import java.util.Comparator;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

public class StormCloudRenderer extends EntityRenderer<StormCloudEntity> {
   private static final ResourceLocation PUFF = AmuletMod.id("textures/entity/storm_cloud.png");
   private static final int PUFFS = 22;
   private static final float GOLDEN_ANGLE = 2.3999631F;

   public StormCloudRenderer(Context context) {
      super(context);
   }

   public void render(StormCloudEntity cloud, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float density = cloud.density(partialTick);
      if (!(density <= 0.01F)) {
         poseStack.pushPose();
         Entity owner = cloud.owner();
         if (owner != null) {
            Vec3 anchor = owner.getPosition(partialTick).add(0.0, 6.5, 0.0);
            Vec3 self = cloud.getPosition(partialTick);
            poseStack.translate(anchor.x - self.x, anchor.y - self.y, anchor.z - self.z);
         }

         float age = cloud.tickCount + partialTick;
         float flash = Mth.clamp(1.0F - (age - cloud.lastStrike()) / 5.0F, 0.0F, 1.0F);
         Quaternionf facing = this.entityRenderDispatcher.cameraOrientation();
         Vec3 eye = this.entityRenderDispatcher.camera.getPosition().subtract(cloud.getPosition(partialTick));
         float spin = age * 0.4F * (float) (Math.PI / 180.0);
         float[][] puffs = new float[22][];

         for (int i = 0; i < 22; i++) {
            float radius = Mth.sqrt(i / 22.0F) * 3.4F * (0.6F + 0.4F * density);
            float angle = i * 2.3999631F + spin;
            float x = Mth.cos(angle) * radius;
            float z = Mth.sin(angle) * radius;
            float y = Mth.sin(i * 1.7F + age * 0.05F) * 0.3F - radius * 0.08F;
            float size = (2.0F - radius * 0.3F + i % 3 * 0.2F) * (0.4F + 0.6F * density);
            puffs[i] = new float[]{x, y, z, size, i};
         }

         Arrays.sort(
            puffs, Comparator.comparingDouble(p -> -((p[0] - eye.x) * (p[0] - eye.x) + (p[1] - eye.y) * (p[1] - eye.y) + (p[2] - eye.z) * (p[2] - eye.z)))
         );
         VertexConsumer consumer = buffers.getBuffer(RenderType.entityTranslucent(PUFF));

         for (float[] puff : puffs) {
            int index = (int)puff[4];
            float shade = 0.2F + index % 4 * 0.035F;
            float lit = flash * (0.6F + 0.4F * Mth.sin(index * 2.1F + age));
            float r = shade + 0.45F * lit;
            float g = shade + 0.5F * lit;
            float b = shade + 0.08F + 0.65F * lit;
            poseStack.pushPose();
            poseStack.translate(puff[0], puff[1], puff[2]);
            poseStack.mulPose(facing);
            poseStack.mulPose(Axis.ZP.rotationDegrees(index * 57.0F + age * (index % 2 == 0 ? 0.3F : -0.3F)));
            Matrix4f pose = poseStack.last().pose();
            Pose normal = poseStack.last();
            float half = puff[3] * 0.5F;
            vertex(consumer, pose, normal, -half, -half, 0.0F, 1.0F, r, g, b, density);
            vertex(consumer, pose, normal, half, -half, 1.0F, 1.0F, r, g, b, density);
            vertex(consumer, pose, normal, half, half, 1.0F, 0.0F, r, g, b, density);
            vertex(consumer, pose, normal, -half, half, 0.0F, 0.0F, r, g, b, density);
            poseStack.popPose();
         }

         if (flash > 0.0F) {
            poseStack.pushPose();
            poseStack.mulPose(facing);
            GlowBatch.add(
               ModRenderTypes.GLOW, poseStack, (glow, posex, normalx) -> GlowDraw.starburst(glow, posex, 3.5F, 0.5F, 0.55F, 0.7F, 1.0F, 0.5F * flash)
            );
            poseStack.popPose();
         }

         poseStack.popPose();
         super.render(cloud, entityYaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   private static void vertex(VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float y, float u, float v, float r, float g, float b, float a) {
      consumer.addVertex(pose, x, y, 0.0F)
         .setColor(r, g, b, a)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(normal, 0.0F, 0.0F, 1.0F);
   }

   public boolean shouldRender(StormCloudEntity cloud, Frustum frustum, double x, double y, double z) {
      return true;
   }

   public ResourceLocation getTextureLocation(StormCloudEntity cloud) {
      return PUFF;
   }
}
