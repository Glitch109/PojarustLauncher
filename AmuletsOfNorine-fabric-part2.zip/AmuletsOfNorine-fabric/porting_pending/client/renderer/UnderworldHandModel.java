package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;

public class UnderworldHandModel extends Model {
   public static final ModelLayerLocation LAYER = new ModelLayerLocation(AmuletMod.id("underworld_hand"), "main");
   public static final float PALM_BASE = 2.0F;
   public static final float HAND_HEIGHT = 32.0F;
   public static final float PALM_FRONT = 3.0F;
   private static final float[] FINGER_X = new float[]{-5.25F, -1.75F, 1.75F, 5.25F};
   private static final float[][] FINGER_SEGMENTS = new float[][]{{6.0F, 5.0F, 4.0F}, {7.0F, 6.0F, 5.0F}, {8.0F, 6.0F, 5.0F}, {7.0F, 6.0F, 4.0F}};
   private final ModelPart root;
   private final ModelPart[][] fingers = new ModelPart[4][3];
   private final ModelPart thumb;
   private final ModelPart thumbTip;

   public UnderworldHandModel(ModelPart root) {
      super(RenderType::entityCutoutNoCull);
      this.root = root;
      ModelPart palm = root.getChild("palm");

      for (int i = 0; i < 4; i++) {
         ModelPart segment = palm.getChild("finger_" + i);

         for (int j = 0; j < 3; j++) {
            this.fingers[i][j] = segment;
            if (j < 2) {
               segment = segment.getChild("joint");
            }
         }
      }

      this.thumb = palm.getChild("thumb");
      this.thumbTip = this.thumb.getChild("joint");
   }

   public static LayerDefinition createLayer() {
      MeshDefinition mesh = new MeshDefinition();
      PartDefinition root = mesh.getRoot();
      root.addOrReplaceChild(
         "arm",
         CubeListBuilder.create()
            .texOffs(0, 0)
            .addBox(-5.0F, -26.0F, -4.0F, 10.0F, 28.0F, 8.0F)
            .texOffs(52, 10)
            .addBox(-1.0F, -8.0F, -6.0F, 2.0F, 3.0F, 2.0F)
            .texOffs(52, 10)
            .addBox(-1.0F, -2.0F, -6.0F, 2.0F, 3.0F, 2.0F),
         PartPose.ZERO
      );
      PartDefinition palm = root.addOrReplaceChild(
         "palm",
         CubeListBuilder.create()
            .texOffs(0, 36)
            .addBox(-7.0F, 0.0F, -3.0F, 14.0F, 12.0F, 6.0F)
            .texOffs(52, 10)
            .addBox(-4.5F, 5.0F, -5.0F, 2.0F, 2.0F, 2.0F)
            .texOffs(52, 10)
            .addBox(-0.5F, 7.0F, -5.5F, 2.0F, 2.0F, 3.0F)
            .texOffs(52, 10)
            .addBox(3.0F, 4.0F, -5.0F, 2.0F, 2.0F, 2.0F),
         PartPose.offset(0.0F, 2.0F, 0.0F)
      );

      for (int i = 0; i < 4; i++) {
         float[] lengths = FINGER_SEGMENTS[i];
         PartDefinition segment = palm.addOrReplaceChild(
            "finger_" + i,
            CubeListBuilder.create().texOffs(40, 0).addBox(-1.5F, 0.0F, -1.5F, 3.0F, lengths[0], 3.0F),
            PartPose.offset(FINGER_X[i], 12.0F, 0.0F)
         );
         segment = segment.addOrReplaceChild(
            "joint", CubeListBuilder.create().texOffs(40, 10).addBox(-1.5F, 0.0F, -1.5F, 3.0F, lengths[1], 3.0F), PartPose.offset(0.0F, lengths[0], 0.0F)
         );
         segment.addOrReplaceChild(
            "joint",
            CubeListBuilder.create()
               .texOffs(40, 20)
               .addBox(-1.5F, 0.0F, -1.5F, 3.0F, lengths[2], 3.0F)
               .texOffs(52, 0)
               .addBox(-1.0F, lengths[2], -0.5F, 2.0F, 3.0F, 2.0F),
            PartPose.offset(0.0F, lengths[1], 0.0F)
         );
      }

      PartDefinition thumb = palm.addOrReplaceChild(
         "thumb", CubeListBuilder.create().texOffs(0, 54).addBox(0.0F, -1.5F, -1.5F, 6.0F, 3.0F, 3.0F), PartPose.offset(7.0F, 3.0F, 0.0F)
      );
      thumb.addOrReplaceChild(
         "joint",
         CubeListBuilder.create().texOffs(18, 54).addBox(0.0F, -1.5F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(52, 0).addBox(5.0F, -1.0F, -0.5F, 3.0F, 2.0F, 2.0F),
         PartPose.offset(6.0F, 0.0F, 0.0F)
      );
      return LayerDefinition.create(mesh, 64, 64);
   }

   public void pose(float grip, float tremor) {
      for (int i = 0; i < 4; i++) {
         float spread = (i - 1.5F) * 0.14F * (1.0F - grip);
         this.fingers[i][0].xRot = Mth.lerp(grip, -0.35F, 1.25F) + tremor;
         this.fingers[i][0].zRot = -spread;
         this.fingers[i][1].xRot = Mth.lerp(grip, 0.1F, 1.2F);
         this.fingers[i][2].xRot = Mth.lerp(grip, 0.15F, 0.95F) - tremor;
      }

      this.thumb.yRot = Mth.lerp(grip, 0.5F, -1.2F);
      this.thumb.zRot = Mth.lerp(grip, 0.35F, 0.15F) + tremor;
      this.thumbTip.yRot = Mth.lerp(grip, 0.1F, -0.9F);
   }

   public void renderToBuffer(PoseStack poseStack, VertexConsumer consumer, int packedLight, int packedOverlay, int color) {
      this.root.render(poseStack, consumer, packedLight, packedOverlay, color);
   }
}
