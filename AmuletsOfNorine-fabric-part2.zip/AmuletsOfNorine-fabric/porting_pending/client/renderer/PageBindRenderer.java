package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.PageBindEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

public class PageBindRenderer extends EntityRenderer<PageBindEntity> {
   private static final ResourceLocation BAND = AmuletMod.id("textures/entity/paper_band.png");
   private static final int SEGMENTS = 24;
   private static final float[] HEIGHTS = new float[]{0.22F, 0.5F, 0.78F};
   private static final float[] TILTS = new float[]{0.12F, -0.09F, 0.14F};
   private static final float[] TURNS = new float[]{1.0F, -1.0F, 1.0F};
   private static final float TILE = 4.0F;

   public PageBindRenderer(Context context) {
      super(context);
   }

   public void render(PageBindEntity bind, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float age = bind.tickCount + partialTick;
      float width = bind.victimWidth();
      float height = bind.victimHeight();
      float wrap = Easing.outCubic(Mth.clamp(age / 7.0F, 0.0F, 1.0F));
      float tear = Mth.clamp((age - bind.tearsAt()) / 8.0F, 0.0F, 1.0F);
      float tight = width * 0.5F + 0.07F;
      float radius = Mth.lerp(wrap, tight + 1.3F, tight) + Easing.outCubic(tear) * 0.7F;
      float halfHeight = Mth.clamp(height * 0.065F, 0.08F, 0.2F) * (1.0F - tear) * Mth.lerp(wrap, 0.6F, 1.0F);
      if (!(halfHeight <= 0.005F)) {
         Vec3 offset = bind.feet(partialTick).subtract(bind.getPosition(partialTick));
         poseStack.pushPose();
         poseStack.translate(offset.x, offset.y, offset.z);
         VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(BAND));
         Matrix4f pose = poseStack.last().pose();
         Pose normal = poseStack.last();
         float whirl = Easing.outCubic(Mth.clamp(age / 11.0F, 0.0F, 1.0F)) * (float) (Math.PI * 2) + age * 0.03F;
         int repeats = Math.max(1, Math.round((float) (Math.PI * 2) * radius / (halfHeight * 2.0F * 4.0F)));

         for (int k = 0; k < HEIGHTS.length; k++) {
            band(consumer, pose, normal, height * HEIGHTS[k], radius, halfHeight, TILTS[k] * radius, TURNS[k] * whirl + k * 2.1F, repeats, packedLight);
         }

         poseStack.popPose();
         float glow = 0.35F * wrap * (1.0F - tear);
         if (glow > 0.01F) {
            poseStack.pushPose();
            poseStack.translate(offset.x, offset.y, offset.z);
            GlowBatch.add(ModRenderTypes.GLOW, poseStack, (glowConsumer, glowPose, glowNormal) -> {
               for (float share : HEIGHTS) {
                  Matrix4f at = new Matrix4f(glowPose).translate(0.0F, height * share, 0.0F);
                  GlowDraw.band(glowConsumer, at, radius + 0.03F, halfHeight * 1.8F, 24, 0.95F, 0.15F, 0.2F, glow);
               }
            });
            poseStack.popPose();
         }

         super.render(bind, entityYaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   private static void band(
      VertexConsumer consumer, Matrix4f pose, Pose normal, float y, float radius, float halfHeight, float tilt, float turn, int repeats, int light
   ) {
      for (int i = 0; i < 24; i++) {
         float a0 = turn + i * (float) (Math.PI * 2) / 24.0F;
         float a1 = turn + (i + 1) * (float) (Math.PI * 2) / 24.0F;
         float c0 = Mth.cos(a0);
         float s0 = Mth.sin(a0);
         float c1 = Mth.cos(a1);
         float s1 = Mth.sin(a1);
         float y0 = y + tilt * s0;
         float y1 = y + tilt * s1;
         float u0 = i / 24.0F * repeats;
         float u1 = (i + 1) / 24.0F * repeats;
         vertex(consumer, pose, normal, c0 * radius, y0 - halfHeight, s0 * radius, u0, 1.0F, c0, s0, light);
         vertex(consumer, pose, normal, c1 * radius, y1 - halfHeight, s1 * radius, u1, 1.0F, c1, s1, light);
         vertex(consumer, pose, normal, c1 * radius, y1 + halfHeight, s1 * radius, u1, 0.0F, c1, s1, light);
         vertex(consumer, pose, normal, c0 * radius, y0 + halfHeight, s0 * radius, u0, 0.0F, c0, s0, light);
      }
   }

   private static void vertex(VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float y, float z, float u, float v, float nx, float nz, int light) {
      consumer.addVertex(pose, x, y, z)
         .setColor(1.0F, 1.0F, 1.0F, 1.0F)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(light)
         .setNormal(normal, nx, 0.0F, nz);
   }

   public ResourceLocation getTextureLocation(PageBindEntity bind) {
      return BAND;
   }
}
