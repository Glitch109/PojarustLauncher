package com.amuletmod.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.world.item.ItemDisplayContext;
import net.neoforged.neoforge.client.model.BakedModelWrapper;

public class GemstoneItemModel extends BakedModelWrapper<BakedModel> {
   private final BakedModel icon;

   public GemstoneItemModel(BakedModel icon, BakedModel gem) {
      super(gem);
      this.icon = icon;
   }

   public BakedModel applyTransform(ItemDisplayContext context, PoseStack poseStack, boolean applyLeftHandTransform) {
      return context == ItemDisplayContext.GUI
         ? this.icon.applyTransform(context, poseStack, applyLeftHandTransform)
         : super.applyTransform(context, poseStack, applyLeftHandTransform);
   }

   public boolean usesBlockLight() {
      return this.icon.usesBlockLight();
   }
}
