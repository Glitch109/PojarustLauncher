package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.RootsEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class RootsRenderer extends EntityRenderer<RootsEntity> {
   private static final ResourceLocation BARK = AmuletMod.id("textures/entity/roots_bark.png");
   private static final ResourceLocation LEAVES = ResourceLocation.fromNamespaceAndPath("minecraft", "textures/block/flowering_azalea_leaves.png");
   private static final int TENDRILS = 7;
   private static final int SEGMENTS = 14;
   private static final int SIDES = 5;
   private static final float LEAF_SIZE = 0.2F;

   public RootsRenderer(Context context) {
      super(context);
   }

   public void render(RootsEntity roots, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float growth = roots.growth(partialTick);
      if (!(growth <= 0.0F)) {
         float age = roots.tickCount + partialTick;
         float wither = roots.witherProgress(partialTick);
         float width = roots.victimWidth();
         float height = roots.victimHeight();
         RandomSource random = RandomSource.create(roots.getId() * 341873128712L);
         List<Vector3f> leaves = new ArrayList<>();
         poseStack.pushPose();
         poseStack.translate(0.0F, -0.35F * wither, 0.0F);
         VertexConsumer bark = buffers.getBuffer(RenderType.entityCutoutNoCull(BARK));
         Matrix4f pose = poseStack.last().pose();
         Pose normal = poseStack.last();

         for (int i = 0; i < 7; i++) {
            float baseAngle = i * (float) (Math.PI * 2) / 7.0F + random.nextFloat() * 0.5F;
            float turn = (random.nextBoolean() ? 1.0F : -1.0F) * (0.7F + random.nextFloat() * 0.6F) * (float) (Math.PI * 2);
            float top = height * (0.45F + random.nextFloat() * 0.5F);
            float outer = width * 0.5F + 0.8F + random.nextFloat() * 0.6F;
            float inner = width * 0.5F + 0.1F;
            float thickness = 0.07F + 0.07F * Math.min(width, 1.5F) + random.nextFloat() * 0.03F;
            float delay = random.nextFloat() * 4.0F;
            float wobble = random.nextFloat() * (float) (Math.PI * 2);
            float length = Easing.outCubic(Mth.clamp((age - delay) / 12.0F, 0.0F, 1.0F)) * (1.0F - wither);
            if (!(length <= 0.01F)) {
               Vector3f[] points = new Vector3f[15];
               float[] radii = new float[15];

               for (int k = 0; k <= 14; k++) {
                  float s = length * k / 14.0F;
                  float radius = Mth.lerp(Easing.smoothstep(0.0F, 1.0F, Math.min(1.0F, s / 0.4F)), outer, inner);
                  float angle = baseAngle + turn * (float)Math.pow(s, 1.3);
                  float y = -0.3F + (top + 0.3F) * s + Mth.sin(s * 9.0F + wobble) * 0.05F;
                  points[k] = new Vector3f(Mth.cos(angle) * radius, y, Mth.sin(angle) * radius);
                  radii[k] = thickness * (1.0F - 0.75F * s) * (k == 14 ? 0.15F : 1.0F);
               }

               tube(bark, pose, normal, points, radii, packedLight);

               for (float at : new float[]{0.45F, 0.7F, 0.9F}) {
                  if (at < length - 0.05F && random.nextFloat() < 0.7F) {
                     Vector3f point = points[Math.round(at / length * 14.0F)];
                     leaves.add(new Vector3f(point).mul(1.08F, 1.0F, 1.08F));
                  }
               }
            }
         }

         VertexConsumer leafConsumer = buffers.getBuffer(RenderType.entityCutoutNoCull(LEAVES));

         for (Vector3f leaf : leaves) {
            leafTuft(leafConsumer, pose, normal, leaf, 0.2F * growth, packedLight);
         }

         poseStack.popPose();
         float glow = 0.3F * growth;
         float outerGlow = width * 0.5F + 1.7F;
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, glowPose, glowNormal) -> {
            GlowDraw.ring(consumer, glowPose, 0.04F, width * 0.5F, width * 0.5F + 0.9F, 32, 0.35F, 1.0F, 0.4F, 0.0F, glow);
            GlowDraw.ring(consumer, glowPose, 0.04F, width * 0.5F + 0.9F, outerGlow, 32, 0.35F, 1.0F, 0.4F, glow, 0.0F);
         });
         super.render(roots, entityYaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   private static void tube(VertexConsumer consumer, Matrix4f pose, Pose normal, Vector3f[] points, float[] radii, int light) {
      int count = points.length;
      Vector3f[][] rings = new Vector3f[count][6];
      Vector3f[][] normals = new Vector3f[count][6];
      float[] v = new float[count];
      Vector3f up = new Vector3f(0.0F, 1.0F, 0.0F);

      for (int k = 0; k < count; k++) {
         Vector3f along = new Vector3f(points[Math.min(k + 1, count - 1)]).sub(points[Math.max(k - 1, 0)]).normalize();
         Vector3f side = new Vector3f(along).cross(up);
         if (side.lengthSquared() < 1.0E-6F) {
            side.set(1.0F, 0.0F, 0.0F);
         }

         side.normalize();
         Vector3f other = new Vector3f(along).cross(side).normalize();

         for (int j = 0; j <= 5; j++) {
            float phi = j * (float) (Math.PI * 2) / 5.0F;
            Vector3f out = new Vector3f(side).mul(Mth.cos(phi)).add(new Vector3f(other).mul(Mth.sin(phi)));
            normals[k][j] = out;
            rings[k][j] = new Vector3f(out).mul(radii[k]).add(points[k]);
         }

         v[k] = k == 0 ? 0.0F : v[k - 1] + points[k].distance(points[k - 1]) * 2.0F;
      }

      for (int k = 0; k + 1 < count; k++) {
         for (int j = 0; j < 5; j++) {
            float u0 = j / 5.0F;
            float u1 = (j + 1) / 5.0F;
            vertex(consumer, pose, normal, rings[k][j], normals[k][j], u0, v[k], light);
            vertex(consumer, pose, normal, rings[k + 1][j], normals[k + 1][j], u0, v[k + 1], light);
            vertex(consumer, pose, normal, rings[k + 1][j + 1], normals[k + 1][j + 1], u1, v[k + 1], light);
            vertex(consumer, pose, normal, rings[k][j + 1], normals[k][j + 1], u1, v[k], light);
         }
      }
   }

   private static void leafTuft(VertexConsumer consumer, Matrix4f pose, Pose normal, Vector3f at, float size, int light) {
      for (int plane = 0; plane < 2; plane++) {
         float dx = plane == 0 ? size : 0.0F;
         float dz = plane == 0 ? 0.0F : size;
         Vector3f n = new Vector3f(plane == 0 ? 0.0F : 1.0F, 0.0F, plane == 0 ? 1.0F : 0.0F);
         vertex(consumer, pose, normal, new Vector3f(at.x - dx, at.y - size, at.z - dz), n, 0.0F, 1.0F, light);
         vertex(consumer, pose, normal, new Vector3f(at.x + dx, at.y - size, at.z + dz), n, 1.0F, 1.0F, light);
         vertex(consumer, pose, normal, new Vector3f(at.x + dx, at.y + size, at.z + dz), n, 1.0F, 0.0F, light);
         vertex(consumer, pose, normal, new Vector3f(at.x - dx, at.y + size, at.z - dz), n, 0.0F, 0.0F, light);
      }
   }

   private static void vertex(VertexConsumer consumer, Matrix4f pose, Pose normal, Vector3f at, Vector3f n, float u, float v, int light) {
      consumer.addVertex(pose, at.x, at.y, at.z)
         .setColor(1.0F, 1.0F, 1.0F, 1.0F)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(light)
         .setNormal(normal, n.x, n.y, n.z);
   }

   public ResourceLocation getTextureLocation(RootsEntity roots) {
      return BARK;
   }
}
