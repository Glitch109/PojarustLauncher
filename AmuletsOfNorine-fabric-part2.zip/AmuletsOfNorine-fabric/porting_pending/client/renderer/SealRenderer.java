package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.seal.Openings;
import com.amuletmod.entity.SealEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import java.util.List;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class SealRenderer extends EntityRenderer<SealEntity> {
   public static final ResourceLocation SCRIPT = AmuletMod.id("textures/misc/seal_script.png");
   public static final ResourceLocation CIRCLE = AmuletMod.id("textures/misc/seal_circle.png");
   public static final ResourceLocation MARK = AmuletMod.id("textures/misc/seal_mark.png");
   public static final float[] GLOW = new float[]{1.0F, 0.22F, 0.42F};
   public static final float[] PALE = new float[]{1.0F, 0.84F, 0.9F};
   private static final float SCRIPT_SCALE = 0.5F;
   private static final float RIM_WIDTH = 0.09F;

   public SealRenderer(Context context) {
      super(context);
   }

   public void render(SealEntity seal, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      int count = seal.size();
      float shatter = seal.shatter(partialTick);
      if (count != 0 && !(shatter >= 1.0F)) {
         float age = seal.tickCount + partialTick;
         float reach = seal.spread(partialTick);
         float left = seal.endTick() - age;
         float flicker = left > 0.0F && left < 60.0F ? 0.55F + 0.45F * Mth.sin(age * (0.5F + 1.5F * (1.0F - left / 60.0F))) : 1.0F;
         float flare = shatter > 0.0F ? 2.0F * Math.max(0.0F, 1.0F - shatter * 4.0F) : 0.0F;
         float strength = flicker * (1.0F - shatter) * (1.0F + flare);
         Direction facing = seal.facing();
         Axis axis = facing.getAxis();
         Vector3f origin = seal.planePoint(0.0, 0.0).subtract(seal.getPosition(partialTick)).toVector3f();
         Vector3f u = SealEntity.unit(Openings.uAxis(axis)).toVector3f();
         Vector3f v = SealEntity.unit(Openings.vAxis(axis)).toVector3f();
         Vector3f out = new Vector3f(facing.getStepX(), facing.getStepY(), facing.getStepZ());
         GlowBatch.add(ModRenderTypes.glowTextured(SCRIPT), poseStack, (consumer, pose, normal) -> {
            for (int i = 0; i < count; i++) {
               float written = Mth.clamp((reach - seal.depth(i)) / 3.0F, 0.0F, 1.0F);
               if (!(written <= 0.0F)) {
                  int cu = seal.u(i);
                  int cv = seal.v(i);
                  float edge = Math.max(0.0F, 1.0F - Math.abs(reach - seal.depth(i) - 1.5F) / 3.0F);
                  float light = (0.5F + 0.12F * Mth.sin(age * 0.12F + (cu + cv) * 0.7F)) * written * strength;
                  float r = Mth.lerp(edge, GLOW[0], PALE[0]) * (light + edge);
                  float g = Mth.lerp(edge, GLOW[1], PALE[1]) * (light + edge);
                  float b = Mth.lerp(edge, GLOW[2], PALE[2]) * (light + edge);
                  float inset = shatter * 0.5F;
                  float drift = shatter * shatter * (i * 37 % 11 - 5) * 0.12F;
                  float u0 = cu + inset;
                  float u1 = cu + 1.0F - inset;
                  float v0 = cv + inset;
                  float v1 = cv + 1.0F - inset;
                  float tu0 = cu * 0.5F;
                  float tu1 = (cu + 1) * 0.5F;
                  float tv0 = -cv * 0.5F;
                  float tv1 = -(cv + 1) * 0.5F;
                  corner(consumer, pose, normal, origin, u, v, out, u0, v0, drift, r, g, b, tu0, tv0);
                  corner(consumer, pose, normal, origin, u, v, out, u1, v0, drift, r, g, b, tu1, tv0);
                  corner(consumer, pose, normal, origin, u, v, out, u1, v1, drift, r, g, b, tu1, tv1);
                  corner(consumer, pose, normal, origin, u, v, out, u0, v1, drift, r, g, b, tu0, tv1);
               }
            }
         });
         SealEntity.Layout layout = seal.layout();
         float[] rim = layout.rim();
         float rimLight = (0.75F + 0.25F * Mth.sin(age * 0.18F)) * strength;
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            for (int at = 0; at + 4 < rim.length; at += 5) {
               float written = Mth.clamp((reach - rim[at + 4]) / 3.0F, 0.0F, 1.0F);
               if (!(written <= 0.0F)) {
                  float alpha = written * rimLight;
                  boolean alongU = rim[at + 1] == rim[at + 3];

                  for (float sign : new float[]{-0.09F, 0.09F}) {
                     float du = alongU ? 0.0F : sign;
                     float dv = alongU ? sign : 0.0F;
                     glow(consumer, pose, origin, u, v, rim[at], rim[at + 1], alpha);
                     glow(consumer, pose, origin, u, v, rim[at + 2], rim[at + 3], alpha);
                     glow(consumer, pose, origin, u, v, rim[at + 2] + du, rim[at + 3] + dv, 0.0F);
                     glow(consumer, pose, origin, u, v, rim[at] + du, rim[at + 1] + dv, 0.0F);
                  }
               }
            }
         });
         Vector3f right = new Vector3f(u).mul(facing != Direction.NORTH && facing != Direction.EAST ? 1.0F : -1.0F);
         Vector3f up = new Vector3f(v).mul(facing == Direction.UP ? -1.0F : 1.0F);
         List<SealEntity.Mark> marks = layout.marks();
         GlowBatch.add(
            ModRenderTypes.glowTextured(CIRCLE),
            poseStack,
            (consumer, pose, normal) -> {
               for (int k = 0; k < marks.size(); k++) {
                  SealEntity.Mark mark = marks.get(k);
                  float stamped = stamped(mark, reach);
                  if (!(stamped <= 0.0F)) {
                     Vector3f at = point(origin, u, v, mark.u(), mark.v());
                     float size = mark.radius() * stamped * (1.0F + 0.5F * shatter);
                     float turn = (k % 2 == 0 ? 1.0F : -1.0F) * age * 0.012F;
                     float light = 0.85F * strength;
                     GlowDraw.stamp(consumer, pose, normal, at, right, up, size, turn, GLOW[0] * light, GLOW[1] * light, GLOW[2] * light);
                     GlowDraw.stamp(
                        consumer,
                        pose,
                        normal,
                        at,
                        right,
                        up,
                        size * 0.66F,
                        -turn * 2.2F,
                        GLOW[0] * light * 0.8F,
                        GLOW[1] * light * 0.8F,
                        GLOW[2] * light * 0.8F
                     );
                  }
               }
            }
         );
         GlowBatch.add(
            ModRenderTypes.glowTextured(MARK),
            poseStack,
            (consumer, pose, normal) -> {
               for (SealEntity.Mark mark : marks) {
                  float stamped = stamped(mark, reach);
                  if (!(stamped <= 0.0F)) {
                     float fresh = Math.max(0.0F, 1.0F - (reach - mark.depth() - 2.0F) / 24.0F);
                     float light = (0.8F + 0.2F * Mth.sin(age * 0.1F) + fresh) * strength;
                     GlowDraw.stamp(
                        consumer,
                        pose,
                        normal,
                        point(origin, u, v, mark.u(), mark.v()),
                        right,
                        up,
                        mark.radius() * 0.36F * stamped * (1.0F + 0.5F * shatter),
                        0.0F,
                        PALE[0] * light,
                        PALE[1] * light,
                        PALE[2] * light
                     );
                  }
               }
            }
         );
         super.render(seal, yaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   private static float stamped(SealEntity.Mark mark, float reach) {
      return Easing.outBack((reach - mark.depth() - 2.0F) / 10.0F);
   }

   private static Vector3f point(Vector3f origin, Vector3f u, Vector3f v, float atU, float atV) {
      return new Vector3f(origin).add(u.x() * atU + v.x() * atV, u.y() * atU + v.y() * atV, u.z() * atU + v.z() * atV);
   }

   private static void corner(
      VertexConsumer consumer,
      Matrix4f pose,
      Pose normal,
      Vector3f origin,
      Vector3f u,
      Vector3f v,
      Vector3f out,
      float atU,
      float atV,
      float drift,
      float r,
      float g,
      float b,
      float texU,
      float texV
   ) {
      GlowDraw.texVertex(
         consumer,
         pose,
         normal,
         origin.x() + u.x() * atU + v.x() * atV + out.x() * drift,
         origin.y() + u.y() * atU + v.y() * atV + out.y() * drift,
         origin.z() + u.z() * atU + v.z() * atV + out.z() * drift,
         r,
         g,
         b,
         texU,
         texV
      );
   }

   private static void glow(VertexConsumer consumer, Matrix4f pose, Vector3f origin, Vector3f u, Vector3f v, float atU, float atV, float alpha) {
      GlowDraw.vertex(
         consumer,
         pose,
         origin.x() + u.x() * atU + v.x() * atV,
         origin.y() + u.y() * atU + v.y() * atV,
         origin.z() + u.z() * atU + v.z() * atV,
         PALE[0],
         PALE[1] * 0.7F,
         PALE[2] * 0.8F,
         alpha
      );
   }

   public ResourceLocation getTextureLocation(SealEntity seal) {
      return CIRCLE;
   }
}
