package com.amuletmod.client.renderer;

import com.amuletmod.client.TitanHands;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;

public class TitanFlameLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
   public TitanFlameLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
      super(parent);
   }

   public void render(
      PoseStack poseStack,
      MultiBufferSource buffers,
      int light,
      AbstractClientPlayer player,
      float limbSwing,
      float limbSwingAmount,
      float partialTick,
      float ageInTicks,
      float netHeadYaw,
      float headPitch
   ) {
      float[] colour = TitanHands.fire(player);
      if (colour != null && !player.isInvisible()) {
         PlayerModel<AbstractClientPlayer> model = (PlayerModel<AbstractClientPlayer>)this.getParentModel();
         sleeve(poseStack, buffers, model.rightArm, colour, ageInTicks);
         sleeve(poseStack, buffers, model.leftArm, colour, ageInTicks + 5.0F);
      }
   }

   private static void sleeve(PoseStack poseStack, MultiBufferSource buffers, ModelPart arm, float[] colour, float time) {
      if (arm.visible) {
         poseStack.pushPose();
         arm.translateAndRotate(poseStack);
         TitanHands.armSleeve(poseStack, buffers, arm, colour, time, true);
         poseStack.popPose();
      }
   }
}
