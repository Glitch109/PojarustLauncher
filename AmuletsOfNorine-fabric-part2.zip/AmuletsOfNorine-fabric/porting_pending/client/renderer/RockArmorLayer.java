package com.amuletmod.client.renderer;

import com.amuletmod.entity.RockShellEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderArmEvent;
import net.neoforged.neoforge.client.model.data.ModelData;

public class RockArmorLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
   private static final float FORM_TICKS = 4.0F;
   private final BlockRenderDispatcher blocks;

   public RockArmorLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent, BlockRenderDispatcher blocks) {
      super(parent);
      this.blocks = blocks;
   }

   public void render(
      PoseStack poseStack,
      MultiBufferSource buffers,
      int packedLight,
      AbstractClientPlayer player,
      float limbSwing,
      float limbSwingAmount,
      float partialTick,
      float ageInTicks,
      float netHeadYaw,
      float headPitch
   ) {
      RockShellEntity shell = RockShellEntity.clientShell(player);
      if (shell != null && !player.isInvisible()) {
         renderPlates(this.blocks, shell, (PlayerModel<?>)this.getParentModel(), null, poseStack, buffers, packedLight, partialTick);
      }
   }

   private static void renderPlates(
      BlockRenderDispatcher blocks,
      RockShellEntity shell,
      PlayerModel<?> model,
      RockShellEntity.Part only,
      PoseStack poseStack,
      MultiBufferSource buffers,
      int light,
      float partialTick
   ) {
      float age = shell.tickCount + partialTick;
      int left = shell.piecesLeft();
      List<BlockState> stones = shell.shellStates();

      for (int i = 0; i < RockShellEntity.PIECES; i++) {
         RockShellEntity.Piece piece = RockShellEntity.LAYOUT.get(i);
         if ((only == null || piece.part() == only) && RockShellEntity.attached(i, left)) {
            float grown = Mth.clamp((age - RockShellEntity.formsAt(i)) / 4.0F, 0.0F, 1.0F);
            if (!(grown <= 0.0F)) {
               float size = piece.size() / 16.0F * Easing.outBack(grown);
               poseStack.pushPose();
               part(model, piece.part()).translateAndRotate(poseStack);
               poseStack.translate(piece.x() / 16.0F, piece.y() / 16.0F, piece.z() / 16.0F);
               poseStack.mulPose(Axis.XP.rotationDegrees(piece.tiltX()));
               poseStack.mulPose(Axis.YP.rotationDegrees(piece.tiltY()));
               poseStack.mulPose(Axis.ZP.rotationDegrees(piece.tiltZ()));
               poseStack.scale(size, size, size);
               poseStack.translate(-0.5F, -0.5F, -0.5F);
               blocks.renderSingleBlock(stones.get(i % stones.size()), poseStack, buffers, light, OverlayTexture.NO_OVERLAY, ModelData.EMPTY, null);
               poseStack.popPose();
            }
         }
      }
   }

   private static ModelPart part(PlayerModel<?> model, RockShellEntity.Part part) {
      return switch (part) {
         case HEAD -> model.head;
         case BODY -> model.body;
         case RIGHT_ARM -> model.rightArm;
         case LEFT_ARM -> model.leftArm;
         case RIGHT_LEG -> model.rightLeg;
         case LEFT_LEG -> model.leftLeg;
      };
   }

   @EventBusSubscriber(
      modid = "amuletmod",
      value = {Dist.CLIENT}
   )
   public static final class FirstPerson {
      private FirstPerson() {
      }

      @SubscribeEvent
      public static void onRenderArm(RenderArmEvent event) {
         AbstractClientPlayer player = event.getPlayer();
         RockShellEntity shell = RockShellEntity.clientShell(player);
         if (shell != null && !player.isInvisible()) {
            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.getEntityRenderDispatcher().getRenderer(player) instanceof PlayerRenderer playerRenderer) {
               PlayerModel<AbstractClientPlayer> model = (PlayerModel<AbstractClientPlayer>)playerRenderer.getModel();
               model.attackTime = 0.0F;
               model.crouching = false;
               model.swimAmount = 0.0F;
               model.setupAnim(player, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
               boolean right = event.getArm() == HumanoidArm.RIGHT;
               (right ? model.rightArm : model.leftArm).xRot = 0.0F;
               RockArmorLayer.renderPlates(
                  minecraft.getBlockRenderer(),
                  shell,
                  model,
                  right ? RockShellEntity.Part.RIGHT_ARM : RockShellEntity.Part.LEFT_ARM,
                  event.getPoseStack(),
                  event.getMultiBufferSource(),
                  event.getPackedLight(),
                  minecraft.getTimer().getGameTimeDeltaPartialTick(true)
               );
            }
         }
      }
   }
}
