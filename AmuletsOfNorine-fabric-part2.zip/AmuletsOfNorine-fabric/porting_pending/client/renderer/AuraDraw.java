package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class AuraDraw {
   public static final ResourceLocation FLAME = AmuletMod.id("textures/misc/aura_flame.png");
   public static final ResourceLocation GLOW = AmuletMod.id("textures/misc/soft_glow.png");
   public static final float[][] AURORA = new float[][]{
      {0.18F, 1.0F, 0.55F}, {0.1F, 0.9F, 1.0F}, {0.3F, 0.5F, 1.0F}, {0.62F, 0.32F, 1.0F}, {1.0F, 0.35F, 0.85F}
   };
   public static final float[][] SHADOW = new float[][]{{0.4F, 0.2F, 0.95F}, {0.55F, 0.25F, 1.0F}, {0.25F, 0.3F, 0.95F}};
   public static final float[][] SMOKE = new float[][]{{0.03F, 0.0F, 0.06F}, {0.05F, 0.01F, 0.1F}};
   public static final float[][] WHITE = new float[][]{{1.0F, 1.0F, 1.0F}};
   private static final int MAX_SEGMENTS = 10;

   private AuraDraw() {
   }

   public static void palette(float[][] colors, float t, float[] out) {
      int count = colors.length;
      float x = (t % count + count) % count;
      int i = (int)x;
      float f = x - i;
      float[] a = colors[i % count];
      float[] b = colors[(i + 1) % count];
      out[0] = Mth.lerp(f, a[0], b[0]);
      out[1] = Mth.lerp(f, a[1], b[1]);
      out[2] = Mth.lerp(f, a[2], b[2]);
   }

   private static float random(int seed, int i, int salt) {
      int h = seed * -1640531535 + i * -2048144789 + salt * -1028477387;
      h ^= h >>> 15;
      h *= 739982445;
      h ^= h >>> 12;
      h *= 695872825;
      h ^= h >>> 15;
      return (h >>> 8) / 1.6777216E7F;
   }

   public static float baseRadius(float width, float strength) {
      return width * 0.5F + 0.12F + strength * 1.6F;
   }

   public static float reach(float height, float strength) {
      return height * (1.05F + 0.35F * strength) + strength * 2.0F + strength * strength * 7.0F;
   }

   public static void flames(
      VertexConsumer consumer,
      Matrix4f pose,
      Vector3f eye,
      float width,
      float height,
      float strength,
      float time,
      int seed,
      int tongues,
      int segments,
      float brightness,
      float[][] colors,
      float hueSpan,
      boolean additive
   ) {
      segments = Math.min(segments, 10);
      float radius = baseRadius(width, strength);
      float reach = reach(height, strength);
      float spread = -0.3F + 1.5F * strength;
      float halfWidth = 0.12F + 0.26F * strength + 0.06F * width;
      float speed = 0.035F + 0.02F * strength;
      float[] xs = new float[segments + 1];
      float[] ys = new float[segments + 1];
      float[] zs = new float[segments + 1];
      float[] color = new float[3];
      Vector3f along = new Vector3f();
      Vector3f toEye = new Vector3f();
      Vector3f side = new Vector3f();

      for (int i = 0; i < tongues; i++) {
         float a = random(seed, i, 1);
         float b = random(seed, i, 2);
         float c = random(seed, i, 3);
         float d = random(seed, i, 4);
         float theta = (i + a * 0.7F) / tongues * (float) (Math.PI * 2) + time * 0.004F * (b - 0.5F);
         float lick = 0.78F + 0.22F * Mth.sin(time * (0.11F + 0.06F * b) + a * 20.0F);
         float length = reach * (0.5F + 0.5F * c) * lick;
         float start = radius * (0.85F + 0.25F * d);
         float twist = (b - 0.5F) * 0.9F + strength * 0.5F;
         float hue = i * 5.0F / tongues + time * 0.01F;
         float scroll = time * speed * (0.8F + 0.4F * b) + a * 5.0F;

         for (int k = 0; k <= segments; k++) {
            float s = (float)k / segments;
            float out = Math.max(0.3F, 1.0F + spread * (float)Math.pow(s, 1.4));
            float angle = theta + twist * s + 0.3F * s * Mth.sin(time * 0.07F + s * 4.0F + a * 12.0F);
            xs[k] = Mth.cos(angle) * start * out;
            ys[k] = s * length;
            zs[k] = Mth.sin(angle) * start * out;
         }

         float prevLeftX = 0.0F;
         float prevLeftY = 0.0F;
         float prevLeftZ = 0.0F;
         float prevRightX = 0.0F;
         float prevRightY = 0.0F;
         float prevRightZ = 0.0F;
         float prevR = 0.0F;
         float prevG = 0.0F;
         float prevB = 0.0F;
         float prevA = 0.0F;
         float prevV = 0.0F;

         for (int k = 0; k <= segments; k++) {
            float s = (float)k / segments;
            int next = Math.min(k + 1, segments);
            int prev = Math.max(k - 1, 0);
            along.set(xs[next] - xs[prev], ys[next] - ys[prev], zs[next] - zs[prev]);
            toEye.set(eye.x() - xs[k], eye.y() - ys[k], eye.z() - zs[k]);
            along.cross(toEye, side);
            float w = halfWidth * (0.3F + 0.7F * Mth.sin((float) Math.PI * Math.min(1.0F, 0.15F + s * 1.1F))) * Mth.sqrt(1.0F - s);
            if (side.lengthSquared() < 1.0E-8F) {
               side.set(w, 0.0F, 0.0F);
            } else {
               side.normalize(w);
            }

            float fade = (0.3F + 0.7F * Easing.smoothstep(0.0F, 0.1F, s)) * (1.0F - Easing.smoothstep(0.45F, 1.0F, s)) * brightness;
            palette(colors, hue + s * hueSpan, color);
            float r = color[0];
            float g = color[1];
            float bl = color[2];
            float alpha = 1.0F;
            if (additive) {
               r *= fade;
               g *= fade;
               bl *= fade;
            } else {
               alpha = fade;
            }

            float v = ys[k] * 0.45F - scroll;
            float leftX = xs[k] - side.x;
            float leftY = ys[k] - side.y;
            float leftZ = zs[k] - side.z;
            float rightX = xs[k] + side.x;
            float rightY = ys[k] + side.y;
            float rightZ = zs[k] + side.z;
            if (k > 0) {
               vertex(consumer, pose, prevLeftX, prevLeftY, prevLeftZ, prevR, prevG, prevB, prevA, 0.0F, prevV);
               vertex(consumer, pose, prevRightX, prevRightY, prevRightZ, prevR, prevG, prevB, prevA, 1.0F, prevV);
               vertex(consumer, pose, rightX, rightY, rightZ, r, g, bl, alpha, 1.0F, v);
               vertex(consumer, pose, leftX, leftY, leftZ, r, g, bl, alpha, 0.0F, v);
            }

            prevLeftX = leftX;
            prevLeftY = leftY;
            prevLeftZ = leftZ;
            prevRightX = rightX;
            prevRightY = rightY;
            prevRightZ = rightZ;
            prevR = r;
            prevG = g;
            prevB = bl;
            prevA = alpha;
            prevV = v;
         }
      }
   }

   public static void curtains(
      VertexConsumer consumer, Matrix4f pose, float width, float height, float strength, float time, int seed, float brightness, float[][] colors
   ) {
      float amount = Easing.smoothstep(0.3F, 0.85F, strength) * brightness;
      if (!(amount <= 0.005F)) {
         float radius = baseRadius(width, strength);
         float reach = reach(height, strength);
         int count = strength > 0.7F ? 3 : 2;
         int segments = 24;
         float[] color = new float[3];

         for (int j = 0; j < count; j++) {
            float phase = j * (float) (Math.PI * 2) / count + random(seed, j, 9) * 2.0F + time * 0.006F;
            float prevBx = 0.0F;
            float prevBy = 0.0F;
            float prevBz = 0.0F;
            float prevTx = 0.0F;
            float prevTy = 0.0F;
            float prevTz = 0.0F;
            float prevR = 0.0F;
            float prevG = 0.0F;
            float prevB = 0.0F;
            float prevU = 0.0F;

            for (int m = 0; m <= segments; m++) {
               float u = (float)m / segments;
               float angle = phase + u * 4.4F;
               float out = radius * (1.15F + 1.8F * u) * (1.0F + 0.08F * Mth.sin(time * 0.05F + u * 7.0F + j));
               float bottom = 0.2F + u * reach * 0.8F + 0.25F * Mth.sin(time * 0.04F + u * 5.0F + j * 2.0F);
               float tall = (0.9F + 2.6F * strength) * (0.55F + 0.45F * Mth.sin((float) Math.PI * u));
               float cos = Mth.cos(angle);
               float sin = Mth.sin(angle);
               float bx = cos * out;
               float bz = sin * out;
               float tx = bx * 1.08F;
               float tz = bz * 1.08F;
               float fade = Easing.smoothstep(0.0F, 0.12F, u) * (1.0F - Easing.smoothstep(0.8F, 1.0F, u)) * amount * 0.9F;
               palette(colors, j * 1.3F + u * 2.5F + time * 0.01F, color);
               float r = color[0] * fade;
               float g = color[1] * fade;
               float b = color[2] * fade;
               float texU = u * 5.0F + time * 0.004F;
               if (m > 0) {
                  vertex(consumer, pose, prevBx, prevBy, prevBz, prevR, prevG, prevB, 1.0F, prevU, 0.9F);
                  vertex(consumer, pose, bx, bottom, bz, r, g, b, 1.0F, texU, 0.9F);
                  vertex(consumer, pose, tx, bottom + tall, tz, 0.0F, 0.0F, 0.0F, 1.0F, texU, 0.1F);
                  vertex(consumer, pose, prevTx, prevTy, prevTz, 0.0F, 0.0F, 0.0F, 1.0F, prevU, 0.1F);
               }

               prevBx = bx;
               prevBy = bottom;
               prevBz = bz;
               prevTx = tx;
               prevTy = bottom + tall;
               prevTz = tz;
               prevR = r;
               prevG = g;
               prevB = b;
               prevU = texU;
            }
         }
      }
   }

   public static void pool(VertexConsumer consumer, Matrix4f pose, float radius, float r, float g, float b) {
      vertex(consumer, pose, -radius, 0.03F, -radius, r, g, b, 1.0F, 0.0F, 0.0F);
      vertex(consumer, pose, -radius, 0.03F, radius, r, g, b, 1.0F, 0.0F, 1.0F);
      vertex(consumer, pose, radius, 0.03F, radius, r, g, b, 1.0F, 1.0F, 1.0F);
      vertex(consumer, pose, radius, 0.03F, -radius, r, g, b, 1.0F, 1.0F, 0.0F);
   }

   private static void vertex(VertexConsumer consumer, Matrix4f pose, float x, float y, float z, float r, float g, float b, float a, float u, float v) {
      consumer.addVertex(pose, x, y, z)
         .setUv(u, v)
         .setColor(Mth.clamp(r, 0.0F, 1.0F), Mth.clamp(g, 0.0F, 1.0F), Mth.clamp(b, 0.0F, 1.0F), Mth.clamp(a, 0.0F, 1.0F));
   }
}
