package com.amuletmod.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.item.ItemColors;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.client.model.data.ModelData;
import org.jetbrains.annotations.Nullable;

public final class GhostItem {
   public static final float HALF_LENGTH = 0.62F;
   private static final Direction[] FACES = Direction.values();
   private static final RandomSource RANDOM = RandomSource.create();

   private GhostItem() {
   }

   public static void render(ItemStack stack, PoseStack poseStack, MultiBufferSource buffers, float r, float g, float b, float alpha, @Nullable Level level) {
      if (!stack.isEmpty() && !(alpha <= 0.01F)) {
         Minecraft minecraft = Minecraft.getInstance();
         ItemRenderer items = minecraft.getItemRenderer();
         BakedModel model = items.getModel(stack, level, null, 0);
         poseStack.pushPose();
         poseStack.mulPose(Axis.ZP.rotationDegrees(45.0F));
         if (model.isCustomRenderer()) {
            if (alpha > 0.5F) {
               items.renderStatic(stack, ItemDisplayContext.NONE, 15728880, OverlayTexture.NO_OVERLAY, poseStack, buffers, level, 0);
            }
         } else {
            poseStack.translate(-0.5F, -0.5F, -0.5F);
            VertexConsumer consumer = buffers.getBuffer(ModRenderTypes.phantom(InventoryMenu.BLOCK_ATLAS));
            Pose pose = poseStack.last();
            ItemColors colors = minecraft.getItemColors();

            for (BakedModel pass : model.getRenderPasses(stack, true)) {
               for (Direction face : FACES) {
                  quads(consumer, pose, pass, face, stack, colors, r, g, b, alpha);
               }

               quads(consumer, pose, pass, null, stack, colors, r, g, b, alpha);
            }
         }

         poseStack.popPose();
      }
   }

   private static void quads(
      VertexConsumer consumer,
      Pose pose,
      BakedModel model,
      @Nullable Direction face,
      ItemStack stack,
      ItemColors colors,
      float r,
      float g,
      float b,
      float alpha
   ) {
      RANDOM.setSeed(42L);

      for (BakedQuad quad : model.getQuads(null, face, RANDOM, ModelData.EMPTY, null)) {
         float qr = r;
         float qg = g;
         float qb = b;
         if (quad.isTinted()) {
            int colour = colors.getColor(stack, quad.getTintIndex());
            qr = r * ((colour >> 16 & 0xFF) / 255.0F);
            qg = g * ((colour >> 8 & 0xFF) / 255.0F);
            qb = b * ((colour & 0xFF) / 255.0F);
         }

         consumer.putBulkData(pose, quad, qr, qg, qb, alpha, 15728880, OverlayTexture.NO_OVERLAY, true);
      }
   }
}
