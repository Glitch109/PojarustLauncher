package com.amuletmod.client.renderer;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import java.util.function.Function;
import net.minecraft.Util;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.RenderStateShard.MultiTextureStateShard;
import net.minecraft.client.renderer.RenderStateShard.ShaderStateShard;
import net.minecraft.client.renderer.RenderStateShard.TextureStateShard;
import net.minecraft.client.renderer.RenderType.CompositeState;
import net.minecraft.client.renderer.RenderType.CompositeState.CompositeStateBuilder;
import net.minecraft.client.renderer.blockentity.TheEndPortalRenderer;
import net.minecraft.resources.ResourceLocation;

public final class ModRenderTypes extends RenderType {
   private static final ShaderStateShard TEX_COLOR_SHADER = new ShaderStateShard(GameRenderer::getPositionTexColorShader);
   public static final RenderType GLOW = create(
      "amuletmod_glow",
      DefaultVertexFormat.POSITION_COLOR,
      Mode.QUADS,
      4096,
      false,
      false,
      CompositeState.builder()
         .setShaderState(RENDERTYPE_LIGHTNING_SHADER)
         .setTransparencyState(LIGHTNING_TRANSPARENCY)
         .setWriteMaskState(COLOR_WRITE)
         .setCullState(NO_CULL)
         .setLayeringState(POLYGON_OFFSET_LAYERING)
         .createCompositeState(false)
   );
   public static final RenderType END_WINDOW = create(
      "amuletmod_end_window",
      DefaultVertexFormat.POSITION,
      Mode.QUADS,
      256,
      false,
      false,
      CompositeState.builder()
         .setShaderState(RENDERTYPE_END_PORTAL_SHADER)
         .setTextureState(
            MultiTextureStateShard.builder()
               .add(TheEndPortalRenderer.END_SKY_LOCATION, false, false)
               .add(TheEndPortalRenderer.END_PORTAL_LOCATION, false, false)
               .build()
         )
         .setCullState(NO_CULL)
         .createCompositeState(false)
   );
   public static final RenderType CONTAINMENT_VOID = create(
      "amuletmod_containment_void",
      DefaultVertexFormat.POSITION_TEX_COLOR,
      Mode.QUADS,
      256,
      false,
      false,
      CompositeState.builder()
         .setShaderState(new ShaderStateShard(SubspaceWalls::shader))
         .setTextureState(
            MultiTextureStateShard.builder()
               .add(TheEndPortalRenderer.END_SKY_LOCATION, false, false)
               .add(TheEndPortalRenderer.END_PORTAL_LOCATION, false, false)
               .build()
         )
         .setCullState(NO_CULL)
         .createCompositeState(false)
   );
   private static final Function<ResourceLocation, RenderType> GLOW_TEXTURED = Util.memoize(
      texture -> create(
         "amuletmod_glow_textured",
         DefaultVertexFormat.NEW_ENTITY,
         Mode.QUADS,
         4096,
         false,
         false,
         CompositeState.builder()
            .setShaderState(RENDERTYPE_EYES_SHADER)
            .setTextureState(new TextureStateShard(texture, false, false))
            .setTransparencyState(ADDITIVE_TRANSPARENCY)
            .setWriteMaskState(COLOR_WRITE)
            .setCullState(NO_CULL)
            .setLayeringState(POLYGON_OFFSET_LAYERING)
            .createCompositeState(false)
      )
   );
   private static final Function<ResourceLocation, RenderType> PHANTOM = Util.memoize(
      texture -> create(
         "amuletmod_phantom",
         DefaultVertexFormat.NEW_ENTITY,
         Mode.QUADS,
         256,
         true,
         true,
         CompositeState.builder()
            .setShaderState(RENDERTYPE_ENTITY_TRANSLUCENT_EMISSIVE_SHADER)
            .setTextureState(new TextureStateShard(texture, false, false))
            .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
            .setCullState(NO_CULL)
            .setOverlayState(OVERLAY)
            .createCompositeState(true)
      )
   );
   public static final RenderType GLOW_XRAY = create(
      "amuletmod_glow_xray",
      DefaultVertexFormat.POSITION_COLOR,
      Mode.QUADS,
      1024,
      false,
      false,
      CompositeState.builder()
         .setShaderState(RENDERTYPE_LIGHTNING_SHADER)
         .setTransparencyState(LIGHTNING_TRANSPARENCY)
         .setWriteMaskState(COLOR_WRITE)
         .setCullState(NO_CULL)
         .setDepthTestState(NO_DEPTH_TEST)
         .createCompositeState(false)
   );
   private static final Function<ResourceLocation, RenderType> SKY_GLOW = Util.memoize(
      texture -> create(
         "amuletmod_sky_glow",
         DefaultVertexFormat.POSITION_TEX_COLOR,
         Mode.QUADS,
         1024,
         false,
         false,
         skyGlowState(texture).setDepthTestState(LEQUAL_DEPTH_TEST).createCompositeState(false)
      )
   );
   private static final Function<ResourceLocation, RenderType> SKY_GLOW_XRAY = Util.memoize(
      texture -> create(
         "amuletmod_sky_glow_xray",
         DefaultVertexFormat.POSITION_TEX_COLOR,
         Mode.QUADS,
         1024,
         false,
         false,
         skyGlowState(texture).setDepthTestState(NO_DEPTH_TEST).createCompositeState(false)
      )
   );
   public static final RenderType SHADE_FLAT = create(
      "amuletmod_shade_flat",
      DefaultVertexFormat.POSITION_COLOR,
      Mode.QUADS,
      1024,
      false,
      false,
      CompositeState.builder()
         .setShaderState(POSITION_COLOR_SHADER)
         .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
         .setWriteMaskState(COLOR_WRITE)
         .setCullState(NO_CULL)
         .setLayeringState(POLYGON_OFFSET_LAYERING)
         .createCompositeState(false)
   );
   private static final Function<ResourceLocation, RenderType> SHADE = Util.memoize(
      texture -> create(
         "amuletmod_shade",
         DefaultVertexFormat.POSITION_TEX_COLOR,
         Mode.QUADS,
         1024,
         false,
         false,
         CompositeState.builder()
            .setShaderState(TEX_COLOR_SHADER)
            .setTextureState(new TextureStateShard(texture, false, false))
            .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
            .setWriteMaskState(COLOR_WRITE)
            .setCullState(NO_CULL)
            .createCompositeState(false)
      )
   );

   private static CompositeStateBuilder skyGlowState(ResourceLocation texture) {
      return CompositeState.builder()
         .setShaderState(TEX_COLOR_SHADER)
         .setTextureState(new TextureStateShard(texture, false, false))
         .setTransparencyState(ADDITIVE_TRANSPARENCY)
         .setWriteMaskState(COLOR_WRITE)
         .setCullState(NO_CULL);
   }

   private ModRenderTypes(
      String name, VertexFormat format, Mode mode, int bufferSize, boolean affectsCrumbling, boolean sortOnUpload, Runnable setupState, Runnable clearState
   ) {
      super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setupState, clearState);
      throw new UnsupportedOperationException();
   }

   public static RenderType phantom(ResourceLocation texture) {
      return PHANTOM.apply(texture);
   }

   public static RenderType glowTextured(ResourceLocation texture) {
      return GLOW_TEXTURED.apply(texture);
   }

   public static RenderType skyGlow(ResourceLocation texture) {
      return SKY_GLOW.apply(texture);
   }

   public static RenderType skyGlowXray(ResourceLocation texture) {
      return SKY_GLOW_XRAY.apply(texture);
   }

   public static RenderType shade(ResourceLocation texture) {
      return SHADE.apply(texture);
   }
}
