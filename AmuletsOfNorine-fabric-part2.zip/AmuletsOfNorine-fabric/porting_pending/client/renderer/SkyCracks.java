package com.amuletmod.client.renderer;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class SkyCracks {
   private static final int SPOKES = 13;
   private static final int RINGS = 9;
   private static final int SPOKE_POINTS = 28;
   private static final int ARC_POINTS = 6;
   private static final float FARTHEST = (float) (Math.PI * 4.0 / 5.0);
   private static final float[] CORE = new float[]{1.0F, 0.93F, 1.0F};
   private static final float[] MAGENTA = new float[]{1.0F, 0.42F, 0.95F};

   private SkyCracks() {
   }

   public static void render(BufferSource buffers, Matrix4f pose, Vector3f rift, float distance, int seed, float broken, float reach, float time) {
      if (!(broken < 0.001F) && !(reach < 0.001F)) {
         Vector3f axis = new Vector3f(rift).normalize();
         Vector3f side = new Vector3f(axis).cross(0.0F, 1.0F, 0.0F);
         if (side.lengthSquared() < 1.0E-5F) {
            side.set(1.0F, 0.0F, 0.0F);
         }

         side.normalize();
         Vector3f up = new Vector3f(side).cross(axis);
         RandomSource random = RandomSource.create(seed);
         float[] spokes = new float[13];

         for (int k = 0; k < 13; k++) {
            spokes[k] = (k + 0.5F + (random.nextFloat() - 0.5F) * 0.6F) / 13.0F * (float) (Math.PI * 2);
         }

         float[] offsets = new float[13];
         float[] bows = new float[13];

         for (int k = 0; k < 13; k++) {
            offsets[k] = (random.nextFloat() - 0.5F) * 0.9F;
            bows[k] = (random.nextFloat() - 0.35F) * 0.08F;
         }

         float end = Math.min(reach * (float) Math.PI, (float) (Math.PI * 4.0 / 5.0));
         float width = distance * 0.0025F;
         float alpha = broken * (0.85F + 0.15F * Mth.sin(time * 5.0F));
         List<Vector3f[]> lines = new ArrayList<>();
         List<Vector3f> line = new ArrayList<>();

         for (int k = 0; k < 13; k++) {
            for (int i = 0; i <= 28; i++) {
               float theta = 0.01F + (end - 0.01F) * i / 28.0F;
               add(lines, line, direction(axis, side, up, theta, spoke(spokes, k, theta, seed)), distance);
            }

            finish(lines, line);
         }

         for (int ring = 1; ring < 9; ring++) {
            for (int k = 0; k < 13; k++) {
               float out = (ring - offsets[k]) / 9.0F;
               float theta = (float) Math.PI * out * out;
               if (!(out <= 0.0F) && !(theta > end)) {
                  float from = spoke(spokes, k, theta, seed);
                  float to = spoke(spokes, (k + 1) % 13, theta, seed) + (k + 1 == 13 ? (float) (Math.PI * 2) : 0.0F);

                  for (int i = 0; i <= 6; i++) {
                     float u = i / 6.0F;
                     add(lines, line, direction(axis, side, up, theta + bows[k] * Mth.sin(u * (float) Math.PI), Mth.lerp(u, from, to)), distance);
                  }

                  finish(lines, line);
               }
            }
         }

         float fogStart = RenderSystem.getShaderFogStart();
         RenderSystem.setShaderFogStart(Float.MAX_VALUE);
         VertexConsumer consumer = buffers.getBuffer(ModRenderTypes.GLOW);
         Vector3f camera = new Vector3f();

         for (Vector3f[] points : lines) {
            GlowDraw.ribbon(consumer, pose, points, camera, width, CORE[0], CORE[1], CORE[2], alpha);
            GlowDraw.ribbon(consumer, pose, points, camera, width * 5.0F, MAGENTA[0], MAGENTA[1], MAGENTA[2], 0.35F * alpha);
         }

         buffers.endBatch(ModRenderTypes.GLOW);
         RenderSystem.setShaderFogStart(fogStart);
      }
   }

   private static float spoke(float[] spokes, int k, float theta, int seed) {
      return spokes[k] + 0.16F * Mth.sin(theta * 4.0F + k * 1.7F + seed) + 0.04F * Mth.sin(theta * 15.0F + k * 3.1F);
   }

   private static Vector3f direction(Vector3f axis, Vector3f side, Vector3f up, float theta, float phi) {
      float sin = Mth.sin(theta);
      return new Vector3f(axis).mul(Mth.cos(theta)).add(new Vector3f(side).mul(sin * Mth.cos(phi))).add(new Vector3f(up).mul(sin * Mth.sin(phi)));
   }

   private static void add(List<Vector3f[]> lines, List<Vector3f> line, Vector3f direction, float distance) {
      if (direction.y() < 0.02F) {
         finish(lines, line);
      } else {
         line.add(direction.mul(distance));
      }
   }

   private static void finish(List<Vector3f[]> lines, List<Vector3f> line) {
      if (line.size() >= 2) {
         lines.add(line.toArray(new Vector3f[0]));
      }

      line.clear();
   }
}
