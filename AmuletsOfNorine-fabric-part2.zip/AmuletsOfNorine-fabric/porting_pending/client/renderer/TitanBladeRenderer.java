package com.amuletmod.client.renderer;

import com.amuletmod.client.TitanHud;
import com.amuletmod.entity.TitanBladeEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import org.joml.Matrix3f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class TitanBladeRenderer extends EntityRenderer<TitanBladeEntity> {
   private static final float[] STEEL = new float[]{0.82F, 0.92F, 1.0F};
   private static final float[] BLUE = TitanHud.BLUE;
   private static final float[] WHITE = new float[]{0.9F, 0.96F, 1.0F};
   private static final Vector3f UP = new Vector3f(0.0F, 1.0F, 0.0F);
   private static final float MAX_ROLL = (float) (Math.PI / 2);
   private static final double AIM_REACH = 64.0;
   private static int aimOwner = -1;
   private static float aimFrame = Float.NaN;
   private static Vec3 aimPoint = Vec3.ZERO;

   public TitanBladeRenderer(Context context) {
      super(context);
   }

   public void render(TitanBladeEntity blade, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      byte phase = blade.phase();
      if (phase != 3) {
         float age = blade.tickCount + partialTick;
         float since = blade.sincePhase(age);
         Vec3 position = blade.getPosition(partialTick);
         boolean stuck = blade.face() != null;
         if (stuck) {
            float alpha = phase == 4 ? 1.0F - Mth.clamp(since / 16.0F, 0.0F, 1.0F) : 1.0F;
            Vector3f shift = blade.to().subtract(position).toVector3f();
            Vector3f heading = blade.heading().toVector3f();
            Vector3f centre = new Vector3f(heading).mul(-0.27F).add(shift);
            Quaternionf pose = aimed(blade, heading);
            if (phase == 2 && since < 10.0F) {
               pose.mul(Axis.XP.rotationDegrees(5.0F * (float)Math.exp(-since / 3.0F) * Mth.sin(since * 2.6F)));
            }

            sword(blade, poseStack, buffers, centre, pose, 1.0F, 0.95F * alpha);
            cracks(blade, poseStack, shift, phase == 2 ? since : 70.0F, alpha);
         } else {
            Entity owner = phase != 4 ? blade.owner() : null;
            Vec3 feet = owner != null ? owner.getPosition(partialTick) : position;
            Vec3 base = owner != null ? TitanBladeEntity.place(feet, owner.getViewYRot(partialTick), blade.offset()) : position;
            Vector3f shift = base.subtract(position).toVector3f();
            float hilt = -0.67F;
            circle(blade, poseStack, age, new Vector3f(shift).add(0.0F, hilt, 0.0F));
            float rise = Easing.outBack(Mth.clamp(age / 8.0F, 0.0F, 1.0F));
            float size = 0.15F + 0.85F * rise;
            float bob = 0.05F * Mth.sin(age * 0.12F + blade.slot() * 1.7F) * Mth.clamp((age - 8.0F) / 10.0F, 0.0F, 1.0F);
            Vector3f centre = new Vector3f(shift).add(0.0F, hilt + 0.62F * size + bob, 0.0F);
            Vector3f toward = feet.subtract(base).toVector3f().mul(1.0F, 0.0F, 1.0F);
            if (toward.lengthSquared() < 1.0E-4F) {
               toward.set(0.0F, 0.0F, 1.0F);
            }

            Quaternionf pose = facing(UP, toward.normalize());
            if (phase == 1 && owner != null) {
               Vec3 centreAt = base.add(0.0, centre.y() - shift.y(), 0.0);
               Vector3f aim = aim(owner, partialTick).subtract(centreAt).toVector3f();
               if (aim.lengthSquared() < 1.0F) {
                  aim = owner.getViewVector(partialTick).toVector3f();
               }

               float turned = Easing.smoothstep(0.0F, 10.0F, since);
               pose = new Quaternionf(pose).slerp(aimed(blade, aim.normalize()), turned);
            }

            float alpha = phase == 4 ? 1.0F - Mth.clamp(since / 16.0F, 0.0F, 1.0F) : 0.92F;
            sword(blade, poseStack, buffers, centre, pose, size, alpha);
         }

         super.render(blade, entityYaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   private static Vec3 aim(Entity owner, float partialTick) {
      float frame = owner.tickCount + partialTick;
      if (owner.getId() != aimOwner || frame != aimFrame) {
         Vec3 eye = owner.getEyePosition(partialTick);
         Vec3 end = eye.add(owner.getViewVector(partialTick).scale(64.0));
         BlockHitResult hit = owner.level().clip(new ClipContext(eye, end, Block.COLLIDER, Fluid.NONE, owner));
         aimPoint = hit.getType() == Type.MISS ? end : hit.getLocation();
         aimOwner = owner.getId();
         aimFrame = frame;
      }

      return aimPoint;
   }

   private static Quaternionf aimed(TitanBladeEntity blade, Vector3f along) {
      int hash = blade.getId() * -1640531527;
      hash ^= hash >>> 15;
      float roll = ((hash >>> 8) / 1.6777216E7F * 2.0F - 1.0F) * (float) (Math.PI / 2);
      return facing(along, UP).mul(Axis.YP.rotation(roll));
   }

   private static Quaternionf facing(Vector3f along, Vector3f flat) {
      Vector3f y = new Vector3f(along).normalize();
      Vector3f z = new Vector3f(flat).sub(new Vector3f(y).mul(flat.dot(y)));
      if (z.lengthSquared() < 1.0E-6F) {
         z = perpendicular(y);
      }

      z.normalize();
      Vector3f x = new Vector3f(y).cross(z);
      return new Quaternionf().setFromNormalized(new Matrix3f(x, y, z));
   }

   private static Vector3f perpendicular(Vector3f v) {
      Vector3f other = Math.abs(v.y()) < 0.9F ? new Vector3f(0.0F, 1.0F, 0.0F) : new Vector3f(1.0F, 0.0F, 0.0F);
      return new Vector3f(v).cross(other).normalize();
   }

   private static void sword(TitanBladeEntity blade, PoseStack poseStack, MultiBufferSource buffers, Vector3f centre, Quaternionf pose, float size, float alpha) {
      if (!(alpha <= 0.01F)) {
         poseStack.pushPose();
         poseStack.translate(centre.x(), centre.y(), centre.z());
         poseStack.mulPose(pose);
         poseStack.scale(size, size, size);
         GhostItem.render(blade.weapon(), poseStack, buffers, STEEL[0], STEEL[1], STEEL[2], alpha, blade.level());
         poseStack.scale(1.1F, 1.05F, 1.6F);
         GhostItem.render(blade.weapon(), poseStack, buffers, BLUE[0], BLUE[1], BLUE[2], 0.22F * alpha, blade.level());
         poseStack.popPose();
      }
   }

   private static void circle(TitanBladeEntity blade, PoseStack poseStack, float age, Vector3f at) {
      if (blade.phase() == 0) {
         float light = 1.0F - Easing.smoothstep(12.0F, 18.0F, age);
         if (!(light <= 0.01F)) {
            float size = 0.55F * Easing.outBack(Mth.clamp(age / 5.0F, 0.0F, 1.0F));
            float spin = age * 0.15F + blade.slot();
            Vector3f right = new Vector3f(1.0F, 0.0F, 0.0F);
            Vector3f forward = new Vector3f(0.0F, 0.0F, 1.0F);
            GlowBatch.add(
               ModRenderTypes.glowTextured(TitanFistRenderer.CIRCLE),
               poseStack,
               (consumer, pose, normal) -> {
                  GlowDraw.stamp(consumer, pose, normal, at, right, forward, size, spin, BLUE[0] * light, BLUE[1] * light, BLUE[2] * light);
                  GlowDraw.stamp(
                     consumer,
                     pose,
                     normal,
                     new Vector3f(at).add(0.0F, 0.01F, 0.0F),
                     right,
                     forward,
                     size * 0.45F,
                     -spin * 2.0F,
                     WHITE[0] * 0.7F * light,
                     WHITE[1] * 0.7F * light,
                     WHITE[2] * 0.7F * light
                  );
               }
            );
         }
      }
   }

   private static void cracks(TitanBladeEntity blade, PoseStack poseStack, Vector3f shift, float sinceLodged, float alpha) {
      Direction face = blade.face();
      if (face != null && !(alpha <= 0.01F)) {
         Vector3f normal = new Vector3f(face.getStepX(), face.getStepY(), face.getStepZ());
         Vector3f right = face.getAxis() == net.minecraft.core.Direction.Axis.X ? new Vector3f(0.0F, 0.0F, 1.0F) : new Vector3f(1.0F, 0.0F, 0.0F);
         Vector3f up = new Vector3f(normal).cross(right).normalize();
         Vector3f at = new Vector3f(normal).mul(0.015F).add(shift);
         float size = 0.6F * Easing.outCubic(Mth.clamp(sinceLodged / 3.0F, 0.0F, 1.0F));
         float turn = blade.getId() * 2.39996F;
         float heat = 1.2F * (1.0F - Easing.smoothstep(0.0F, 25.0F, sinceLodged)) * alpha;
         GlowBatch.add(
            ModRenderTypes.shade(TitanFistRenderer.CRACKS),
            poseStack,
            (consumer, pose, matrix) -> TitanFistRenderer.shadeStamp(consumer, pose, at, right, up, size, turn, 0.8F * alpha, TitanFistRenderer.SMOKE)
         );
         if (heat > 0.01F) {
            GlowBatch.add(
               ModRenderTypes.glowTextured(TitanFistRenderer.CRACKS),
               poseStack,
               (consumer, pose, matrix) -> GlowDraw.stamp(
                  consumer, pose, matrix, new Vector3f(normal).mul(0.02F).add(shift), right, up, size, turn, BLUE[0] * heat, BLUE[1] * heat, BLUE[2] * heat
               )
            );
         }
      }
   }

   public ResourceLocation getTextureLocation(TitanBladeEntity blade) {
      return TitanFistRenderer.CIRCLE;
   }
}
