package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.librarian.PageLook;
import com.amuletmod.entity.PageEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class PageRenderer extends EntityRenderer<PageEntity> {
   private static final ResourceLocation PAGE = AmuletMod.id("textures/entity/page.png");
   private static final float HALF_WIDTH = 0.2F;
   private static final float HALF_HEIGHT = 0.27F;
   private static final float U0 = 0.125F;
   private static final float U1 = 0.875F;
   private static final float HOLD_SPIN = 34.0F;
   private static final float FLIGHT_SPIN = 55.0F;
   private static final float LEAN = (float) (Math.PI / 4);
   private static final float ROLL = (float) (Math.PI * 2.0 / 9.0);
   private static final float TURN_TICKS = 3.0F;
   private static final Vector3f FORWARD = new Vector3f(0.0F, 0.0F, 1.0F);
   private static final Vec3 UP = new Vec3(0.0, 1.0, 0.0);

   public PageRenderer(Context context) {
      super(context);
   }

   public void render(PageEntity page, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float age = page.tickCount + partialTick;
      int slot = page.slot();
      int volley = page.volley();
      Entity thrower = page.thrower();
      Vec3 at = page.getPosition(partialTick);
      Vec3 drawn;
      Vector3f facing;
      float spin;
      if (!page.isFlying()) {
         if (thrower == null) {
            return;
         }

         drawn = PageEntity.holdPosition(thrower, slot, volley, partialTick);
         facing = towards(drawn, thrower.getEyePosition(partialTick));
         spin = age * 34.0F;
      } else {
         drawn = at.add(page.flingOffset(partialTick));
         facing = flightFacing(page, slot, volley);
         float turned = Mth.clamp((age - page.flungAt()) / 3.0F, 0.0F, 1.0F);
         if (turned < 1.0F && thrower != null) {
            facing = towards(drawn, thrower.getEyePosition(partialTick)).lerp(facing, Easing.outCubic(turned)).normalize();
         }

         spin = age * 55.0F;
      }

      spin = (spin + slot * 60.0F) * (float) (Math.PI / 180.0);
      float appear = Easing.outBack(Mth.clamp((age - PageEntity.appearsAt(slot, volley)) / 3.0F, 0.0F, 1.0F));
      float flare = Math.max(pulse(age, 3.5F, 2.5F), page.flungAt() < 0 ? 0.0F : pulse(age, page.flungAt(), 2.0F));
      float scale = Math.max(0.0F, appear) * (1.0F + 0.2F * flare);
      if (!(scale <= 0.01F)) {
         PageLook look = page.look();
         Vec3 offset = drawn.subtract(at);
         poseStack.pushPose();
         poseStack.translate(offset.x, offset.y, offset.z);
         Pose normal = poseStack.last().copy();
         poseStack.pushPose();
         poseStack.mulPose(new Quaternionf().rotationTo(FORWARD, facing).rotateZ(spin));
         poseStack.scale(scale, scale, scale);
         VertexConsumer consumer = ItemRenderer.getFoilBufferDirect(buffers, RenderType.entityCutoutNoCull(PAGE), false, look.glints());
         Matrix4f pose = poseStack.last().pose();
         vertex(consumer, pose, normal, -0.2F, -0.27F, 0.125F, 1.0F);
         vertex(consumer, pose, normal, 0.2F, -0.27F, 0.875F, 1.0F);
         vertex(consumer, pose, normal, 0.2F, 0.27F, 0.875F, 0.0F);
         vertex(consumer, pose, normal, -0.2F, 0.27F, 0.125F, 0.0F);
         poseStack.popPose();
         if (!page.isFlying()) {
            float halo = 0.22F + 0.08F * Mth.sin(age * 0.6F + slot);
            float radius = 0.34F * scale;
            GlowBatch.add(
               ModRenderTypes.GLOW,
               poseStack,
               (glow, glowPose, glowNormal) -> GlowDraw.glowSphere(
                  glow, glowPose, radius, (float) (-Math.PI / 2), (float) (Math.PI / 2), 10, 5, look.r(), look.g(), look.b(), (nx, ny, nz) -> halo
               )
            );
         }

         if (flare > 0.0F) {
            poseStack.pushPose();
            poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
            float size = 0.75F * flare;
            GlowBatch.add(ModRenderTypes.GLOW, poseStack, (glow, glowPose, glowNormal) -> {
               GlowDraw.starburst(glow, glowPose, size, 0.3F, look.r(), look.g(), look.b(), 0.8F * flare);
               GlowDraw.starburst(glow, glowPose, size * 0.5F, 0.45F, 1.0F, 0.97F, 0.88F, flare);
            });
            poseStack.popPose();
         }

         poseStack.popPose();
         if (page.isFlying()) {
            int count = 1;

            while (count <= 5 && page.trail[count - 1] != null) {
               count++;
            }

            if (count > 2) {
               Vector3f[] points = new Vector3f[count];
               points[0] = offset.toVector3f();

               for (int i = 1; i < count; i++) {
                  points[i] = page.trail[i - 1].subtract(at).toVector3f();
               }

               Vector3f eye = this.entityRenderDispatcher.camera.getPosition().subtract(at).toVector3f();
               float alpha = look == PageLook.PLAIN ? 0.3F : 0.5F;
               GlowBatch.add(
                  ModRenderTypes.GLOW,
                  poseStack,
                  (glow, glowPose, glowNormal) -> GlowDraw.taperedRibbon(glow, glowPose, points, eye, 0.1F, look.r(), look.g(), look.b(), alpha)
               );
            }
         }

         super.render(page, entityYaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   private static Vector3f towards(Vec3 from, Vec3 to) {
      Vec3 direction = to.subtract(from);
      return direction.lengthSqr() < 1.0E-6 ? new Vector3f(0.0F, 1.0F, 0.0F) : direction.normalize().toVector3f();
   }

   private static Vector3f flightFacing(PageEntity page, int slot, int volley) {
      Vec3 heading = page.getDeltaMovement();
      if (heading.lengthSqr() < 1.0E-6) {
         heading = page.trail[0] != null ? page.position().subtract(page.trail[0]) : UP;
      }

      if (heading.lengthSqr() < 1.0E-6) {
         heading = UP;
      }

      heading = heading.normalize();
      Vec3 lift = UP.subtract(heading.scale(UP.dot(heading)));
      lift = lift.lengthSqr() < 1.0E-4 ? new Vec3(1.0, 0.0, 0.0) : lift.normalize();
      Vec3 side = heading.cross(lift);
      float roll = volley <= 1 ? 0.0F : Mth.lerp((float)slot / (volley - 1), (float) (Math.PI * 2.0 / 9.0), (float) (-Math.PI * 2.0 / 9.0));
      Vec3 up = lift.scale(Mth.cos(roll)).add(side.scale(Mth.sin(roll)));
      return heading.scale(Mth.cos((float) (Math.PI / 4))).add(up.scale(Mth.sin((float) (Math.PI / 4)))).normalize().toVector3f();
   }

   private static float pulse(float age, float at, float width) {
      return Math.max(0.0F, 1.0F - Math.abs(age - at) / width);
   }

   private static void vertex(VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float y, float u, float v) {
      consumer.addVertex(pose, x, y, 0.0F)
         .setColor(1.0F, 1.0F, 1.0F, 1.0F)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(normal, 0.0F, 1.0F, 0.0F);
   }

   public ResourceLocation getTextureLocation(PageEntity page) {
      return PAGE;
   }
}
