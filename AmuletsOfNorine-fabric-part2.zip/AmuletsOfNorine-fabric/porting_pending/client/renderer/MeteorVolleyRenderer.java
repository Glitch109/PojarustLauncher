package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.MeteorVolleyEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class MeteorVolleyRenderer extends EntityRenderer<MeteorVolleyEntity> {
   private static final ResourceLocation CIRCLE = AmuletMod.id("textures/misc/meteor_circle.png");
   private static final ResourceLocation RETICLE = AmuletMod.id("textures/misc/strike_reticle.png");
   private static final float[] RED = new float[]{1.0F, 0.16F, 0.05F};
   private static final float[] EMBER = new float[]{1.0F, 0.5F, 0.12F};
   private static final float[] WHITE_HOT = new float[]{1.0F, 0.9F, 0.72F};
   private static final float ROCK_SIZE = 0.6F;
   private final MeteorModel rock;

   public MeteorVolleyRenderer(Context context) {
      super(context);
      this.rock = new MeteorModel(context.bakeLayer(MeteorModel.LAYER));
   }

   public void render(MeteorVolleyEntity volley, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float age = volley.tickCount + partialTick;
      Vec3 origin = volley.getPosition(partialTick);
      Vec3 eye = volley.eye(partialTick);
      Vec3 aim = volley.aim(partialTick);
      List<MeteorVolleyRenderer.Circle> circles = new ArrayList<>();

      for (int k = 0; k < 5; k++) {
         float open = (age - MeteorVolleyEntity.opensAt(k)) / 8.0F;
         if (!(open <= 0.0F)) {
            int closes = volley.closesAt(k);
            float closing = Mth.clamp((age - closes) / 8.0F, 0.0F, 1.0F);
            float scale = Easing.outBack(open) * (1.0F - Easing.smoothstep(0.0F, 1.0F, closing));
            if (!(scale <= 0.01F)) {
               Vec3 center = MeteorVolleyEntity.circleCenter(k, eye, aim);
               Vector3f at = center.subtract(origin).toVector3f();
               Vector3f facing = aim.subtract(center).normalize().toVector3f();
               float charge = Easing.smoothstep(MeteorVolleyEntity.opensAt(k), MeteorVolleyEntity.firesAt(k), age);
               int fires = MeteorVolleyEntity.firesAt(k);
               float flare = volley.fired(k) ? Math.max(0.0F, 1.0F - Math.abs(age - fires) / 4.0F) : 0.0F;
               float direction = k % 2 == 0 ? 1.0F : -1.0F;
               float spin = direction * (age * (2.0F + 9.0F * charge) + closing * 240.0F) * (float) (Math.PI / 180.0);
               float light = (0.72F + 0.18F * Mth.sin(age * 0.35F + k * 1.3F)) * (0.55F + 0.45F * charge) + flare;
               float r = Mth.lerp(flare, Mth.lerp(charge, RED[0], EMBER[0]), WHITE_HOT[0]) * light;
               float g = Mth.lerp(flare, Mth.lerp(charge, RED[1], EMBER[1]), WHITE_HOT[1]) * light;
               float b = Mth.lerp(flare, Mth.lerp(charge, RED[2], EMBER[2]), WHITE_HOT[2]) * light;
               float size = 0.62F * scale * (1.0F + 0.3F * flare);
               circles.add(new MeteorVolleyRenderer.Circle(at, facing, size, spin, r, g, b, charge, flare));
               if (age < closes) {
                  this.rock(poseStack, buffers, at, charge * Math.min(1.0F, scale), age, k + volley.getId());
               }
            }
         }
      }

      if (!circles.isEmpty()) {
         GlowBatch.add(ModRenderTypes.skyGlow(CIRCLE), poseStack, (consumer, pose, normal) -> {
            for (MeteorVolleyRenderer.Circle c : circles) {
               GlowDraw.disc(consumer, pose, c.at(), c.facing(), c.size() * 1.35F, -c.spin() * 0.3F, c.r() * 0.3F, c.g() * 0.3F, c.b() * 0.3F);
               GlowDraw.disc(consumer, pose, c.at(), c.facing(), c.size(), c.spin(), c.r(), c.g(), c.b());
               Vector3f inner = new Vector3f(c.facing()).mul(0.03F).add(c.at());
               GlowDraw.disc(consumer, pose, inner, c.facing(), c.size() * 0.55F, -c.spin() * 1.7F, c.r() * 0.85F, c.g() * 0.85F, c.b() * 0.85F);
            }
         });
         GlowBatch.add(
            ModRenderTypes.GLOW,
            poseStack,
            (consumer, pose, normal) -> {
               for (MeteorVolleyRenderer.Circle c : circles) {
                  Matrix4f atx = new Matrix4f(pose).translate(c.at());
                  GlowDraw.glowSphere(
                     consumer,
                     atx,
                     0.2F + 0.3F * c.charge(),
                     (float) (-Math.PI / 2),
                     (float) (Math.PI / 2),
                     10,
                     5,
                     1.0F,
                     0.42F,
                     0.08F,
                     (nx, ny, nz) -> 0.15F + 0.35F * c.charge()
                  );
                  if (c.flare() > 0.0F) {
                     GlowDraw.glowSphere(
                        consumer,
                        atx,
                        0.4F + 0.6F * (1.0F - c.flare()),
                        (float) (-Math.PI / 2),
                        (float) (Math.PI / 2),
                        12,
                        6,
                        1.0F,
                        0.85F,
                        0.6F,
                        (nx, ny, nz) -> 0.8F * c.flare()
                     );
                  }
               }
            }
         );
      }

      reticle(volley, poseStack, partialTick, age, aim, origin);
      super.render(volley, entityYaw, partialTick, poseStack, buffers, packedLight);
   }

   private void rock(PoseStack poseStack, MultiBufferSource buffers, Vector3f at, float grown, float age, int seed) {
      float size = 0.6F * Easing.outCubic(grown);
      if (!(size <= 0.01F)) {
         poseStack.pushPose();
         poseStack.translate(at.x(), at.y(), at.z());
         poseStack.mulPose(Axis.YP.rotationDegrees(seed * 37 % 360 + age * (6.0F + 14.0F * grown)));
         poseStack.mulPose(Axis.XP.rotationDegrees(seed * 53 % 360 + age * (9.0F + 18.0F * grown)));
         poseStack.scale(size, size, size);
         this.rock.renderToBuffer(poseStack, buffers.getBuffer(RenderType.entitySolid(MeteorRenderer.TEXTURE)), 15728880, OverlayTexture.NO_OVERLAY);
         this.rock.renderToBuffer(poseStack, buffers.getBuffer(RenderType.eyes(MeteorRenderer.GLOW)), 15728880, OverlayTexture.NO_OVERLAY);
         poseStack.popPose();
      }
   }

   private static void reticle(MeteorVolleyEntity volley, PoseStack poseStack, float partialTick, float age, Vec3 aim, Vec3 origin) {
      float show = Mth.lerp(partialTick, volley.reticleBefore, volley.reticle);
      if (!(show <= 0.01F)) {
         Vector3f feet = aim.subtract(origin).toVector3f().add(0.0F, -volley.targetHeight() * 0.5F + 0.06F, 0.0F);
         float lockIn = 1.0F + 1.2F * (1.0F - Easing.outCubic(Mth.clamp(age / 12.0F, 0.0F, 1.0F)));
         float radius = Math.max(0.9F, volley.targetWidth() * 1.4F) * lockIn * (1.0F + 0.05F * Mth.sin(age * 0.6F));
         float spin = age * 2.5F * (float) (Math.PI / 180.0);
         float light = show * (0.75F + 0.25F * Mth.sin(age * 0.6F));
         GlowBatch.add(
            ModRenderTypes.glowTextured(RETICLE),
            poseStack,
            (consumer, pose, normal) -> flat(consumer, pose, normal, feet, radius, spin, RED[0] * light, RED[1] * light * 1.6F, RED[2] * light)
         );
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            Matrix4f at = new Matrix4f(pose).translate(feet);
            GlowDraw.ring(consumer, at, 0.0F, radius * 0.6F, radius * 1.05F, 40, RED[0], RED[1], RED[2], 0.0F, 0.35F * show);
            GlowDraw.ring(consumer, at, 0.0F, radius * 1.05F, radius * 1.25F, 40, RED[0], RED[1], RED[2], 0.35F * show, 0.0F);
         });
      }
   }

   private static void flat(VertexConsumer consumer, Matrix4f pose, Pose normal, Vector3f at, float radius, float spin, float r, float g, float b) {
      float cos = Mth.cos(spin) * radius;
      float sin = Mth.sin(spin) * radius;
      float[][] corners = new float[][]{{-1.0F, -1.0F, 0.0F, 0.0F}, {-1.0F, 1.0F, 0.0F, 1.0F}, {1.0F, 1.0F, 1.0F, 1.0F}, {1.0F, -1.0F, 1.0F, 0.0F}};

      for (float[] corner : corners) {
         float x = corner[0] * cos - corner[1] * sin;
         float z = corner[0] * sin + corner[1] * cos;
         GlowDraw.texVertex(consumer, pose, normal, at.x() + x, at.y(), at.z() + z, r, g, b, corner[2], corner[3]);
      }
   }

   public ResourceLocation getTextureLocation(MeteorVolleyEntity volley) {
      return CIRCLE;
   }

   private record Circle(Vector3f at, Vector3f facing, float size, float spin, float r, float g, float b, float charge, float flare) {
   }
}
