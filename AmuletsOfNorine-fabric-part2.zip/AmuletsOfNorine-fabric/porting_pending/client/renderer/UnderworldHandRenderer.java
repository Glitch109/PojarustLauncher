package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.UnderworldHandEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.FastColor.ARGB32;
import org.joml.Matrix4f;

public class UnderworldHandRenderer extends EntityRenderer<UnderworldHandEntity> {
   private static final ResourceLocation SKIN = AmuletMod.id("textures/entity/underworld_hand.png");
   private static final ResourceLocation VEINS = AmuletMod.id("textures/entity/underworld_hand_glow.png");
   public static final ResourceLocation HELL_CIRCLE = AmuletMod.id("textures/misc/hell_circle.png");
   public static final ResourceLocation HELL_PIT = AmuletMod.id("textures/misc/hell_pit.png");
   private final UnderworldHandModel model;

   public UnderworldHandRenderer(Context context) {
      super(context);
      this.model = new UnderworldHandModel(context.bakeLayer(UnderworldHandModel.LAYER));
   }

   public void render(UnderworldHandEntity hand, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float age = hand.tickCount + partialTick;
      float scale = hand.scale();
      float radius = hand.pitRadius();
      float open = Easing.outBack(Mth.clamp(age / 8.0F, 0.0F, 1.0F)) * (1.0F - Easing.smoothstep(0.0F, 1.0F, Mth.clamp((age - 50.0F) / 14.0F, 0.0F, 1.0F)));
      if (!(open <= 0.0F)) {
         poseStack.pushPose();
         poseStack.translate(0.0F, 0.02F, 0.0F);
         disc(buffers.getBuffer(RenderType.entityTranslucent(HELL_PIT)), poseStack, radius * open, 1.0F, 1.0F, 1.0F);
         poseStack.popPose();
         float flare = 1.0F + 0.8F * Mth.clamp(1.0F - Math.abs(age - 22.0F) / 6.0F, 0.0F, 1.0F);
         float circle = radius * 1.45F * open;
         float spin = age * 2.5F;
         poseStack.pushPose();
         poseStack.translate(0.0F, 0.05F, 0.0F);
         poseStack.mulPose(Axis.YP.rotationDegrees(spin));
         GlowBatch.add(
            ModRenderTypes.glowTextured(HELL_CIRCLE),
            poseStack,
            (consumer, pose, normal) -> flat(consumer, pose, normal, circle, 1.0F * flare, 0.32F * flare, 0.08F * flare)
         );
         poseStack.popPose();
         GlowBatch.add(
            ModRenderTypes.GLOW,
            poseStack,
            (consumer, pose, normal) -> GlowDraw.band(consumer, pose, radius * open, 0.6F * open, 32, 1.0F, 0.3F, 0.05F, 0.35F * flare)
         );
         if (!(age < 6.0F)) {
            float handHeight = 32.0F * scale / 16.0F;
            float rise = Easing.outBack(Mth.clamp((age - 6.0F) / 10.0F, 0.0F, 1.0F));
            float lift = -(1.0F - rise) * (handHeight + 0.4F) - UnderworldHandEntity.drag(age) * (handHeight + 0.6F);
            float grip = UnderworldHandEntity.clamp(age);
            float tremor = grip >= 1.0F && age < 50.0F ? Mth.sin(age * 2.3F) * 0.03F : 0.0F;
            poseStack.pushPose();
            poseStack.mulPose(Axis.YP.rotationDegrees(hand.facing()));
            poseStack.translate(0.0F, lift - 2.0F * scale / 16.0F, -(hand.victimWidth() * 0.5F + 0.1F) - 3.0F * scale / 16.0F);
            poseStack.scale(scale, scale, scale);
            this.model.pose(grip, tremor);
            this.model.renderToBuffer(poseStack, buffers.getBuffer(this.model.renderType(SKIN)), packedLight, OverlayTexture.NO_OVERLAY);
            float pulse = 0.75F + 0.25F * Mth.sin(age * 0.4F);
            this.model
               .renderToBuffer(
                  poseStack, buffers.getBuffer(RenderType.eyes(VEINS)), 15728880, OverlayTexture.NO_OVERLAY, ARGB32.colorFromFloat(1.0F, pulse, pulse, pulse)
               );
            poseStack.popPose();
            super.render(hand, entityYaw, partialTick, poseStack, buffers, packedLight);
         }
      }
   }

   private static void disc(VertexConsumer consumer, PoseStack poseStack, float radius, float r, float g, float b) {
      Matrix4f pose = poseStack.last().pose();
      Pose normal = poseStack.last();
      corner(consumer, pose, normal, -radius, -radius, 0.0F, 0.0F, r, g, b);
      corner(consumer, pose, normal, -radius, radius, 0.0F, 1.0F, r, g, b);
      corner(consumer, pose, normal, radius, radius, 1.0F, 1.0F, r, g, b);
      corner(consumer, pose, normal, radius, -radius, 1.0F, 0.0F, r, g, b);
   }

   private static void corner(VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float z, float u, float v, float r, float g, float b) {
      consumer.addVertex(pose, x, 0.0F, z)
         .setColor(r, g, b, 1.0F)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(normal, 0.0F, 1.0F, 0.0F);
   }

   static void flat(VertexConsumer consumer, Matrix4f pose, Pose normal, float radius, float r, float g, float b) {
      GlowDraw.texVertex(consumer, pose, normal, -radius, 0.0F, -radius, r, g, b, 0.0F, 0.0F);
      GlowDraw.texVertex(consumer, pose, normal, -radius, 0.0F, radius, r, g, b, 0.0F, 1.0F);
      GlowDraw.texVertex(consumer, pose, normal, radius, 0.0F, radius, r, g, b, 1.0F, 1.0F);
      GlowDraw.texVertex(consumer, pose, normal, radius, 0.0F, -radius, r, g, b, 1.0F, 0.0F);
   }

   public ResourceLocation getTextureLocation(UnderworldHandEntity hand) {
      return SKIN;
   }
}
