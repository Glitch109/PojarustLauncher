package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.TimeFieldEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

public class TimeFieldRenderer extends EntityRenderer<TimeFieldEntity> {
   private static final ResourceLocation SHELL = AmuletMod.id("textures/entity/chrono_field.png");
   private static final ResourceLocation CLOCK = AmuletMod.id("textures/entity/chrono_clock.png");
   private static final float RED = 1.0F;
   private static final float GREEN = 0.84F;
   private static final float BLUE = 0.55F;

   public TimeFieldRenderer(Context context) {
      super(context);
   }

   public void render(TimeFieldEntity field, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float time = field.tickCount + partialTick;
      float duration = field.duration();
      float fade = Mth.clamp(time / 3.0F, 0.0F, 1.0F) * (time > duration ? Math.max(0.0F, 1.0F - (time - duration) / 16.0F) : 1.0F);
      if (!(fade <= 0.01F)) {
         float windDown = Easing.outCubic(time / 8.0F);
         float resumed = Math.max(0.0F, time - duration);
         float motion = windDown + resumed * resumed * 0.02F;
         float radius = field.currentRadius(partialTick) * (1.0F + resumed / 16.0F * 0.15F);
         Vec3 camera = this.entityRenderDispatcher.camera.getPosition().subtract(field.getPosition(partialTick)).subtract(0.0, 1.0, 0.0);
         float cx = (float)camera.x;
         float cy = (float)camera.y;
         float cz = (float)camera.z;
         float sweep = 1.0F + 2.0F * Math.max(0.0F, 1.0F - time / 12.0F);
         poseStack.pushPose();
         poseStack.translate(0.0F, 1.0F, 0.0F);
         GlowDraw.SphereShader shader = (nx, ny, nz) -> {
            float px = cx - nx * radius;
            float py = cy - ny * radius;
            float pz = cz - nz * radius;
            float toCamera = Mth.sqrt(px * px + py * py + pz * pz);
            float facing = toCamera < 1.0E-4F ? 1.0F : Math.abs(nx * px + ny * py + nz * pz) / toCamera;
            float rim = (1.0F - facing) * (1.0F - facing);
            return (0.06F + 0.55F * rim) * sweep * fade;
         };
         GlowBatch.add(
            ModRenderTypes.glowTextured(SHELL),
            poseStack,
            (consumer, pose, normal) -> GlowDraw.sphere(
               consumer,
               pose,
               normal,
               radius,
               (float) (-Math.PI / 2),
               (float) (Math.PI / 2),
               48,
               24,
               12.0F,
               6.0F,
               motion * 1.5F,
               0.0F,
               1.0F,
               0.84F,
               0.55F,
               shader
            )
         );

         for (int ring = 0; ring < 3; ring++) {
            float ringRadius = 1.5F + ring * 0.35F;
            float spin = motion * (720.0F - ring * 180.0F) * (ring % 2 == 0 ? 1.0F : -1.0F);
            poseStack.pushPose();
            poseStack.mulPose(Axis.XP.rotationDegrees(ring * 60.0F + 25.0F));
            poseStack.mulPose(Axis.ZP.rotationDegrees(ring * 40.0F));
            poseStack.mulPose(Axis.YP.rotationDegrees(spin));
            GlowBatch.add(
               ModRenderTypes.GLOW,
               poseStack,
               (consumer, pose, normal) -> GlowDraw.band(consumer, pose, ringRadius, 0.07F, 48, 1.0F, 0.84F, 0.55F, 0.8F * fade)
            );
            poseStack.popPose();
         }

         poseStack.popPose();
         float clockRadius = Math.min(field.radius() * 0.55F, 6.0F) * Easing.outBack(time / 12.0F);
         float faceTurn = -motion * 30.0F;
         float minuteHand = -windDown * 1080.0F + resumed * resumed * 4.0F;
         float hourHand = 120.0F - windDown * 90.0F + resumed * resumed * 0.4F;
         poseStack.pushPose();
         poseStack.translate(0.0F, 0.04F, 0.0F);
         poseStack.mulPose(Axis.YP.rotationDegrees(faceTurn));
         GlowBatch.add(ModRenderTypes.glowTextured(CLOCK), poseStack, (consumer, pose, normal) -> clockFace(consumer, pose, normal, clockRadius, 0.9F * fade));
         poseStack.popPose();
         poseStack.pushPose();
         poseStack.translate(0.0F, 0.06F, 0.0F);
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            hand(consumer, pose, minuteHand, clockRadius * 0.82F, clockRadius * 0.035F, fade);
            hand(consumer, pose, hourHand, clockRadius * 0.52F, clockRadius * 0.05F, fade);
         });
         poseStack.popPose();
         super.render(field, yaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   private static void clockFace(VertexConsumer consumer, Matrix4f pose, Pose normal, float radius, float brightness) {
      float r = 1.0F * brightness;
      float g = 0.84F * brightness;
      float b = 0.55F * brightness;
      GlowDraw.texVertex(consumer, pose, normal, -radius, 0.0F, -radius, r, g, b, 0.0F, 0.0F);
      GlowDraw.texVertex(consumer, pose, normal, -radius, 0.0F, radius, r, g, b, 0.0F, 1.0F);
      GlowDraw.texVertex(consumer, pose, normal, radius, 0.0F, radius, r, g, b, 1.0F, 1.0F);
      GlowDraw.texVertex(consumer, pose, normal, radius, 0.0F, -radius, r, g, b, 1.0F, 0.0F);
   }

   private static void hand(VertexConsumer consumer, Matrix4f pose, float degrees, float length, float width, float alpha) {
      float angle = degrees * (float) (Math.PI / 180.0);
      float dx = Mth.sin(angle);
      float dz = -Mth.cos(angle);
      float px = -dz;
      float pz = dx;
      float tail = length * 0.15F;
      float midX = dx * length * 0.3F;
      float midZ = dz * length * 0.3F;

      for (float side : new float[]{-1.0F, 1.0F}) {
         GlowDraw.vertex(consumer, pose, -dx * tail, 0.0F, -dz * tail, 1.0F, 0.84F, 0.55F, alpha);
         GlowDraw.vertex(consumer, pose, midX + px * width * side, 0.0F, midZ + pz * width * side, 1.0F, 0.84F, 0.55F, 0.3F * alpha);
         GlowDraw.vertex(consumer, pose, dx * length, 0.0F, dz * length, 1.0F, 1.0F, 1.0F, alpha);
         GlowDraw.vertex(consumer, pose, dx * length, 0.0F, dz * length, 1.0F, 1.0F, 1.0F, alpha);
      }
   }

   public ResourceLocation getTextureLocation(TimeFieldEntity field) {
      return CLOCK;
   }
}
