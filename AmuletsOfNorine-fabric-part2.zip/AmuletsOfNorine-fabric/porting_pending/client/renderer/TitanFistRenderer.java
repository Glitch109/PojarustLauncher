package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.titan.Stance;
import com.amuletmod.entity.TitanFistEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.FastColor.ARGB32;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class TitanFistRenderer extends EntityRenderer<TitanFistEntity> {
   private static final ResourceLocation SKIN = AmuletMod.id("textures/entity/titan_fist.png");
   private static final ResourceLocation RUNES = AmuletMod.id("textures/entity/titan_fist_glow.png");
   public static final ResourceLocation CIRCLE = AmuletMod.id("textures/misc/titan_circle.png");
   private static final ResourceLocation VORTEX = AmuletMod.id("textures/misc/titan_vortex.png");
   public static final ResourceLocation CRACKS = AmuletMod.id("textures/misc/titan_cracks.png");
   private static final ResourceLocation GLOW = AmuletMod.id("textures/misc/soft_glow.png");
   public static final float[] GOLD = new float[]{1.0F, 0.72F, 0.26F};
   private static final float[] WHITE_GOLD = new float[]{1.0F, 0.93F, 0.74F};
   public static final float[] SMOKE = new float[]{0.03F, 0.01F, 0.05F};
   private static final int STRANDS = 3;
   private static final int STRAND_POINTS = 16;
   private final TitanFistModel rightHand;
   private final TitanFistModel leftHand;

   public TitanFistRenderer(Context context) {
      super(context);
      this.rightHand = new TitanFistModel(context.bakeLayer(TitanFistModel.LAYER));
      this.leftHand = new TitanFistModel(context.bakeLayer(TitanFistModel.LEFT_LAYER));
   }

   public void render(TitanFistEntity fist, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float age = fist.tickCount + partialTick;
      Vec3 position = fist.getPosition(partialTick);
      Camera camera = this.entityRenderDispatcher.camera;
      Vector3f eye = camera.getPosition().subtract(position).toVector3f();
      circle(fist, poseStack, age, position);
      if (fist.stance() != Stance.JAB) {
         cracks(fist, poseStack, age);
      }

      if (fist.stance() == Stance.CRUSH) {
         shockwave(fist, poseStack, age);
      }

      if (fist.thrown(age)) {
         this.fist(fist, poseStack, buffers, packedLight, age, position, camera, eye);
      }

      strike(fist, poseStack, age, position, camera);
      super.render(fist, entityYaw, partialTick, poseStack, buffers, packedLight);
   }

   private static void circle(TitanFistEntity fist, PoseStack poseStack, float age, Vec3 position) {
      float size = fist.circleScale(age);
      if (!(size <= 0.01F)) {
         float light = fist.circleLight(age);
         Vector3f at = fist.circleCenter(position).toVector3f();

         Vector3f facing = switch (fist.stance()) {
            case JAB -> fist.heading(position).toVector3f();
            case CRUSH -> new Vector3f(0.0F, -1.0F, 0.0F);
            case UPPERCUT -> new Vector3f(0.0F, 1.0F, 0.0F);
         };
         Vector3f right = new Vector3f(facing)
            .cross(Math.abs(facing.y()) > 0.95F ? new Vector3f(1.0F, 0.0F, 0.0F) : new Vector3f(0.0F, 1.0F, 0.0F))
            .normalize();
         Vector3f up = new Vector3f(right).cross(facing).normalize();
         float spin = age * (fist.stance() == Stance.JAB ? 0.2F : 0.07F);
         float fade = Math.min(1.0F, light);
         Vector3f behind = new Vector3f(facing).mul(-0.03F).add(at);
         GlowBatch.add(
            ModRenderTypes.shade(VORTEX),
            poseStack,
            (consumer, pose, normal) -> shadeStamp(consumer, pose, behind, right, up, size * 0.95F, -spin * 2.2F, 0.9F * fade)
         );
         GlowBatch.add(
            ModRenderTypes.glowTextured(CIRCLE),
            poseStack,
            (consumer, pose, normal) -> {
               GlowDraw.stamp(
                  consumer, pose, normal, at, right, up, size * 1.3F, -spin * 0.5F, GOLD[0] * 0.3F * light, GOLD[1] * 0.3F * light, GOLD[2] * 0.3F * light
               );
               GlowDraw.stamp(
                  consumer, pose, normal, new Vector3f(facing).mul(0.01F).add(at), right, up, size, spin, GOLD[0] * light, GOLD[1] * light, GOLD[2] * light
               );
               GlowDraw.stamp(
                  consumer,
                  pose,
                  normal,
                  new Vector3f(facing).mul(0.02F).add(at),
                  right,
                  up,
                  size * 0.45F,
                  -spin * 2.5F,
                  WHITE_GOLD[0] * 0.8F * light,
                  WHITE_GOLD[1] * 0.8F * light,
                  WHITE_GOLD[2] * 0.8F * light
               );
            }
         );
      }
   }

   private void fist(
      TitanFistEntity fist, PoseStack poseStack, MultiBufferSource buffers, int packedLight, float age, Vec3 position, Camera camera, Vector3f eye
   ) {
      float width = fist.width();
      float grown = fist.grown(age);
      float solid = 1.0F - fist.dissolving(age);
      Vector3f knuckles = fist.knuckles(age, position).toVector3f();
      Vector3f heading = fist.heading(position).toVector3f();
      Vector3f back = fist.backFacing(position).toVector3f();
      back.sub(new Vector3f(heading).mul(back.dot(heading)));
      if (back.lengthSquared() < 1.0E-4F) {
         back = new Vector3f(heading).cross(Math.abs(heading.y()) < 0.9F ? new Vector3f(0.0F, 1.0F, 0.0F) : new Vector3f(1.0F, 0.0F, 0.0F));
      }

      back.normalize();
      Vector3f side = new Vector3f(back).cross(heading);
      float scale = width / 0.75F * grown;
      float length = 0.9375F * scale;
      float since = age - fist.impactTick();
      float flare = since >= 0.0F ? Math.max(0.0F, 1.0F - since / 6.0F) : 0.0F;
      Vector3f wrist = new Vector3f(heading).mul(-length).add(knuckles);
      Vector3f circle = fist.circleCenter(position).toVector3f();
      float retract = Easing.smoothstep(fist.impactTick(), fist.impactTick() + 8.0F, age);
      Vector3f tail = new Vector3f(circle).lerp(wrist, fist.stance() == Stance.UPPERCUT ? Math.max(retract, 0.5F) : retract);
      float trail = solid * (fist.stance() == Stance.JAB ? 0.75F : 0.9F);
      swirls(poseStack, age, eye, knuckles, wrist, tail, heading, back, side, width * grown, trail, fist.getId());
      Vector3f middle = new Vector3f(heading).mul(-length * 0.4F).add(knuckles);
      Vector3f left = camera.getLeftVector();
      Vector3f up = camera.getUpVector();
      float halo = (0.25F + 0.6F * flare) * solid;
      GlowBatch.add(
         ModRenderTypes.glowTextured(GLOW),
         poseStack,
         (consumer, pose, normal) -> GlowDraw.stamp(
            consumer, pose, normal, middle, left, up, width * (1.1F + 0.5F * flare) * grown, 0.0F, GOLD[0] * halo, GOLD[1] * halo, GOLD[2] * halo
         )
      );
      poseStack.pushPose();
      poseStack.translate(knuckles.x(), knuckles.y(), knuckles.z());
      poseStack.mulPose(new Quaternionf().setFromNormalized(new Matrix3f(side, back, heading)));
      poseStack.scale(scale, scale, scale);
      poseStack.translate(0.0F, 0.0F, -0.6875F);
      TitanFistModel model = fist.leftHanded() ? this.leftHand : this.rightHand;
      int light = LightTexture.pack(Math.max(LightTexture.block(packedLight), 9), LightTexture.sky(packedLight));
      model.renderToBuffer(
         poseStack,
         buffers.getBuffer(RenderType.entityTranslucent(SKIN)),
         light,
         OverlayTexture.NO_OVERLAY,
         ARGB32.colorFromFloat(0.94F * solid, 1.0F, 1.0F, 1.0F)
      );
      float runes = (0.7F + 0.15F * Mth.sin(age * 0.7F) + 0.8F * flare) * solid;
      model.renderToBuffer(
         poseStack, buffers.getBuffer(RenderType.eyes(RUNES)), 15728880, OverlayTexture.NO_OVERLAY, ARGB32.colorFromFloat(1.0F, runes, runes, runes)
      );
      poseStack.popPose();
   }

   private static void swirls(
      PoseStack poseStack,
      float age,
      Vector3f eye,
      Vector3f knuckles,
      Vector3f wrist,
      Vector3f tail,
      Vector3f heading,
      Vector3f back,
      Vector3f side,
      float width,
      float alpha,
      int seed
   ) {
      if (!(alpha <= 0.01F)) {
         Vector3f start = new Vector3f(knuckles).lerp(wrist, 0.35F);
         Vector3f[][] smoke = new Vector3f[3][];
         Vector3f[][] gold = new Vector3f[2][];

         for (int k = 0; k < 3; k++) {
            smoke[k] = helix(start, wrist, tail, back, side, width * 0.62F, age * -0.32F + k * (float) (Math.PI * 2) / 3.0F + seed, 2.2F);
         }

         for (int k = 0; k < gold.length; k++) {
            gold[k] = helix(start, wrist, tail, back, side, width * 0.7F, age * 0.45F + k * (float) Math.PI + seed * 0.7F, -1.6F);
         }

         Vector3f[] core = new Vector3f[]{new Vector3f(wrist), new Vector3f(wrist).lerp(tail, 0.5F), new Vector3f(tail)};
         GlowBatch.add(ModRenderTypes.SHADE_FLAT, poseStack, (consumer, pose, normal) -> {
            if (wrist.distanceSquared(tail) > 0.04F) {
               GlowDraw.taperedRibbon(consumer, pose, core, eye, width * 0.42F, SMOKE[0], SMOKE[1], SMOKE[2], 0.5F * alpha);
            }

            for (Vector3f[] strand : smoke) {
               GlowDraw.taperedRibbon(consumer, pose, strand, eye, width * 0.2F, SMOKE[0], SMOKE[1], SMOKE[2], 0.8F * alpha);
            }
         });
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            for (Vector3f[] strand : gold) {
               GlowDraw.taperedRibbon(consumer, pose, strand, eye, width * 0.045F, GOLD[0], GOLD[1], GOLD[2], 0.75F * alpha);
            }
         });
      }
   }

   private static Vector3f[] helix(Vector3f start, Vector3f wrist, Vector3f tail, Vector3f back, Vector3f side, float radius, float phase, float turns) {
      Vector3f[] points = new Vector3f[16];
      int onFist = 5;

      for (int i = 0; i < 16; i++) {
         float s = i / 15.0F;
         Vector3f along = i <= onFist
            ? new Vector3f(start).lerp(wrist, (float)i / onFist)
            : new Vector3f(wrist).lerp(tail, (float)(i - onFist) / (15 - onFist));
         float angle = phase + s * turns * (float) (Math.PI * 2);
         float r = radius * (1.0F - 0.65F * s);
         points[i] = along.add(new Vector3f(back).mul(Mth.cos(angle) * r)).add(new Vector3f(side).mul(Mth.sin(angle) * r));
      }

      return points;
   }

   private static void strike(TitanFistEntity fist, PoseStack poseStack, float age, Vec3 position, Camera camera) {
      float since = age - fist.impactTick();
      if (!(since < 0.0F) && !(since > 6.0F)) {
         float t = since / 6.0F;
         float width = fist.width();
         Vector3f at = fist.knuckles(fist.impactTick(), position).toVector3f();
         Vector3f heading = fist.heading(position).toVector3f();
         float big = fist.stance() == Stance.JAB ? 1.0F : 1.6F;
         poseStack.pushPose();
         poseStack.translate(at.x(), at.y(), at.z());
         poseStack.pushPose();
         poseStack.mulPose(camera.rotation());
         float flash = 1.0F - Easing.outCubic(t);
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            GlowDraw.starburst(consumer, pose, width * big * (0.9F + 1.4F * t), 0.35F, WHITE_GOLD[0], WHITE_GOLD[1], WHITE_GOLD[2], 0.9F * flash);
            GlowDraw.starburst(consumer, pose, width * big * (1.5F + 2.0F * t), 0.2F, GOLD[0], GOLD[1], GOLD[2], 0.5F * flash);
         });
         poseStack.popPose();
         poseStack.mulPose(new Quaternionf().rotationTo(new Vector3f(0.0F, 1.0F, 0.0F), heading));
         float radius = width * big * (0.4F + 1.6F * Easing.outCubic(t));
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            GlowDraw.ring(consumer, pose, 0.0F, radius * 0.7F, radius, 32, GOLD[0], GOLD[1], GOLD[2], 0.0F, 0.7F * flash);
            GlowDraw.ring(consumer, pose, 0.0F, radius, radius * 1.12F, 32, WHITE_GOLD[0], WHITE_GOLD[1], WHITE_GOLD[2], 0.7F * flash, 0.0F);
         });
         poseStack.popPose();
      }
   }

   private static void cracks(TitanFistEntity fist, PoseStack poseStack, float age) {
      float since = age - fist.impactTick() + 1.0F;
      if (!(since < 0.0F)) {
         float life = fist.lifetime() - fist.impactTick();
         float fade = 1.0F - Easing.smoothstep(life * 0.5F, life, since);
         if (!(fade <= 0.0F)) {
            float size = (fist.stance() == Stance.CRUSH ? fist.width() * 1.5F + 1.0F : fist.width() * 1.1F)
               * Easing.outCubic(Mth.clamp(since / 3.0F, 0.0F, 1.0F));
            float heat = 1.3F * (1.0F - Easing.smoothstep(0.0F, life * 0.45F, since));
            float turn = fist.getId() * 2.39996F;
            Vector3f at = new Vector3f(0.0F, 0.03F, 0.0F);
            Vector3f right = new Vector3f(1.0F, 0.0F, 0.0F);
            Vector3f forward = new Vector3f(0.0F, 0.0F, 1.0F);
            GlowBatch.add(
               ModRenderTypes.shade(CRACKS),
               poseStack,
               (consumer, pose, normal) -> shadeStamp(consumer, pose, at, right, forward, size, turn, 0.85F * fade, SMOKE)
            );
            if (heat > 0.01F) {
               GlowBatch.add(
                  ModRenderTypes.glowTextured(CRACKS),
                  poseStack,
                  (consumer, pose, normal) -> GlowDraw.stamp(
                     consumer,
                     pose,
                     normal,
                     new Vector3f(at).add(0.0F, 0.01F, 0.0F),
                     right,
                     forward,
                     size,
                     turn,
                     GOLD[0] * heat,
                     GOLD[1] * heat,
                     GOLD[2] * heat
                  )
               );
            }
         }
      }
   }

   private static void shockwave(TitanFistEntity fist, PoseStack poseStack, float age) {
      float since = age - fist.impactTick();
      float span = 14.0F;
      if (!(since < 0.0F) && !(since > span)) {
         float t = since / span;
         float radius = Math.max(0.2F, fist.wave() * Easing.outCubic(Math.min(1.0F, since / 10.0F)));
         float fade = 1.0F - t;
         poseStack.pushPose();
         poseStack.translate(0.0F, 0.12F, 0.0F);
         GlowBatch.add(
            ModRenderTypes.SHADE_FLAT,
            poseStack,
            (consumer, pose, normal) -> GlowDraw.ring(consumer, pose, 0.0F, radius * 0.6F, radius * 1.05F, 48, SMOKE[0], SMOKE[1], SMOKE[2], 0.0F, 0.55F * fade)
         );
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            GlowDraw.ring(consumer, pose, 0.0F, radius * 0.8F, radius, 48, GOLD[0], GOLD[1], GOLD[2], 0.0F, 0.6F * fade);
            GlowDraw.band(consumer, pose, radius, 0.45F * fade, 48, GOLD[0], GOLD[1], GOLD[2], 0.35F * fade);
         });
         poseStack.popPose();
      }
   }

   public static void shadeStamp(VertexConsumer consumer, Matrix4f pose, Vector3f at, Vector3f right, Vector3f up, float size, float spin, float alpha) {
      shadeStamp(consumer, pose, at, right, up, size, spin, alpha, new float[]{1.0F, 1.0F, 1.0F});
   }

   public static void shadeStamp(
      VertexConsumer consumer, Matrix4f pose, Vector3f at, Vector3f right, Vector3f up, float size, float spin, float alpha, float[] colour
   ) {
      float cos = Mth.cos(spin) * size;
      float sin = Mth.sin(spin) * size;
      float[][] corners = new float[][]{{-1.0F, -1.0F, 0.0F, 1.0F}, {1.0F, -1.0F, 1.0F, 1.0F}, {1.0F, 1.0F, 1.0F, 0.0F}, {-1.0F, 1.0F, 0.0F, 0.0F}};

      for (float[] corner : corners) {
         float across = corner[0] * cos - corner[1] * sin;
         float along = corner[0] * sin + corner[1] * cos;
         consumer.addVertex(
               pose, at.x() + right.x() * across + up.x() * along, at.y() + right.y() * across + up.y() * along, at.z() + right.z() * across + up.z() * along
            )
            .setUv(corner[2], corner[3])
            .setColor(colour[0], colour[1], colour[2], Mth.clamp(alpha, 0.0F, 1.0F));
      }
   }

   public ResourceLocation getTextureLocation(TitanFistEntity fist) {
      return SKIN;
   }
}
