package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.BlockHoleEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

public class BlockHoleRenderer extends EntityRenderer<BlockHoleEntity> {
   private static final ResourceLocation TEXTURE = AmuletMod.id("textures/entity/block_hole_orb.png");

   public BlockHoleRenderer(Context context) {
      super(context);
   }

   public void render(BlockHoleEntity orb, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float size = size(orb, partialTick);
      if (!(size <= 0.01F)) {
         float age = orb.tickCount + partialTick;
         VertexConsumer consumer = buffers.getBuffer(RenderType.eyes(TEXTURE));
         poseStack.pushPose();
         poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
         poseStack.pushPose();
         poseStack.mulPose(Axis.ZP.rotationDegrees(age * 2.0F));
         poseStack.scale(size * 2.4F, size * 2.4F, size * 2.4F);
         quad(poseStack, consumer, 170);
         poseStack.popPose();
         poseStack.pushPose();
         poseStack.mulPose(Axis.ZP.rotationDegrees(-age * 5.0F));
         poseStack.scale(size, size, size);
         quad(poseStack, consumer, 255);
         poseStack.popPose();
         poseStack.popPose();
         super.render(orb, yaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   private static float size(BlockHoleEntity orb, float partialTick) {
      float phaseAge = orb.clientPhaseAge(partialTick);
      float pulse = 0.08F * Mth.sin((orb.tickCount + partialTick) * 0.5F);

      return switch (orb.phase()) {
         case TRAVEL -> 0.5F;
         case CHARGE -> 0.5F + 0.7F * Math.min(1.0F, phaseAge / 100.0F);
         case ABSORB -> 1.2F + 0.3F * Math.min(1.0F, phaseAge / 300.0F) + pulse;
         case COLLAPSE -> 1.5F * Math.max(0.0F, 1.0F - phaseAge / 15.0F);
      };
   }

   private static void quad(PoseStack poseStack, VertexConsumer consumer, int brightness) {
      Matrix4f pose = poseStack.last().pose();
      Pose normal = poseStack.last();
      vertex(consumer, pose, normal, -0.5F, -0.5F, 0.0F, 1.0F, brightness);
      vertex(consumer, pose, normal, 0.5F, -0.5F, 1.0F, 1.0F, brightness);
      vertex(consumer, pose, normal, 0.5F, 0.5F, 1.0F, 0.0F, brightness);
      vertex(consumer, pose, normal, -0.5F, 0.5F, 0.0F, 0.0F, brightness);
   }

   private static void vertex(VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float y, float u, float v, int brightness) {
      consumer.addVertex(pose, x, y, 0.0F)
         .setColor(brightness, brightness, brightness, 255)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(normal, 0.0F, 1.0F, 0.0F);
   }

   public ResourceLocation getTextureLocation(BlockHoleEntity orb) {
      return TEXTURE;
   }
}
