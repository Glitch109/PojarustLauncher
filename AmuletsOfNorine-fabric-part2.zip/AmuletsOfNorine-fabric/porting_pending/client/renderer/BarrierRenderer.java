package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.BarrierEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

public class BarrierRenderer extends EntityRenderer<BarrierEntity> {
   private static final ResourceLocation HEX = AmuletMod.id("textures/entity/aegis_hex.png");
   private static final float RIPPLE_TICKS = 18.0F;
   private static final float RED = 0.62F;
   private static final float GREEN = 0.46F;
   private static final float BLUE = 0.2F;

   public BarrierRenderer(Context context) {
      super(context);
   }

   public void render(BarrierEntity barrier, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float fade = barrier.fade(partialTick);
      float radius = barrier.radius() * barrier.scale(partialTick);
      if (!(fade <= 0.01F) && !(radius <= 0.05F)) {
         boolean dome = barrier.mode() == BarrierEntity.Mode.DOME;
         Vec3 origin = barrier.getPosition(partialTick);
         if (!dome) {
            Entity owner = barrier.level().getEntity(barrier.ownerEntityId());
            if (owner != null) {
               origin = owner.getPosition(partialTick);
            }
         }

         Vec3 offset = origin.subtract(barrier.getPosition(partialTick)).add(0.0, dome ? 0.0 : 0.95F, 0.0);
         Vec3 camera = this.entityRenderDispatcher.camera.getPosition().subtract(barrier.getPosition(partialTick).add(offset));
         float time = barrier.tickCount + partialTick;
         float since = barrier.sinceImpact(partialTick);
         Vec3 impact = barrier.impactDirection();
         float ripple = since < 18.0F ? 1.0F - since / 18.0F : 0.0F;
         float rippleArc = since * radius * 0.16F;
         float rippleWidth = Math.max(0.35F, radius * 0.08F);
         float cx = (float)camera.x;
         float cy = (float)camera.y;
         float cz = (float)camera.z;
         float ix = (float)impact.x;
         float iy = (float)impact.y;
         float iz = (float)impact.z;
         GlowDraw.SphereShader shader = (nx, ny, nz) -> {
            float px = cx - nx * radius;
            float py = cy - ny * radius;
            float pz = cz - nz * radius;
            float toCamera = Mth.sqrt(px * px + py * py + pz * pz);
            float facing = toCamera < 1.0E-4F ? 1.0F : Math.abs(nx * px + ny * py + nz * pz) / toCamera;
            float rim = (1.0F - facing) * (1.0F - facing);
            float brightness = 0.3F + 1.1F * rim;
            brightness *= 0.9F + 0.1F * Mth.sin(time * 0.2F + ny * 6.0F);
            if (ripple > 0.0F) {
               float arc = (float)Math.acos(Mth.clamp(nx * ix + ny * iy + nz * iz, -1.0F, 1.0F)) * radius;
               float ring = (arc - rippleArc) / rippleWidth;
               brightness += 2.2F * ripple * (float)Math.exp(-ring * ring);
               brightness += 2.5F * Math.max(0.0F, 1.0F - since / 5.0F) * (float)Math.exp(-arc * arc / (0.25F * radius));
            }

            return brightness * fade;
         };
         poseStack.pushPose();
         poseStack.translate(offset.x, offset.y, offset.z);
         float latFrom = dome ? -0.18F : (float) (-Math.PI / 2);
         int lonSegments = dome ? 56 : 28;
         int latSegments = dome ? 20 : 16;
         float uTiles = dome ? Math.max(8.0F, (float)Math.round(radius * 1.7F)) : 7.0F;
         float vTiles = dome ? Math.max(3.0F, (float)Math.round(radius * 0.6F)) : 5.0F;
         GlowBatch.add(
            ModRenderTypes.glowTextured(HEX),
            poseStack,
            (consumer, pose, normal) -> GlowDraw.sphere(
               consumer,
               pose,
               normal,
               radius,
               latFrom,
               (float) (Math.PI / 2),
               lonSegments,
               latSegments,
               uTiles,
               vTiles,
               time * 0.004F,
               -time * 0.003F,
               0.62F,
               0.46F,
               0.2F,
               shader
            )
         );
         if (dome) {
            float pulse = 0.8F + 0.2F * Mth.sin(time * 0.3F);
            float strength = fade * pulse;
            GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
               band(consumer, pose, radius - 0.1875F, radius - 0.0625F, 1.0F, 0.85F, 0.5F, 0.3F * strength);
               band(consumer, pose, radius - 0.0625F, radius + 0.0625F, 1.0F, 0.9F, 0.6F, 0.95F * strength);
               band(consumer, pose, radius + 0.0625F, radius + 0.25F, 1.0F, 0.75F, 0.35F, 0.45F * strength);
               band(consumer, pose, radius + 0.25F, radius + 0.5F, 1.0F, 0.75F, 0.35F, 0.18F * strength);
            });
         }

         poseStack.popPose();
         super.render(barrier, yaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   private static void band(VertexConsumer consumer, Matrix4f pose, float inner, float outer, float r, float g, float b, float alpha) {
      GlowDraw.ring(consumer, pose, 0.04F, inner, outer, 48, r, g, b, alpha, alpha);
   }

   public ResourceLocation getTextureLocation(BarrierEntity barrier) {
      return HEX;
   }
}
