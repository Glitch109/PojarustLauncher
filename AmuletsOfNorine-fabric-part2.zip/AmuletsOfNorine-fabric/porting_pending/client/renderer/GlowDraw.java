package com.amuletmod.client.renderer;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class GlowDraw {
   private static final Vector3f X = new Vector3f(1.0F, 0.0F, 0.0F);
   private static final Vector3f Y = new Vector3f(0.0F, 1.0F, 0.0F);

   private GlowDraw() {
   }

   public static void vertex(VertexConsumer consumer, Matrix4f pose, float x, float y, float z, float r, float g, float b, float a) {
      consumer.addVertex(pose, x, y, z).setColor(r, g, b, a);
   }

   public static void texVertex(VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float y, float z, float r, float g, float b, float u, float v) {
      consumer.addVertex(pose, x, y, z)
         .setColor(Mth.clamp(r, 0.0F, 1.0F), Mth.clamp(g, 0.0F, 1.0F), Mth.clamp(b, 0.0F, 1.0F), 1.0F)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(normal, 0.0F, 1.0F, 0.0F);
   }

   public static void disc(VertexConsumer consumer, Matrix4f pose, Vector3f at, Vector3f normal, float size, float spin, float r, float g, float b) {
      Vector3f u = new Vector3f(normal).cross(Math.abs(normal.y()) > 0.95F ? X : Y).normalize();
      Vector3f v = new Vector3f(normal).cross(u).normalize();
      float cos = Mth.cos(spin);
      float sin = Mth.sin(spin);
      Vector3f across = new Vector3f(u).mul(cos).add(new Vector3f(v).mul(sin)).mul(size);
      Vector3f up = new Vector3f(v).mul(cos).sub(new Vector3f(u).mul(sin)).mul(size);
      float[][] corners = new float[][]{{-1.0F, -1.0F, 0.0F, 0.0F}, {1.0F, -1.0F, 1.0F, 0.0F}, {1.0F, 1.0F, 1.0F, 1.0F}, {-1.0F, 1.0F, 0.0F, 1.0F}};

      for (float[] corner : corners) {
         float x = at.x() + across.x() * corner[0] + up.x() * corner[1];
         float y = at.y() + across.y() * corner[0] + up.y() * corner[1];
         float z = at.z() + across.z() * corner[0] + up.z() * corner[1];
         consumer.addVertex(pose, x, y, z)
            .setUv(corner[2], corner[3])
            .setColor(Mth.clamp(r, 0.0F, 1.0F), Mth.clamp(g, 0.0F, 1.0F), Mth.clamp(b, 0.0F, 1.0F), 1.0F);
      }
   }

   public static void stamp(
      VertexConsumer consumer, Matrix4f pose, Pose normal, Vector3f at, Vector3f right, Vector3f up, float size, float spin, float r, float g, float b
   ) {
      float cos = Mth.cos(spin) * size;
      float sin = Mth.sin(spin) * size;
      float[][] corners = new float[][]{{-1.0F, -1.0F, 0.0F, 1.0F}, {1.0F, -1.0F, 1.0F, 1.0F}, {1.0F, 1.0F, 1.0F, 0.0F}, {-1.0F, 1.0F, 0.0F, 0.0F}};

      for (float[] corner : corners) {
         float across = corner[0] * cos - corner[1] * sin;
         float along = corner[0] * sin + corner[1] * cos;
         texVertex(
            consumer,
            pose,
            normal,
            at.x() + right.x() * across + up.x() * along,
            at.y() + right.y() * across + up.y() * along,
            at.z() + right.z() * across + up.z() * along,
            r,
            g,
            b,
            corner[2],
            corner[3]
         );
      }
   }

   public static void farBeam(
      VertexConsumer consumer,
      Matrix4f pose,
      Vector3f from,
      Vector3f to,
      Vector3f camera,
      int segments,
      float spread,
      float narrowest,
      float widest,
      float r,
      float g,
      float b,
      float alpha
   ) {
      Vector3f along = new Vector3f(to).sub(from);
      Vector3f before = null;
      Vector3f beforeSide = null;

      for (int i = 0; i <= segments; i++) {
         Vector3f point = new Vector3f(from).lerp(to, (float)i / segments);
         Vector3f toCamera = new Vector3f(camera).sub(point);
         Vector3f side = new Vector3f(along).cross(toCamera);
         if (side.lengthSquared() < 1.0E-8F) {
            side.set(1.0F, 0.0F, 0.0F);
         }

         side.normalize(Mth.clamp(toCamera.length() * spread, narrowest, widest));
         if (before != null) {
            for (float sign : new float[]{-1.0F, 1.0F}) {
               vertex(consumer, pose, before.x, before.y, before.z, r, g, b, alpha);
               vertex(consumer, pose, point.x, point.y, point.z, r, g, b, alpha);
               vertex(consumer, pose, point.x + side.x * sign, point.y + side.y * sign, point.z + side.z * sign, r, g, b, 0.0F);
               vertex(consumer, pose, before.x + beforeSide.x * sign, before.y + beforeSide.y * sign, before.z + beforeSide.z * sign, r, g, b, 0.0F);
            }
         }

         before = point;
         beforeSide = side;
      }
   }

   public static void sphere(
      VertexConsumer consumer,
      Matrix4f pose,
      Pose normal,
      float radius,
      float latFrom,
      float latTo,
      int lonSegments,
      int latSegments,
      float uTiles,
      float vTiles,
      float spin,
      float vScroll,
      float r,
      float g,
      float b,
      GlowDraw.SphereShader shader
   ) {
      for (int lat = 0; lat < latSegments; lat++) {
         float lat0 = Mth.lerp((float)lat / latSegments, latFrom, latTo);
         float lat1 = Mth.lerp((float)(lat + 1) / latSegments, latFrom, latTo);
         float v0 = (float)lat / latSegments * vTiles + vScroll;
         float v1 = (float)(lat + 1) / latSegments * vTiles + vScroll;

         for (int lon = 0; lon < lonSegments; lon++) {
            float lon0 = (float)lon / lonSegments * (float) (Math.PI * 2);
            float lon1 = (float)(lon + 1) / lonSegments * (float) (Math.PI * 2);
            float u0 = (float)lon / lonSegments * uTiles;
            float u1 = (float)(lon + 1) / lonSegments * uTiles;
            sphereVertex(consumer, pose, normal, radius, lat0, lon0, spin, r, g, b, u0, v0, shader);
            sphereVertex(consumer, pose, normal, radius, lat1, lon0, spin, r, g, b, u0, v1, shader);
            sphereVertex(consumer, pose, normal, radius, lat1, lon1, spin, r, g, b, u1, v1, shader);
            sphereVertex(consumer, pose, normal, radius, lat0, lon1, spin, r, g, b, u1, v0, shader);
         }
      }
   }

   private static void sphereVertex(
      VertexConsumer consumer,
      Matrix4f pose,
      Pose normal,
      float radius,
      float lat,
      float lon,
      float spin,
      float r,
      float g,
      float b,
      float u,
      float v,
      GlowDraw.SphereShader shader
   ) {
      float cosLat = Mth.cos(lat);
      float nx = cosLat * Mth.cos(lon + spin);
      float ny = Mth.sin(lat);
      float nz = cosLat * Mth.sin(lon + spin);
      float brightness = shader.brightness(nx, ny, nz);
      texVertex(consumer, pose, normal, nx * radius, ny * radius, nz * radius, r * brightness, g * brightness, b * brightness, u, v);
   }

   public static void ribbon(
      VertexConsumer consumer, Matrix4f pose, Vector3f[] points, Vector3f camera, float halfWidth, float r, float g, float b, float alpha
   ) {
      Vector3f[] sides = new Vector3f[points.length];

      for (int i = 0; i < points.length; i++) {
         Vector3f along = new Vector3f(points[Math.min(i + 1, points.length - 1)]).sub(points[Math.max(i - 1, 0)]);
         Vector3f side = along.cross(new Vector3f(camera).sub(points[i]));
         if (side.lengthSquared() < 1.0E-8F) {
            side.set(1.0F, 0.0F, 0.0F);
         }

         sides[i] = side.normalize(halfWidth);
      }

      for (int i = 0; i + 1 < points.length; i++) {
         Vector3f p0 = points[i];
         Vector3f p1 = points[i + 1];
         Vector3f s0 = sides[i];
         Vector3f s1 = sides[i + 1];

         for (float sign : new float[]{-1.0F, 1.0F}) {
            vertex(consumer, pose, p0.x, p0.y, p0.z, r, g, b, alpha);
            vertex(consumer, pose, p1.x, p1.y, p1.z, r, g, b, alpha);
            vertex(consumer, pose, p1.x + s1.x * sign, p1.y + s1.y * sign, p1.z + s1.z * sign, r, g, b, 0.0F);
            vertex(consumer, pose, p0.x + s0.x * sign, p0.y + s0.y * sign, p0.z + s0.z * sign, r, g, b, 0.0F);
         }
      }
   }

   public static void taperedRibbon(
      VertexConsumer consumer, Matrix4f pose, Vector3f[] points, Vector3f camera, float halfWidth, float r, float g, float b, float alpha
   ) {
      int last = points.length - 1;
      Vector3f[] sides = new Vector3f[points.length];

      for (int i = 0; i <= last; i++) {
         Vector3f along = new Vector3f(points[Math.min(i + 1, last)]).sub(points[Math.max(i - 1, 0)]);
         Vector3f side = along.cross(new Vector3f(camera).sub(points[i]));
         if (side.lengthSquared() < 1.0E-8F) {
            side.set(1.0F, 0.0F, 0.0F);
         }

         sides[i] = side.normalize(halfWidth * (1.0F - (float)i / last));
      }

      for (int i = 0; i < last; i++) {
         Vector3f p0 = points[i];
         Vector3f p1 = points[i + 1];
         Vector3f s0 = sides[i];
         Vector3f s1 = sides[i + 1];
         float a0 = alpha * (1.0F - (float)i / last);
         float a1 = alpha * (1.0F - (float)(i + 1) / last);

         for (float sign : new float[]{-1.0F, 1.0F}) {
            vertex(consumer, pose, p0.x, p0.y, p0.z, r, g, b, a0);
            vertex(consumer, pose, p1.x, p1.y, p1.z, r, g, b, a1);
            vertex(consumer, pose, p1.x + s1.x * sign, p1.y + s1.y * sign, p1.z + s1.z * sign, r, g, b, 0.0F);
            vertex(consumer, pose, p0.x + s0.x * sign, p0.y + s0.y * sign, p0.z + s0.z * sign, r, g, b, 0.0F);
         }
      }
   }

   public static void beam(
      VertexConsumer consumer,
      Matrix4f pose,
      Vector3f from,
      Vector3f to,
      Vector3f camera,
      float halfWidth,
      int segments,
      float r,
      float g,
      float b,
      float alpha
   ) {
      Vector3f[] points = new Vector3f[segments + 1];

      for (int i = 0; i <= segments; i++) {
         points[i] = new Vector3f(from).lerp(to, (float)i / segments);
      }

      ribbon(consumer, pose, points, camera, halfWidth, r, g, b, alpha);
   }

   public static void glowSphere(
      VertexConsumer consumer,
      Matrix4f pose,
      float radius,
      float latFrom,
      float latTo,
      int lonSegments,
      int latSegments,
      float r,
      float g,
      float b,
      GlowDraw.SphereShader alpha
   ) {
      for (int lat = 0; lat < latSegments; lat++) {
         float lat0 = Mth.lerp((float)lat / latSegments, latFrom, latTo);
         float lat1 = Mth.lerp((float)(lat + 1) / latSegments, latFrom, latTo);

         for (int lon = 0; lon < lonSegments; lon++) {
            float lon0 = (float)lon / lonSegments * (float) (Math.PI * 2);
            float lon1 = (float)(lon + 1) / lonSegments * (float) (Math.PI * 2);
            glowSphereVertex(consumer, pose, radius, lat0, lon0, r, g, b, alpha);
            glowSphereVertex(consumer, pose, radius, lat1, lon0, r, g, b, alpha);
            glowSphereVertex(consumer, pose, radius, lat1, lon1, r, g, b, alpha);
            glowSphereVertex(consumer, pose, radius, lat0, lon1, r, g, b, alpha);
         }
      }
   }

   private static void glowSphereVertex(
      VertexConsumer consumer, Matrix4f pose, float radius, float lat, float lon, float r, float g, float b, GlowDraw.SphereShader alpha
   ) {
      float cosLat = Mth.cos(lat);
      float nx = cosLat * Mth.cos(lon);
      float ny = Mth.sin(lat);
      float nz = cosLat * Mth.sin(lon);
      vertex(consumer, pose, nx * radius, ny * radius, nz * radius, r, g, b, alpha.brightness(nx, ny, nz));
   }

   public static void starburst(VertexConsumer consumer, Matrix4f pose, float size, float squat, float r, float g, float b, float alpha) {
      for (int i = 0; i < 8; i++) {
         float a0 = i * (float) Math.PI / 4.0F;
         float a1 = (i + 1) * (float) Math.PI / 4.0F;
         float r0 = size * (i % 2 == 0 ? 1.0F : squat);
         float r1 = size * (i % 2 == 0 ? squat : 1.0F);
         vertex(consumer, pose, 0.0F, 0.0F, 0.0F, r, g, b, alpha);
         vertex(consumer, pose, Mth.cos(a0) * r0, Mth.sin(a0) * r0, 0.0F, r, g, b, 0.0F);
         vertex(consumer, pose, Mth.cos(a1) * r1, Mth.sin(a1) * r1, 0.0F, r, g, b, 0.0F);
         vertex(consumer, pose, 0.0F, 0.0F, 0.0F, r, g, b, alpha);
      }
   }

   public static void band(VertexConsumer consumer, Matrix4f pose, float radius, float halfHeight, int segments, float r, float g, float b, float alpha) {
      for (int i = 0; i < segments; i++) {
         float a0 = (float)i / segments * (float) (Math.PI * 2);
         float a1 = (float)(i + 1) / segments * (float) (Math.PI * 2);
         float x0 = Mth.cos(a0) * radius;
         float z0 = Mth.sin(a0) * radius;
         float x1 = Mth.cos(a1) * radius;
         float z1 = Mth.sin(a1) * radius;

         for (float edge : new float[]{-halfHeight, halfHeight}) {
            vertex(consumer, pose, x0, 0.0F, z0, r, g, b, alpha);
            vertex(consumer, pose, x1, 0.0F, z1, r, g, b, alpha);
            vertex(consumer, pose, x1, edge, z1, r, g, b, 0.0F);
            vertex(consumer, pose, x0, edge, z0, r, g, b, 0.0F);
         }
      }
   }

   public static void ring(
      VertexConsumer consumer,
      Matrix4f pose,
      float y,
      float innerRadius,
      float outerRadius,
      int segments,
      float r,
      float g,
      float b,
      float innerAlpha,
      float outerAlpha
   ) {
      for (int i = 0; i < segments; i++) {
         float a0 = (float)i / segments * (float) (Math.PI * 2);
         float a1 = (float)(i + 1) / segments * (float) (Math.PI * 2);
         float c0 = Mth.cos(a0);
         float s0 = Mth.sin(a0);
         float c1 = Mth.cos(a1);
         float s1 = Mth.sin(a1);
         vertex(consumer, pose, c0 * innerRadius, y, s0 * innerRadius, r, g, b, innerAlpha);
         vertex(consumer, pose, c0 * outerRadius, y, s0 * outerRadius, r, g, b, outerAlpha);
         vertex(consumer, pose, c1 * outerRadius, y, s1 * outerRadius, r, g, b, outerAlpha);
         vertex(consumer, pose, c1 * innerRadius, y, s1 * innerRadius, r, g, b, innerAlpha);
      }
   }

   @FunctionalInterface
   public interface SphereShader {
      float brightness(float var1, float var2, float var3);
   }
}
