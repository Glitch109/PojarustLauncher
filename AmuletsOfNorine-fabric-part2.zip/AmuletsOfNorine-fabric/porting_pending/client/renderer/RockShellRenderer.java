package com.amuletmod.client.renderer;

import com.amuletmod.entity.RockShellEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.List;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.model.data.ModelData;

public class RockShellRenderer extends EntityRenderer<RockShellEntity> {
   private static final float ROCK_SIZE = 0.22F;
   private final BlockRenderDispatcher blocks;

   public RockShellRenderer(Context context) {
      super(context);
      this.blocks = context.getBlockRenderDispatcher();
   }

   public void render(RockShellEntity shell, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      Entity owner = shell.owner();
      List<RockShellEntity.Source> sources = shell.sources();
      float age = shell.tickCount + partialTick;
      if (owner != null && !sources.isEmpty() && !(age > RockShellEntity.formsAt(RockShellEntity.PIECES - 1))) {
         Vec3 feet = owner.getPosition(partialTick);
         Vec3 self = shell.getPosition(partialTick);
         float bodyYaw = owner instanceof LivingEntity living ? Mth.rotLerp(partialTick, living.yBodyRotO, living.yBodyRot) : owner.getYRot();

         for (int i = 0; i < RockShellEntity.PIECES; i++) {
            float t = (age - RockShellEntity.launchAt(i)) / 14.0F;
            if (!(t <= 0.0F) && !(t >= 1.0F)) {
               RockShellEntity.Source source = sources.get(i % sources.size());
               Vec3 at = RockShellEntity.flightPosition(source, i, age, feet, bodyYaw).subtract(self);
               poseStack.pushPose();
               poseStack.translate(at.x, at.y, at.z);
               poseStack.mulPose(Axis.YP.rotationDegrees(age * 25.0F + i * 40.0F));
               poseStack.mulPose(Axis.XP.rotationDegrees(age * 18.0F));
               poseStack.scale(0.22F, 0.22F, 0.22F);
               poseStack.translate(-0.5F, -0.5F, -0.5F);
               this.blocks.renderSingleBlock(source.state(), poseStack, buffers, packedLight, OverlayTexture.NO_OVERLAY, ModelData.EMPTY, null);
               poseStack.popPose();
            }
         }

         super.render(shell, entityYaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   public boolean shouldRender(RockShellEntity shell, Frustum frustum, double x, double y, double z) {
      return shell.owner() != null && super.shouldRender(shell, frustum, x, y, z);
   }

   public ResourceLocation getTextureLocation(RockShellEntity shell) {
      return TextureAtlas.LOCATION_BLOCKS;
   }
}
