package com.amuletmod.client.renderer;

import com.amuletmod.entity.SealCoreEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class SealCoreRenderer extends EntityRenderer<SealCoreEntity> {
   private static final float FLOOR = -0.53F;
   private static final float OUTER = 0.4F;
   private static final float INNER = 0.24F;
   private static final Quaternionf ON_CORNER = new Quaternionf()
      .setAngleAxis((float)Math.acos(1.0 / Math.sqrt(3.0)), Mth.sin((float) (Math.PI / 4)), 0.0F, -Mth.sin((float) (Math.PI / 4)));

   public SealCoreRenderer(Context context) {
      super(context);
   }

   public void render(SealCoreEntity core, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float age = core.tickCount + partialTick;
      float strain = core.strain();
      float breaking = core.isAlive() ? 0.0F : Mth.clamp((core.deathTime + partialTick) / 18.0F, 0.0F, 1.0F);
      float flinch = core.hurtTime > 0 ? Math.max(0.0F, (core.hurtTime - partialTick) / 10.0F) : 0.0F;
      float middle = core.getBbHeight() * 0.5F;
      Vector3f eye = this.entityRenderDispatcher.camera.getPosition().subtract(core.getPosition(partialTick)).subtract(0.0, middle, 0.0).toVector3f();
      float[] glow = SealRenderer.GLOW;
      float[] pale = SealRenderer.PALE;
      float heat = Mth.clamp(strain * 0.7F + flinch * 0.5F + breaking, 0.0F, 1.0F);
      float[] colour = new float[]{Mth.lerp(heat, glow[0], pale[0]), Mth.lerp(heat, glow[1], pale[1]), Mth.lerp(heat, glow[2], pale[2])};
      float fade = 1.0F - breaking;
      float swell = (1.0F + 0.15F * flinch + 2.2F * Easing.outCubic(breaking)) * (1.0F + 0.04F * Mth.sin(age * 0.25F));
      float spin = age * (2.0F + 7.0F * strain) + breaking * 300.0F;
      RandomSource shake = RandomSource.create(core.getId() * 31L + (long)(age * 2.0F));
      float jitter = 0.05F * strain * strain;
      poseStack.pushPose();
      poseStack.translate(
         (shake.nextFloat() - 0.5F) * jitter, middle + 0.06F * Mth.sin(age * 0.08F) + (shake.nextFloat() - 0.5F) * jitter, (shake.nextFloat() - 0.5F) * jitter
      );
      poseStack.pushPose();
      poseStack.mulPose(Axis.YP.rotationDegrees(spin));
      poseStack.mulPose(ON_CORNER);
      float outer = 0.4F * swell;
      GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
         SealCaptureRenderer.box(consumer, pose, new Vector3f(), outer, outer, outer, colour, 0.14F * fade);
         frame(consumer, pose, outer, colour, 0.85F * fade);
      });
      poseStack.popPose();
      poseStack.pushPose();
      poseStack.mulPose(Axis.YP.rotationDegrees(-spin * 1.7F));
      poseStack.mulPose(ON_CORNER);
      float inner = 0.24F * swell;
      GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
         SealCaptureRenderer.box(consumer, pose, new Vector3f(), inner, inner, inner, colour, 0.3F * fade);
         frame(consumer, pose, inner, pale, 0.9F * fade);
      });
      poseStack.popPose();
      GlowBatch.add(
         ModRenderTypes.GLOW,
         poseStack,
         (consumer, pose, normal) -> {
            float pulse = 1.0F + 0.2F * Mth.sin(age * (0.3F + strain));
            GlowDraw.glowSphere(
               consumer,
               pose,
               0.13F * pulse * swell,
               (float) (-Math.PI / 2),
               (float) (Math.PI / 2),
               10,
               5,
               pale[0],
               pale[1],
               pale[2],
               (nx, ny, nz) -> 0.95F * fade
            );
            GlowDraw.glowSphere(
               consumer,
               pose,
               0.75F * swell,
               (float) (-Math.PI / 2),
               (float) (Math.PI / 2),
               14,
               7,
               colour[0],
               colour[1],
               colour[2],
               (nx, ny, nz) -> (0.12F + 0.14F * strain + 0.3F * flinch) * fade
            );
            if (strain > 0.3F && breaking <= 0.0F) {
               RandomSource random = RandomSource.create(core.getId() * 17L + (long)(age / 2.0F));

               for (int arc = 0; arc < 1 + (int)(strain * 3.0F); arc++) {
                  if (!(random.nextFloat() > strain)) {
                     Vector3f to = new Vector3f(random.nextFloat() - 0.5F, random.nextFloat() - 0.5F, random.nextFloat() - 0.5F)
                        .normalize(0.5F + random.nextFloat() * 0.5F);
                     Vector3f[] points = new Vector3f[6];

                     for (int k = 0; k < points.length; k++) {
                        float along = (float)k / (points.length - 1);
                        float kink = Mth.sin(along * (float) Math.PI) * 0.18F;
                        points[k] = new Vector3f(to)
                           .mul(along)
                           .add((random.nextFloat() - 0.5F) * kink, (random.nextFloat() - 0.5F) * kink, (random.nextFloat() - 0.5F) * kink);
                     }

                     GlowDraw.ribbon(consumer, pose, points, eye, 0.07F, glow[0], glow[1], glow[2], 0.6F);
                     GlowDraw.ribbon(consumer, pose, points, eye, 0.025F, pale[0], pale[1], pale[2], 0.95F);
                  }
               }
            }

            if (breaking > 0.0F) {
               GlowDraw.glowSphere(
                  consumer,
                  pose,
                  0.4F + 7.0F * Easing.outCubic(breaking),
                  (float) (-Math.PI / 2),
                  (float) (Math.PI / 2),
                  20,
                  10,
                  pale[0],
                  pale[1],
                  pale[2],
                  (nx, ny, nz) -> 0.9F * fade
               );
            }
         }
      );
      if (breaking > 0.0F && breaking < 0.5F) {
         float flash = 1.0F - breaking * 2.0F;
         poseStack.pushPose();
         poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
         poseStack.mulPose(Axis.ZP.rotationDegrees(22.5F));
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            GlowDraw.starburst(consumer, pose, 2.0F + 4.0F * breaking, 0.3F, colour[0], colour[1], colour[2], flash);
            GlowDraw.starburst(consumer, pose, 1.2F, 0.4F, pale[0], pale[1], pale[2], flash);
         });
         poseStack.popPose();
      }

      poseStack.popPose();
      float circleLight = (0.75F + 0.25F * Mth.sin(age * 0.15F) + flinch) * fade;
      GlowBatch.add(
         ModRenderTypes.glowTextured(SealRenderer.CIRCLE),
         poseStack,
         (consumer, pose, normal) -> {
            Vector3f at = new Vector3f(0.0F, -0.53F, 0.0F);
            Vector3f right = new Vector3f(1.0F, 0.0F, 0.0F);
            Vector3f up = new Vector3f(0.0F, 0.0F, -1.0F);
            GlowDraw.stamp(consumer, pose, normal, at, right, up, 1.5F, age * 0.02F, glow[0] * circleLight, glow[1] * circleLight, glow[2] * circleLight);
            GlowDraw.stamp(
               consumer,
               pose,
               normal,
               at,
               right,
               up,
               0.95F,
               -age * (0.04F + 0.1F * strain),
               colour[0] * circleLight,
               colour[1] * circleLight,
               colour[2] * circleLight
            );
         }
      );
      poseStack.pushPose();
      poseStack.translate(0.0F, (-0.53F + middle) * 0.5F, 0.0F);
      GlowBatch.add(
         ModRenderTypes.GLOW,
         poseStack,
         (consumer, pose, normal) -> GlowDraw.band(consumer, pose, 0.45F, (middle - -0.53F) * 0.5F, 24, glow[0], glow[1], glow[2], 0.22F * fade)
      );
      poseStack.popPose();
      super.render(core, yaw, partialTick, poseStack, buffers, packedLight);
   }

   private static void frame(VertexConsumer consumer, Matrix4f pose, float half, float[] colour, float alpha) {
      float in = half * 0.82F;
      float[] point = new float[3];

      for (int axis = 0; axis < 3; axis++) {
         for (float side = -1.0F; side <= 1.0F; side += 2.0F) {
            for (int edge = 0; edge < 4; edge++) {
               int fixed = (axis + (edge < 2 ? 1 : 2)) % 3;
               int along = (axis + (edge < 2 ? 2 : 1)) % 3;
               float sign = edge % 2 == 0 ? -1.0F : 1.0F;

               for (int corner = 0; corner < 4; corner++) {
                  boolean inner = corner >= 2;
                  point[axis] = side * half;
                  point[fixed] = sign * (inner ? in : half);
                  point[along] = corner != 0 && corner != 3 ? half : -half;
                  GlowDraw.vertex(consumer, pose, point[0], point[1], point[2], colour[0], colour[1], colour[2], inner ? 0.0F : alpha);
               }
            }
         }
      }
   }

   public ResourceLocation getTextureLocation(SealCoreEntity core) {
      return SealRenderer.CIRCLE;
   }
}
