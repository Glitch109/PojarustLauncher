package com.amuletmod.client.renderer;

import com.amuletmod.client.PetalOrbitClient;
import com.amuletmod.entity.PetalEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class PetalRenderer extends EntityRenderer<PetalEntity> {
   private static final float HALF_LENGTH = 0.16F;
   private static final float HALF_WIDTH = 0.09F;

   public PetalRenderer(Context context) {
      super(context);
   }

   public void render(PetalEntity petal, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      int color = petal.color();
      float r = (color >> 16 & 0xFF) / 255.0F;
      float g = (color >> 8 & 0xFF) / 255.0F;
      float b = (color & 0xFF) / 255.0F;
      Vec3 at = petal.getPosition(partialTick);
      int count = 1;

      while (count <= 6 && petal.trail[count - 1] != null) {
         count++;
      }

      if (count > 2) {
         Vector3f[] points = new Vector3f[count];
         points[0] = new Vector3f();

         for (int i = 1; i < count; i++) {
            points[i] = petal.trail[i - 1].subtract(at).toVector3f();
         }

         Vec3 view = this.entityRenderDispatcher.camera.getPosition();
         Vector3f eye = view.subtract(at).toVector3f();
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumerx, posex, normalx) -> GlowDraw.ribbon(consumerx, posex, points, eye, 0.07F, r, g, b, 0.55F));
      }

      poseStack.pushPose();
      poseStack.mulPose(Axis.YP.rotationDegrees(Mth.rotLerp(partialTick, petal.yRotO, petal.getYRot())));
      poseStack.mulPose(Axis.XP.rotationDegrees(-Mth.lerp(partialTick, petal.xRotO, petal.getXRot())));
      poseStack.mulPose(Axis.ZP.rotationDegrees((petal.tickCount + partialTick) * 38.0F));
      VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(this.getTextureLocation(petal)));
      Matrix4f pose = poseStack.last().pose();
      Pose normal = poseStack.last();
      vertex(consumer, pose, normal, -0.09F, -0.16F, 0.0F, 1.0F, r, g, b);
      vertex(consumer, pose, normal, 0.09F, -0.16F, 1.0F, 1.0F, r, g, b);
      vertex(consumer, pose, normal, 0.09F, 0.16F, 1.0F, 0.0F, r, g, b);
      vertex(consumer, pose, normal, -0.09F, 0.16F, 0.0F, 0.0F, r, g, b);
      poseStack.popPose();
      super.render(petal, entityYaw, partialTick, poseStack, buffers, packedLight);
   }

   private static void vertex(VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float z, float u, float v, float r, float g, float b) {
      consumer.addVertex(pose, x, 0.0F, z)
         .setColor(r, g, b, 1.0F)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(normal, 0.0F, 1.0F, 0.0F);
   }

   public ResourceLocation getTextureLocation(PetalEntity petal) {
      return PetalOrbitClient.PETAL;
   }
}
