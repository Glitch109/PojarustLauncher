package com.amuletmod.client.renderer;

import com.amuletmod.entity.SealCaptureEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class SealCaptureRenderer extends EntityRenderer<SealCaptureEntity> {
   private static final int[][] BARS = new int[][]{{0, 1}, {1, 3}, {3, 2}, {2, 0}, {4, 5}, {5, 7}, {7, 6}, {6, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};

   public SealCaptureRenderer(Context context) {
      super(context);
   }

   public void render(SealCaptureEntity seal, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float age = seal.tickCount + partialTick;
      float width = seal.victimWidth();
      float height = seal.victimHeight();
      float failing = seal.failing(partialTick);
      float whole = 1.0F - failing;
      Vec3 feet = seal.getPosition(partialTick);
      Vector3f eye = this.entityRenderDispatcher.camera.getPosition().subtract(feet).toVector3f();
      Vector3f heart = SealCaptureEntity.heart(height).toVector3f();
      float[] glow = SealRenderer.GLOW;
      float[] pale = SealRenderer.PALE;
      boolean caged = age < 20.0F || seal.outcome() == 2;
      float circleFade = whole * (1.0F - Easing.smoothstep(20.0F, 28.0F, age));
      if (circleFade > 0.01F) {
         float open = Easing.outBack(age / 7.0F);
         float size = Math.max(1.0F, width * 0.5F + 0.9F) * open;
         float spin = age * age * 0.006F;
         float light = (0.7F + 0.5F * SealCaptureEntity.squeeze(age)) * circleFade;
         GlowBatch.add(ModRenderTypes.glowTextured(SealRenderer.CIRCLE), poseStack, (consumer, pose, normal) -> {
            Vector3f at = new Vector3f(0.0F, 0.05F, 0.0F);
            Vector3f right = new Vector3f(1.0F, 0.0F, 0.0F);
            Vector3f up = new Vector3f(0.0F, 0.0F, -1.0F);
            GlowDraw.stamp(consumer, pose, normal, at, right, up, size, spin, glow[0] * light, glow[1] * light, glow[2] * light);
            GlowDraw.stamp(consumer, pose, normal, at, right, up, size * 0.62F, -spin * 1.7F, glow[0] * light, glow[1] * light, glow[2] * light);
         });
      }

      if (caged) {
         float w = SealCaptureEntity.cageWidth(width, age) * (1.0F + 0.4F * failing);
         float h = SealCaptureEntity.cageHeight(height, age) * (1.0F + 0.4F * failing);
         float drawn = Mth.clamp(age / 8.0F, 0.0F, 1.0F);
         float squeeze = SealCaptureEntity.squeeze(age);
         Vector3f[] corners = new Vector3f[8];

         for (int i = 0; i < 8; i++) {
            corners[i] = new Vector3f(heart).add((i & 1) == 0 ? -w : w, (i & 4) == 0 ? -h : h, (i & 2) == 0 ? -w : w);
         }

         float barLight = (0.7F + 0.6F * squeeze) * whole;
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            for (int k = 0; k < BARS.length; k++) {
               float grown = Easing.outCubic(Mth.clamp(drawn * 1.6F - k * 0.05F, 0.0F, 1.0F));
               if (!(grown <= 0.0F)) {
                  Vector3f from = corners[BARS[k][0]];
                  Vector3f to = new Vector3f(from).lerp(corners[BARS[k][1]], grown);
                  GlowDraw.beam(consumer, pose, from, to, eye, 0.09F, 4, glow[0], glow[1], glow[2], 0.6F * barLight);
                  GlowDraw.beam(consumer, pose, from, to, eye, 0.03F, 4, pale[0], pale[1], pale[2], barLight);
               }
            }

            box(consumer, pose, heart, w, h, w, glow, (0.05F + 0.3F * squeeze) * drawn * whole);
         });
      } else {
         this.flight(seal, age, feet, heart, eye, poseStack);
      }

      float snap = age - 20.0F;
      if (seal.outcome() == 1 && snap >= 0.0F && snap < 7.0F) {
         float flash = 1.0F - snap / 7.0F;
         poseStack.pushPose();
         poseStack.translate(heart.x(), heart.y(), heart.z());
         GlowBatch.add(
            ModRenderTypes.GLOW,
            poseStack,
            (consumer, pose, normal) -> GlowDraw.glowSphere(
               consumer,
               pose,
               0.3F + 1.3F * (1.0F - flash),
               (float) (-Math.PI / 2),
               (float) (Math.PI / 2),
               14,
               7,
               pale[0],
               pale[1],
               pale[2],
               (nx, ny, nz) -> 0.7F * flash * flash
            )
         );
         poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
         poseStack.mulPose(Axis.ZP.rotationDegrees(22.5F));
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            GlowDraw.starburst(consumer, pose, 1.6F + 1.4F * (1.0F - flash), 0.3F, glow[0], glow[1], glow[2], flash);
            GlowDraw.starburst(consumer, pose, 0.8F, 0.4F, pale[0], pale[1], pale[2], flash);
         });
         poseStack.popPose();
      }

      super.render(seal, yaw, partialTick, poseStack, buffers, packedLight);
   }

   private void flight(SealCaptureEntity seal, float age, Vec3 feet, Vector3f heart, Vector3f eye, PoseStack poseStack) {
      Entity caster = seal.level().getEntity(seal.casterId());
      if (caster != null) {
         float partialTick = age - seal.tickCount;
         Vector3f chest = caster.getPosition(partialTick).add(0.0, caster.getBbHeight() * 0.62, 0.0).subtract(feet).toVector3f();
         Vector3f control = new Vector3f(heart).lerp(chest, 0.5F).add(0.0F, 1.2F + heart.distance(chest) * 0.2F, 0.0F);
         float flown = SealCaptureEntity.flight(age);
         float[] glow = SealRenderer.GLOW;
         float[] pale = SealRenderer.PALE;
         if (!(flown < 1.0F)) {
            float landed = Mth.clamp((age - 20.0F - 12.0F) / 6.0F, 0.0F, 1.0F);
            poseStack.pushPose();
            poseStack.translate(chest.x(), chest.y(), chest.z());
            GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
               float ring = 0.2F + 0.9F * Easing.outCubic(landed);
               float light = 0.8F * (1.0F - landed);
               GlowDraw.ring(consumer, pose, 0.0F, Math.max(0.0F, ring - 0.35F), ring, 28, glow[0], glow[1], glow[2], 0.0F, light);
               GlowDraw.ring(consumer, pose, 0.0F, ring, ring + 0.12F, 28, pale[0], pale[1], pale[2], light, 0.0F);
            });
            poseStack.popPose();
         } else {
            Vector3f[] trail = new Vector3f[12];

            for (int i = 0; i < trail.length; i++) {
               trail[i] = bezier(heart, control, chest, Mth.lerp((float)i / (trail.length - 1), flown, Math.max(0.0F, flown - 0.35F)));
            }

            Vector3f cube = trail[0];
            GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
               GlowDraw.taperedRibbon(consumer, pose, trail, eye, 0.2F, glow[0], glow[1], glow[2], 0.7F);
               GlowDraw.taperedRibbon(consumer, pose, trail, eye, 0.07F, pale[0], pale[1], pale[2], 0.9F);
            });
            poseStack.pushPose();
            poseStack.translate(cube.x(), cube.y(), cube.z());
            GlowBatch.add(
               ModRenderTypes.GLOW,
               poseStack,
               (consumer, pose, normal) -> GlowDraw.glowSphere(
                  consumer, pose, 0.55F, (float) (-Math.PI / 2), (float) (Math.PI / 2), 12, 6, glow[0], glow[1], glow[2], (nx, ny, nz) -> 0.3F
               )
            );
            poseStack.mulPose(Axis.YP.rotationDegrees(age * 31.0F));
            poseStack.mulPose(Axis.XP.rotationDegrees(age * 23.0F));
            GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
               box(consumer, pose, new Vector3f(), 0.2F, 0.2F, 0.2F, glow, 0.55F);
               box(consumer, pose, new Vector3f(), 0.1F, 0.1F, 0.1F, pale, 0.9F);
            });
            poseStack.popPose();
         }
      }
   }

   private static Vector3f bezier(Vector3f from, Vector3f control, Vector3f to, float s) {
      float t = 1.0F - s;
      return new Vector3f(from).mul(t * t).add(new Vector3f(control).mul(2.0F * t * s)).add(new Vector3f(to).mul(s * s));
   }

   static void box(VertexConsumer consumer, Matrix4f pose, Vector3f middle, float x, float y, float z, float[] colour, float alpha) {
      float[] half = new float[]{x, y, z};
      float[] point = new float[3];

      for (int axis = 0; axis < 3; axis++) {
         for (float side = -1.0F; side <= 1.0F; side += 2.0F) {
            for (int corner = 0; corner < 4; corner++) {
               point[axis] = side * half[axis];
               point[(axis + 1) % 3] = (corner != 1 && corner != 2 ? -1.0F : 1.0F) * half[(axis + 1) % 3];
               point[(axis + 2) % 3] = (corner >= 2 ? 1.0F : -1.0F) * half[(axis + 2) % 3];
               GlowDraw.vertex(consumer, pose, middle.x() + point[0], middle.y() + point[1], middle.z() + point[2], colour[0], colour[1], colour[2], alpha);
            }
         }
      }
   }

   public ResourceLocation getTextureLocation(SealCaptureEntity seal) {
      return SealRenderer.CIRCLE;
   }
}
