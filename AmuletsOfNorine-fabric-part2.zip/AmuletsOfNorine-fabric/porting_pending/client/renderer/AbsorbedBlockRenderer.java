package com.amuletmod.client.renderer;

import com.amuletmod.entity.AbsorbedBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;

public class AbsorbedBlockRenderer extends EntityRenderer<AbsorbedBlockEntity> {
   private final BlockRenderDispatcher blockRenderer;

   public AbsorbedBlockRenderer(Context context) {
      super(context);
      this.blockRenderer = context.getBlockRenderDispatcher();
   }

   public void render(AbsorbedBlockEntity entity, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      BlockState state = entity.getBlockState();
      if (state.getRenderShape() == RenderShape.MODEL) {
         float age = entity.tickCount + partialTick;
         float scale = Math.max(0.1F, entity.visualScale());
         poseStack.pushPose();
         poseStack.mulPose(Axis.YP.rotationDegrees(age * 12.0F + entity.getId() * 31));
         poseStack.mulPose(Axis.XP.rotationDegrees(age * 7.0F));
         poseStack.scale(scale, scale, scale);
         poseStack.translate(-0.5F, -0.5F, -0.5F);
         this.blockRenderer.renderSingleBlock(state, poseStack, buffers, 15728880, OverlayTexture.NO_OVERLAY);
         poseStack.popPose();
         super.render(entity, yaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   public ResourceLocation getTextureLocation(AbsorbedBlockEntity entity) {
      return TextureAtlas.LOCATION_BLOCKS;
   }
}
