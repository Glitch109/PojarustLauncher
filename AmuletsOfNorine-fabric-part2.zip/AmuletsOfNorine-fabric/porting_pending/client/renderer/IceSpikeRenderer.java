package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.IceSpikeEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class IceSpikeRenderer extends EntityRenderer<IceSpikeEntity> {
   private static final ResourceLocation TEXTURE = AmuletMod.id("textures/entity/ice_spike.png");
   private static final int SIDES = 6;
   private static final int MIN_BLOCK_LIGHT = 8;

   public IceSpikeRenderer(Context context) {
      super(context);
   }

   public void render(IceSpikeEntity spike, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float shatter = spike.shatter(partialTick);
      if (!(shatter >= 1.0F)) {
         float height = spike.spikeHeight();
         float rise = spike.rise(partialTick);
         float crumble = 1.0F - shatter * shatter;
         RandomSource random = RandomSource.create(spike.getId() * -7046029254386353131L);
         int light = LightTexture.pack(Math.max(LightTexture.block(packedLight), 8), LightTexture.sky(packedLight));
         VertexConsumer consumer = buffers.getBuffer(RenderType.entityTranslucent(TEXTURE));
         poseStack.pushPose();
         poseStack.translate(0.0F, -(1.0F - rise) * height * 1.05F - shatter * 0.4F, 0.0F);
         poseStack.mulPose(Axis.YP.rotationDegrees(-spike.tiltYaw()));
         poseStack.mulPose(Axis.XP.rotationDegrees(spike.tilt()));
         poseStack.mulPose(Axis.YP.rotationDegrees(random.nextFloat() * 360.0F));
         poseStack.scale(crumble, 1.0F - shatter * 0.5F, crumble);
         float baseRadius = 0.26F + 0.07F * height;
         shard(poseStack, consumer, light, baseRadius, height, random);
         int satellites = 2 + random.nextInt(3);

         for (int i = 0; i < satellites; i++) {
            float angle = (i + random.nextFloat() * 0.6F) * 360.0F / satellites;
            poseStack.pushPose();
            poseStack.mulPose(Axis.YP.rotationDegrees(angle));
            poseStack.translate(0.0F, 0.0F, baseRadius * (0.6F + random.nextFloat() * 0.5F));
            poseStack.mulPose(Axis.XP.rotationDegrees(22.0F + random.nextFloat() * 22.0F));
            shard(poseStack, consumer, light, baseRadius * (0.4F + random.nextFloat() * 0.25F), height * (0.3F + random.nextFloat() * 0.3F), random);
            poseStack.popPose();
         }

         poseStack.popPose();
         float frost = rise * (1.0F - shatter);
         GlowBatch.add(
            ModRenderTypes.GLOW,
            poseStack,
            (glow, pose, normal) -> GlowDraw.ring(glow, pose, 0.03F, 0.15F, 0.55F + height * 0.12F, 20, 0.55F, 0.85F, 1.0F, 0.35F * frost, 0.0F)
         );
         super.render(spike, yaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   private static void shard(PoseStack poseStack, VertexConsumer consumer, int light, float radius, float height, RandomSource random) {
      Matrix4f pose = poseStack.last().pose();
      Pose normal = poseStack.last();
      float shoulderHeight = height * (0.5F + random.nextFloat() * 0.2F);
      float shoulderRadius = radius * (0.65F + random.nextFloat() * 0.15F);
      Vector3f tip = new Vector3f((random.nextFloat() - 0.5F) * radius * 0.5F, height, (random.nextFloat() - 0.5F) * radius * 0.5F);
      float twist = random.nextFloat() * (float) (Math.PI * 2);
      Vector3f[] base = new Vector3f[6];
      Vector3f[] shoulder = new Vector3f[6];

      for (int i = 0; i < 6; i++) {
         float angle = twist + i * (float) (Math.PI * 2) / 6.0F;
         float jitter = 0.85F + random.nextFloat() * 0.3F;
         base[i] = new Vector3f(Mth.cos(angle) * radius * jitter, -0.3F, Mth.sin(angle) * radius * jitter);
         shoulder[i] = new Vector3f(Mth.cos(angle + 0.15F) * shoulderRadius * jitter, shoulderHeight, Mth.sin(angle + 0.15F) * shoulderRadius * jitter);
      }

      for (int i = 0; i < 6; i++) {
         int j = (i + 1) % 6;
         float u0 = i / 6.0F;
         float u1 = (i + 1) / 6.0F;
         face(consumer, pose, normal, light, base[i], base[j], shoulder[j], shoulder[i], u0, u1, 1.0F, 1.0F - shoulderHeight / height);
         face(consumer, pose, normal, light, shoulder[i], shoulder[j], tip, tip, u0, u1, 1.0F - shoulderHeight / height, 0.0F);
      }
   }

   private static void face(
      VertexConsumer consumer,
      Matrix4f pose,
      Pose normal,
      int light,
      Vector3f a,
      Vector3f b,
      Vector3f c,
      Vector3f d,
      float u0,
      float u1,
      float vBottom,
      float vTop
   ) {
      Vector3f faceNormal = new Vector3f(d).sub(a).cross(new Vector3f(b).sub(a));
      if (faceNormal.lengthSquared() < 1.0E-8F) {
         faceNormal.set(0.0F, 1.0F, 0.0F);
      }

      faceNormal.normalize();
      vertex(consumer, pose, normal, light, a, u0, vBottom, faceNormal);
      vertex(consumer, pose, normal, light, b, u1, vBottom, faceNormal);
      vertex(consumer, pose, normal, light, c, u1, vTop, faceNormal);
      vertex(consumer, pose, normal, light, d, u0, vTop, faceNormal);
   }

   private static void vertex(VertexConsumer consumer, Matrix4f pose, Pose normal, int light, Vector3f p, float u, float v, Vector3f n) {
      consumer.addVertex(pose, p.x(), p.y(), p.z())
         .setColor(1.0F, 1.0F, 1.0F, 0.85F)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(light)
         .setNormal(normal, n.x(), n.y(), n.z());
   }

   public ResourceLocation getTextureLocation(IceSpikeEntity spike) {
      return TEXTURE;
   }
}
