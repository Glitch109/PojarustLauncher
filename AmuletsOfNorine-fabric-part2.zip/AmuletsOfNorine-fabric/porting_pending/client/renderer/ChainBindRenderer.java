package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.ChainBindEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class ChainBindRenderer extends EntityRenderer<ChainBindEntity> {
   private static final ResourceLocation CIRCLE = AmuletMod.id("textures/misc/binding_circle.png");
   private static final ResourceLocation CHAIN = ResourceLocation.fromNamespaceAndPath("minecraft", "textures/block/chain.png");
   private static final float[] VIOLET = new float[]{0.62F, 0.36F, 1.0F};
   private static final float[] PALE = new float[]{0.9F, 0.82F, 1.0F};
   private static final Vector3f X = new Vector3f(1.0F, 0.0F, 0.0F);
   private static final Vector3f Y = new Vector3f(0.0F, 1.0F, 0.0F);
   private static final int COIL_POINTS = 14;

   public ChainBindRenderer(Context context) {
      super(context);
   }

   public void render(ChainBindEntity bind, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float age = bind.tickCount + partialTick;
      float width = bind.victimWidth();
      float height = bind.victimHeight();
      int seed = bind.getId();
      int release = bind.releaseAt();
      float closing = Mth.clamp((age - release) / 14.0F, 0.0F, 1.0F);
      Vector3f eye = this.entityRenderDispatcher.camera.getPosition().subtract(bind.getPosition(partialTick)).toVector3f();
      Vector3f middle = new Vector3f(0.0F, height * 0.5F, 0.0F);
      float linkWidth = 0.1F * Mth.clamp(0.8F + width * 0.35F, 0.9F, 1.8F);
      List<Vector3f[]> held = new ArrayList<>();
      if (age < release) {
         VertexConsumer links = buffers.getBuffer(RenderType.entityCutoutNoCull(CHAIN));
         Matrix4f pose = poseStack.last().pose();
         Pose normal = poseStack.last();

         for (int k = 0; k < 5; k++) {
            int fires = ChainBindEntity.firesAt(k);
            float flight = Mth.clamp((age - fires) / 5.0F, 0.0F, 1.0F);
            if (fires < release && !(flight <= 0.0F)) {
               float wrap = Mth.clamp((age - fires - 5.0F) / 8.0F, 0.0F, 1.0F);
               Vector3f[] path = path(k, width, height, seed);
               int straight = path.length - 1 - 14;
               float reach = length(path, 0, straight) * Easing.outCubic(flight) + length(path, straight, path.length - 1) * wrap;
               Vector3f[] shown = clip(path, reach);
               chain(links, pose, normal, shown, linkWidth);
               held.add(shown);
            }
         }
      }

      GlowBatch.add(ModRenderTypes.skyGlow(CIRCLE), poseStack, (consumer, posex, normalx) -> {
         for (int kx = 0; kx < 5; kx++) {
            circle(consumer, posex, bind, kx, age, width, height, seed, closing, middle);
         }
      });
      if (!held.isEmpty()) {
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, posex, normalx) -> {
            for (int kx = 0; kx < held.size(); kx++) {
               Vector3f[] chain = held.get(kx);
               GlowDraw.ribbon(consumer, posex, chain, eye, linkWidth * 2.4F, VIOLET[0], VIOLET[1], VIOLET[2], 0.28F);
               float along = (age * 0.035F + kx * 0.21F) % 1.0F;
               Vector3f[] pulse = section(chain, along - 0.08F, along + 0.08F);
               if (pulse.length > 1) {
                  GlowDraw.ribbon(consumer, posex, pulse, eye, linkWidth * 2.0F, PALE[0], PALE[1], PALE[2], 0.55F);
               }
            }
         });
      }

      super.render(bind, entityYaw, partialTick, poseStack, buffers, packedLight);
   }

   private static void circle(
      VertexConsumer consumer, Matrix4f pose, ChainBindEntity bind, int k, float age, float width, float height, int seed, float closing, Vector3f middle
   ) {
      float appear = Easing.outBack((age - k * 2) / 10.0F);
      float shrink = 1.0F - Easing.smoothstep(0.0F, 1.0F, closing);
      float scale = Math.max(0.0F, appear) * shrink;
      if (!(scale <= 0.01F)) {
         int fires = ChainBindEntity.firesAt(k);
         float flare = fires < bind.releaseAt() ? Math.max(0.0F, 1.0F - Math.abs(age - fires) / 4.0F) : 0.0F;
         float charge = Easing.smoothstep(0.0F, 32.0F, age);
         float direction = k % 2 == 0 ? 1.0F : -1.0F;
         float spin = direction * (age * (3.0F + 6.0F * charge) + closing * 200.0F) * (float) (Math.PI / 180.0);
         float size = ChainBindEntity.circleSize(width, height) * scale * (1.0F + 0.25F * flare);
         float brightness = (0.75F + 0.2F * Mth.sin(age * 0.3F + k * 1.7F)) * (0.6F + 0.4F * charge) * shrink;
         Vec3 center = ChainBindEntity.circleCenter(k, width, height, seed);
         Vector3f at = center.toVector3f();
         Vector3f facing = new Vector3f(middle).sub(at).normalize();
         float r = Mth.lerp(flare, VIOLET[0], 1.0F) * (brightness + flare);
         float g = Mth.lerp(flare, VIOLET[1], 0.9F) * (brightness + flare);
         float b = Mth.lerp(flare, VIOLET[2], 1.0F) * (brightness + flare);
         GlowDraw.disc(consumer, pose, at, facing, size, spin, r, g, b);
         GlowDraw.disc(consumer, pose, new Vector3f(facing).mul(0.02F).add(at), facing, size * 0.55F, -spin * 1.6F, r * 0.8F, g * 0.8F, b * 0.8F);
      }
   }

   private static Vector3f[] path(int k, float width, float height, int seed) {
      Vec3 from = ChainBindEntity.circleCenter(k, width, height, seed);
      Vec3 grip = ChainBindEntity.grip(k, width, height, seed);
      int straight = Math.max(2, Mth.ceil(from.distanceTo(grip) / 0.4));
      Vector3f[] points = new Vector3f[straight + 14 + 1];

      for (int i = 0; i <= straight; i++) {
         points[i] = from.lerp(grip, (double)i / straight).toVector3f();
      }

      for (int j = 1; j <= 14; j++) {
         points[straight + j] = ChainBindEntity.coil(k, j / 14.0F, width, height, seed).toVector3f();
      }

      return points;
   }

   private static float length(Vector3f[] points, int from, int to) {
      float total = 0.0F;

      for (int i = from; i < to; i++) {
         total += points[i].distance(points[i + 1]);
      }

      return total;
   }

   private static Vector3f[] clip(Vector3f[] points, float reach) {
      List<Vector3f> out = new ArrayList<>();
      out.add(points[0]);
      float travelled = 0.0F;

      for (int i = 0; i + 1 < points.length; i++) {
         float segment = points[i].distance(points[i + 1]);
         if (travelled + segment >= reach) {
            if (segment > 1.0E-4F) {
               out.add(new Vector3f(points[i]).lerp(points[i + 1], (reach - travelled) / segment));
            }
            break;
         }

         travelled += segment;
         out.add(points[i + 1]);
      }

      return out.toArray(new Vector3f[0]);
   }

   private static Vector3f[] section(Vector3f[] points, float from, float to) {
      float total = length(points, 0, points.length - 1);
      Vector3f[] head = clip(points, Math.max(0.0F, to) * total);
      List<Vector3f> out = new ArrayList<>();
      float start = Math.max(0.0F, from) * total;
      float travelled = 0.0F;

      for (int i = 0; i + 1 < head.length; i++) {
         float segment = head[i].distance(head[i + 1]);
         if (travelled + segment > start) {
            if (out.isEmpty()) {
               out.add(segment > 1.0E-4F ? new Vector3f(head[i]).lerp(head[i + 1], Math.max(0.0F, start - travelled) / segment) : head[i]);
            }

            out.add(head[i + 1]);
         }

         travelled += segment;
      }

      return out.toArray(new Vector3f[0]);
   }

   private static void chain(VertexConsumer consumer, Matrix4f pose, Pose normal, Vector3f[] points, float halfWidth) {
      float tile = halfWidth * 2.0F * 16.0F / 3.0F;
      float v = 0.0F;

      for (int i = 0; i + 1 < points.length; i++) {
         Vector3f a = points[i];
         Vector3f b = points[i + 1];
         Vector3f direction = new Vector3f(b).sub(a);
         float length = direction.length();
         if (!(length < 1.0E-4F)) {
            direction.div(length);
            Vector3f side = new Vector3f(direction).cross(Math.abs(direction.y()) > 0.9F ? X : Y).normalize(halfWidth);
            Vector3f other = new Vector3f(direction).cross(side).normalize(halfWidth);
            float next = v + length / tile;
            strip(consumer, pose, normal, a, b, side, other, 0.0F, 0.1875F, v, next);
            strip(consumer, pose, normal, a, b, other, side, 0.1875F, 0.375F, v, next);
            v = next;
         }
      }
   }

   private static void strip(
      VertexConsumer consumer, Matrix4f pose, Pose normal, Vector3f a, Vector3f b, Vector3f side, Vector3f facing, float u0, float u1, float v0, float v1
   ) {
      linkVertex(consumer, pose, normal, a.x() - side.x(), a.y() - side.y(), a.z() - side.z(), facing, u0, v0);
      linkVertex(consumer, pose, normal, a.x() + side.x(), a.y() + side.y(), a.z() + side.z(), facing, u1, v0);
      linkVertex(consumer, pose, normal, b.x() + side.x(), b.y() + side.y(), b.z() + side.z(), facing, u1, v1);
      linkVertex(consumer, pose, normal, b.x() - side.x(), b.y() - side.y(), b.z() - side.z(), facing, u0, v1);
   }

   private static void linkVertex(VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float y, float z, Vector3f facing, float u, float v) {
      Vector3f n = new Vector3f(facing).normalize();
      consumer.addVertex(pose, x, y, z)
         .setColor(0.86F, 0.8F, 1.0F, 1.0F)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(normal, n.x(), n.y(), n.z());
   }

   public ResourceLocation getTextureLocation(ChainBindEntity bind) {
      return CHAIN;
   }
}
