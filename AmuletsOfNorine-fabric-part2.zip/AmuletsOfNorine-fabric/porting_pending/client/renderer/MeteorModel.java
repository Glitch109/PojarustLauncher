package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.renderer.RenderType;

public class MeteorModel extends Model {
   public static final ModelLayerLocation LAYER = new ModelLayerLocation(AmuletMod.id("meteor"), "main");
   private final ModelPart root;

   public MeteorModel(ModelPart root) {
      super(RenderType::entitySolid);
      this.root = root;
   }

   public static LayerDefinition createLayer() {
      MeshDefinition mesh = new MeshDefinition();
      mesh.getRoot()
         .addOrReplaceChild(
            "rock",
            CubeListBuilder.create()
               .texOffs(0, 0)
               .addBox(-6.0F, -6.0F, -6.0F, 12.0F, 12.0F, 12.0F)
               .texOffs(0, 24)
               .addBox(-8.0F, -3.0F, -4.0F, 2.0F, 6.0F, 7.0F)
               .texOffs(20, 24)
               .addBox(6.0F, -5.0F, -2.0F, 2.0F, 7.0F, 5.0F)
               .texOffs(36, 24)
               .addBox(-4.0F, 6.0F, -5.0F, 7.0F, 2.0F, 6.0F)
               .texOffs(0, 40)
               .addBox(-3.0F, -8.0F, -2.0F, 6.0F, 2.0F, 7.0F)
               .texOffs(28, 40)
               .addBox(-5.0F, -2.0F, 6.0F, 6.0F, 5.0F, 2.0F)
               .texOffs(46, 40)
               .addBox(-2.0F, -4.0F, -8.0F, 5.0F, 6.0F, 2.0F)
               .texOffs(0, 52)
               .addBox(3.0F, 3.0F, 3.0F, 4.0F, 4.0F, 4.0F)
               .texOffs(18, 52)
               .addBox(-7.0F, 3.0F, 1.0F, 3.0F, 3.0F, 4.0F)
               .texOffs(34, 52)
               .addBox(2.0F, -7.0F, -6.0F, 4.0F, 3.0F, 3.0F)
               .texOffs(50, 52)
               .addBox(-7.0F, -7.0F, -5.0F, 3.0F, 4.0F, 3.0F),
            PartPose.ZERO
         );
      return LayerDefinition.create(mesh, 64, 64);
   }

   public void renderToBuffer(PoseStack poseStack, VertexConsumer consumer, int packedLight, int packedOverlay, int color) {
      this.root.render(poseStack, consumer, packedLight, packedOverlay, color);
   }
}
