package com.amuletmod.client.renderer;

import com.amuletmod.entity.SeismicWaveEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.client.model.data.ModelData;
import org.joml.Vector3f;

public class SeismicWaveRenderer extends EntityRenderer<SeismicWaveEntity> {
   private static final float MIN_LIFT = 0.03F;
   private final BlockRenderDispatcher blocks;

   public SeismicWaveRenderer(Context context) {
      super(context);
      this.blocks = context.getBlockRenderDispatcher();
   }

   public void render(SeismicWaveEntity wave, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float age = wave.tickCount + partialTick;
      double ex = wave.getX();
      double ey = wave.getY();
      double ez = wave.getZ();

      for (SeismicWaveEntity.Column column : wave.columns()) {
         float lift = wave.lift(column.distance(), age);
         if (!(lift < 0.03F)) {
            BlockPos pos = column.pos();
            float cx = (float)(pos.getX() + 0.5 - ex);
            float cz = (float)(pos.getZ() + 0.5 - ez);
            float distance = Math.max(0.01F, column.distance());
            float tilt = (column.distance() - wave.front(age)) * lift * -22.0F;
            poseStack.pushPose();
            poseStack.translate(cx, pos.getY() - ey + lift + 0.5, cz);
            poseStack.mulPose(Axis.of(new Vector3f(-cz / distance, 0.0F, cx / distance)).rotationDegrees(tilt));
            poseStack.translate(-0.5F, -0.5F, -0.5F);
            this.blocks.renderSingleBlock(column.state(), poseStack, buffers, column.light(), OverlayTexture.NO_OVERLAY, ModelData.EMPTY, null);
            poseStack.popPose();
         }
      }

      super.render(wave, entityYaw, partialTick, poseStack, buffers, packedLight);
   }

   public boolean shouldRender(SeismicWaveEntity wave, Frustum frustum, double x, double y, double z) {
      return frustum.isVisible(wave.getBoundingBoxForCulling());
   }

   public ResourceLocation getTextureLocation(SeismicWaveEntity wave) {
      return TextureAtlas.LOCATION_BLOCKS;
   }
}
