package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.ContainmentEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class ContainmentRenderer extends EntityRenderer<ContainmentEntity> {
   private static final ResourceLocation LATTICE = AmuletMod.id("textures/misc/seal_lattice.png");
   private static final float TILE = 4.0F;
   private static final float GRID = 5.0F;
   private static final int MAX_GRID = 20;
   private static final float NEAR = 16.0F;
   private static final float RIPPLE_TICKS = 26.0F;
   private static final float LINE_NEAR = 20.0F;
   private static final float LINE_WIDTH = 0.0011F;
   private static final float[] CORNER_U = new float[]{-1.0F, 1.0F, 1.0F, -1.0F};
   private static final float[] CORNER_V = new float[]{-1.0F, -1.0F, 1.0F, 1.0F};

   public ContainmentRenderer(Context context) {
      super(context);
   }

   public void render(ContainmentEntity walls, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float fall = walls.fall(partialTick);
      if (!(fall >= 1.0F)) {
         float age = walls.tickCount + partialTick;
         float reach = walls.reach(partialTick);
         Vec3 view = this.entityRenderDispatcher.camera.getPosition().subtract(walls.getPosition(partialTick));
         Vector3f eye = view.toVector3f();
         boolean spreading = walls.isSpreading();
         float set = spreading ? 0.0F : Math.max(0.0F, 1.0F - walls.sinceSet(partialTick) / 16.0F);
         float sinceImpact = walls.sinceImpact(partialTick);
         float ripple = sinceImpact < 26.0F ? 1.0F - sinceImpact / 26.0F : 0.0F;
         Vector3f impact = walls.impactPoint();
         float fade = (1.0F - fall) * (1.0F + (fall > 0.0F ? 3.0F * Math.max(0.0F, 1.0F - fall * 3.0F) : 0.0F));
         float base = spreading ? 0.3F : 0.1F;
         float[] glow = SealRenderer.GLOW;
         float[] pale = SealRenderer.PALE;
         SubspaceWalls.Mode mode = spreading ? SubspaceWalls.Mode.NONE : SubspaceWalls.mode();
         SubspaceWalls.Tiles tiles = mode == SubspaceWalls.Mode.NONE ? null : SubspaceWalls.tiles(walls, partialTick);
         if (tiles != null && !SubspaceWalls.drawVoid(mode, tiles, reach, eye, partialTick, poseStack, buffers)) {
            tiles = null;
         }

         SubspaceWalls.Tiles voided = tiles;
         float extent = voided == null ? reach : reach - 0.02F;
         int grid = voided == null ? Mth.clamp(Mth.ceil(reach * 2.0F / 5.0F), 2, 20) : voided.n;
         float scroll = age * 0.002F;
         GlowBatch.add(
            ModRenderTypes.glowTextured(LATTICE),
            poseStack,
            (consumer, pose, normal) -> {
               float[] point = new float[3];

               for (int axis = 0; axis < 3; axis++) {
                  for (float side = -1.0F; side <= 1.0F; side += 2.0F) {
                     for (int i = 0; i < grid; i++) {
                        for (int j = 0; j < grid; j++) {
                           float dim = voided == null ? 1.0F : 1.0F - voided.fill[voided.index(axis * 2 + (side > 0.0F ? 1 : 0), i, j)];
                           if (!(dim <= 0.0F)) {
                              for (int corner = 0; corner < 4; corner++) {
                                 float a = -extent + 2.0F * extent * (i + (corner != 1 && corner != 2 ? 0 : 1)) / grid;
                                 float b = -extent + 2.0F * extent * (j + (corner >= 2 ? 1 : 0)) / grid;
                                 point[axis] = side * extent;
                                 point[(axis + 1) % 3] = a;
                                 point[(axis + 2) % 3] = b;
                                 float dx = point[0] - eye.x();
                                 float dy = point[1] - eye.y();
                                 float dz = point[2] - eye.z();
                                 float near = (float)Math.exp(-(dx * dx + dy * dy + dz * dz) / 256.0F);
                                 float light = base + 0.9F * near + set;
                                 if (ripple > 0.0F) {
                                    float ix = point[0] - impact.x();
                                    float iy = point[1] - impact.y();
                                    float iz = point[2] - impact.z();
                                    float ring = (Mth.sqrt(ix * ix + iy * iy + iz * iz) - sinceImpact * 1.1F) / 1.6F;
                                    light += 1.8F * ripple * (float)Math.exp(-ring * ring);
                                 }

                                 light *= (0.85F + 0.15F * Mth.sin(age * 0.1F + (point[0] + point[1] + point[2]) * 0.15F)) * fade * dim;
                                 float white = Mth.clamp(light - 0.9F, 0.0F, 1.0F);
                                 GlowDraw.texVertex(
                                    consumer,
                                    pose,
                                    normal,
                                    point[0],
                                    point[1],
                                    point[2],
                                    Mth.lerp(white, glow[0], pale[0]) * light,
                                    Mth.lerp(white, glow[1], pale[1]) * light,
                                    Mth.lerp(white, glow[2], pale[2]) * light,
                                    a / 4.0F + scroll,
                                    b / 4.0F - scroll
                                 );
                              }
                           }
                        }
                     }
                  }
               }
            }
         );
         if (voided != null) {
            float lineLight = (0.14F + 0.9F * voided.flash + 1.2F * voided.lock) * fade;
            GlowBatch.add(
               ModRenderTypes.GLOW,
               poseStack,
               (consumer, pose, normal) -> gridLines(consumer, pose, voided, extent, eye, lineLight, ripple, sinceImpact, impact)
            );
            if (mode == SubspaceWalls.Mode.GEOMETRY) {
               GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> rims(consumer, pose, voided, extent, fade));
            }
         }

         float edgeLight = (0.55F + set + (spreading ? 0.3F : 0.0F)) * fade;
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            int segments = Mth.clamp(Mth.ceil(extent / 4.0F), 2, 16);

            for (int axis = 0; axis < 3; axis++) {
               for (float a = -1.0F; a <= 1.0F; a += 2.0F) {
                  for (float b = -1.0F; b <= 1.0F; b += 2.0F) {
                     Vector3f from = new Vector3f();
                     Vector3f to = new Vector3f();
                     from.setComponent(axis, -extent).setComponent((axis + 1) % 3, a * extent).setComponent((axis + 2) % 3, b * extent);
                     to.setComponent(axis, extent).setComponent((axis + 1) % 3, a * extent).setComponent((axis + 2) % 3, b * extent);
                     GlowDraw.farBeam(consumer, pose, from, to, eye, segments, 0.012F, 0.1F, 1.2F, glow[0], glow[1], glow[2], 0.6F * edgeLight);
                     GlowDraw.farBeam(consumer, pose, from, to, eye, segments, 0.004F, 0.035F, 0.4F, pale[0], pale[1], pale[2], edgeLight);
                  }
               }
            }
         });
         float circle = Math.min(4.0F, reach * 0.8F);
         float circleLight = (0.7F + 0.2F * Mth.sin(age * 0.2F) + set) * fade;
         GlowBatch.add(
            ModRenderTypes.glowTextured(SealRenderer.CIRCLE),
            poseStack,
            (consumer, pose, normal) -> {
               Vector3f at = new Vector3f(0.0F, -0.95F, 0.0F);
               Vector3f right = new Vector3f(1.0F, 0.0F, 0.0F);
               Vector3f up = new Vector3f(0.0F, 0.0F, -1.0F);
               GlowDraw.stamp(consumer, pose, normal, at, right, up, circle, age * 0.02F, glow[0] * circleLight, glow[1] * circleLight, glow[2] * circleLight);
               GlowDraw.stamp(
                  consumer, pose, normal, at, right, up, circle * 0.62F, -age * 0.045F, glow[0] * circleLight, glow[1] * circleLight, glow[2] * circleLight
               );
            }
         );
         super.render(walls, yaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   private static void gridLines(
      VertexConsumer consumer,
      Matrix4f pose,
      SubspaceWalls.Tiles tiles,
      float extent,
      Vector3f eye,
      float light,
      float ripple,
      float sinceImpact,
      Vector3f impact
   ) {
      int n = tiles.n;
      float drawn = extent * tiles.grid;
      float[] from = new float[3];
      float[] to = new float[3];

      for (int face = 0; face < 6; face++) {
         int axis = face / 2;
         from[axis] = to[axis] = face % 2 == 0 ? -extent : extent;

         for (int turn = 0; turn < 2; turn++) {
            int along = (axis + 1 + turn) % 3;
            int across = (axis + 2 - turn) % 3;

            for (int line = 1; line < n; line++) {
               from[across] = to[across] = -extent + 2.0F * extent * line / n;

               for (int s = 0; s < n; s++) {
                  from[along] = -drawn + 2.0F * drawn * s / n;
                  to[along] = -drawn + 2.0F * drawn * (s + 1) / n;
                  float fromWidth = lineWidth(from, eye);
                  float toWidth = lineWidth(to, eye);
                  float fromLight = lineLight(from, eye, light, ripple, sinceImpact, impact);
                  float toLight = lineLight(to, eye, light, ripple, sinceImpact, impact);
                  lineVertex(consumer, pose, from, across, -fromWidth, fromLight);
                  lineVertex(consumer, pose, to, across, -toWidth, toLight);
                  lineVertex(consumer, pose, to, across, toWidth, toLight);
                  lineVertex(consumer, pose, from, across, fromWidth, fromLight);
               }
            }
         }
      }
   }

   private static float lineWidth(float[] at, Vector3f eye) {
      float dx = at[0] - eye.x();
      float dy = at[1] - eye.y();
      float dz = at[2] - eye.z();
      return Mth.clamp(Mth.sqrt(dx * dx + dy * dy + dz * dz) * 0.0011F, 0.004F, 0.25F);
   }

   private static float lineLight(float[] at, Vector3f eye, float light, float ripple, float sinceImpact, Vector3f impact) {
      float dx = at[0] - eye.x();
      float dy = at[1] - eye.y();
      float dz = at[2] - eye.z();
      float value = light * (0.25F + 0.75F * (float)Math.exp(-(dx * dx + dy * dy + dz * dz) / 400.0F));
      if (ripple > 0.0F) {
         float ix = at[0] - impact.x();
         float iy = at[1] - impact.y();
         float iz = at[2] - impact.z();
         float ring = (Mth.sqrt(ix * ix + iy * iy + iz * iz) - sinceImpact * 1.1F) / 1.6F;
         value += 1.8F * ripple * (float)Math.exp(-ring * ring);
      }

      return value;
   }

   private static void lineVertex(VertexConsumer consumer, Matrix4f pose, float[] at, int across, float offset, float light) {
      float[] glow = SealRenderer.GLOW;
      float[] pale = SealRenderer.PALE;
      float white = Mth.clamp(light - 1.0F, 0.0F, 1.0F);
      GlowDraw.vertex(
         consumer,
         pose,
         at[0] + (across == 0 ? offset : 0.0F),
         at[1] + (across == 1 ? offset : 0.0F),
         at[2] + (across == 2 ? offset : 0.0F),
         Mth.lerp(white, glow[0], pale[0]),
         Mth.lerp(white, glow[1], pale[1]),
         Mth.lerp(white, glow[2], pale[2]),
         Mth.clamp(light, 0.0F, 1.0F)
      );
   }

   private static void rims(VertexConsumer consumer, Matrix4f pose, SubspaceWalls.Tiles tiles, float extent, float fade) {
      int n = tiles.n;
      float half = extent / n;
      float[] point = new float[3];

      for (int face = 0; face < 6; face++) {
         int axis = face / 2;
         point[axis] = face % 2 == 0 ? -extent : extent;

         for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
               int k = tiles.index(face, i, j);
               float burn = Math.min(1.0F, tiles.rim[k] * fade);
               float fill = tiles.fill[k];
               if (!(burn <= 0.01F) && !(fill <= 0.0F)) {
                  float a = -extent + half * (2 * i + 1);
                  float b = -extent + half * (2 * j + 1);
                  float outer = fill * half;
                  float inner = Math.max(0.0F, outer - half * 0.3F);

                  for (int side = 0; side < 4; side++) {
                     rimVertex(consumer, pose, point, axis, a, b, outer, side, burn);
                     rimVertex(consumer, pose, point, axis, a, b, outer, side + 1, burn);
                     rimVertex(consumer, pose, point, axis, a, b, inner, side + 1, 0.0F);
                     rimVertex(consumer, pose, point, axis, a, b, inner, side, 0.0F);
                  }
               }
            }
         }
      }
   }

   private static void rimVertex(VertexConsumer consumer, Matrix4f pose, float[] point, int axis, float a, float b, float size, int corner, float alpha) {
      float[] glow = SealRenderer.GLOW;
      float[] pale = SealRenderer.PALE;
      point[(axis + 1) % 3] = a + CORNER_U[corner % 4] * size;
      point[(axis + 2) % 3] = b + CORNER_V[corner % 4] * size;
      GlowDraw.vertex(
         consumer,
         pose,
         point[0],
         point[1],
         point[2],
         Mth.lerp(0.6F, glow[0], pale[0]),
         Mth.lerp(0.6F, glow[1], pale[1]),
         Mth.lerp(0.6F, glow[2], pale[2]),
         alpha
      );
   }

   public ResourceLocation getTextureLocation(ContainmentEntity walls) {
      return LATTICE;
   }
}
