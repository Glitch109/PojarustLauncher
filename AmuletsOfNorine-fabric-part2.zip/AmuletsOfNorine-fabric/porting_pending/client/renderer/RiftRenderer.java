package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.rift.RiftKind;
import com.amuletmod.client.ShaderPacks;
import com.amuletmod.entity.RiftEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import net.minecraft.Util;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.renderer.blockentity.TheEndPortalRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

public class RiftRenderer extends EntityRenderer<RiftEntity> {
   private static final ResourceLocation NETHER_VIEW = AmuletMod.id("textures/entity/rift_nether.png");
   private static final ResourceLocation NETHER_EMBERS = AmuletMod.id("textures/entity/rift_nether_embers.png");
   private static final ResourceLocation OVERWORLD_VIEW = AmuletMod.id("textures/entity/rift_overworld.png");
   private static final ResourceLocation OVERWORLD_CLOUDS = AmuletMod.id("textures/entity/rift_overworld_clouds.png");
   private static final RenderType END_VOID = RenderType.entityCutoutNoCull(TheEndPortalRenderer.END_SKY_LOCATION);
   private static final RenderType END_STARS = ModRenderTypes.glowTextured(TheEndPortalRenderer.END_PORTAL_LOCATION);
   private static final float END_SCREEN = 0.125F;
   private static final float[][] END_COLORS = new float[][]{
      {0.022087F, 0.098399F, 0.110818F},
      {0.011892F, 0.095924F, 0.089485F},
      {0.027636F, 0.101689F, 0.100326F},
      {0.046564F, 0.109883F, 0.114838F},
      {0.064901F, 0.117696F, 0.097189F},
      {0.063761F, 0.086895F, 0.123646F},
      {0.084817F, 0.111994F, 0.16638F},
      {0.097489F, 0.15412F, 0.091064F},
      {0.106152F, 0.131144F, 0.195191F},
      {0.097721F, 0.110188F, 0.187229F},
      {0.133516F, 0.138278F, 0.148582F},
      {0.070006F, 0.243332F, 0.235792F},
      {0.196766F, 0.142899F, 0.214696F},
      {0.047281F, 0.315338F, 0.32197F},
      {0.204675F, 0.39001F, 0.302066F},
      {0.080955F, 0.314821F, 0.661491F}
   };
   private static final int SIDE_POINTS = 14;
   private static final float MID = 1.6F;
   private static final int CRACKS = 7;
   private static final int FLASH_TICKS = 8;

   public RiftRenderer(Context context) {
      super(context);
   }

   public void render(RiftEntity rift, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float open = rift.openness(partialTick);
      float seam = rift.seamLength(partialTick);
      if (!(open <= 0.001F) || !(seam <= 0.001F)) {
         float time = rift.tickCount + partialTick;
         float sinceTear = time - rift.tearTick();
         float[] outline = outline(rift.getId(), open, seam, time);
         poseStack.pushPose();
         poseStack.mulPose(Axis.YP.rotationDegrees(-rift.getYRot()));
         if (open > 0.01F) {
            this.renderWindow(rift, outline, partialTick, time, poseStack, buffers);
         }

         queueGlow(rift.kind(), outline, open, seam, time, sinceTear, rift.getId(), poseStack);
         poseStack.popPose();
         super.render(rift, yaw, partialTick, poseStack, buffers, packedLight);
      }
   }

   public static float[] outline(int seed, float open, float seam, float time) {
      float[] points = new float[56];
      int k = 0;

      for (int i = 0; i <= 14; i++) {
         k = edgePoint(points, k, seed, i, 1.0F, open, seam, time);
      }

      for (int i = 13; i >= 1; i--) {
         k = edgePoint(points, k, seed, i, -1.0F, open, seam, time);
      }

      return points;
   }

   private static int edgePoint(float[] points, int k, int seed, int i, float side, float open, float seam, float time) {
      float v = i / 14.0F;
      float width = RiftEntity.halfWidthAt(v) * open;
      int salt = seed * 131 + i * 17 + (side > 0.0F ? 0 : 7919);
      float notch = (hash(salt) - 0.5F) * 0.22F;
      float flicker = 0.06F * Mth.sin(time * 0.35F + i * 2.1F + side * 1.3F) + 0.03F * Mth.sin(time * 1.1F + i * 4.7F);
      points[k++] = side * (width + (notch + flicker) * width / 0.95F);
      points[k++] = 1.6F + (v * 3.2F - 1.6F) * seam + 0.03F * Mth.sin(time * 0.8F + i * 3.3F) * open;
      return k;
   }

   private void renderWindow(RiftEntity rift, float[] outline, float partialTick, float time, PoseStack poseStack, MultiBufferSource buffers) {
      Matrix4f pose = poseStack.last().pose();
      Pose normal = poseStack.last();
      RiftKind kind = rift.kind();
      if (kind == RiftKind.END) {
         endWindow(buffers, pose, normal, outline);
      } else {
         Vec3 camera = this.entityRenderDispatcher.camera.getPosition().subtract(rift.getPosition(partialTick));
         float yaw = rift.getYRot() * (float) (Math.PI / 180.0);
         float cx = (float)(camera.x * Mth.cos(yaw) + camera.z * Mth.sin(yaw));
         float cz = (float)(-camera.x * Mth.sin(yaw) + camera.z * Mth.cos(yaw));
         float cy = (float)camera.y - 1.6F;
         float distance = Math.max(0.4F, Math.abs(cz));
         if (kind == RiftKind.NETHER) {
            parallaxLayer(
               buffers.getBuffer(RenderType.entityCutoutNoCull(NETHER_VIEW)), pose, normal, outline, cx, cy, distance, 10.0F, 0.041666668F, 0.0F, 0.0F, 1.0F
            );
            parallaxLayer(
               buffers.getBuffer(ModRenderTypes.glowTextured(NETHER_EMBERS)),
               pose,
               normal,
               outline,
               cx,
               cy,
               distance,
               3.0F,
               0.16666667F,
               0.0F,
               time * 0.012F,
               1.0F
            );
         } else {
            parallaxLayer(
               buffers.getBuffer(RenderType.entityCutoutNoCull(OVERWORLD_VIEW)), pose, normal, outline, cx, cy, distance, 16.0F, 0.035714287F, 0.0F, 0.0F, 1.0F
            );
            parallaxLayer(
               buffers.getBuffer(ModRenderTypes.glowTextured(OVERWORLD_CLOUDS)),
               pose,
               normal,
               outline,
               cx,
               cy,
               distance,
               8.0F,
               0.071428575F,
               time * 0.0015F,
               0.0F,
               0.75F
            );
         }
      }
   }

   public static void endWindow(MultiBufferSource buffers, Matrix4f pose, Pose normal, float[] outline) {
      if (ShaderPacks.inUse()) {
         endStars(buffers, pose, normal, outline);
      } else {
         VertexConsumer consumer = buffers.getBuffer(ModRenderTypes.END_WINDOW);
         int count = outline.length / 2;

         for (int i = 0; i < count; i++) {
            int j = (i + 1) % count;
            consumer.addVertex(pose, 0.0F, 1.6F, 0.0F);
            consumer.addVertex(pose, outline[2 * i], outline[2 * i + 1], 0.0F);
            consumer.addVertex(pose, outline[2 * j], outline[2 * j + 1], 0.0F);
            consumer.addVertex(pose, 0.0F, 1.6F, 0.0F);
         }
      }
   }

   public static void flushEndWindow(BufferSource buffers) {
      buffers.endBatch(ModRenderTypes.END_WINDOW);
      buffers.endBatch(END_VOID);
      buffers.endBatch(END_STARS);
   }

   private static void endStars(MultiBufferSource buffers, Matrix4f pose, Pose normal, float[] outline) {
      float time = (float)(Util.getMillis() % 86400000L) / 50.0F;
      float[] base = END_COLORS[0];
      endLayer(buffers.getBuffer(END_VOID), pose, normal, outline, 0, time, base[0], base[1], base[2]);
      VertexConsumer stars = buffers.getBuffer(END_STARS);

      for (int layer = 1; layer <= END_COLORS.length - 1; layer++) {
         float[] color = END_COLORS[layer - 1];
         endLayer(stars, pose, normal, outline, layer, time, color[0], color[1], color[2]);
      }
   }

   private static void endLayer(VertexConsumer consumer, Matrix4f pose, Pose normal, float[] outline, int layer, float time, float r, float g, float b) {
      int count = outline.length / 2;

      for (int i = 0; i < count; i++) {
         int j = (i + 1) % count;
         endVertex(consumer, pose, normal, 0.0F, 1.6F, layer, time, r, g, b);
         endVertex(consumer, pose, normal, outline[2 * i], outline[2 * i + 1], layer, time, r, g, b);
         endVertex(consumer, pose, normal, outline[2 * j], outline[2 * j + 1], layer, time, r, g, b);
         endVertex(consumer, pose, normal, 0.0F, 1.6F, layer, time, r, g, b);
      }
   }

   private static void endVertex(VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float y, int layer, float time, float r, float g, float b) {
      float u = x * 0.125F;
      float v = y * 0.125F;
      if (layer > 0) {
         float px = u + 17.0F / layer;
         float py = v + (2.0F + layer / 1.5F) * 1.5F * (time / 24000.0F);
         float scale = (4.5F - layer / 4.0F) * 2.0F;
         double angle = Math.toRadians(((double)layer * layer * 4321.0 + layer * 9.0) * 2.0);
         float cos = (float)Math.cos(angle);
         float sin = (float)Math.sin(angle);
         u = (px * cos - py * sin) * scale;
         v = (px * sin + py * cos) * scale;
      }

      GlowDraw.texVertex(consumer, pose, normal, x, y, 0.0F, r, g, b, u, v);
   }

   private static void parallaxLayer(
      VertexConsumer consumer,
      Matrix4f pose,
      Pose normal,
      float[] outline,
      float cx,
      float cy,
      float distance,
      float behind,
      float scale,
      float uScroll,
      float vScroll,
      float brightness
   ) {
      float magnify = 1.0F + behind / distance;
      int count = outline.length / 2;

      for (int i = 0; i < count; i++) {
         int j = (i + 1) % count;
         windowVertex(consumer, pose, normal, 0.0F, 1.6F, cx, cy, magnify, scale, uScroll, vScroll, brightness);
         windowVertex(consumer, pose, normal, outline[2 * i], outline[2 * i + 1], cx, cy, magnify, scale, uScroll, vScroll, brightness);
         windowVertex(consumer, pose, normal, outline[2 * j], outline[2 * j + 1], cx, cy, magnify, scale, uScroll, vScroll, brightness);
         windowVertex(consumer, pose, normal, 0.0F, 1.6F, cx, cy, magnify, scale, uScroll, vScroll, brightness);
      }
   }

   private static void windowVertex(
      VertexConsumer consumer,
      Matrix4f pose,
      Pose normal,
      float x,
      float y,
      float cx,
      float cy,
      float magnify,
      float scale,
      float uScroll,
      float vScroll,
      float brightness
   ) {
      float backX = cx + (x - cx) * magnify;
      float backY = cy + (y - 1.6F - cy) * magnify;
      consumer.addVertex(pose, x, y, 0.0F)
         .setColor(brightness, brightness, brightness, 1.0F)
         .setUv(0.5F + backX * scale + uScroll, 0.5F - backY * scale + vScroll)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(normal, 0.0F, 1.0F, 0.0F);
   }

   private static void queueGlow(RiftKind kind, float[] outline, float open, float seam, float time, float sinceTear, int seed, PoseStack poseStack) {
      GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> light(consumer, pose, kind, outline, open, seam, time, sinceTear, seed));
   }

   public static void light(
      VertexConsumer consumer, Matrix4f pose, RiftKind kind, float[] outline, float open, float seam, float time, float sinceTear, int seed
   ) {
      float[] glow = rgb(kind.glow());
      float[] core = rgb(kind.core());
      if (open > 0.01F) {
         halo(consumer, pose, outline, glow, open * (0.85F + 0.15F * Mth.sin(time * 0.25F)));
         rim(consumer, pose, outline, glow, core, Math.min(1.0F, open * 1.5F));
      }

      float seamAlpha = seam * (1.0F - Math.min(1.0F, open * 1.6F));
      if (seamAlpha > 0.01F) {
         seam(consumer, pose, seam, time, glow, core, seamAlpha);
      }

      if (sinceTear > 0.0F && sinceTear < 8.0F) {
         flash(consumer, pose, glow, core, 1.0F - sinceTear / 8.0F);
      }

      if (open > 0.3F) {
         cracks(consumer, pose, outline, time, seed, glow, core, Math.min(1.0F, (open - 0.3F) * 2.0F));
      }
   }

   private static void halo(VertexConsumer consumer, Matrix4f pose, float[] outline, float[] glow, float strength) {
      int count = outline.length / 2;

      for (int i = 0; i < count; i++) {
         int j = (i + 1) % count;
         float ax = outline[2 * i];
         float ay = outline[2 * i + 1];
         float bx = outline[2 * j];
         float by = outline[2 * j + 1];
         GlowDraw.vertex(consumer, pose, ax, ay, 0.0F, glow[0], glow[1], glow[2], 0.6F * strength);
         GlowDraw.vertex(consumer, pose, bx, by, 0.0F, glow[0], glow[1], glow[2], 0.6F * strength);
         GlowDraw.vertex(consumer, pose, haloX(bx), haloY(by), 0.0F, glow[0], glow[1], glow[2], 0.0F);
         GlowDraw.vertex(consumer, pose, haloX(ax), haloY(ay), 0.0F, glow[0], glow[1], glow[2], 0.0F);
      }
   }

   private static float haloX(float x) {
      return x * 2.2F + Math.signum(x) * 0.3F;
   }

   private static float haloY(float y) {
      return 1.6F + (y - 1.6F) * 1.22F;
   }

   private static void rim(VertexConsumer consumer, Matrix4f pose, float[] outline, float[] glow, float[] core, float alpha) {
      int count = outline.length / 2;

      for (int i = 0; i < count; i++) {
         int j = (i + 1) % count;
         float ax = outline[2 * i];
         float ay = outline[2 * i + 1];
         float bx = outline[2 * j];
         float by = outline[2 * j + 1];
         float[] an = outward(ax, ay);
         float[] bn = outward(bx, by);
         GlowDraw.vertex(consumer, pose, ax - an[0] * 0.07F, ay - an[1] * 0.07F, 0.0F, glow[0], glow[1], glow[2], 0.0F);
         GlowDraw.vertex(consumer, pose, bx - bn[0] * 0.07F, by - bn[1] * 0.07F, 0.0F, glow[0], glow[1], glow[2], 0.0F);
         GlowDraw.vertex(consumer, pose, bx, by, 0.0F, core[0], core[1], core[2], alpha);
         GlowDraw.vertex(consumer, pose, ax, ay, 0.0F, core[0], core[1], core[2], alpha);
         GlowDraw.vertex(consumer, pose, ax, ay, 0.0F, core[0], core[1], core[2], alpha);
         GlowDraw.vertex(consumer, pose, bx, by, 0.0F, core[0], core[1], core[2], alpha);
         GlowDraw.vertex(consumer, pose, bx + bn[0] * 0.11F, by + bn[1] * 0.11F, 0.0F, glow[0], glow[1], glow[2], 0.0F);
         GlowDraw.vertex(consumer, pose, ax + an[0] * 0.11F, ay + an[1] * 0.11F, 0.0F, glow[0], glow[1], glow[2], 0.0F);
      }
   }

   private static float[] outward(float x, float y) {
      float dy = (y - 1.6F) * 0.25F;
      float length = Mth.sqrt(x * x + dy * dy);
      return length < 1.0E-4F ? new float[]{0.0F, Math.signum(y - 1.6F)} : new float[]{x / length, dy / length};
   }

   private static void seam(VertexConsumer consumer, Matrix4f pose, float length, float time, float[] glow, float[] core, float alpha) {
      int segments = 12;
      float half = 1.6F * length;
      float flicker = 0.75F + 0.25F * Mth.sin(time * 2.7F);

      for (int s = 0; s < segments; s++) {
         float y0 = 1.6F - half + 2.0F * half * s / segments;
         float y1 = 1.6F - half + 2.0F * half * (s + 1) / segments;
         float x0 = seamX(s, time);
         float x1 = seamX(s + 1, time);
         float w0 = seamWidth(s, segments);
         float w1 = seamWidth(s + 1, segments);
         seamBand(consumer, pose, x0, y0, x1, y1, 0.04F * w0, 0.04F * w1, core, alpha * flicker);
         seamBand(consumer, pose, x0, y0, x1, y1, 0.35F * w0, 0.35F * w1, glow, 0.45F * alpha * flicker);
      }
   }

   private static float seamX(int s, float time) {
      return 0.05F * Mth.sin(s * 2.3F + time * 1.9F) + 0.03F * Mth.sin(s * 5.1F - time * 3.3F);
   }

   private static float seamWidth(int s, int segments) {
      return Mth.sin((float) Math.PI * s / segments) * 0.8F + 0.2F;
   }

   private static void seamBand(VertexConsumer consumer, Matrix4f pose, float x0, float y0, float x1, float y1, float w0, float w1, float[] color, float alpha) {
      for (float side : new float[]{-1.0F, 1.0F}) {
         GlowDraw.vertex(consumer, pose, x0, y0, 0.0F, color[0], color[1], color[2], alpha);
         GlowDraw.vertex(consumer, pose, x1, y1, 0.0F, color[0], color[1], color[2], alpha);
         GlowDraw.vertex(consumer, pose, x1 + side * w1, y1, 0.0F, color[0], color[1], color[2], 0.0F);
         GlowDraw.vertex(consumer, pose, x0 + side * w0, y0, 0.0F, color[0], color[1], color[2], 0.0F);
      }
   }

   private static void flash(VertexConsumer consumer, Matrix4f pose, float[] glow, float[] core, float strength) {
      float grow = 1.0F - strength;
      starburst(consumer, pose, 1.2F + grow * 3.0F, 0.08F, core, strength);
      starburst(consumer, pose, 2.2F + grow * 2.0F, 0.9F, glow, 0.5F * strength);
   }

   private static void starburst(VertexConsumer consumer, Matrix4f pose, float size, float squat, float[] color, float alpha) {
      for (int i = 0; i < 8; i++) {
         float a0 = i * (float) Math.PI / 4.0F;
         float a1 = (i + 1) * (float) Math.PI / 4.0F;
         float r0 = size * (i % 2 == 0 ? 1.0F : squat);
         float r1 = size * (i % 2 == 0 ? squat : 1.0F);
         GlowDraw.vertex(consumer, pose, 0.0F, 1.6F, 0.0F, color[0], color[1], color[2], alpha);
         GlowDraw.vertex(consumer, pose, Mth.cos(a0) * r0, 1.6F + Mth.sin(a0) * r0, 0.0F, color[0], color[1], color[2], 0.0F);
         GlowDraw.vertex(consumer, pose, Mth.cos(a1) * r1, 1.6F + Mth.sin(a1) * r1, 0.0F, color[0], color[1], color[2], 0.0F);
         GlowDraw.vertex(consumer, pose, 0.0F, 1.6F, 0.0F, color[0], color[1], color[2], alpha);
      }
   }

   private static void cracks(VertexConsumer consumer, Matrix4f pose, float[] outline, float time, int seed, float[] glow, float[] core, float alpha) {
      int count = outline.length / 2;
      int epoch = (int)(time / 4.0F);

      for (int c = 0; c < 7; c++) {
         int salt = seed * 977 + c * 131 + epoch * 7907;
         int start = (int)(hash(salt) * count);
         float x = outline[2 * start];
         float y = outline[2 * start + 1];
         float[] out = outward(x, y);
         float angle = (float)Math.atan2(out[1], out[0]) + (hash(salt + 1) - 0.5F) * 1.4F;
         float width = 0.03F;
         float fade = alpha * (0.5F + 0.5F * hash(salt + 2));

         for (int s = 0; s < 3; s++) {
            float length = 0.15F + 0.25F * hash(salt + 10 + s);
            angle += (hash(salt + 20 + s) - 0.5F) * 1.2F;
            float nx = x + Mth.cos(angle) * length;
            float ny = y + Mth.sin(angle) * length;
            float px = -Mth.sin(angle);
            float py = Mth.cos(angle);
            float nextWidth = width * 0.55F;
            float nextFade = fade * 0.6F;
            crackSegment(consumer, pose, x, y, nx, ny, px, py, width, nextWidth, core, fade, nextFade);
            crackSegment(consumer, pose, x, y, nx, ny, px, py, width * 4.0F, nextWidth * 4.0F, glow, fade * 0.35F, nextFade * 0.35F);
            x = nx;
            y = ny;
            width = nextWidth;
            fade = nextFade;
         }
      }
   }

   private static void crackSegment(
      VertexConsumer consumer, Matrix4f pose, float x0, float y0, float x1, float y1, float px, float py, float w0, float w1, float[] color, float a0, float a1
   ) {
      GlowDraw.vertex(consumer, pose, x0 - px * w0, y0 - py * w0, 0.0F, color[0], color[1], color[2], a0);
      GlowDraw.vertex(consumer, pose, x1 - px * w1, y1 - py * w1, 0.0F, color[0], color[1], color[2], a1);
      GlowDraw.vertex(consumer, pose, x1 + px * w1, y1 + py * w1, 0.0F, color[0], color[1], color[2], a1);
      GlowDraw.vertex(consumer, pose, x0 + px * w0, y0 + py * w0, 0.0F, color[0], color[1], color[2], a0);
   }

   private static float[] rgb(int color) {
      return new float[]{(color >> 16 & 0xFF) / 255.0F, (color >> 8 & 0xFF) / 255.0F, (color & 0xFF) / 255.0F};
   }

   private static float hash(int x) {
      x = x ^ 61 ^ x >>> 16;
      x *= 9;
      x ^= x >>> 4;
      x *= 668265261;
      x ^= x >>> 15;
      return (x & 65535) / 65536.0F;
   }

   public ResourceLocation getTextureLocation(RiftEntity rift) {
      return NETHER_VIEW;
   }
}
