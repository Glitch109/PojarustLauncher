package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.TitanSlashEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import java.util.Arrays;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class TitanSlashRenderer extends EntityRenderer<TitanSlashEntity> {
   private static final ResourceLocation WAKE = AmuletMod.id("textures/misc/titan_slash.png");
   private static final float[] CUT = new float[]{1.0F, 0.5F, 0.12F};
   private static final float[] CORE = new float[]{1.0F, 0.94F, 0.8F};
   private static final float[] SPINE = new float[]{1.0F, 0.66F, 0.26F};
   private static final float[] WAKE_HOT = new float[]{1.0F, 0.8F, 0.52F};
   private static final float[] WAKE_COOL = new float[]{0.5F, 0.15F, 0.03F};
   private static final float[] DEEP_HOT = new float[]{0.8F, 0.4F, 0.1F};
   private static final float[] DEEP_COOL = new float[]{0.25F, 0.06F, 0.01F};
   private static final float[] STEEL = new float[]{0.76F, 0.89F, 1.0F};
   private static final float[] SMEAR = new float[]{0.55F, 0.78F, 1.0F};
   private static final int ARC_POINTS = 28;
   private static final int SMEAR_STEPS = 12;
   private static final float SWORD_SCALE = 2.8F;
   private static final float SMEAR_LAG = 0.8F;
   private static final float BAND = 0.22F;
   private static final float THICKNESS = 0.05F;
   private static final float HALO = 0.1F;
   private static final float SPINE_AT = 0.35F;
   private static final float WAKE_LENGTH = 7.0F;

   public TitanSlashRenderer(Context context) {
      super(context);
   }

   public void render(TitanSlashEntity slash, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float age = slash.tickCount + partialTick;
      Vec3 position = slash.getPosition(partialTick);
      Vector3f eye = this.entityRenderDispatcher.camera.getPosition().subtract(position).toVector3f();
      if (slash.thrown() && age >= slash.launchAge()) {
         crescent(slash, poseStack, age, position);
      } else {
         sword(slash, poseStack, buffers, age, position);
         smear(slash, poseStack, age, position);
         line(slash, poseStack, age, position, eye);
      }

      super.render(slash, entityYaw, partialTick, poseStack, buffers, packedLight);
   }

   private static Vector3f local(Vec3 point, Vec3 position) {
      return point.subtract(position).toVector3f();
   }

   private static void sword(TitanSlashEntity slash, PoseStack poseStack, MultiBufferSource buffers, float age, Vec3 position) {
      float fade = Easing.smoothstep(-0.5F, 0.8F, age) * (1.0F - Easing.smoothstep(3.0F, 7.0F, age));
      if (!(fade <= 0.01F)) {
         float scale = slash.scale();
         float angle = slash.swing(age);
         float size = 2.8F * scale;
         float tip = slash.radius() + 0.3F * scale;
         Vec3 centre = slash.arc(angle, tip - 0.62F * size);
         Vector3f along = slash.bow().scale(Mth.cos(angle)).add(slash.sweep().scale(Mth.sin(angle))).toVector3f().normalize();
         Vector3f flat = slash.look().scale(-1.0).toVector3f();
         Vector3f across = new Vector3f(along).cross(flat).normalize();
         poseStack.pushPose();
         Vector3f at = local(centre, position);
         poseStack.translate(at.x(), at.y(), at.z());
         poseStack.mulPose(new Quaternionf().setFromNormalized(new Matrix3f(across, along, flat)));
         poseStack.scale(size, size, size * 1.5F);
         GhostItem.render(slash.weapon(), poseStack, buffers, STEEL[0], STEEL[1], STEEL[2], 0.82F * fade, slash.level());
         poseStack.scale(1.08F, 1.03F, 1.6F);
         GhostItem.render(slash.weapon(), poseStack, buffers, SMEAR[0], SMEAR[1], SMEAR[2], 0.25F * fade, slash.level());
         poseStack.popPose();
      }
   }

   private static void smear(TitanSlashEntity slash, PoseStack poseStack, float age, Vec3 position) {
      float fade = 1.0F - Easing.smoothstep(3.0F, 6.0F, age);
      float head = slash.swing(age);
      float tail = Math.max(-TitanSlashEntity.SWEEP, head - 0.8F);
      if (!(fade <= 0.01F) && !(head - tail < 0.02F)) {
         float scale = slash.scale();
         float inner = slash.radius() - 1.7F * scale;
         float outer = slash.radius() + 0.3F * scale;
         Vector3f[] in = new Vector3f[13];
         Vector3f[] out = new Vector3f[13];

         for (int i = 0; i <= 12; i++) {
            float angle = Mth.lerp(i / 12.0F, tail, head);
            in[i] = local(slash.arc(angle, inner), position);
            out[i] = local(slash.arc(angle, outer), position);
         }

         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            for (int ix = 0; ix < 12; ix++) {
               float a0 = 0.5F * fade * ix / 12.0F;
               float a1 = 0.5F * fade * (ix + 1) / 12.0F;
               GlowDraw.vertex(consumer, pose, in[ix].x, in[ix].y, in[ix].z, SMEAR[0], SMEAR[1], SMEAR[2], a0 * 0.15F);
               GlowDraw.vertex(consumer, pose, out[ix].x, out[ix].y, out[ix].z, SMEAR[0], SMEAR[1], SMEAR[2], a0);
               GlowDraw.vertex(consumer, pose, out[ix + 1].x, out[ix + 1].y, out[ix + 1].z, SMEAR[0], SMEAR[1], SMEAR[2], a1);
               GlowDraw.vertex(consumer, pose, in[ix + 1].x, in[ix + 1].y, in[ix + 1].z, SMEAR[0], SMEAR[1], SMEAR[2], a1 * 0.15F);
            }
         });
      }
   }

   private static void line(TitanSlashEntity slash, PoseStack poseStack, float age, Vec3 position, Vector3f eye) {
      float light = slash.lineLight(age);
      if (!(light <= 0.01F)) {
         float scale = slash.scale();
         float reveal = Math.min(slash.swing(age), TitanSlashEntity.SWEEP);
         int count = 0;
         Vector3f[] points = new Vector3f[29];
         float[] profile = new float[29];

         for (int i = 0; i <= 28; i++) {
            float t = i / 28.0F;
            float angle = Mth.lerp(t, -TitanSlashEntity.SWEEP, TitanSlashEntity.SWEEP);
            boolean last = angle >= reveal;
            if (last) {
               angle = reveal;
               t = (reveal + TitanSlashEntity.SWEEP) / (2.0F * TitanSlashEntity.SWEEP);
            }

            points[count] = local(slash.arc(angle, slash.radius()), position);
            profile[count] = (float)Math.pow(Math.max(0.0F, Mth.sin(t * (float) Math.PI)), 0.6);
            count++;
            if (last) {
               break;
            }
         }

         if (count >= 2) {
            Vector3f[] line = Arrays.copyOf(points, count);
            float[] shape = Arrays.copyOf(profile, count);
            float flash = Math.max(0.0F, 1.0F - Math.abs(age - 3.0F) / 2.5F);
            float thin = 0.4F + 0.6F * light;
            float glow = (0.1F + 0.16F * flash) * scale * thin;
            float core = (0.028F + 0.03F * flash) * scale * thin;
            GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
               taperedLine(consumer, pose, line, shape, eye, glow, CUT[0], CUT[1], CUT[2], 0.9F * light);
               taperedLine(consumer, pose, line, shape, eye, core, CORE[0], CORE[1], CORE[2], light);
            });
         }
      }
   }

   private static void taperedLine(
      VertexConsumer consumer, Matrix4f pose, Vector3f[] points, float[] shape, Vector3f eye, float halfWidth, float r, float g, float b, float alpha
   ) {
      int last = points.length - 1;
      Vector3f[] sides = new Vector3f[points.length];

      for (int i = 0; i <= last; i++) {
         Vector3f along = new Vector3f(points[Math.min(i + 1, last)]).sub(points[Math.max(i - 1, 0)]);
         Vector3f side = along.cross(new Vector3f(eye).sub(points[i]));
         if (side.lengthSquared() < 1.0E-8F) {
            side.set(1.0F, 0.0F, 0.0F);
         }

         sides[i] = side.normalize(halfWidth * shape[i]);
      }

      for (int i = 0; i < last; i++) {
         Vector3f p0 = points[i];
         Vector3f p1 = points[i + 1];
         Vector3f s0 = sides[i];
         Vector3f s1 = sides[i + 1];
         float a0 = alpha * shape[i];
         float a1 = alpha * shape[i + 1];

         for (float sign : new float[]{-1.0F, 1.0F}) {
            GlowDraw.vertex(consumer, pose, p0.x, p0.y, p0.z, r, g, b, a0);
            GlowDraw.vertex(consumer, pose, p1.x, p1.y, p1.z, r, g, b, a1);
            GlowDraw.vertex(consumer, pose, p1.x + s1.x * sign, p1.y + s1.y * sign, p1.z + s1.z * sign, r, g, b, 0.0F);
            GlowDraw.vertex(consumer, pose, p0.x + s0.x * sign, p0.y + s0.y * sign, p0.z + s0.z * sign, r, g, b, 0.0F);
         }
      }
   }

   private static void crescent(TitanSlashEntity slash, PoseStack poseStack, float age, Vec3 position) {
      float since = slash.sinceStop(age);
      float gone = since < 0.0F ? 0.0F : since / 10.0F;
      if (!(gone >= 1.0F)) {
         int segments = 24;
         float radius = slash.radius() * slash.thrownSize(age);
         Vec3 bow = slash.bow();
         Vec3 sweep = slash.sweep();
         Vec3 middle = slash.flying(age);
         Vector3f heading = slash.heading().toVector3f();
         float wake = Math.min(slash.travelled(age), 7.0F * slash.scale()) - Math.max(0.0F, since) * 2.2F;
         Vector3f[] edge = new Vector3f[segments + 1];
         Vector3f[] front = new Vector3f[segments + 1];
         Vector3f[] inner = new Vector3f[segments + 1];
         Vector3f[] rear = new Vector3f[segments + 1];
         Vector3f[] halo = new Vector3f[segments + 1];
         float[] reach = new float[segments + 1];

         for (int i = 0; i <= segments; i++) {
            float t = (float)i / segments;
            float angle = Mth.lerp(t, -TitanSlashEntity.SWEEP, TitanSlashEntity.SWEEP);
            float shape = (float)Math.pow(Mth.sin(t * (float) Math.PI), 0.75);
            float band = 0.22F * radius * shape * (1.0F - 0.6F * gone);
            float thick = 0.05F * radius * shape;
            edge[i] = local(TitanSlashEntity.crescentPoint(middle, bow, sweep, radius, angle, 0.0F), position);
            inner[i] = local(TitanSlashEntity.crescentPoint(middle, bow, sweep, radius, angle, band), position);
            halo[i] = local(TitanSlashEntity.crescentPoint(middle, bow, sweep, radius, angle, -0.1F * radius * shape), position);
            Vector3f spine = local(TitanSlashEntity.crescentPoint(middle, bow, sweep, radius, angle, band * 0.35F), position);
            front[i] = new Vector3f(heading).mul(thick).add(spine);
            rear[i] = new Vector3f(heading).mul(-thick).add(spine);
            reach[i] = Math.max(0.0F, wake) * (0.3F + 0.7F * shape);
         }

         boolean[] whole = new boolean[segments];

         for (int k = 0; k < segments; k++) {
            whole[k] = slash.breaksAt(k, segments) >= gone;
         }

         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
            for (int k = 0; k < segments; k++) {
               if (whole[k]) {
                  int j = k + 1;
                  face(consumer, pose, edge[k], edge[j], front[j], front[k], CORE, 1.0F, SPINE, 0.8F);
                  face(consumer, pose, front[k], front[j], inner[j], inner[k], SPINE, 0.8F, CUT, 0.08F);
                  face(consumer, pose, inner[k], inner[j], rear[j], rear[k], CUT, 0.08F, SPINE, 0.8F);
                  face(consumer, pose, rear[k], rear[j], edge[j], edge[k], SPINE, 0.8F, CORE, 1.0F);
                  face(consumer, pose, edge[k], edge[j], halo[j], halo[k], CUT, 0.35F, CUT, 0.0F);
               }
            }
         });
         if (!(wake <= 0.05F)) {
            float bright = 1.0F - gone;
            GlowBatch.add(ModRenderTypes.glowTextured(WAKE), poseStack, (consumer, pose, normal) -> {
               for (int k = 0; k < segments; k++) {
                  if (whole[k]) {
                     int j = k + 1;
                     float v0 = (float)k / segments;
                     float v1 = (float)j / segments;
                     sheet(consumer, pose, normal, edge[k], edge[j], heading, reach[k], reach[j], v0, v1, WAKE_HOT, WAKE_COOL, bright);
                     sheet(consumer, pose, normal, rear[k], rear[j], heading, 0.8F * reach[k], 0.8F * reach[j], v0, v1, DEEP_HOT, DEEP_COOL, bright);
                  }
               }
            });
         }
      }
   }

   private static void face(
      VertexConsumer consumer, Matrix4f pose, Vector3f a0, Vector3f a1, Vector3f b1, Vector3f b0, float[] a, float alphaA, float[] b, float alphaB
   ) {
      GlowDraw.vertex(consumer, pose, a0.x, a0.y, a0.z, a[0], a[1], a[2], alphaA);
      GlowDraw.vertex(consumer, pose, a1.x, a1.y, a1.z, a[0], a[1], a[2], alphaA);
      GlowDraw.vertex(consumer, pose, b1.x, b1.y, b1.z, b[0], b[1], b[2], alphaB);
      GlowDraw.vertex(consumer, pose, b0.x, b0.y, b0.z, b[0], b[1], b[2], alphaB);
   }

   private static void sheet(
      VertexConsumer consumer,
      Matrix4f pose,
      Pose normal,
      Vector3f p0,
      Vector3f p1,
      Vector3f heading,
      float reach0,
      float reach1,
      float v0,
      float v1,
      float[] hot,
      float[] cool,
      float bright
   ) {
      GlowDraw.texVertex(consumer, pose, normal, p0.x, p0.y, p0.z, hot[0] * bright, hot[1] * bright, hot[2] * bright, 0.0F, v0);
      GlowDraw.texVertex(consumer, pose, normal, p1.x, p1.y, p1.z, hot[0] * bright, hot[1] * bright, hot[2] * bright, 0.0F, v1);
      GlowDraw.texVertex(
         consumer,
         pose,
         normal,
         p1.x - heading.x * reach1,
         p1.y - heading.y * reach1,
         p1.z - heading.z * reach1,
         cool[0] * bright,
         cool[1] * bright,
         cool[2] * bright,
         1.0F,
         v1
      );
      GlowDraw.texVertex(
         consumer,
         pose,
         normal,
         p0.x - heading.x * reach0,
         p0.y - heading.y * reach0,
         p0.z - heading.z * reach0,
         cool[0] * bright,
         cool[1] * bright,
         cool[2] * bright,
         1.0F,
         v0
      );
   }

   public ResourceLocation getTextureLocation(TitanSlashEntity slash) {
      return WAKE;
   }
}
