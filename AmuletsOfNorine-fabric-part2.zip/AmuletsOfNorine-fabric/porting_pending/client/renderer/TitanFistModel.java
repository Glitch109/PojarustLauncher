package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.RenderType;

public class TitanFistModel extends Model {
   public static final ModelLayerLocation LAYER = new ModelLayerLocation(AmuletMod.id("titan_fist"), "main");
   public static final ModelLayerLocation LEFT_LAYER = new ModelLayerLocation(AmuletMod.id("titan_fist"), "left");
   public static final float KNUCKLES = 11.0F;
   public static final float BRACER = 4.0F;
   public static final float HAND_WIDTH = 12.0F;
   private static final float[] FINGER_X = new float[]{-6.0F, -3.0F, 0.0F, 3.0F};
   private final ModelPart root;

   public TitanFistModel(ModelPart root) {
      super(RenderType::entityTranslucent);
      this.root = root;
   }

   public static LayerDefinition createLayer() {
      return createLayer(false);
   }

   public static LayerDefinition createLeftLayer() {
      return createLayer(true);
   }

   private static LayerDefinition createLayer(boolean left) {
      MeshDefinition mesh = new MeshDefinition();
      PartDefinition root = mesh.getRoot();
      CubeListBuilder fist = CubeListBuilder.create().mirror(left);
      box(fist, left, 0, 0, -7.0F, -5.0F, -4.0F, 14.0F, 9.0F, 4.0F);
      box(fist, left, 0, 13, -6.0F, -4.0F, 0.0F, 12.0F, 7.0F, 7.0F);
      box(fist, left, 0, 27, 5.0F, -3.0F, 3.0F, 3.0F, 3.0F, 8.0F);
      box(fist, left, 24, 27, 1.0F, -4.0F, 10.0F, 6.0F, 3.0F, 2.0F);

      for (int i = 0; i < FINGER_X.length; i++) {
         float x = FINGER_X[i];
         float proud = i != 1 && i != 2 ? 0.0F : 0.5F;
         box(fist, left, 40, 0, x, -1.0F, 7.0F + proud, 3.0F, 5.0F, 3.0F);
         box(fist, left, 40, 8, x, -4.0F, 7.0F, 3.0F, 3.0F, 3.0F);
         box(fist, left, 52, 0, x, -5.0F, 4.0F, 3.0F, 2.0F, 3.0F);
      }

      root.addOrReplaceChild("fist", fist, PartPose.ZERO);
      return LayerDefinition.create(mesh, 64, 64);
   }

   private static void box(CubeListBuilder fist, boolean left, int u, int v, float x, float y, float z, float width, float height, float depth) {
      fist.texOffs(u, v).addBox(left ? -x - width : x, y, z, width, height, depth);
   }

   public void renderToBuffer(PoseStack poseStack, VertexConsumer consumer, int packedLight, int packedOverlay, int color) {
      this.root.render(poseStack, consumer, packedLight, packedOverlay, color);
   }
}
