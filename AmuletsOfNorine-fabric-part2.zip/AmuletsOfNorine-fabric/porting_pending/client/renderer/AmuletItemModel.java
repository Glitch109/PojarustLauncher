package com.amuletmod.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public class AmuletItemModel implements BakedModel {
   private final BakedModel icon;
   private final BakedModel chain;
   private final List<BakedQuad> quads;
   private final Map<Direction, List<BakedQuad>> culledQuads = new EnumMap<>(Direction.class);

   public AmuletItemModel(BakedModel icon, BakedModel chain, BakedModel pendant) {
      this.icon = icon;
      this.chain = chain;
      RandomSource random = RandomSource.create(42L);
      this.quads = merge(chain, pendant, null, random);

      for (Direction side : Direction.values()) {
         this.culledQuads.put(side, merge(chain, pendant, side, random));
      }
   }

   private static List<BakedQuad> merge(BakedModel first, BakedModel second, @Nullable Direction side, RandomSource random) {
      List<BakedQuad> merged = new ArrayList<>(first.getQuads(null, side, random));
      merged.addAll(second.getQuads(null, side, random));
      return List.copyOf(merged);
   }

   public List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction side, RandomSource random) {
      return side == null ? this.quads : this.culledQuads.get(side);
   }

   public BakedModel applyTransform(ItemDisplayContext context, PoseStack poseStack, boolean applyLeftHandTransform) {
      if (context == ItemDisplayContext.GUI) {
         return this.icon.applyTransform(context, poseStack, applyLeftHandTransform);
      } else {
         this.getTransforms().getTransform(context).apply(applyLeftHandTransform, poseStack);
         return this;
      }
   }

   public boolean usesBlockLight() {
      return this.icon.usesBlockLight();
   }

   public boolean useAmbientOcclusion() {
      return false;
   }

   public boolean isGui3d() {
      return true;
   }

   public boolean isCustomRenderer() {
      return false;
   }

   public TextureAtlasSprite getParticleIcon() {
      return this.icon.getParticleIcon();
   }

   public ItemTransforms getTransforms() {
      return this.chain.getTransforms();
   }

   public ItemOverrides getOverrides() {
      return ItemOverrides.EMPTY;
   }
}
