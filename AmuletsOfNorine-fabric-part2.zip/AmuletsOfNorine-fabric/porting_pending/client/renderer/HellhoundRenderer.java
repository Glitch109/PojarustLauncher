package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.HellhoundEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.WolfModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class HellhoundRenderer extends MobRenderer<HellhoundEntity, WolfModel<HellhoundEntity>> {
   public static final ModelLayerLocation LAYER = new ModelLayerLocation(AmuletMod.id("hellhound"), "main");
   private static final ResourceLocation TEXTURE = AmuletMod.id("textures/entity/hellhound.png");
   private static final ResourceLocation EMBERS = AmuletMod.id("textures/entity/hellhound_glow.png");
   private static final float SCALE = 1.25F;
   private static final int RISE_TICKS = 10;

   public HellhoundRenderer(Context context) {
      super(context, new WolfModel(context.bakeLayer(LAYER)), 0.6F);
      this.addLayer(new EyesLayer<HellhoundEntity, WolfModel<HellhoundEntity>>(this) {
         public RenderType renderType() {
            return RenderType.eyes(HellhoundRenderer.EMBERS);
         }
      });
   }

   public static LayerDefinition createLayer() {
      MeshDefinition mesh = new MeshDefinition();
      PartDefinition root = mesh.getRoot();
      PartDefinition head = root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(-1.0F, 13.5F, -7.0F));
      PartDefinition realHead = head.addOrReplaceChild(
         "real_head",
         CubeListBuilder.create()
            .texOffs(0, 0)
            .addBox(-2.0F, -3.0F, -2.0F, 6.0F, 6.0F, 4.0F)
            .texOffs(16, 14)
            .addBox(-2.0F, -5.0F, 0.0F, 2.0F, 2.0F, 1.0F)
            .texOffs(16, 14)
            .addBox(2.0F, -5.0F, 0.0F, 2.0F, 2.0F, 1.0F)
            .texOffs(0, 10)
            .addBox(-0.5F, -0.001F, -5.0F, 3.0F, 3.0F, 4.0F),
         PartPose.ZERO
      );
      realHead.addOrReplaceChild(
         "right_horn",
         CubeListBuilder.create().texOffs(52, 0).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F),
         PartPose.offsetAndRotation(-1.2F, -2.6F, -0.5F, -0.75F, 0.0F, -0.35F)
      );
      realHead.addOrReplaceChild(
         "left_horn",
         CubeListBuilder.create().texOffs(52, 0).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F),
         PartPose.offsetAndRotation(3.2F, -2.6F, -0.5F, -0.75F, 0.0F, 0.35F)
      );
      PartDefinition body = root.addOrReplaceChild(
         "body",
         CubeListBuilder.create().texOffs(18, 14).addBox(-3.0F, -2.0F, -3.0F, 6.0F, 9.0F, 6.0F),
         PartPose.offsetAndRotation(0.0F, 14.0F, 2.0F, (float) (Math.PI / 2), 0.0F, 0.0F)
      );
      body.addOrReplaceChild(
         "spines",
         CubeListBuilder.create().texOffs(56, 0).addBox(-0.5F, 0.5F, 3.0F, 1.0F, 1.0F, 2.0F).texOffs(56, 0).addBox(-0.5F, 4.0F, 3.0F, 1.0F, 1.0F, 2.0F),
         PartPose.ZERO
      );
      PartDefinition upperBody = root.addOrReplaceChild(
         "upper_body",
         CubeListBuilder.create().texOffs(21, 0).addBox(-3.0F, -3.0F, -3.0F, 8.0F, 6.0F, 7.0F),
         PartPose.offsetAndRotation(-1.0F, 14.0F, -3.0F, (float) (Math.PI / 2), 0.0F, 0.0F)
      );
      upperBody.addOrReplaceChild(
         "spines",
         CubeListBuilder.create().texOffs(56, 0).addBox(0.5F, -2.5F, 4.0F, 1.0F, 1.0F, 3.0F).texOffs(56, 0).addBox(0.5F, 0.5F, 4.0F, 1.0F, 1.0F, 2.0F),
         PartPose.ZERO
      );
      CubeListBuilder leg = CubeListBuilder.create().texOffs(0, 18).addBox(0.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F);
      root.addOrReplaceChild("right_hind_leg", leg, PartPose.offset(-2.5F, 16.0F, 7.0F));
      root.addOrReplaceChild("left_hind_leg", leg, PartPose.offset(0.5F, 16.0F, 7.0F));
      root.addOrReplaceChild("right_front_leg", leg, PartPose.offset(-2.5F, 16.0F, -4.0F));
      root.addOrReplaceChild("left_front_leg", leg, PartPose.offset(0.5F, 16.0F, -4.0F));
      PartDefinition tail = root.addOrReplaceChild(
         "tail", CubeListBuilder.create(), PartPose.offsetAndRotation(-1.0F, 12.0F, 8.0F, (float) (Math.PI / 5), 0.0F, 0.0F)
      );
      tail.addOrReplaceChild("real_tail", CubeListBuilder.create().texOffs(9, 18).addBox(0.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F), PartPose.ZERO);
      return LayerDefinition.create(mesh, 64, 32);
   }

   public void render(HellhoundEntity hound, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float rise = Easing.outCubic(Mth.clamp((hound.tickCount + partialTick) / 10.0F, 0.0F, 1.0F));
      poseStack.pushPose();
      poseStack.translate(0.0F, -(1.0F - rise) * 1.4F, 0.0F);
      super.render(hound, entityYaw, partialTick, poseStack, buffers, packedLight);
      poseStack.popPose();
   }

   protected void scale(HellhoundEntity hound, PoseStack poseStack, float partialTick) {
      poseStack.scale(1.25F, 1.25F, 1.25F);
   }

   protected float getBob(HellhoundEntity hound, float partialTick) {
      return hound.getTailAngle();
   }

   public ResourceLocation getTextureLocation(HellhoundEntity hound) {
      return TEXTURE;
   }
}
