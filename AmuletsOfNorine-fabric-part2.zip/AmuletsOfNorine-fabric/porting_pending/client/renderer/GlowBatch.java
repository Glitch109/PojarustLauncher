package com.amuletmod.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import org.joml.Matrix4f;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class GlowBatch {
   private static final Map<RenderType, List<GlowBatch.Entry>> QUEUE = new LinkedHashMap<>();

   private GlowBatch() {
   }

   public static void add(RenderType type, PoseStack poseStack, GlowBatch.Painter painter) {
      Pose last = poseStack.last();
      QUEUE.computeIfAbsent(type, t -> new ArrayList<>()).add(new GlowBatch.Entry(new Matrix4f(last.pose()), last.copy(), painter));
   }

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      if (event.getStage() == Stage.AFTER_SKY) {
         QUEUE.clear();
      } else if (event.getStage() == Stage.AFTER_PARTICLES && !QUEUE.isEmpty()) {
         BufferSource buffers = LateBuffers.get();

         for (Map.Entry<RenderType, List<GlowBatch.Entry>> batch : QUEUE.entrySet()) {
            VertexConsumer consumer = buffers.getBuffer(batch.getKey());

            for (GlowBatch.Entry entry : batch.getValue()) {
               entry.painter().paint(consumer, entry.pose(), entry.normal());
            }

            buffers.endBatch(batch.getKey());
         }

         QUEUE.clear();
      }
   }

   private record Entry(Matrix4f pose, Pose normal, GlowBatch.Painter painter) {
   }

   @FunctionalInterface
   public interface Painter {
      void paint(VertexConsumer var1, Matrix4f var2, Pose var3);
   }
}
