package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.ClientClock;
import com.amuletmod.client.ShaderPacks;
import com.amuletmod.entity.ContainmentEntity;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.blockentity.TheEndPortalRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.slf4j.Logger;

public final class SubspaceWalls {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final ResourceLocation SHADER = AmuletMod.id("containment_void");
   private static final float TILE = 2.0F;
   private static final int MIN_TILES = 4;
   private static final int MAX_TILES = 24;
   public static final int SUBDIVIDE_TICKS = 14;
   public static final int TURN_SPAN = 110;
   public static final int TURN_TICKS = 6;
   private static final float RIM_TICKS = 10.0F;
   private static final float COLLAPSE_SPREAD = 9.0F;
   private static final float COLLAPSE_TICKS = 4.0F;
   private static final float X1 = 0.55F;
   private static final float Y1 = 0.0F;
   private static final float X2 = 0.9F;
   private static final float Y2 = 0.25F;
   public static final float INSET = 0.02F;
   private static final float STAR_SCALE = 0.42F;
   private static final float DRIFT = 2.0F;
   private static final float[][] END_COLORS = new float[][]{
      {0.022087F, 0.098399F, 0.110818F},
      {0.011892F, 0.095924F, 0.089485F},
      {0.027636F, 0.101689F, 0.100326F},
      {0.046564F, 0.109883F, 0.114838F},
      {0.064901F, 0.117696F, 0.097189F},
      {0.063761F, 0.086895F, 0.123646F},
      {0.084817F, 0.111994F, 0.16638F},
      {0.097489F, 0.15412F, 0.091064F},
      {0.106152F, 0.131144F, 0.195191F},
      {0.097721F, 0.110188F, 0.187229F},
      {0.133516F, 0.138278F, 0.148582F},
      {0.070006F, 0.243332F, 0.235792F},
      {0.196766F, 0.142899F, 0.214696F},
      {0.047281F, 0.315338F, 0.32197F},
      {0.204675F, 0.39001F, 0.302066F},
      {0.080955F, 0.314821F, 0.661491F}
   };
   private static final int LAYERS = 15;
   private static final RenderType END_SKY = RenderType.entityCutoutNoCull(TheEndPortalRenderer.END_SKY_LOCATION);
   private static final RenderType END_STARS = ModRenderTypes.glowTextured(TheEndPortalRenderer.END_PORTAL_LOCATION);
   @Nullable
   private static ShaderInstance shader;
   private static boolean failed;
   private static final ByteBufferBuilder BYTES = new ByteBufferBuilder(65536);
   private static final Map<ContainmentEntity, SubspaceWalls.Tiles> TILES = new WeakHashMap<>();
   private static float[] rects = new float[1280];

   private SubspaceWalls() {
   }

   public static void onRegisterShaders(RegisterShadersEvent event) {
      shader = null;
      failed = false;

      try {
         ShaderInstance loaded = new ShaderInstance(event.getResourceProvider(), SHADER, DefaultVertexFormat.POSITION_TEX_COLOR);
         if (GlStateManager.glGetProgrami(loaded.getId(), 35714) == 0) {
            LOGGER.warn("Contain's walls won't turn to the void: their shader didn't link");
            loaded.close();
            return;
         }

         event.registerShader(loaded, registered -> shader = registered);
      } catch (IOException var2) {
         LOGGER.warn("Contain's walls won't turn to the void: {}", var2.getMessage());
      }
   }

   @Nullable
   public static ShaderInstance shader() {
      return shader;
   }

   public static SubspaceWalls.Mode mode() {
      if (ShaderPacks.inUse()) {
         return SubspaceWalls.Mode.GEOMETRY;
      } else {
         return shader != null && !failed ? SubspaceWalls.Mode.SHADER : SubspaceWalls.Mode.NONE;
      }
   }

   public static boolean shown() {
      return mode() != SubspaceWalls.Mode.NONE;
   }

   public static int tilesPerSide(float reach) {
      return Mth.clamp(Math.round(2.0F * reach / 2.0F), 4, 24);
   }

   public static int tileCount(float reach) {
      int n = tilesPerSide(reach);
      return 6 * n * n;
   }

   public static float turned(float x) {
      if (x <= 0.0F) {
         return 0.0F;
      } else {
         return x >= 1.0F ? 1.0F : bezier(solve(x, 0.55F, 0.9F), 0.0F, 0.25F);
      }
   }

   private static float turnTime(float share) {
      return bezier(solve(share, 0.0F, 0.25F), 0.55F, 0.9F) * 110.0F;
   }

   private static float solve(float value, float a, float b) {
      float low = 0.0F;
      float high = 1.0F;

      for (int i = 0; i < 24; i++) {
         float mid = (low + high) * 0.5F;
         if (bezier(mid, a, b) < value) {
            low = mid;
         } else {
            high = mid;
         }
      }

      return (low + high) * 0.5F;
   }

   private static float bezier(float s, float a, float b) {
      float t = 1.0F - s;
      return 3.0F * t * t * s * a + 3.0F * t * s * s * b + s * s * s;
   }

   private static float easeOut(float x) {
      return 1.0F - (1.0F - x) * (1.0F - x);
   }

   public static SubspaceWalls.Tiles tiles(ContainmentEntity walls, float partialTick) {
      int n = tilesPerSide(walls.reach(partialTick));
      SubspaceWalls.Tiles tiles = TILES.get(walls);
      if (tiles == null || tiles.n != n) {
         tiles = new SubspaceWalls.Tiles(n, walls.getUUID().getLeastSignificantBits());
         TILES.put(walls, tiles);
      }

      float fall = walls.fall(partialTick);
      tiles.update(walls.heldFor(partialTick), fall > 0.0F ? fall * 20.0F : -1.0F);
      return tiles;
   }

   public static boolean drawVoid(
      SubspaceWalls.Mode mode, SubspaceWalls.Tiles tiles, float reach, Vector3f eye, float partialTick, PoseStack poseStack, MultiBufferSource buffers
   ) {
      float time = ClientClock.time(partialTick) / 24000.0F;
      if (mode == SubspaceWalls.Mode.GEOMETRY) {
         if (!ShaderPacks.renderingShadows()) {
            geometry(tiles, reach, eye, time, poseStack, buffers);
         }

         return true;
      } else {
         ShaderInstance shader = SubspaceWalls.shader;
         if (shader != null && !failed) {
            try {
               shaded(shader, tiles, reach, eye, time, poseStack);
               return true;
            } catch (RuntimeException var10) {
               failed = true;
               LOGGER.warn("Contain's walls won't turn to the void any more: drawing it failed", var10);
               return false;
            }
         } else {
            return false;
         }
      }
   }

   private static void shaded(ShaderInstance shader, SubspaceWalls.Tiles tiles, float reach, Vector3f eye, float time, PoseStack poseStack) {
      int n = tiles.n;
      float wall = reach - 0.02F;
      BufferBuilder builder = new BufferBuilder(BYTES, com.mojang.blaze3d.vertex.VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
      float[] point = new float[3];

      for (int face = 0; face < 6; face++) {
         int axis = face / 2;
         point[axis] = face % 2 == 0 ? -wall : wall;

         for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
               int k = tiles.index(face, i, j);
               float fill = tiles.fill[k];
               if (!(fill <= 0.0F)) {
                  int red = Mth.ceil(fill * 255.0F);
                  int green = Math.round(Mth.clamp(tiles.rim[k], 0.0F, 1.0F) * 255.0F);

                  for (int corner = 0; corner < 4; corner++) {
                     int u = corner != 1 && corner != 2 ? 0 : 1;
                     int v = corner >= 2 ? 1 : 0;
                     point[(axis + 1) % 3] = -wall + 2.0F * wall * (i + u) / n;
                     point[(axis + 2) % 3] = -wall + 2.0F * wall * (j + v) / n;
                     builder.addVertex(point[0], point[1], point[2]).setUv(u, v).setColor(red, green, 0, 255);
                  }
               }
            }
         }
      }

      MeshData mesh = builder.build();
      if (mesh != null) {
         boolean outside = Math.abs(eye.x()) > wall || Math.abs(eye.y()) > wall || Math.abs(eye.z()) > wall;
         RenderType type = ModRenderTypes.CONTAINMENT_VOID;
         type.setupRenderState();

         try {
            shader.safeGetUniform("ModelViewMat").set(new Matrix4f(RenderSystem.getModelViewMatrix()).mul(poseStack.last().pose()));
            shader.safeGetUniform("ProjMat").set(RenderSystem.getProjectionMatrix());
            shader.safeGetUniform("Camera").set(eye);
            shader.safeGetUniform("Void").set(reach, time, outside ? 1.0F : 0.0F, 0.0F);
            shader.safeGetUniform("FogStart").set(RenderSystem.getShaderFogStart());
            shader.safeGetUniform("FogEnd").set(RenderSystem.getShaderFogEnd());
            float[] fog = RenderSystem.getShaderFogColor();
            shader.safeGetUniform("FogColor").set(fog[0], fog[1], fog[2], fog[3]);
            shader.setSampler("Sampler0", RenderSystem.getShaderTexture(0));
            shader.setSampler("Sampler1", RenderSystem.getShaderTexture(1));
            shader.apply();
            BufferUploader.draw(mesh);
         } finally {
            mesh.close();
            shader.clear();
            type.clearRenderState();
         }
      }
   }

   private static void geometry(SubspaceWalls.Tiles tiles, float reach, Vector3f eye, float time, PoseStack poseStack, MultiBufferSource buffers) {
      int n = tiles.n;
      float wall = reach - 0.02F;
      float half = wall / n;
      int count = 0;

      for (int face = 0; face < 6; face++) {
         boolean whole = true;

         for (int i = 0; i < n && whole; i++) {
            for (int j = 0; j < n && whole; j++) {
               whole = tiles.fill[tiles.index(face, i, j)] >= 1.0F;
            }
         }

         if (whole) {
            count = rect(count, face, -wall, wall, -wall, wall);
         } else {
            for (int i = 0; i < n; i++) {
               float a0 = edge(i, n, wall);
               float a1 = edge(i + 1, n, wall);
               int run = -1;

               for (int j = 0; j <= n; j++) {
                  float fill = j < n ? tiles.fill[tiles.index(face, i, j)] : 0.0F;
                  if (fill >= 1.0F) {
                     if (run < 0) {
                        run = j;
                     }
                  } else {
                     if (run >= 0) {
                        count = rect(count, face, a0, a1, edge(run, n, wall), edge(j, n, wall));
                        run = -1;
                     }

                     if (fill > 0.0F) {
                        float a = (a0 + a1) * 0.5F;
                        float b = edge(j, n, wall) + half;
                        float size = fill * half;
                        count = rect(count, face, a - size, a + size, b - size, b + size);
                     }
                  }
               }
            }
         }
      }

      if (count != 0) {
         Matrix4f pose = poseStack.last().pose();
         Pose normal = poseStack.last();
         VertexConsumer sky = buffers.getBuffer(END_SKY);

         for (int r = 0; r < count; r++) {
            starRect(sky, pose, normal, r, wall, reach, eye, 0, time);
         }

         VertexConsumer stars = buffers.getBuffer(END_STARS);

         for (int layer = 1; layer <= 15; layer++) {
            for (int r = 0; r < count; r++) {
               starRect(stars, pose, normal, r, wall, reach, eye, layer, time);
            }
         }
      }
   }

   private static float edge(int i, int n, float wall) {
      return -wall + 2.0F * wall * i / n;
   }

   private static int rect(int count, int face, float a0, float a1, float b0, float b1) {
      if (5 * (count + 1) > rects.length) {
         rects = Arrays.copyOf(rects, rects.length * 2);
      }

      int at = 5 * count;
      rects[at] = face;
      rects[at + 1] = a0;
      rects[at + 2] = a1;
      rects[at + 3] = b0;
      rects[at + 4] = b1;
      return count + 1;
   }

   private static void starRect(VertexConsumer consumer, Matrix4f pose, Pose normal, int r, float wall, float reach, Vector3f eye, int layer, float time) {
      int at = 5 * r;
      int face = (int)rects[at];
      int axis = face / 2;
      int alongI = (axis + 1) % 3;
      int alongJ = (axis + 2) % 3;
      float plane = face % 2 == 0 ? -wall : wall;
      float radius = reach * (layer == 0 ? 10.0F : 1.6F + 0.45F * (16 - layer));
      float distance = Math.max(1.0F, Math.abs(eye.get(axis) - plane));
      float magnify = 1.0F + (radius - reach) / distance;
      float perBlock = 0.42F / radius;
      float footI = eye.get(alongI);
      float footJ = eye.get(alongJ);
      float[] color = END_COLORS[Math.max(0, layer - 1)];
      float[] point = new float[3];
      point[axis] = plane;

      for (int corner = 0; corner < 4; corner++) {
         float a = rects[at + (corner != 1 && corner != 2 ? 1 : 2)];
         float b = rects[at + (corner >= 2 ? 4 : 3)];
         point[alongI] = a;
         point[alongJ] = b;
         float px = (footI + (a - footI) * magnify) * perBlock;
         float py = (footJ + (b - footJ) * magnify) * perBlock;
         float u = px;
         float v = py;
         if (layer > 0) {
            px += 17.0F / layer;
            py += (2.0F + layer / 1.5F) * time * 1.5F * 2.0F;
            float scale = (4.5F - layer / 4.0F) * 2.0F;
            double angle = Math.toRadians(((double)layer * layer * 4321.0 + layer * 9.0) * 2.0 % 360.0);
            float cos = (float)Math.cos(angle);
            float sin = (float)Math.sin(angle);
            u = (cos * px + sin * py) * scale;
            v = (-sin * px + cos * py) * scale;
         }

         GlowDraw.texVertex(consumer, pose, normal, point[0], point[1], point[2], color[0], color[1], color[2], u, v);
      }
   }

   public static enum Mode {
      SHADER,
      GEOMETRY,
      NONE;
   }

   public static final class Tiles {
      public final int n;
      private final float[] turnAt;
      private final float[] emptyAt;
      public final float[] fill;
      public final float[] rim;
      public float grid;
      public float flash;
      public float lock;

      private Tiles(int n, long seed) {
         this.n = n;
         int count = 6 * n * n;
         this.turnAt = new float[count];
         this.emptyAt = new float[count];
         this.fill = new float[count];
         this.rim = new float[count];
         Random random = new Random(seed);
         int[] order = new int[count];
         int k = 0;

         while (k < count) {
            order[k] = k++;
         }

         for (int kx = count - 1; kx > 0; kx--) {
            int other = random.nextInt(kx + 1);
            int swap = order[kx];
            order[kx] = order[other];
            order[other] = swap;
         }

         for (int rank = 0; rank < count; rank++) {
            this.turnAt[order[rank]] = SubspaceWalls.turnTime((rank + 0.5F) / count);
         }

         for (int kx = 0; kx < count; kx++) {
            this.emptyAt[kx] = random.nextFloat() * 9.0F;
         }
      }

      public int index(int wall, int i, int j) {
         return (wall * this.n + i) * this.n + j;
      }

      private void update(float held, float fallen) {
         this.grid = SubspaceWalls.easeOut(Mth.clamp(held / 14.0F, 0.0F, 1.0F));
         this.flash = held < 14.0F ? 1.0F : (float)Math.exp(-(held - 14.0F) / 10.0F);
         float t = held - 14.0F;
         float done = t - 110.0F - 6.0F;
         this.lock = done > 0.0F ? (float)Math.exp(-done / 10.0F) : 0.0F;

         for (int k = 0; k < this.fill.length; k++) {
            float into = t - this.turnAt[k];
            float full = 0.0F;
            float burn = 0.0F;
            if (into > 0.0F) {
               full = into >= 6.0F ? 1.0F : SubspaceWalls.easeOut(into / 6.0F);
               burn = into < 6.0F ? 1.0F : Math.max(0.0F, 1.0F - (into - 6.0F) / 10.0F);
            }

            if (fallen > 0.0F && full > 0.0F) {
               float out = (fallen - this.emptyAt[k]) / 4.0F;
               if (out > 0.0F) {
                  out = Math.min(out, 1.0F);
                  full *= 1.0F - out * out;
                  burn = 1.0F;
               }
            }

            this.fill[k] = full;
            this.rim[k] = burn;
         }
      }
   }
}
