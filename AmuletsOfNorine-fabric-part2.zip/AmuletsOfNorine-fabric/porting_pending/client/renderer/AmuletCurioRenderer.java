package com.amuletmod.client.renderer;

import com.amuletmod.amulet.AmuletItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.joml.Vector3f;
import top.theillusivec4.curios.api.SlotContext;
import top.theillusivec4.curios.api.client.ICurioRenderer;

public class AmuletCurioRenderer implements ICurioRenderer {
   public static final AmuletCurioRenderer INSTANCE = new AmuletCurioRenderer();
   private static final Vector3f CHAIN_NECK = new Vector3f(8.0F, 16.0F, 8.0F);
   private static final Vector3f PENDANT_BAIL = new Vector3f(8.0F, 8.25F, 8.0F);
   private static final Vector3f PENDANT_HANG = new Vector3f(0.0F, -4.25F, 3.0F);
   private static final float PENDANT_SCALE = 0.42F;

   private AmuletCurioRenderer() {
   }

   public <T extends LivingEntity, M extends EntityModel<T>> void render(
      ItemStack stack,
      SlotContext slotContext,
      PoseStack poseStack,
      RenderLayerParent<T, M> renderLayerParent,
      MultiBufferSource buffers,
      int light,
      float limbSwing,
      float limbSwingAmount,
      float partialTicks,
      float ageInTicks,
      float netHeadYaw,
      float headPitch
   ) {
      LivingEntity wearer = slotContext.entity();
      if (stack.getItem() instanceof AmuletItem amulet
         && renderLayerParent.getModel() instanceof HumanoidModel<?> model
         && !(wearer.getItemBySlot(EquipmentSlot.CHEST).getItem() instanceof ArmorItem)) {
         ModelManager models = Minecraft.getInstance().getModelManager();
         BakedModel pendant = models.getModel(AmuletModels.pendant(amulet));
         if (pendant != models.getMissingModel()) {
            BakedModel chain = models.getModel(AmuletModels.wornChain(amulet.definition().tier()));
            poseStack.pushPose();
            model.body.translateAndRotate(poseStack);
            poseStack.mulPose(Axis.XP.rotationDegrees(180.0F));
            draw(stack, chain, CHAIN_NECK, new Vector3f(), 1.0F, poseStack, buffers, light);
            draw(stack, pendant, PENDANT_BAIL, PENDANT_HANG, 0.42F, poseStack, buffers, light);
            poseStack.popPose();
         }
      }
   }

   private static void draw(
      ItemStack stack, BakedModel model, Vector3f from, Vector3f to, float scale, PoseStack poseStack, MultiBufferSource buffers, int light
   ) {
      poseStack.pushPose();
      poseStack.translate(to.x() / 16.0F, to.y() / 16.0F, to.z() / 16.0F);
      poseStack.scale(scale, scale, scale);
      poseStack.translate(0.5F - from.x() / 16.0F, 0.5F - from.y() / 16.0F, 0.5F - from.z() / 16.0F);
      Minecraft.getInstance().getItemRenderer().render(stack, ItemDisplayContext.NONE, false, poseStack, buffers, light, OverlayTexture.NO_OVERLAY, model);
      poseStack.popPose();
   }
}
