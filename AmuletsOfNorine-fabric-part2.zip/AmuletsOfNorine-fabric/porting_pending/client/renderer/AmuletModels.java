package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.AmuletItem;
import com.amuletmod.amulet.AmuletTier;
import com.amuletmod.registry.ModItems;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelBakery;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.FastColor.ARGB32;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ModelEvent.ModifyBakingResult;
import net.neoforged.neoforge.client.event.ModelEvent.RegisterAdditional;
import net.neoforged.neoforge.registries.DeferredHolder;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class AmuletModels {
   public static final int METAL_TINT = 1;

   private AmuletModels() {
   }

   public static ModelResourceLocation chain(AmuletTier tier) {
      return ModelResourceLocation.standalone(AmuletMod.id("item/amulet/chain/" + tier.chain()));
   }

   public static ModelResourceLocation wornChain(AmuletTier tier) {
      return ModelResourceLocation.standalone(AmuletMod.id("item/amulet/chain/" + tier.chain() + "_worn"));
   }

   public static ModelResourceLocation pendant(Item amulet) {
      ResourceLocation id = BuiltInRegistries.ITEM.getKey(amulet);
      return ModelResourceLocation.standalone(ResourceLocation.fromNamespaceAndPath(id.getNamespace(), "item/amulet/pendant/" + id.getPath()));
   }

   @Nullable
   public static AmuletTier chainTier(Item item) {
      if (item == ModItems.IRON_AMULET_CHAIN.get()) {
         return AmuletTier.SILVER;
      } else if (item == ModItems.GOLD_AMULET_CHAIN.get()) {
         return AmuletTier.GOLD;
      } else {
         return item == ModItems.SHULKER_AMULET_CHAIN.get() ? AmuletTier.SHULKER : null;
      }
   }

   public static List<AmuletItem> amulets() {
      return ModItems.ITEMS.getEntries().stream().<Item>map(DeferredHolder::get).filter(AmuletItem.class::isInstance).map(AmuletItem.class::cast).toList();
   }

   @SubscribeEvent
   public static void onRegisterAdditionalModels(RegisterAdditional event) {
      for (AmuletTier tier : AmuletTier.values()) {
         event.register(chain(tier));
         event.register(wornChain(tier));
      }

      ResourceManager resources = Minecraft.getInstance().getResourceManager();

      for (AmuletItem amulet : amulets()) {
         ModelResourceLocation pendant = pendant(amulet);
         if (resources.getResource(ModelBakery.MODEL_LISTER.idToFile(pendant.id())).isPresent()) {
            event.register(pendant);
         }
      }
   }

   @SubscribeEvent
   public static void onModifyBakingResult(ModifyBakingResult event) {
      Map<ModelResourceLocation, BakedModel> models = event.getModels();

      for (AmuletItem amulet : amulets()) {
         ModelResourceLocation inventory = ModelResourceLocation.inventory(BuiltInRegistries.ITEM.getKey(amulet));
         BakedModel icon = models.get(inventory);
         BakedModel chain = models.get(chain(amulet.definition().tier()));
         BakedModel pendant = models.get(pendant(amulet));
         if (icon != null && chain != null && pendant != null) {
            models.put(inventory, new AmuletItemModel(icon, chain, pendant));
         }
      }
   }

   @SubscribeEvent
   public static void onRegisterItemColors(net.neoforged.neoforge.client.event.RegisterColorHandlersEvent.Item event) {
      event.register(
         (stack, tintIndex) -> tintIndex == 1 && stack.getItem() instanceof AmuletItem amulet ? ARGB32.opaque(amulet.definition().tier().metalColor()) : -1,
         (ItemLike[])amulets().toArray(Item[]::new)
      );
      event.register((stack, tintIndex) -> {
         AmuletTier tier = chainTier(stack.getItem());
         return tintIndex == 1 && tier != null ? ARGB32.opaque(tier.metalColor()) : -1;
      }, new ItemLike[]{(ItemLike)ModItems.IRON_AMULET_CHAIN.get(), (ItemLike)ModItems.GOLD_AMULET_CHAIN.get(), (ItemLike)ModItems.SHULKER_AMULET_CHAIN.get()});
   }
}
