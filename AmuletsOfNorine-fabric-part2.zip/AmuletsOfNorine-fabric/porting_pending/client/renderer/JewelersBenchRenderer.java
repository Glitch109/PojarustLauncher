package com.amuletmod.client.renderer;

import com.amuletmod.amulet.AmuletTier;
import com.amuletmod.bench.JewelersBenchBlock;
import com.amuletmod.bench.JewelersBenchBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

public class JewelersBenchRenderer implements BlockEntityRenderer<JewelersBenchBlockEntity> {
   private static final float HANG_X = 8.0F;
   private static final float HANG_Y = 15.3F;
   private static final float HANG_Z = 8.0F;
   private static final float SCALE = 0.55F;
   private final ItemRenderer itemRenderer;

   public JewelersBenchRenderer(Context context) {
      this.itemRenderer = context.getItemRenderer();
   }

   public AABB getRenderBoundingBox(JewelersBenchBlockEntity bench) {
      BlockPos pos = bench.getBlockPos();
      return new AABB(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, pos.getY() + 2, pos.getZ() + 1);
   }

   public void render(JewelersBenchBlockEntity bench, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight, int packedOverlay) {
      Level level = bench.getLevel();
      if (level != null) {
         ItemStack stack = bench.displayedAmulet();
         BakedModel model;
         if (!stack.isEmpty()) {
            model = this.itemRenderer.getModel(stack, level, null, 0);
         } else {
            stack = bench.displayedChain();
            AmuletTier tier = AmuletModels.chainTier(stack.getItem());
            if (tier == null) {
               return;
            }

            model = Minecraft.getInstance().getModelManager().getModel(AmuletModels.chain(tier));
         }

         poseStack.pushPose();
         poseStack.translate(0.5F, 0.0F, 0.5F);
         poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - ((Direction)bench.getBlockState().getValue(JewelersBenchBlock.FACING)).toYRot()));
         poseStack.translate(0.0F, 1.4375F, 0.046875F);
         poseStack.mulPose(Axis.YP.rotationDegrees(180.0F));
         poseStack.scale(0.55F, 0.55F, 0.55F);
         poseStack.translate(0.0F, -0.45625F, 0.0F);
         this.itemRenderer.render(stack, ItemDisplayContext.NONE, false, poseStack, buffers, packedLight, OverlayTexture.NO_OVERLAY, model);
         poseStack.popPose();
      }
   }
}
