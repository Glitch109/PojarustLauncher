package com.amuletmod.client.renderer;

import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.FastColor.ARGB32;

public final class TintedBuffers implements MultiBufferSource {
   private static final Map<RenderType, TintedBuffers.Kind> KINDS = new IdentityHashMap<>();
   private final MultiBufferSource inner;
   private final float[] surface;
   private final float[] glow;

   public TintedBuffers(MultiBufferSource inner, float[] surface, float[] glow) {
      this.inner = inner;
      this.surface = surface;
      this.glow = glow;
   }

   public VertexConsumer getBuffer(RenderType type) {
      VertexConsumer buffer = this.inner.getBuffer(type);

      return (VertexConsumer)(switch ((TintedBuffers.Kind)KINDS.computeIfAbsent(type, TintedBuffers::classify)) {
         case SURFACE -> new TintedBuffers.Tint(buffer, this.surface);
         case GLOW -> new TintedBuffers.Tint(buffer, this.glow);
         case UNTOUCHED -> buffer;
      });
   }

   private static TintedBuffers.Kind classify(RenderType type) {
      String text = type.toString();
      String name = text.startsWith("RenderType[") ? text.substring(11, Math.max(11, text.indexOf(58))) : text;
      if (name.contains("text") || name.contains("outline")) {
         return TintedBuffers.Kind.UNTOUCHED;
      } else {
         return !name.contains("eyes")
               && !name.contains("swirl")
               && !name.contains("emissive")
               && !name.contains("glint")
               && !name.contains("beam")
               && !name.contains("lightning")
            ? TintedBuffers.Kind.SURFACE
            : TintedBuffers.Kind.GLOW;
      }
   }

   private static enum Kind {
      SURFACE,
      GLOW,
      UNTOUCHED;
   }

   private static final class Tint implements VertexConsumer {
      private final VertexConsumer inner;
      private final float red;
      private final float green;
      private final float blue;

      Tint(VertexConsumer inner, float[] color) {
         this.inner = inner;
         this.red = color[0];
         this.green = color[1];
         this.blue = color[2];
      }

      public VertexConsumer addVertex(float x, float y, float z) {
         this.inner.addVertex(x, y, z);
         return this;
      }

      public VertexConsumer setColor(int r, int g, int b, int a) {
         this.inner.setColor((int)(r * this.red), (int)(g * this.green), (int)(b * this.blue), a);
         return this;
      }

      public VertexConsumer setUv(float u, float v) {
         this.inner.setUv(u, v);
         return this;
      }

      public VertexConsumer setUv1(int u, int v) {
         this.inner.setUv1(u, v);
         return this;
      }

      public VertexConsumer setUv2(int u, int v) {
         this.inner.setUv2(u, v);
         return this;
      }

      public VertexConsumer setNormal(float x, float y, float z) {
         this.inner.setNormal(x, y, z);
         return this;
      }

      public void addVertex(float x, float y, float z, int color, float u, float v, int overlay, int light, float normalX, float normalY, float normalZ) {
         int tinted = ARGB32.color(
            ARGB32.alpha(color), (int)(ARGB32.red(color) * this.red), (int)(ARGB32.green(color) * this.green), (int)(ARGB32.blue(color) * this.blue)
         );
         this.inner.addVertex(x, y, z, tinted, u, v, overlay, light, normalX, normalY, normalZ);
      }
   }
}
