package com.amuletmod.client.renderer;

import com.amuletmod.AmuletMod;
import com.amuletmod.entity.MeteorEntity;
import com.amuletmod.entity.SeekingMeteorEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

public class MeteorRenderer<T extends MeteorEntity> extends EntityRenderer<T> {
   public static final ResourceLocation TEXTURE = AmuletMod.id("textures/entity/meteor.png");
   public static final ResourceLocation GLOW = AmuletMod.id("textures/entity/meteor_glow.png");
   private static final float MAX_TAIL = 8.0F;
   private final MeteorModel model;

   public MeteorRenderer(Context context) {
      super(context);
      this.model = new MeteorModel(context.bakeLayer(MeteorModel.LAYER));
   }

   public void render(T meteor, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      float age = meteor.tickCount + partialTick;
      int seed = meteor.getId();
      float size = meteor.getBbWidth();
      poseStack.pushPose();
      poseStack.translate(0.0F, meteor.getBbHeight() * 0.5F, 0.0F);
      if (meteor instanceof SeekingMeteorEntity seeking) {
         this.tail(seeking, partialTick, poseStack);
      }

      poseStack.mulPose(Axis.YP.rotationDegrees(seed * 37 % 360 + age * 9.0F));
      poseStack.mulPose(Axis.XP.rotationDegrees(seed * 53 % 360 + age * 13.0F));
      poseStack.scale(size, size, size);
      this.model.renderToBuffer(poseStack, buffers.getBuffer(RenderType.entitySolid(TEXTURE)), packedLight, OverlayTexture.NO_OVERLAY);
      this.model.renderToBuffer(poseStack, buffers.getBuffer(RenderType.eyes(GLOW)), 15728880, OverlayTexture.NO_OVERLAY);
      poseStack.popPose();
      super.render(meteor, yaw, partialTick, poseStack, buffers, packedLight);
   }

   private void tail(SeekingMeteorEntity meteor, float partialTick, PoseStack poseStack) {
      Vec3 middle = meteor.getPosition(partialTick).add(0.0, meteor.getBbHeight() * 0.5, 0.0);
      Vector3f eye = this.entityRenderDispatcher.camera.getPosition().subtract(middle).toVector3f();
      float halo = meteor.getBbWidth() * (0.95F + 0.08F * Mth.sin((meteor.tickCount + partialTick) * 0.9F));
      List<Vector3f> tail = new ArrayList<>();
      tail.add(new Vector3f());
      float length = 0.0F;

      for (int i = 0; i < 8 && meteor.trail[i] != null && length < 8.0F; i++) {
         Vector3f point = meteor.trail[i].subtract(middle).toVector3f();
         Vector3f previous = tail.get(tail.size() - 1);
         float step = previous.distance(point);
         if (length + step > 8.0F) {
            point = new Vector3f(previous).lerp(point, (8.0F - length) / step);
         }

         length += step;
         tail.add(point);
      }

      Vector3f[] points = tail.toArray(new Vector3f[0]);
      Vector3f toEye = new Vector3f(eye).normalize();
      GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
         GlowDraw.glowSphere(consumer, pose, halo, (float) (-Math.PI / 2), (float) (Math.PI / 2), 12, 6, 1.0F, 0.4F, 0.08F, (nx, ny, nz) -> {
            float facing = nx * toEye.x() + ny * toEye.y() + nz * toEye.z();
            return 0.35F * facing * facing;
         });
         if (points.length > 2) {
            GlowDraw.taperedRibbon(consumer, pose, points, eye, meteor.getBbWidth() * 0.75F, 1.0F, 0.32F, 0.06F, 0.6F);
            GlowDraw.taperedRibbon(consumer, pose, points, eye, meteor.getBbWidth() * 0.28F, 1.0F, 0.82F, 0.5F, 0.9F);
         }
      });
   }

   protected int getBlockLightLevel(T meteor, BlockPos pos) {
      return 15;
   }

   public ResourceLocation getTextureLocation(T meteor) {
      return TEXTURE;
   }
}
