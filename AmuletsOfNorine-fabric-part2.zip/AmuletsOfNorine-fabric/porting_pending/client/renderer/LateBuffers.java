package com.amuletmod.client.renderer;

import com.amuletmod.client.ShaderPacks;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;

public final class LateBuffers {
   private static final BufferSource OWN = MultiBufferSource.immediate(new ByteBufferBuilder(4096));

   private LateBuffers() {
   }

   public static BufferSource get() {
      return ShaderPacks.inUse() ? Minecraft.getInstance().renderBuffers().bufferSource() : OWN;
   }
}
