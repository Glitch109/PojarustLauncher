package com.amuletmod.client.renderer;

import com.amuletmod.registry.ModItems;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelBakery;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.item.Item;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ModelEvent.ModifyBakingResult;
import net.neoforged.neoforge.client.event.ModelEvent.RegisterAdditional;
import net.neoforged.neoforge.registries.DeferredHolder;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class GemstoneModels {
   private GemstoneModels() {
   }

   public static ModelResourceLocation gem(Item item) {
      ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
      return ModelResourceLocation.standalone(ResourceLocation.fromNamespaceAndPath(id.getNamespace(), "item/gemstone/" + id.getPath()));
   }

   private static List<Item> items() {
      return ModItems.ITEMS.getEntries().stream().<Item>map(DeferredHolder::get).toList();
   }

   @SubscribeEvent
   public static void onRegisterAdditionalModels(RegisterAdditional event) {
      ResourceManager resources = Minecraft.getInstance().getResourceManager();

      for (Item item : items()) {
         ModelResourceLocation gem = gem(item);
         if (resources.getResource(ModelBakery.MODEL_LISTER.idToFile(gem.id())).isPresent()) {
            event.register(gem);
         }
      }
   }

   @SubscribeEvent
   public static void onModifyBakingResult(ModifyBakingResult event) {
      Map<ModelResourceLocation, BakedModel> models = event.getModels();

      for (Item item : items()) {
         ModelResourceLocation inventory = ModelResourceLocation.inventory(BuiltInRegistries.ITEM.getKey(item));
         BakedModel icon = models.get(inventory);
         BakedModel gem = models.get(gem(item));
         if (icon != null && gem != null) {
            models.put(inventory, new GemstoneItemModel(icon, gem));
         }
      }
   }
}
