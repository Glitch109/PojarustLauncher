package com.amuletmod.client.renderer;

import com.amuletmod.entity.ShadowPlayerEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidArmorModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.HumanoidModel.ArmPose;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.client.resources.PlayerSkin.Model;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import org.jetbrains.annotations.Nullable;

public class ShadowPlayerRenderer extends HumanoidMobRenderer<ShadowPlayerEntity, PlayerModel<ShadowPlayerEntity>> {
   private final PlayerModel<ShadowPlayerEntity> wide = (PlayerModel<ShadowPlayerEntity>)this.model;
   private final PlayerModel<ShadowPlayerEntity> slim;

   public ShadowPlayerRenderer(Context context) {
      super(context, new PlayerModel(context.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
      this.slim = new PlayerModel(context.bakeLayer(ModelLayers.PLAYER_SLIM), true);
      this.addLayer(
         new HumanoidArmorLayer(
            this,
            new HumanoidArmorModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
            new HumanoidArmorModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
            context.getModelManager()
         )
      );
   }

   public void render(ShadowPlayerEntity entity, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int light) {
      UUID victim = entity.victimId();
      PlayerInfo info = playerInfo(victim);
      PlayerSkin skin = info != null ? info.getSkin() : (victim != null ? DefaultPlayerSkin.get(victim) : null);
      this.model = skin != null && skin.model() == Model.SLIM ? this.slim : this.wide;
      ArmPose main = armPose(entity, InteractionHand.MAIN_HAND);
      ArmPose off = armPose(entity, InteractionHand.OFF_HAND);
      if (main.isTwoHanded()) {
         off = entity.getOffhandItem().isEmpty() ? ArmPose.EMPTY : ArmPose.ITEM;
      }

      boolean rightHanded = entity.getMainArm() == HumanoidArm.RIGHT;
      ((PlayerModel)this.model).rightArmPose = rightHanded ? main : off;
      ((PlayerModel)this.model).leftArmPose = rightHanded ? off : main;
      super.render(entity, yaw, partialTick, poseStack, buffers, light);
   }

   private static ArmPose armPose(ShadowPlayerEntity entity, InteractionHand hand) {
      ItemStack stack = entity.getItemInHand(hand);
      if (stack.isEmpty()) {
         return ArmPose.EMPTY;
      } else {
         if (entity.getUsedItemHand() == hand && entity.getUseItemRemainingTicks() > 0) {
            UseAnim animation = stack.getUseAnimation();
            if (animation == UseAnim.BOW) {
               return ArmPose.BOW_AND_ARROW;
            }

            if (animation == UseAnim.CROSSBOW) {
               return ArmPose.CROSSBOW_CHARGE;
            }

            if (animation == UseAnim.BLOCK) {
               return ArmPose.BLOCK;
            }
         } else if (!entity.swinging && stack.getItem() instanceof CrossbowItem && CrossbowItem.isCharged(stack)) {
            return ArmPose.CROSSBOW_HOLD;
         }

         return ArmPose.ITEM;
      }
   }

   @Nullable
   private static PlayerInfo playerInfo(@Nullable UUID victim) {
      ClientPacketListener connection = Minecraft.getInstance().getConnection();
      return victim != null && connection != null ? connection.getPlayerInfo(victim) : null;
   }

   public ResourceLocation getTextureLocation(ShadowPlayerEntity entity) {
      UUID victim = entity.victimId();
      PlayerInfo info = playerInfo(victim);
      if (info != null) {
         return info.getSkin().texture();
      } else {
         return victim != null ? DefaultPlayerSkin.get(victim).texture() : DefaultPlayerSkin.getDefaultTexture();
      }
   }

   protected void scale(ShadowPlayerEntity entity, PoseStack poseStack, float partialTick) {
      poseStack.scale(0.9375F, 0.9375F, 0.9375F);
   }
}
