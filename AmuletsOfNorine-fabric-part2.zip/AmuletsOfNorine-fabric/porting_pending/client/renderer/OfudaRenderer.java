package com.amuletmod.client.renderer;

import com.amuletmod.amulet.ability.librarian.Kanji;
import com.amuletmod.client.OfudaClient;
import com.amuletmod.entity.OfudaEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class OfudaRenderer extends EntityRenderer<OfudaEntity> {
   private static final float INK_R = 0.1F;
   private static final float INK_G = 0.08F;
   private static final float INK_B = 0.06F;
   private static final float SLIP_U = 0.625F;
   private static final float SLIP_V = 0.8125F;
   private static final float SEAL_U0 = 0.6875F;
   private static final float SEAL_U1 = 0.875F;
   private static final float SEAL_V1 = 0.09375F;

   public OfudaRenderer(Context context) {
      super(context);
   }

   public void render(OfudaEntity ofuda, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
      Vec3 at = ofuda.getPosition(partialTick);
      switch (ofuda.phase()) {
         case WRITING:
            this.writing(ofuda, partialTick, poseStack, buffers, at);
            break;
         case FLYING:
            this.orb(ofuda, partialTick, poseStack, at);
            break;
         case STUCK:
         case BURNING:
            this.stuck(ofuda, partialTick, poseStack, buffers, at, packedLight);
      }

      super.render(ofuda, entityYaw, partialTick, poseStack, buffers, packedLight);
   }

   private void writing(OfudaEntity ofuda, float partialTick, PoseStack poseStack, MultiBufferSource buffers, Vec3 at) {
      Entity writer = ofuda.caster();
      if (writer != null && writer != Minecraft.getInstance().player) {
         float age = ofuda.tickCount + partialTick;
         float unfurl = Mth.clamp(age / 5.0F, 0.0F, 1.0F);
         float fold = Mth.clamp((age - 29.0F) / 7.0F, 0.0F, 1.0F);
         float shrink = 1.0F - fold * fold;
         Vec3[] frame = OfudaEntity.writingFrame(writer, partialTick);
         Kanji drawn = ofuda.drawn();
         float sinceDrawn = age - OfudaEntity.strikesAt(2);
         poseStack.pushPose();
         place(poseStack, frame, at);
         poseStack.mulPose(Axis.ZP.rotationDegrees(fold * 35.0F));
         float height = 0.95F * shrink;
         poseStack.scale(Mth.lerp(unfurl, 0.8F, 1.0F), Math.max(0.01F, Easing.outBack(unfurl)), 1.0F);
         slip(poseStack, buffers, height, 0.0F, age >= 24.0F, 15728880);
         float texel = height / 104.0F;

         for (int k = 0; k < 3; k++) {
            float start = OfudaEntity.strikesAt(k) - 4;
            if (!(age < start)) {
               boolean isDrawn = k == 2;
               float fall = Mth.clamp((age - start) / 4.0F, 0.0F, 1.0F);
               float scale = 1.0F + 3.5F * (1.0F - fall * fall * fall);
               float alpha = 0.2F + 0.8F * fall;
               if (!isDrawn) {
                  float leave = Mth.clamp((age - (OfudaEntity.strikesAt(k + 1) - 4)) / 3.0F, 0.0F, 1.0F);
                  if (leave >= 1.0F) {
                     continue;
                  }

                  alpha *= 1.0F - leave;
                  scale *= 1.0F + 0.3F * leave;
               }

               Kanji kanji = ofuda.kanji(k);
               float lift = (scale - 1.0F) * 0.12F;
               ink(poseStack, buffers, kanji, 16.0F * texel * scale, 8.0F * texel, lift, alpha);
               float since = age - OfudaEntity.strikesAt(k);
               float flash = since >= 0.0F && since < 6.0F ? 1.0F - since / 6.0F : 0.0F;
               float burn = isDrawn && since >= 0.0F ? Mth.clamp(since / 2.0F, 0.0F, 1.0F) * (0.65F + 0.25F * Mth.sin(age * 0.7F)) : 0.0F;
               kanjiGlow(poseStack, kanji, 16.0F * texel * scale * 1.04F, 8.0F * texel, lift + 0.004F, Math.max(burn, flash * 0.8F) * shrink);
               if (flash > 0.0F) {
                  star(poseStack, 0.0F, 8.0F * texel, 0.05F, (isDrawn ? 1.1F : 0.7F) * flash, kanji, flash);
               }
            }
         }

         if (sinceDrawn >= 0.0F) {
            halo(poseStack, 0.7125F * shrink, drawn, Mth.clamp(sinceDrawn / 3.0F, 0.0F, 1.0F) * 0.35F);
         }

         poseStack.popPose();
         if (fold > 0.0F) {
            Vec3 middle = frame[0].subtract(at);
            float swell = Mth.sin(fold * (float) Math.PI) * 0.5F + fold * 0.5F;
            poseStack.pushPose();
            poseStack.translate(middle.x, middle.y, middle.z);
            this.orbGlow(poseStack, drawn, 0.25F * swell + 0.05F, fold);
            poseStack.popPose();
         }
      }
   }

   private void orb(OfudaEntity ofuda, float partialTick, PoseStack poseStack, Vec3 at) {
      Kanji kanji = ofuda.drawn();
      float age = ofuda.tickCount + partialTick;
      this.orbGlow(poseStack, kanji, 0.22F + 0.03F * Mth.sin(age * 0.8F), 1.0F);
      poseStack.pushPose();
      poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
      kanjiGlow(poseStack, kanji, 0.16F, 0.0F, 0.0F, 1.0F);
      poseStack.popPose();
      int count = 1;

      while (count <= 6 && ofuda.trail[count - 1] != null) {
         count++;
      }

      if (count > 2) {
         Vector3f[] points = new Vector3f[count];
         points[0] = new Vector3f();

         for (int i = 1; i < count; i++) {
            points[i] = ofuda.trail[i - 1].subtract(at).toVector3f();
         }

         Vector3f eye = this.entityRenderDispatcher.camera.getPosition().subtract(at).toVector3f();
         GlowBatch.add(ModRenderTypes.GLOW, poseStack, (glow, pose, normal) -> {
            GlowDraw.taperedRibbon(glow, pose, points, eye, 0.18F, kanji.r(), kanji.g(), kanji.b(), 0.55F);
            GlowDraw.taperedRibbon(glow, pose, points, eye, 0.06F, 1.0F, 1.0F, 1.0F, 0.6F);
         });
      }
   }

   private void stuck(OfudaEntity ofuda, float partialTick, PoseStack poseStack, MultiBufferSource buffers, Vec3 at, int light) {
      LivingEntity bearer = ofuda.target();
      Player viewer = Minecraft.getInstance().player;
      if (bearer != null && (viewer == null || !bearer.isInvisibleTo(viewer))) {
         Kanji kanji = ofuda.drawn();
         float age = ofuda.tickCount + partialTick;
         float burnt = ofuda.phase() == OfudaEntity.Phase.BURNING ? Mth.clamp(ofuda.phaseAge(partialTick) / 14.0F, 0.0F, 1.0F) : 0.0F;
         float settle = ofuda.phase() == OfudaEntity.Phase.STUCK ? Mth.clamp(ofuda.phaseAge(partialTick) / 4.0F, 0.0F, 1.0F) : 1.0F;
         float height = OfudaEntity.stuckHeight(bearer) * Mth.lerp(Easing.outBack(settle), 1.6F, 1.0F);
         float texel = height / 104.0F;
         poseStack.pushPose();
         place(poseStack, OfudaEntity.stuckFrame(bearer, ofuda.spot(), partialTick), at);
         poseStack.translate(0.0F, height * 0.5F, 0.0F);
         poseStack.mulPose(Axis.XP.rotationDegrees(-4.0F - 4.0F * Mth.sin(age * 0.13F + ofuda.getId())));
         poseStack.translate(0.0F, -height * 0.5F, 0.0F);
         slip(poseStack, buffers, height, burnt, true, light);
         float fade = (1.0F - burnt) * (1.0F - burnt);
         ink(poseStack, buffers, kanji, 16.0F * texel, 8.0F * texel, 0.0F, fade);
         float glow = settle < 1.0F ? 1.0F - settle * 0.6F : 0.35F + 0.15F * Mth.sin(age * 0.15F);
         kanjiGlow(poseStack, kanji, 16.0F * texel * 1.04F, 8.0F * texel, 0.004F, glow * fade);
         if (burnt > 0.0F && burnt < 1.0F) {
            float edge = -height * 0.5F + height * burnt;
            float halfWidth = height * 20.0F / 104.0F;
            GlowBatch.add(ModRenderTypes.GLOW, poseStack, (consumer, pose, normal) -> {
               GlowDraw.vertex(consumer, pose, -halfWidth, edge - 0.03F, 0.006F, 1.0F, 0.45F, 0.1F, 0.0F);
               GlowDraw.vertex(consumer, pose, halfWidth, edge - 0.03F, 0.006F, 1.0F, 0.45F, 0.1F, 0.0F);
               GlowDraw.vertex(consumer, pose, halfWidth, edge, 0.006F, 1.0F, 0.6F, 0.2F, 0.9F);
               GlowDraw.vertex(consumer, pose, -halfWidth, edge, 0.006F, 1.0F, 0.6F, 0.2F, 0.9F);
               GlowDraw.vertex(consumer, pose, -halfWidth, edge, 0.006F, 1.0F, 0.6F, 0.2F, 0.9F);
               GlowDraw.vertex(consumer, pose, halfWidth, edge, 0.006F, 1.0F, 0.6F, 0.2F, 0.9F);
               GlowDraw.vertex(consumer, pose, halfWidth, edge + 0.05F, 0.006F, 1.0F, 0.3F, 0.05F, 0.0F);
               GlowDraw.vertex(consumer, pose, -halfWidth, edge + 0.05F, 0.006F, 1.0F, 0.3F, 0.05F, 0.0F);
            });
         }

         if (settle < 1.0F) {
            halo(poseStack, height * 0.8F, kanji, (1.0F - settle) * 0.8F);
         }

         poseStack.popPose();
      }
   }

   private static void place(PoseStack poseStack, Vec3[] frame, Vec3 at) {
      Vec3 offset = frame[0].subtract(at);
      poseStack.translate(offset.x, offset.y, offset.z);
      Matrix3f basis = new Matrix3f().setColumn(0, frame[1].toVector3f()).setColumn(1, frame[2].toVector3f()).setColumn(2, frame[3].toVector3f());
      poseStack.mulPose(new Quaternionf().setFromNormalized(basis));
   }

   private static void slip(PoseStack poseStack, MultiBufferSource buffers, float height, float burnt, boolean sealed, int light) {
      if (!(height <= 0.001F) && !(burnt >= 1.0F)) {
         float halfWidth = height * 20.0F / 104.0F;
         float top = height * 0.5F;
         float bottom = -height * 0.5F + height * burnt;
         VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(OfudaClient.SLIP));
         Matrix4f pose = poseStack.last().pose();
         Pose normal = poseStack.last();
         float v1 = 0.8125F * (1.0F - burnt);
         quad(consumer, pose, normal, -halfWidth, bottom, halfWidth, top, 0.0F, 0.0F, 0.0F, 0.625F, v1, light, 1.0F, 1.0F, 1.0F, 1.0F);
         float texel = height / 104.0F;
         float sealBottom = -46.0F * texel;
         if (sealed && sealBottom > bottom) {
            quad(
               consumer,
               pose,
               normal,
               -6.0F * texel,
               sealBottom,
               6.0F * texel,
               -34.0F * texel,
               0.002F,
               0.6875F,
               0.0F,
               0.875F,
               0.09375F,
               light,
               1.0F,
               1.0F,
               1.0F,
               1.0F
            );
         }
      }
   }

   private static void ink(PoseStack poseStack, MultiBufferSource buffers, Kanji kanji, float half, float y, float lift, float alpha) {
      if (!(alpha <= 0.01F)) {
         VertexConsumer consumer = buffers.getBuffer(RenderType.entityTranslucent(OfudaClient.KANJI));
         float u0 = kanji.ordinal() / 4.0F;
         float u1 = u0 + 0.25F;
         quad(
            consumer,
            poseStack.last().pose(),
            poseStack.last(),
            -half,
            y - half,
            half,
            y + half,
            0.002F + lift,
            u0,
            0.0F,
            u1,
            1.0F,
            15728880,
            0.1F,
            0.08F,
            0.06F,
            alpha
         );
      }
   }

   private static void kanjiGlow(PoseStack poseStack, Kanji kanji, float half, float y, float lift, float strength) {
      if (!(strength <= 0.01F)) {
         float u0 = kanji.ordinal() / 4.0F;
         float u1 = u0 + 0.25F;
         float r = kanji.r() * strength;
         float g = kanji.g() * strength;
         float b = kanji.b() * strength;
         float z = 0.003F + lift;
         GlowBatch.add(ModRenderTypes.skyGlow(OfudaClient.KANJI), poseStack, (consumer, pose, normal) -> {
            glowVertex(consumer, pose, -half, y - half, z, u0, 1.0F, r, g, b);
            glowVertex(consumer, pose, half, y - half, z, u1, 1.0F, r, g, b);
            glowVertex(consumer, pose, half, y + half, z, u1, 0.0F, r, g, b);
            glowVertex(consumer, pose, -half, y + half, z, u0, 0.0F, r, g, b);
         });
      }
   }

   private static void star(PoseStack poseStack, float x, float y, float z, float size, Kanji kanji, float strength) {
      poseStack.pushPose();
      poseStack.translate(x, y, z);
      GlowBatch.add(ModRenderTypes.GLOW, poseStack, (glow, pose, normal) -> {
         GlowDraw.starburst(glow, pose, size, 0.3F, kanji.r(), kanji.g(), kanji.b(), strength);
         GlowDraw.starburst(glow, pose, size * 0.45F, 0.45F, 1.0F, 1.0F, 1.0F, strength);
      });
      poseStack.popPose();
   }

   private static void halo(PoseStack poseStack, float radius, Kanji kanji, float strength) {
      if (!(strength <= 0.01F)) {
         GlowBatch.add(
            ModRenderTypes.GLOW,
            poseStack,
            (glow, pose, normal) -> GlowDraw.glowSphere(
               glow,
               pose,
               radius,
               (float) (-Math.PI / 2),
               (float) (Math.PI / 2),
               12,
               6,
               kanji.r(),
               kanji.g(),
               kanji.b(),
               (nx, ny, nz) -> strength * Math.abs(nz) * 0.6F
            )
         );
      }
   }

   private void orbGlow(PoseStack poseStack, Kanji kanji, float radius, float strength) {
      GlowBatch.add(
         ModRenderTypes.GLOW,
         poseStack,
         (glow, pose, normal) -> {
            GlowDraw.glowSphere(
               glow,
               pose,
               radius * 1.6F,
               (float) (-Math.PI / 2),
               (float) (Math.PI / 2),
               12,
               6,
               kanji.r(),
               kanji.g(),
               kanji.b(),
               (nx, ny, nz) -> 0.35F * strength
            );
            GlowDraw.glowSphere(
               glow, pose, radius * 0.55F, (float) (-Math.PI / 2), (float) (Math.PI / 2), 10, 5, 1.0F, 1.0F, 1.0F, (nx, ny, nz) -> 0.85F * strength
            );
         }
      );
      poseStack.pushPose();
      poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
      GlowBatch.add(
         ModRenderTypes.GLOW,
         poseStack,
         (glow, pose, normal) -> GlowDraw.starburst(glow, pose, radius * 3.0F, 0.25F, kanji.r(), kanji.g(), kanji.b(), 0.7F * strength)
      );
      poseStack.popPose();
   }

   private static void quad(
      VertexConsumer consumer,
      Matrix4f pose,
      Pose normal,
      float x0,
      float y0,
      float x1,
      float y1,
      float z,
      float u0,
      float v0,
      float u1,
      float v1,
      int light,
      float r,
      float g,
      float b,
      float a
   ) {
      vertex(consumer, pose, normal, x0, y0, z, u0, v1, light, r, g, b, a);
      vertex(consumer, pose, normal, x1, y0, z, u1, v1, light, r, g, b, a);
      vertex(consumer, pose, normal, x1, y1, z, u1, v0, light, r, g, b, a);
      vertex(consumer, pose, normal, x0, y1, z, u0, v0, light, r, g, b, a);
   }

   private static void vertex(
      VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float y, float z, float u, float v, int light, float r, float g, float b, float a
   ) {
      consumer.addVertex(pose, x, y, z)
         .setColor(r, g, b, a)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(light)
         .setNormal(normal, 0.0F, 0.0F, 1.0F);
   }

   private static void glowVertex(VertexConsumer consumer, Matrix4f pose, float x, float y, float z, float u, float v, float r, float g, float b) {
      consumer.addVertex(pose, x, y, z).setUv(u, v).setColor(Mth.clamp(r, 0.0F, 1.0F), Mth.clamp(g, 0.0F, 1.0F), Mth.clamp(b, 0.0F, 1.0F), 1.0F);
   }

   public ResourceLocation getTextureLocation(OfudaEntity ofuda) {
      return OfudaClient.SLIP;
   }
}
