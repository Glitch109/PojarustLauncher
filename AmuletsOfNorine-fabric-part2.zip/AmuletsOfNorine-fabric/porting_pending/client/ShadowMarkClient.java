package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.client.renderer.LateBuffers;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import org.joml.Matrix4f;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class ShadowMarkClient {
   private static final ResourceLocation SIGIL = AmuletMod.id("textures/misc/shadow_sigil.png");
   private static final float SIZE = 0.35F;
   private static int markId = -1;

   private ShadowMarkClient() {
   }

   public static void update(int entityId) {
      markId = entityId;
   }

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      ClientLevel level = Minecraft.getInstance().level;
      if (event.getStage() == Stage.AFTER_PARTICLES && level != null && markId >= 0) {
         Entity marked = level.getEntity(markId);
         if (marked != null && marked.isAlive()) {
            float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
            float time = ClientClock.time(partialTick);
            Vec3 view = event.getCamera().getPosition();
            Vec3 at = marked.getPosition(partialTick).add(0.0, marked.getBbHeight() + 0.45 + Mth.sin(time * 0.1F) * 0.06, 0.0);
            float pulse = 0.7F + 0.3F * Mth.sin(time * 0.15F);
            PoseStack poseStack = event.getPoseStack();
            poseStack.pushPose();
            poseStack.translate(at.x - view.x, at.y - view.y, at.z - view.z);
            poseStack.mulPose(event.getCamera().rotation());
            poseStack.mulPose(Axis.ZP.rotationDegrees(180.0F));
            BufferSource buffers = LateBuffers.get();
            RenderType type = ModRenderTypes.skyGlowXray(SIGIL);
            VertexConsumer consumer = buffers.getBuffer(type);
            Matrix4f pose = poseStack.last().pose();
            float r = 0.65F * pulse;
            float g = 0.25F * pulse;
            float b = 1.0F * pulse;
            corner(consumer, pose, -0.35F, -0.35F, 0.0F, 0.0F, r, g, b);
            corner(consumer, pose, -0.35F, 0.35F, 0.0F, 1.0F, r, g, b);
            corner(consumer, pose, 0.35F, 0.35F, 1.0F, 1.0F, r, g, b);
            corner(consumer, pose, 0.35F, -0.35F, 1.0F, 0.0F, r, g, b);
            buffers.endBatch(type);
            poseStack.popPose();
         }
      }
   }

   private static void corner(VertexConsumer consumer, Matrix4f pose, float x, float y, float u, float v, float r, float g, float b) {
      consumer.addVertex(pose, x, y, 0.0F).setUv(u, v).setColor(r, g, b, 1.0F);
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      markId = -1;
   }
}
