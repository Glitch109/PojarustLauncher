package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import org.jetbrains.annotations.Nullable;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class ScreenEffects {
   private static final ResourceLocation TIME_STOP = AmuletMod.id("shaders/post/time_stop.json");
   private static final ResourceLocation REWIND = AmuletMod.id("shaders/post/rewind.json");
   @Nullable
   private static ResourceLocation loaded;
   private static final Set<ResourceLocation> BROKEN = new HashSet<>();
   private static int rewindTicks;

   private ScreenEffects() {
   }

   public static void startRewind(int durationTicks) {
      rewindTicks = Math.max(rewindTicks, durationTicks);
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      Minecraft minecraft = Minecraft.getInstance();
      if (rewindTicks > 0 && !minecraft.isPaused()) {
         rewindTicks--;
      }

      ResourceLocation wanted = null;
      if (minecraft.level != null) {
         if (rewindTicks > 0) {
            wanted = REWIND;
         } else if (ChronoClient.isCameraInStoppedTime()) {
            wanted = TIME_STOP;
         }
      }

      apply(minecraft.gameRenderer, wanted);
   }

   private static void apply(GameRenderer renderer, @Nullable ResourceLocation wanted) {
      PostChain current = renderer.currentEffect();
      if (loaded != null && (current == null || !current.getName().equals(loaded.toString()))) {
         loaded = null;
      }

      if (!Objects.equals(loaded, wanted)) {
         if (loaded != null) {
            renderer.shutdownEffect();
            loaded = null;
         }

         if (wanted != null && renderer.currentEffect() == null && !BROKEN.contains(wanted)) {
            renderer.loadEffect(wanted);
            PostChain now = renderer.currentEffect();
            if (now != null && now.getName().equals(wanted.toString())) {
               loaded = wanted;
            } else {
               BROKEN.add(wanted);
            }
         }
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      rewindTicks = 0;
      apply(Minecraft.getInstance().gameRenderer, null);
   }
}
