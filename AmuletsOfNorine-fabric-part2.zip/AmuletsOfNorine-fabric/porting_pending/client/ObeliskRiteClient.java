package com.amuletmod.client;

import com.amuletmod.client.renderer.RunicObeliskRenderer;
import com.amuletmod.obelisk.ObeliskRite;
import com.amuletmod.obelisk.RunicObeliskBlock;
import com.amuletmod.obelisk.RunicObeliskBlockEntity;
import com.amuletmod.util.Easing;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance.Attenuation;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

public final class ObeliskRiteClient {
   private static final Map<RunicObeliskBlockEntity, Integer> PLAYED = new WeakHashMap<>();
   private static final Set<RunicObeliskBlockEntity> UNDERWAY = Collections.newSetFromMap(new WeakHashMap<>());
   private static final double FAR = 256.0;
   private static final Vector3f[] DUST = new Vector3f[]{dust(0), dust(1), dust(2)};

   private ObeliskRiteClient() {
   }

   public static Iterable<RunicObeliskBlockEntity> underway() {
      return UNDERWAY;
   }

   public static void tick(RunicObeliskBlockEntity obelisk) {
      float age = obelisk.riteAge(0.0F);
      if (age < 0.0F) {
         PLAYED.remove(obelisk);
         UNDERWAY.remove(obelisk);
      } else {
         UNDERWAY.add(obelisk);
         int now = (int)age;
         Integer last = PLAYED.put(obelisk, now);
         int from = last != null && now - last <= 40 ? last + 1 : now;

         for (int t = from; t <= now; t++) {
            moment(obelisk, t);
         }

         ongoing(obelisk, now);
      }
   }

   private static void moment(RunicObeliskBlockEntity obelisk, int t) {
      Level level = obelisk.getLevel();
      BlockPos base = obelisk.getBlockPos();
      Direction facing = (Direction)obelisk.getBlockState().getValue(RunicObeliskBlock.FACING);
      Vec3 tip = RunicObeliskRenderer.toWorld(base, facing, new Vector3f(0.5F, 3.5625F, 0.5F));
      Vec3 core = RunicObeliskRenderer.toWorld(base, facing, RunicObeliskRenderer.core());
      Vec3 middle = RunicObeliskRenderer.toWorld(base, facing, new Vector3f(0.5F, 1.5F, 0.5F));
      Vec3 eye = RunicObeliskRenderer.toWorld(base, facing, new Vector3f(0.5F, 16.5625F, 0.5F));
      RandomSource random = level.random;
      float near = nearness(core, 40.0, 140.0);
      if (t == 0) {
         sound(level, middle, SoundEvents.BEACON_ACTIVATE, 1.2F, 0.5F);
         sound(level, middle, SoundEvents.RESPAWN_ANCHOR_CHARGE, 1.0F, 0.6F);
         CameraShake.from(middle, 0.4F, 32.0, 20);
      }

      for (int k = 0; k < 6; k++) {
         if (t == ObeliskRite.circleOpens(k)) {
            Vec3 at = RunicObeliskRenderer.toWorld(base, facing, RunicObeliskRenderer.circleCenter(k, t));
            sound(level, at, SoundEvents.ILLUSIONER_CAST_SPELL, 1.0F, 0.8F + 0.08F * k);
            sound(level, at, SoundEvents.AMETHYST_BLOCK_RESONATE, 0.8F, 0.6F + 0.1F * k);
            burst(level, ParticleTypes.ENCHANT, at, 16, 0.6, random);
            ImpactFrames.punch(-0.012F * (k + 1) * near);
         }
      }

      if (t == 112) {
         sound(level, tip, SoundEvents.EVOKER_PREPARE_SUMMON, 1.2F, 0.6F);
         sound(level, tip, SoundEvents.BELL_RESONATE, 1.0F, 0.7F);
      }

      if (t == 120) {
         sound(level, middle, SoundEvents.CONDUIT_ACTIVATE, 1.5F, 0.5F);
         sound(level, middle, SoundEvents.BELL_RESONATE, 1.2F, 0.5F);
      }

      if (t == 140) {
         sound(level, eye, SoundEvents.END_PORTAL_SPAWN, 1.2F, 0.6F);
         sound(level, eye, SoundEvents.LIGHTNING_BOLT_THUNDER, 0.8F, 0.5F);
         CameraShake.from(middle, 1.4F, 48.0, 30);
         ImpactFrames.punch(0.06F * near);
      }

      for (int h = 0; h < 3; h++) {
         if (t == ObeliskRite.haloOpens(h)) {
            sound(level, eye, SoundEvents.AMETHYST_BLOCK_RESONATE, 1.2F, 0.5F + 0.15F * h);
            sound(level, eye, SoundEvents.BEACON_POWER_SELECT, 0.8F, 0.7F + 0.2F * h);
         }
      }

      if (t == 190) {
         sound(level, eye, SoundEvents.BEACON_POWER_SELECT, 1.5F, 0.5F);
         sound(level, eye, SoundEvents.WARDEN_SONIC_CHARGE, 1.0F, 1.4F);
      }

      if (t == ObeliskRite.strikes()) {
         strike(obelisk, level, tip, random, near);
      }

      if (t == ObeliskRite.strikes() + 3) {
         ObeliskRiteView.whiteout(obelisk, 0.4F);
      }

      for (int row = 0; row < 6; row++) {
         if (t == ObeliskRite.strikes() + row * 3) {
            sound(level, middle, SoundEvents.AMETHYST_BLOCK_CHIME, 0.8F, 0.8F + 0.1F * row);
         }
      }

      for (int kx = 0; kx < 6; kx++) {
         if (t == ObeliskRite.pillarRises(kx)) {
            Vec3 at = RunicObeliskRenderer.toWorld(base, facing, RunicObeliskRenderer.circleCenter(kx, t));
            sound(level, at, SoundEvents.RESPAWN_ANCHOR_SET_SPAWN, 0.7F, 0.7F + 0.1F * kx);
            burst(level, ParticleTypes.END_ROD, at, 10, 0.3, random);
         }
      }

      if (t == 262) {
         sound(level, middle, SoundEvents.ENCHANTMENT_TABLE_USE, 1.0F, 0.7F);
         sound(level, middle, (SoundEvent)SoundEvents.SOUL_ESCAPE.value(), 1.0F, 0.6F);
      }

      if (t == 396) {
         sound(level, core, SoundEvents.WARDEN_SONIC_CHARGE, 1.2F, 0.8F);
      }

      if (t == 410) {
         sound(level, core, SoundEvents.BEACON_ACTIVATE, 1.0F, 1.8F);
      }

      if (t == 420) {
         sound(level, core, SoundEvents.AMETHYST_CLUSTER_BREAK, 1.5F, 0.6F);
         sound(level, core, SoundEvents.AMETHYST_CLUSTER_BREAK, 1.5F, 0.9F);
         sound(level, core, SoundEvents.GLASS_BREAK, 1.2F, 0.5F);

         for (int niche = 0; niche < 3; niche++) {
            ItemStack stack = obelisk.displayed(niche);
            if (!stack.isEmpty()) {
               burst(level, new ItemParticleOption(ParticleTypes.ITEM, stack), core, 24, 0.25, random);
            }

            burst(level, new DustParticleOptions(DUST[niche], 1.4F), core, 20, 0.6, random);
         }

         burst(level, ParticleTypes.END_ROD, core, 24, 0.25, random);
         CameraShake.from(core, 2.0F, 40.0, 14);
         ImpactFrames.punch(0.1F * near);
      }

      if (t == 423) {
         ObeliskRiteView.whiteout(obelisk, 0.3F);
         sound(level, core, SoundEvents.PORTAL_TRIGGER, 1.0F, 1.6F);
         sound(level, core, SoundEvents.BEACON_DEACTIVATE, 1.2F, 0.5F);
      }

      if (t == 430 || t == 440 || t == 446) {
         sound(level, core, SoundEvents.WARDEN_HEARTBEAT, 1.5F, t == 446 ? 0.9F : 0.6F);
      }

      if (t == 450) {
         birth(obelisk, level, core, random, near);
      }

      if (t == 455) {
         ObeliskRiteView.whiteout(obelisk, 1.0F);
      }

      if (t == 458) {
         sound(level, tip, SoundEvents.END_PORTAL_FRAME_FILL, 1.2F, 0.5F);
      }

      if (t == 464) {
         sound(level, eye, SoundEvents.FIREWORK_ROCKET_TWINKLE_FAR, 1.2F, 0.8F);
         sound(level, eye, SoundEvents.AMETHYST_BLOCK_CHIME, 1.2F, 0.5F);
      }

      if (t == 490) {
         sound(level, middle, SoundEvents.BELL_RESONATE, 1.0F, 1.2F);
      }

      if (t == 516) {
         sound(level, middle, SoundEvents.CHAIN_PLACE, 1.0F, 1.2F);
      }

      if (t == 540) {
         sound(level, middle, SoundEvents.BEACON_DEACTIVATE, 1.0F, 0.8F);
      }
   }

   private static void strike(RunicObeliskBlockEntity obelisk, Level level, Vec3 tip, RandomSource random, float near) {
      far(tip, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.5F, 0.6F, false);
      far(tip, SoundEvents.WARDEN_SONIC_BOOM, 1.0F, 1.3F, false);
      far(tip, (SoundEvent)SoundEvents.TRIDENT_THUNDER.value(), 1.0F, 0.6F, true);
      far(tip, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 0.6F, 0.5F, true);
      CameraShake.from(tip, 3.5F, 64.0, 20);
      ImpactFrames.punch(0.12F * near);
      level.addParticle(ParticleTypes.FLASH, tip.x, tip.y, tip.z, 0.0, 0.0, 0.0);
      burst(level, ParticleTypes.ELECTRIC_SPARK, tip, 40, 0.8, random);
      burst(level, ParticleTypes.END_ROD, tip, 30, 0.4, random);
      Vec3 foot = Vec3.atBottomCenterOf(obelisk.getBlockPos());

      for (int i = 0; i < 60; i++) {
         double angle = random.nextDouble() * (float) (Math.PI * 2);
         level.addParticle(
            ParticleTypes.CLOUD,
            foot.x + Math.cos(angle) * 1.5,
            foot.y + 0.1,
            foot.z + Math.sin(angle) * 1.5,
            Math.cos(angle) * 0.5,
            0.02,
            Math.sin(angle) * 0.5
         );
      }
   }

   private static void birth(RunicObeliskBlockEntity obelisk, Level level, Vec3 core, RandomSource random, float near) {
      far(core, SoundEvents.TOTEM_USE, 1.5F, 0.8F, false);
      far(core, SoundEvents.BEACON_ACTIVATE, 2.0F, 1.4F, false);
      far(core, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.0F, 0.5F, false);
      far(core, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 1.0F, 0.6F, true);
      far(core, SoundEvents.LIGHTNING_BOLT_THUNDER, 1.0F, 0.6F, true);
      far(core, SoundEvents.WARDEN_SONIC_BOOM, 1.0F, 0.7F, true);
      far(core, SoundEvents.FIREWORK_ROCKET_LARGE_BLAST_FAR, 1.0F, 0.6F, true);
      if (distance(core) < 16.0) {
         sound(level, core, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 0.8F, 1.0F);
      }

      CameraShake.from(core, 5.0F, 64.0, 36);
      float felt = nearness(core, 64.0, 200.0);
      if (felt > 0.0F) {
         CameraShake.quake(1.5F * felt, 30, (int)(distance(core) / 34.0));
      }

      ImpactFrames.punch(-0.22F * near);
      level.addParticle(ParticleTypes.FLASH, core.x, core.y, core.z, 0.0, 0.0, 0.0);
      burst(level, ParticleTypes.END_ROD, core, 80, 0.6, random);
      burst(level, ParticleTypes.FIREWORK, core, 60, 0.5, random);

      for (int i = 0; i < 120; i++) {
         double angle = random.nextDouble() * (float) (Math.PI * 2);
         double speed = 0.6 + random.nextDouble() * 0.6;
         level.addParticle(
            new DustParticleOptions(DUST[i % 3], 1.6F),
            core.x,
            core.y,
            core.z,
            Math.cos(angle) * speed,
            (random.nextDouble() - 0.5) * 0.1,
            Math.sin(angle) * speed
         );
      }

      Vec3 foot = Vec3.atBottomCenterOf(obelisk.getBlockPos());

      for (int i = 0; i < 90; i++) {
         double angle = random.nextDouble() * (float) (Math.PI * 2);
         level.addParticle(
            ParticleTypes.CLOUD,
            foot.x + Math.cos(angle) * 2.0,
            foot.y + 0.1,
            foot.z + Math.sin(angle) * 2.0,
            Math.cos(angle) * 0.9,
            0.03,
            Math.sin(angle) * 0.9
         );
      }
   }

   private static void ongoing(RunicObeliskBlockEntity obelisk, int t) {
      Level level = obelisk.getLevel();
      BlockPos base = obelisk.getBlockPos();
      Direction facing = (Direction)obelisk.getBlockState().getValue(RunicObeliskBlock.FACING);
      RandomSource random = level.random;
      Vec3 middle = RunicObeliskRenderer.toWorld(base, facing, new Vector3f(0.5F, 1.5F, 0.5F));
      Vec3 core = RunicObeliskRenderer.toWorld(base, facing, RunicObeliskRenderer.core());
      if (t < 450 && random.nextInt(2) == 0) {
         level.addParticle(
            ParticleTypes.REVERSE_PORTAL,
            middle.x + (random.nextDouble() - 0.5) * 2.0,
            base.getY() + 0.2,
            middle.z + (random.nextDouble() - 0.5) * 2.0,
            0.0,
            0.05,
            0.0
         );
      }

      if (t >= ObeliskRite.strikes() && t < 420) {
         float charge = ObeliskRite.charge(t);
         Vec3 circle = RunicObeliskRenderer.toWorld(base, facing, RunicObeliskRenderer.circleCenter(random.nextInt(6), t));
         Vec3 into = middle.add(0.0, 0.4, 0.0);
         level.addParticle(ParticleTypes.ENCHANT, into.x, into.y, into.z, circle.x - into.x, circle.y - into.y, circle.z - into.z);
         if (t >= 262) {
            for (int i = 0; i < 1 + (int)(charge * 2.0F); i++) {
               double angle = random.nextDouble() * (float) (Math.PI * 2);
               double radius = 1.2 + random.nextDouble() * 1.8;
               level.addParticle(
                  new DustParticleOptions(DUST[random.nextInt(3)], 1.0F),
                  middle.x + Math.cos(angle) * radius,
                  base.getY() + 0.3 + random.nextDouble() * 4.0,
                  middle.z + Math.sin(angle) * radius,
                  -Math.sin(angle) * 0.2,
                  0.15,
                  Math.cos(angle) * 0.2
               );
            }
         }

         if (t % 10 == 0) {
            CameraShake.from(middle, 0.35F + 0.8F * charge, 32.0, 14);
         }

         if (t % 40 == 0) {
            sound(level, middle, SoundEvents.BEACON_AMBIENT, 1.0F, 0.6F + 0.8F * charge);
         }
      }

      if (t >= 380 && t < 450) {
         float closing = 0.05F * Easing.smoothstep(380.0F, 420.0F, t) + 0.08F * ObeliskRite.implode(t);
         ImpactFrames.focus(closing * nearness(core, 40.0, 140.0));
      }

      if (t > 420 && t < 450) {
         for (int i = 0; i < 3; i++) {
            Vec3 from = core.add(
               new Vec3(random.nextGaussian(), random.nextGaussian() * 0.6, random.nextGaussian()).normalize().scale(5.0 + random.nextDouble() * 5.0)
            );
            Vec3 pull = core.subtract(from).scale(0.09);
            level.addParticle(ParticleTypes.END_ROD, from.x, from.y, from.z, pull.x, pull.y, pull.z);
         }

         if (t % 5 == 0) {
            CameraShake.from(core, 0.6F, 32.0, 8);
         }
      }

      if (t > 450 && t < 530) {
         float fade = 1.0F - (t - 450) / 80.0F;

         for (int i = 0; i < (int)(4.0F * fade) + 1; i++) {
            double angle = random.nextDouble() * (float) (Math.PI * 2);
            double radius = random.nextDouble() * 10.0;
            double x = middle.x + Math.cos(angle) * radius;
            double y = base.getY() + 6.0 + random.nextDouble() * 8.0;
            double z = middle.z + Math.sin(angle) * radius;
            if (random.nextInt(3) == 0) {
               level.addParticle(new DustParticleOptions(DUST[random.nextInt(3)], 1.2F), x, y, z, 0.0, -0.05, 0.0);
            } else {
               level.addParticle(ParticleTypes.END_ROD, x, y, z, 0.0, -0.04, 0.0);
            }
         }
      }
   }

   private static Vector3f dust(int gem) {
      float[] colour = RunicObeliskRenderer.GEMS[gem];
      return new Vector3f(colour[0], colour[1], colour[2]);
   }

   private static double distance(Vec3 at) {
      Minecraft minecraft = Minecraft.getInstance();
      return minecraft.player == null ? Double.MAX_VALUE : minecraft.player.position().distanceTo(at);
   }

   private static float nearness(Vec3 at, double near, double far) {
      double distance = distance(at);
      return (float)Mth.clamp(1.0 - (distance - near) / (far - near), 0.0, 1.0);
   }

   private static void sound(Level level, Vec3 at, SoundEvent sound, float volume, float pitch) {
      level.playLocalSound(at.x, at.y, at.z, sound, SoundSource.BLOCKS, volume, pitch, false);
   }

   private static void far(Vec3 at, SoundEvent sound, float volume, float pitch, boolean boom) {
      Minecraft minecraft = Minecraft.getInstance();
      double distance = distance(at);
      if (!(distance > 256.0)) {
         float scaled = volume * (float)Mth.clamp(1.0 - (distance - 32.0) / 224.0, 0.15, 1.0);
         SimpleSoundInstance instance = new SimpleSoundInstance(
            sound.getLocation(), SoundSource.BLOCKS, scaled, pitch, RandomSource.create(), false, 0, Attenuation.NONE, at.x, at.y, at.z, false
         );
         int delay = boom ? (int)(distance / 34.0) : 0;
         if (delay > 0) {
            minecraft.getSoundManager().playDelayed(instance, delay);
         } else {
            minecraft.getSoundManager().play(instance);
         }
      }
   }

   private static void burst(Level level, ParticleOptions particle, Vec3 at, int count, double speed, RandomSource random) {
      for (int i = 0; i < count; i++) {
         level.addParticle(
            particle, at.x, at.y, at.z, (random.nextDouble() - 0.5) * speed, (random.nextDouble() - 0.5) * speed, (random.nextDouble() - 0.5) * speed
         );
      }
   }
}
