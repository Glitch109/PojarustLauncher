package com.amuletmod.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.ClientTickEvent.Pre;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class RootedClient {
   private static int ticks;
   private static int heldUntil;

   private RootedClient() {
   }

   public static void hold(int victimId) {
      LocalPlayer player = Minecraft.getInstance().player;
      if (player != null && player.getId() == victimId) {
         heldUntil = ticks + 2;
      }
   }

   private static boolean isHeld() {
      return ticks < heldUntil;
   }

   @SubscribeEvent
   public static void onClientTickEnd(Post event) {
      if (!Minecraft.getInstance().isPaused()) {
         ticks++;
      }
   }

   @SubscribeEvent
   public static void onClientTick(Pre event) {
      Minecraft minecraft = Minecraft.getInstance();
      if (!minecraft.isPaused()) {
         LocalPlayer player = minecraft.player;
         if (player != null && isHeld()) {
            Vec3 motion = player.getDeltaMovement();
            player.setDeltaMovement(0.0, Math.min(0.0, motion.y), 0.0);
            player.setSprinting(false);
         }
      }
   }

   @SubscribeEvent
   public static void onMovementInput(MovementInputUpdateEvent event) {
      if (isHeld()) {
         Input input = event.getInput();
         input.forwardImpulse = 0.0F;
         input.leftImpulse = 0.0F;
         input.up = false;
         input.down = false;
         input.left = false;
         input.right = false;
         input.jumping = false;
      }
   }
}
