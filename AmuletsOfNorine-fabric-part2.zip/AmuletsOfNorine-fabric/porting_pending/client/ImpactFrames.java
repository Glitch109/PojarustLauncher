package com.amuletmod.client;

import com.amuletmod.util.Easing;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.RenderGuiEvent.Pre;
import net.neoforged.neoforge.client.event.ViewportEvent.ComputeFov;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class ImpactFrames {
   private static final int PUNCH_IN = 2;
   private static final int PUNCH_OUT = 16;
   private static final int FLASH_TICKS = 5;
   private static final int FLASH_RGB = 16773336;
   private static float punch;
   private static int punchAge = -1;
   private static float focusWanted;
   private static float focusBefore;
   private static float focus;
   private static float flash;
   private static int flashAge = -1;

   private ImpactFrames() {
   }

   public static void punch(float strength) {
      if (Math.abs(strength) >= Math.abs(punchNow(0.0F))) {
         punch = strength;
         punchAge = 0;
      }
   }

   public static void flash(float strength) {
      if (strength >= flashNow(0.0F)) {
         flash = strength;
         flashAge = 0;
      }
   }

   public static void focus(float amount) {
      focusWanted = Math.max(focusWanted, amount);
   }

   private static float punchNow(float partialTick) {
      if (punchAge < 0) {
         return 0.0F;
      } else {
         float age = punchAge + partialTick;
         if (age < 2.0F) {
            return punch * Easing.outCubic(age / 2.0F);
         } else {
            float out = Mth.clamp((age - 2.0F) / 16.0F, 0.0F, 1.0F);
            return punch * (1.0F - out) * (1.0F - out);
         }
      }
   }

   private static float flashNow(float partialTick) {
      if (flashAge < 0) {
         return 0.0F;
      } else {
         float fade = 1.0F - Mth.clamp((flashAge + partialTick) / 5.0F, 0.0F, 1.0F);
         return flash * fade * fade;
      }
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      if (!Minecraft.getInstance().isPaused()) {
         if (punchAge >= 0 && ++punchAge > 18) {
            punchAge = -1;
         }

         if (flashAge >= 0 && ++flashAge > 5) {
            flashAge = -1;
         }

         focusBefore = focus;
         focus = focus + (focusWanted - focus) * 0.25F;
         focusWanted = 0.0F;
      }
   }

   @SubscribeEvent
   public static void onComputeFov(ComputeFov event) {
      if (event.usedConfiguredFov()) {
         float partialTick = (float)event.getPartialTick();
         float zoom = punchNow(partialTick) + Mth.lerp(partialTick, focusBefore, focus);
         if (!(Math.abs(zoom) < 1.0E-4F)) {
            double scale = (Double)Minecraft.getInstance().options.fovEffectScale().get();
            event.setFOV(event.getFOV() * (1.0 - zoom * scale));
         }
      }
   }

   @SubscribeEvent
   public static void onRenderGui(Pre event) {
      float strength = flashNow(event.getPartialTick().getGameTimeDeltaPartialTick(false));
      if (!(strength <= 0.0F) && !(Boolean)Minecraft.getInstance().options.hideLightningFlash().get()) {
         GuiGraphics graphics = event.getGuiGraphics();
         int alpha = (int)(Mth.clamp(strength, 0.0F, 1.0F) * 0.55F * 255.0F);
         graphics.fill(0, 0, graphics.guiWidth(), graphics.guiHeight(), alpha << 24 | 16773336);
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      punchAge = -1;
      flashAge = -1;
      focus = 0.0F;
      focusBefore = 0.0F;
      focusWanted = 0.0F;
   }
}
