package com.amuletmod.client;

import com.amuletmod.entity.PageStormEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public final class TempestClient {
   private TempestClient() {
   }

   private static boolean isLocalPlayer(int entityId) {
      LocalPlayer player = Minecraft.getInstance().player;
      return player != null && player.getId() == entityId;
   }

   public static void started(PageStormEntity storm) {
      Minecraft.getInstance().getSoundManager().play(new TempestClient.Wind(storm));
   }

   public static void building(int casterId, float build) {
      if (isLocalPlayer(casterId)) {
         ImpactFrames.focus(0.07F * build);
      }
   }

   public static void broke(int casterId) {
      if (isLocalPlayer(casterId)) {
         ImpactFrames.punch(0.12F);
         ImpactFrames.flash(0.45F);
         CameraShake.quake(2.2F, 16, 0);
      }
   }

   private static final class Wind extends AbstractTickableSoundInstance {
      private final PageStormEntity storm;

      private Wind(PageStormEntity storm) {
         super(SoundEvents.ELYTRA_FLYING, SoundSource.PLAYERS, SoundInstance.createUnseededRandom());
         this.storm = storm;
         this.looping = true;
         this.delay = 0;
         this.volume = 0.05F;
         this.pitch = 0.5F;
         Vec3 at = storm.center(1.0F);
         this.x = at.x;
         this.y = at.y + 1.5;
         this.z = at.z;
      }

      public void tick() {
         float age = this.storm.tickCount;
         float fade = this.storm.collapsedAt() >= 0 ? 1.0F - (age - this.storm.collapsedAt()) / 15.0F : 1.0F - (age - 240.0F) / 25.0F;
         if (!this.storm.isRemoved() && !(fade <= 0.0F)) {
            Vec3 at = this.storm.center(1.0F);
            this.x = at.x;
            this.y = at.y + 1.5;
            this.z = at.z;
            float charge = PageStormEntity.charge(age);
            this.volume = (0.08F + 0.9F * charge * charge) * Mth.clamp(fade, 0.0F, 1.0F);
            this.pitch = 0.5F + 1.0F * charge;
         } else {
            this.stop();
         }
      }
   }
}
