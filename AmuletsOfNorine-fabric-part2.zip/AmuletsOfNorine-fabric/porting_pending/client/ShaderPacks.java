package com.amuletmod.client;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;

public final class ShaderPacks {
   private static final MethodHandle IN_USE = find("isShaderPackInUse");
   private static final MethodHandle SHADOWS = find("isRenderingShadowPass");

   private ShaderPacks() {
   }

   public static boolean inUse() {
      return ask(IN_USE);
   }

   public static boolean renderingShadows() {
      return ask(SHADOWS);
   }

   private static boolean ask(MethodHandle question) {
      if (question == null) {
         return false;
      } else {
         try {
            return (boolean)question.invokeExact();
         } catch (Throwable var2) {
            return false;
         }
      }
   }

   private static MethodHandle find(String name) {
      try {
         Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
         Object instance = api.getMethod("getInstance").invoke(null);
         return MethodHandles.publicLookup().findVirtual(api, name, MethodType.methodType(boolean.class)).bindTo(instance);
      } catch (LinkageError | ReflectiveOperationException var3) {
         return null;
      }
   }
}
