package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.slf4j.Logger;

public final class ObeliskRitePost {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static final ResourceLocation WORLD = AmuletMod.id("obelisk_rite_world");
   private static final ResourceLocation LENS = AmuletMod.id("obelisk_rite_lens");
   @Nullable
   private static ShaderInstance world;
   @Nullable
   private static ShaderInstance lens;
   @Nullable
   private static TextureTarget scratch;
   @Nullable
   private static TextureTarget held;

   private ObeliskRitePost() {
   }

   public static void onRegisterShaders(RegisterShadersEvent event) {
      world = null;
      lens = null;

      try {
         event.registerShader(new ShaderInstance(event.getResourceProvider(), WORLD, DefaultVertexFormat.POSITION_TEX), shader -> world = shader);
         event.registerShader(new ShaderInstance(event.getResourceProvider(), LENS, DefaultVertexFormat.POSITION_TEX), shader -> lens = shader);
      } catch (IOException var2) {
         LOGGER.warn("The Runic Obelisk's screen effects are off: {}", var2.getMessage());
         world = null;
         lens = null;
      }
   }

   public static boolean available() {
      return world != null && lens != null && !ShaderPacks.inUse();
   }

   public static void world(Matrix4f view, Matrix4f projection, ObeliskRitePost.Look look) {
      ShaderInstance world = ObeliskRitePost.world;
      if (world != null && look.worldVisible()) {
         Minecraft minecraft = Minecraft.getInstance();
         RenderTarget main = minecraft.getMainRenderTarget();
         TextureTarget scratch = ObeliskRitePost.scratch = sized(ObeliskRitePost.scratch, main);
         Matrix4f viewProjection = new Matrix4f(projection).mul(view);
         world.safeGetUniform("ViewProj").set(viewProjection);
         world.safeGetUniform("InvViewProj").set(new Matrix4f(viewProjection).invert());
         world.safeGetUniform("Obelisk").set(look.obelisk);
         world.safeGetUniform("Pole").set(look.pole);
         world.safeGetUniform("BeamTop").set(look.beamTop);
         world.safeGetUniform("BeamBottom").set(look.beamBottom);
         world.safeGetUniform("Heavens").set(look.night, look.wheel, look.trails, look.aurora);
         world.safeGetUniform("Eye").set(look.eye, look.swirl, look.front, look.white);
         world.safeGetUniform("Ground").set(look.sigil, look.merge, look.light, look.gloom);
         world.safeGetUniform("Pulse").set(look.shockRadius, look.shock, look.heat, look.time);
         world.safeGetUniform("Extra").set(look.auroraEdge, look.implode, look.charge, look.sigilBright);
         world.safeGetUniform("OutSize").set(main.width, main.height);
         world.setSampler("DiffuseSampler", main.getColorTextureId());
         world.setSampler("DepthSampler", main.getDepthTextureId());
         begin();
         scratch.bindWrite(true);
         fullScreen(world);
         copy(scratch, main);
         RenderTarget particles = minecraft.levelRenderer.getParticlesTarget();
         if (Minecraft.useShaderTransparency() && particles != null) {
            particles.bindWrite(false);
         } else {
            main.bindWrite(false);
         }

         end();
      }
   }

   public static void hold() {
      if (world != null && lens != null) {
         RenderTarget main = Minecraft.getInstance().getMainRenderTarget();
         held = sized(held, main);
         copy(main, held);
         main.bindWrite(false);
      }
   }

   public static void lens(ObeliskRitePost.Look look) {
      ShaderInstance lens = ObeliskRitePost.lens;
      if (lens != null && look.lensVisible()) {
         RenderTarget main = Minecraft.getInstance().getMainRenderTarget();
         TextureTarget scratch = ObeliskRitePost.scratch = sized(ObeliskRitePost.scratch, main);
         if (ObeliskRitePost.held == null || ObeliskRitePost.held.width != main.width || ObeliskRitePost.held.height != main.height) {
            hold();
         }

         TextureTarget held = ObeliskRitePost.held;
         if (held != null) {
            copy(main, scratch);
            lens.safeGetUniform("Focus").set(look.focusX, look.focusY, look.focusAhead ? 1.0F : 0.0F);
            lens.safeGetUniform("Lens").set(look.aberration, look.zoomBlur, look.shafts, look.time);
            lens.safeGetUniform("Impact").set(look.impact, look.impactStyle, look.impact > 0.001F ? 1.0F : 0.0F, look.focusLines);
            lens.safeGetUniform("Grade").set(look.afterimage, look.vignette, look.grain, 0.0F);
            lens.safeGetUniform("OutSize").set(main.width, main.height);
            lens.setSampler("DiffuseSampler", scratch.getColorTextureId());
            lens.setSampler("HeldSampler", held.getColorTextureId());
            begin();
            main.bindWrite(true);
            RenderSystem.colorMask(true, true, true, false);
            fullScreen(lens);
            RenderSystem.colorMask(true, true, true, true);
            main.bindWrite(false);
            end();
         }
      }
   }

   private static TextureTarget sized(@Nullable TextureTarget target, RenderTarget main) {
      if (target == null) {
         target = new TextureTarget(main.width, main.height, false, Minecraft.ON_OSX);
         target.setFilterMode(9729);
      } else if (target.width != main.width || target.height != main.height) {
         target.resize(main.width, main.height, Minecraft.ON_OSX);
      }

      return target;
   }

   private static void copy(RenderTarget from, RenderTarget to) {
      GlStateManager._glBindFramebuffer(36008, from.frameBufferId);
      GlStateManager._glBindFramebuffer(36009, to.frameBufferId);
      GlStateManager._glBlitFrameBuffer(0, 0, from.width, from.height, 0, 0, to.width, to.height, 16384, 9728);
   }

   private static void begin() {
      RenderSystem.disableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.disableBlend();
      RenderSystem.disableCull();
      RenderSystem.colorMask(true, true, true, true);
   }

   private static void end() {
      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
      RenderSystem.enableDepthTest();
   }

   private static void fullScreen(ShaderInstance shader) {
      BufferBuilder builder = Tesselator.getInstance().begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
      builder.addVertex(-1.0F, -1.0F, 0.0F).setUv(0.0F, 0.0F);
      builder.addVertex(1.0F, -1.0F, 0.0F).setUv(1.0F, 0.0F);
      builder.addVertex(1.0F, 1.0F, 0.0F).setUv(1.0F, 1.0F);
      builder.addVertex(-1.0F, 1.0F, 0.0F).setUv(0.0F, 1.0F);
      shader.apply();
      RenderSystem.disableBlend();
      BufferUploader.draw(builder.buildOrThrow());
      shader.clear();
   }

   public static final class Look {
      public final Vector3f obelisk = new Vector3f();
      public final Vector3f pole = new Vector3f(0.0F, 1.0F, 0.0F);
      public final Vector3f beamTop = new Vector3f();
      public final Vector3f beamBottom = new Vector3f();
      public float night;
      public float wheel;
      public float trails;
      public float aurora;
      public float auroraEdge;
      public float eye;
      public float swirl;
      public float front;
      public float white;
      public float sigil;
      public float sigilBright;
      public float merge;
      public float light;
      public float gloom;
      public float shockRadius;
      public float shock;
      public float heat;
      public float implode;
      public float charge;
      public float time;
      public float focusX;
      public float focusY;
      public boolean focusAhead;
      public float aberration;
      public float zoomBlur;
      public float shafts;
      public float impact;
      public float impactStyle;
      public float focusLines;
      public float afterimage;
      public float vignette;
      public float grain;

      public boolean worldVisible() {
         return this.night > 0.001F
            || this.aurora > 0.001F
            || this.eye > 0.001F
            || this.white > 0.001F
            || this.sigil > 0.001F
            || this.light > 0.001F
            || this.gloom > 0.001F
            || this.shock > 0.001F
            || this.heat > 0.001F;
      }

      public boolean lensVisible() {
         return this.aberration > 0.001F
            || this.zoomBlur > 0.001F
            || this.shafts > 0.001F
            || this.impact > 0.001F
            || this.afterimage > 0.001F
            || this.vignette > 0.001F
            || this.grain > 0.001F;
      }
   }
}
