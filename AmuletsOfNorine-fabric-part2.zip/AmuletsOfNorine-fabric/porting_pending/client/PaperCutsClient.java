package com.amuletmod.client;

import com.amuletmod.amulet.Amulets;
import com.amuletmod.amulet.ability.librarian.PaperCutsAbility;
import com.amuletmod.amulet.ability.librarian.Tome;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.IItemDecorator;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class PaperCutsClient {
   public static final IItemDecorator WEAR_BAR = (graphics, font, stack, x, y) -> {
      if (!Tome.isWorn(stack)) {
         return false;
      } else {
         float left = Tome.pagesLeft(stack) / 18.0F;
         int color = Mth.hsvToRgb(left / 3.0F, 1.0F, 1.0F);
         graphics.fill(RenderType.guiOverlay(), x + 2, y + 13, x + 15, y + 15, -16777216);
         graphics.fill(RenderType.guiOverlay(), x + 2, y + 13, x + 2 + Math.round(13.0F * left), y + 14, 0xFF000000 | color);
         return false;
      }
   };

   private PaperCutsClient() {
   }

   private static boolean isLocalPlayer(int entityId) {
      LocalPlayer player = Minecraft.getInstance().player;
      return player != null && player.getId() == entityId;
   }

   public static void impactFrame(int throwerId) {
      if (isLocalPlayer(throwerId)) {
         ImpactFrames.punch(0.06F);
         ImpactFrames.flash(0.3F);
         CameraShake.quake(0.6F, 4, 0);
      }
   }

   public static void flung(int throwerId) {
      if (isLocalPlayer(throwerId)) {
         CameraShake.quake(0.35F, 3, 0);
      }
   }

   @SubscribeEvent
   public static void onTooltip(ItemTooltipEvent event) {
      ItemStack stack = event.getItemStack();
      if (Tome.isTome(stack)) {
         LocalPlayer player = Minecraft.getInstance().player;
         if (Tome.isWorn(stack) || player != null && Amulets.<PaperCutsAbility>find(player, PaperCutsAbility.class) != null) {
            event.getToolTip()
               .add(Component.translatable("tooltip.amuletmod.pages_left", new Object[]{Tome.pagesLeft(stack), 18}).withStyle(ChatFormatting.GRAY));
         }
      }
   }
}
