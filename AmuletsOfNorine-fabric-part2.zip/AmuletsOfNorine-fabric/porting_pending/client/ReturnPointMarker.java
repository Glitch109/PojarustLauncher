package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.recall.ReturnPoint;
import com.amuletmod.client.renderer.LateBuffers;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class ReturnPointMarker {
   private static final double PARTICLE_RANGE_SQR = 4096.0;
   private static final ResourceLocation CIRCLE_TEXTURE = AmuletMod.id("textures/misc/magic_circle.png");
   private static final float CIRCLE_SIZE = 1.0F;
   @Nullable
   private static ReturnPoint point;

   private ReturnPointMarker() {
   }

   public static void update(@Nullable ReturnPoint newPoint, boolean justSet) {
      point = newPoint;
      if (justSet) {
         burst();
      }
   }

   @Nullable
   private static ClientLevel visibleIn() {
      ClientLevel level = Minecraft.getInstance().level;
      return point != null && level != null && level.dimension() == point.dimension() ? level : null;
   }

   private static Vec3 floorCenter() {
      BlockPos block = point.markerPos();
      return new Vec3(block.getX() + 0.5, point.position().y + 0.05, block.getZ() + 0.5);
   }

   private static void burst() {
      ClientLevel level = visibleIn();
      if (level != null) {
         Vec3 center = floorCenter();

         for (int i = 0; i < 32; i++) {
            double angle = (Math.PI * 2) * i / 32.0;
            level.addParticle(ParticleTypes.END_ROD, center.x, center.y, center.z, Math.cos(angle) * 0.12, 0.02, Math.sin(angle) * 0.12);
         }
      }
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      Minecraft minecraft = Minecraft.getInstance();
      ClientLevel level = visibleIn();
      if (level != null && minecraft.player != null && !minecraft.isPaused()) {
         Vec3 center = floorCenter();
         long time = level.getGameTime();
         if (time % 2L == 0L && !(minecraft.player.distanceToSqr(center) > 4096.0)) {
            for (int i = 0; i < 2; i++) {
               double angle = time * 0.25 + Math.PI * i;
               level.addParticle(ParticleTypes.END_ROD, center.x + Math.cos(angle) * 0.45, center.y, center.z + Math.sin(angle) * 0.45, 0.0, 0.03, 0.0);
            }
         }
      }
   }

   @SubscribeEvent
   public static void onRenderLevel(RenderLevelStageEvent event) {
      ClientLevel level = visibleIn();
      if (event.getStage() == Stage.AFTER_TRANSLUCENT_BLOCKS && level != null) {
         Vec3 center = floorCenter();
         Vec3 camera = event.getCamera().getPosition();
         float time = ClientClock.time(event.getPartialTick().getGameTimeDeltaPartialTick(false));
         int alpha = (int)(255.0F * (0.8F + 0.2F * Mth.sin(time * 0.1F)));
         PoseStack poseStack = event.getPoseStack();
         poseStack.pushPose();
         poseStack.translate(center.x - camera.x, point.position().y + 0.02 - camera.y, center.z - camera.z);
         poseStack.mulPose(Axis.YP.rotationDegrees(time * 0.6F));
         BufferSource buffers = LateBuffers.get();
         RenderType renderType = RenderType.entityTranslucentEmissive(CIRCLE_TEXTURE);
         VertexConsumer consumer = buffers.getBuffer(renderType);
         Matrix4f pose = poseStack.last().pose();
         Pose normal = poseStack.last();
         float half = 0.5F;
         circleVertex(consumer, pose, normal, -half, -half, 0.0F, 0.0F, alpha);
         circleVertex(consumer, pose, normal, -half, half, 0.0F, 1.0F, alpha);
         circleVertex(consumer, pose, normal, half, half, 1.0F, 1.0F, alpha);
         circleVertex(consumer, pose, normal, half, -half, 1.0F, 0.0F, alpha);
         poseStack.popPose();
         buffers.endBatch(renderType);
      }
   }

   private static void circleVertex(VertexConsumer consumer, Matrix4f pose, Pose normal, float x, float z, float u, float v, int alpha) {
      consumer.addVertex(pose, x, 0.0F, z)
         .setColor(255, 255, 255, alpha)
         .setUv(u, v)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(15728880)
         .setNormal(normal, 0.0F, 1.0F, 0.0F);
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      point = null;
   }
}
