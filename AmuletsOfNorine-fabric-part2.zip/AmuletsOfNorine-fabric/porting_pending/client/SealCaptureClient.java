package com.amuletmod.client;

import com.amuletmod.seal.SealBarrierBlock;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.RenderHighlightEvent.Block;
import net.neoforged.neoforge.client.event.RenderLivingEvent.Post;
import net.neoforged.neoforge.client.event.RenderLivingEvent.Pre;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class SealCaptureClient {
   private static final Map<Integer, SealCaptureClient.Shrunk> SHRUNK = new HashMap<>();
   private static final Set<Integer> SCALED = new HashSet<>();
   private static int ticks;

   private SealCaptureClient() {
   }

   public static void shrink(int entityId, float scale, float height) {
      SHRUNK.put(entityId, new SealCaptureClient.Shrunk(scale, height * 0.5F, ticks + 2));
   }

   @SubscribeEvent
   public static void onClientTick(net.neoforged.neoforge.client.event.ClientTickEvent.Post event) {
      if (!Minecraft.getInstance().isPaused()) {
         ticks++;
         if (!SHRUNK.isEmpty()) {
            SHRUNK.values().removeIf(shrunk -> shrunk.until() < ticks);
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public static void onRenderLivingPre(Pre<?, ?> event) {
      SealCaptureClient.Shrunk shrunk = SHRUNK.get(event.getEntity().getId());
      if (shrunk != null) {
         event.getPoseStack().pushPose();
         event.getPoseStack().translate(0.0F, shrunk.lift() * (1.0F - shrunk.scale()), 0.0F);
         event.getPoseStack().scale(shrunk.scale(), shrunk.scale(), shrunk.scale());
         SCALED.add(event.getEntity().getId());
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public static void onRenderLivingPost(Post<?, ?> event) {
      if (SCALED.remove(event.getEntity().getId())) {
         event.getPoseStack().popPose();
      }
   }

   @SubscribeEvent
   public static void onRenderHighlight(Block event) {
      if (Minecraft.getInstance().level != null) {
         BlockState state = Minecraft.getInstance().level.getBlockState(event.getTarget().getBlockPos());
         if (state.is(SealBarrierBlock.block())) {
            event.setCanceled(true);
         }
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      SHRUNK.clear();
      SCALED.clear();
   }

   private record Shrunk(float scale, float lift, int until) {
   }
}
