package com.amuletmod.client;

import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.client.renderer.LateBuffers;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.amuletmod.client.renderer.RunicObeliskRenderer;
import com.amuletmod.obelisk.ObeliskRite;
import com.amuletmod.obelisk.RunicObeliskBlock;
import com.amuletmod.obelisk.RunicObeliskBlockEntity;
import com.amuletmod.util.Easing;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.RenderGuiEvent.Post;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class ObeliskRiteView {
   private static final double SCREEN_NEAR = 40.0;
   private static final double SCREEN_FAR = 140.0;
   private static final double SKY_NEAR = 96.0;
   private static final double SKY_FAR = 256.0;
   private static final float POLE_HEIGHT = 400.0F;
   private static final int TRAIL_TICKS = 30;
   public static final int STRIKE_FRAMES = 3;
   public static final int SHATTER_FRAMES = 3;
   public static final int BIRTH_FRAMES = 5;
   private static final int STARS = 240;
   private static final int RAYS = 72;
   private static final ObeliskRitePost.Look LOOK = new ObeliskRitePost.Look();
   @Nullable
   private static RunicObeliskBlockEntity shown;
   private static float shownAge;
   private static boolean fresh;
   @Nullable
   private static RunicObeliskBlockEntity heldFor;
   private static int heldHit = -1;
   private static float flash;

   private ObeliskRiteView() {
   }

   public static void whiteout(RunicObeliskBlockEntity obelisk, float strength) {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft.player != null && !(Boolean)minecraft.options.hideLightningFlash().get()) {
         double distance = minecraft.player.getEyePosition().distanceTo(heart(obelisk));
         flash = Math.max(flash, strength * nearness(distance, 40.0, 140.0));
      }
   }

   private static float kick(float t, float at, float ticks) {
      if (t < at) {
         return 0.0F;
      } else {
         float left = Math.max(0.0F, 1.0F - (t - at) / ticks);
         return left * left;
      }
   }

   private static float nearness(double distance, double near, double far) {
      return 1.0F - Easing.smoothstep((float)near, (float)far, (float)distance);
   }

   private static float turning(float s) {
      if (s >= 450.0F) {
         return 0.0F;
      } else {
         float charge = ObeliskRite.charge(s);
         return 0.0035F * Easing.smoothstep(120.0F, 200.0F, s) * (1.0F + 5.0F * charge * charge) * (1.0F - ObeliskRite.implode(s));
      }
   }

   private static float wheel(float t) {
      float sum = 0.0F;

      for (int s = 120; s < t; s++) {
         sum += turning(s + 0.5F) * Math.min(1.0F, t - s);
      }

      return sum;
   }

   private static int hitAt(float t) {
      if (t >= ObeliskRite.strikes() && t < ObeliskRite.strikes() + 3) {
         return ObeliskRite.strikes();
      } else if (t >= 420.0F && t < 423.0F) {
         return 420;
      } else {
         return t >= 450.0F && t < 455.0F ? 450 : -1;
      }
   }

   private static Vec3 heart(RunicObeliskBlockEntity obelisk) {
      Direction facing = (Direction)obelisk.getBlockState().getValue(RunicObeliskBlock.FACING);
      return RunicObeliskRenderer.toWorld(obelisk.getBlockPos(), facing, RunicObeliskRenderer.core());
   }

   private static void look(RunicObeliskBlockEntity obelisk, float t, Vec3 camera, Matrix4f view, Matrix4f projection) {
      Minecraft minecraft = Minecraft.getInstance();
      ObeliskRitePost.Look look = LOOK;
      BlockPos base = obelisk.getBlockPos();
      Vec3 foot = new Vec3(base.getX() + 0.5, base.getY(), base.getZ() + 0.5);
      Vec3 heart = heart(obelisk);
      double distance = camera.distanceTo(heart);
      float near = nearness(distance, 40.0, 140.0);
      float sky = nearness(distance, 96.0, 256.0);
      float distort = ((Double)minecraft.options.screenEffectScale().get()).floatValue();
      boolean flashes = !(Boolean)minecraft.options.hideLightningFlash().get();
      float charge = ObeliskRite.charge(t);
      float implode = ObeliskRite.implode(t);
      float merge = ObeliskRite.merge(t);
      float drawn = ObeliskRite.sigil(t);
      float born = t >= 450.0F ? 1.0F : 0.0F;
      float after = Easing.smoothstep(450.0F, 530.0F, t);
      look.obelisk.set((float)(foot.x - camera.x), (float)(foot.y - camera.y), (float)(foot.z - camera.z));
      look.pole.set(look.obelisk).add(0.0F, 400.0F, 0.0F);
      look.beamBottom.set((float)(foot.x - camera.x), (float)(foot.y + 3.5625 - camera.y), (float)(foot.z - camera.z));
      look.beamTop.set(look.beamBottom).add(0.0F, 13.0F + 60.0F * born, 0.0F);
      look.time = t / 20.0F;
      look.night = ObeliskRite.night(t) * sky;
      look.wheel = wheel(t);
      look.trails = look.wheel - wheel(t - 30.0F);
      look.aurora = (
            t < 450.0F
               ? Easing.smoothstep(ObeliskRite.strikes(), ObeliskRite.strikes() + 60.0F, t) * (0.55F + 0.45F * charge) * (1.0F - 0.7F * implode)
               : 0.9F * (1.0F - after)
         )
         * sky;
      look.auroraEdge = t < 450.0F ? Mth.lerp(charge, 1.15F, 0.6F) * (1.0F - 0.75F * implode) : 0.6F + 0.9F * Easing.outCubic((t - 450.0F) / 60.0F);
      float open = Easing.smoothstep(140.0F, 172.0F, t);
      look.eye = ((t < 450.0F ? open * (0.6F + 0.4F * charge) * (1.0F - implode) : 0.0F) + 3.0F * kick(t, 450.0F, 20.0F)) * sky;
      look.swirl = 1.2F * Easing.smoothstep(140.0F, 420.0F, t) * (1.0F - born) + 2.5F * implode;
      look.front = sky > 0.001F ? ObeliskRite.birthFront(t) : -1.0F;
      look.white = kick(t, 450.0F, 30.0F) * sky;
      look.sigil = drawn;
      look.sigilBright = ((0.7F + 0.6F * charge) * (1.0F - 0.5F * implode) + 2.0F * kick(t, 450.0F, 20.0F)) * (1.0F - after);
      look.merge = merge;
      look.light = (
            t < ObeliskRite.strikes()
               ? 0.15F * drawn / 6.0F
               : (t < 450.0F ? (0.5F + 0.6F * charge) * (1.0F - 0.8F * implode) + 1.5F * kick(t, ObeliskRite.strikes(), 16.0F) : 0.4F * (1.0F - after))
         )
         + 3.0F * kick(t, 450.0F, 30.0F);
      look.gloom = Math.min(1.0F, 0.12F * drawn / 6.0F + 0.3F * ObeliskRite.night(t) + 0.15F * charge + 0.35F * implode)
         * (t < 450.0F ? 1.0F : 0.5F * (1.0F - Easing.smoothstep(450.0F, 500.0F, t)))
         * near;
      if (t >= 450.0F) {
         look.shockRadius = 18.0F * Easing.outCubic((t - 450.0F) / 28.0F);
         look.shock = Math.max(0.0F, 1.0F - (t - 450.0F) / 28.0F);
      } else {
         look.shockRadius = 8.0F * Easing.outCubic((t - ObeliskRite.strikes()) / 14.0F);
         look.shock = t >= ObeliskRite.strikes() ? 0.6F * Math.max(0.0F, 1.0F - (t - ObeliskRite.strikes()) / 14.0F) : 0.0F;
      }

      look.heat = (t >= ObeliskRite.strikes() && t < 450.0F ? (t >= 420.0F ? 0.25F : 0.3F + 0.5F * charge) : kick(t, 450.0F, 40.0F)) * near;
      look.implode = implode;
      look.charge = charge;
      Vector4f clip = new Matrix4f(projection)
         .mul(view)
         .transform(new Vector4f((float)(heart.x - camera.x), (float)(heart.y - camera.y), (float)(heart.z - camera.z), 1.0F));
      look.focusAhead = clip.w > 0.05F;
      look.focusX = look.focusAhead ? clip.x / clip.w * 0.5F + 0.5F : 0.5F;
      look.focusY = look.focusAhead ? clip.y / clip.w * 0.5F + 0.5F : 0.5F;
      float aberration = 0.4F * kick(t, 112.0F, 20.0F)
         + 0.5F * kick(t, 140.0F, 30.0F)
         + 1.6F * kick(t, ObeliskRite.strikes(), 30.0F)
         + 1.8F * kick(t, 420.0F, 30.0F)
         + 3.0F * kick(t, 455.0F, 50.0F)
         + 0.8F * implode;

      for (int k = 0; k < 6; k++) {
         aberration += 0.25F * kick(t, ObeliskRite.circleOpens(k), 16.0F);
      }

      if (t >= 190.0F && t < 450.0F) {
         aberration += 0.1F + 0.6F * charge * charge;
      }

      look.aberration = aberration * near * distort;
      look.zoomBlur = (0.6F * kick(t, ObeliskRite.strikes(), 12.0F) + 0.7F * implode * Mth.sqrt(implode) + 1.3F * kick(t, 455.0F, 30.0F)) * near * distort;
      look.shafts = (
            (t >= ObeliskRite.strikes() && t < 450.0F ? 0.3F + 0.4F * charge + 0.5F * implode : 0.0F)
               + 1.6F * kick(t, 455.0F, 60.0F)
               + 0.3F * born * (1.0F - Easing.smoothstep(450.0F, 540.0F, t))
         )
         * near;
      look.vignette = Math.min(
            1.0F,
            0.25F * ObeliskRite.night(t)
               + 0.35F * charge * (1.0F - born)
               + 0.6F * implode
               + 0.5F * kick(t, ObeliskRite.strikes(), 30.0F)
               + 0.6F * kick(t, 455.0F, 40.0F)
         )
         * near;
      look.grain = (0.25F * implode + 0.08F * ObeliskRite.night(t)) * near;
      look.impact = 0.0F;
      look.impactStyle = 0.0F;
      look.focusLines = 0.0F;
      boolean frames = flashes && near > 0.25F;
      int hit = hitAt(t);
      if (frames && hit >= 0) {
         float into = t - hit;
         if (hit == 450) {
            look.impactStyle = into < 1.5F ? 3.0F : (into < 3.5F ? 4.0F : 2.0F);
            look.impact = into < 4.0F ? 1.0F : 5.0F - into;
            look.focusLines = look.impactStyle == 4.0F ? 1.0F : 0.0F;
         } else {
            look.impactStyle = hit == 420 ? 2.0F : 1.0F;
            look.impact = into < 2.0F ? 1.0F : 3.0F - into;
            look.focusLines = hit == 420 ? 0.6F : 1.0F;
         }
      }

      look.afterimage = frames ? (0.5F * kick(t, ObeliskRite.strikes() + 3, 20.0F) + 0.5F * kick(t, 423.0F, 20.0F) + kick(t, 455.0F, 50.0F)) * near : 0.0F;
   }

   @SubscribeEvent(
      priority = EventPriority.HIGH
   )
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      Stage stage = event.getStage();
      if (stage == Stage.AFTER_PARTICLES) {
         beforeLight(event);
      } else if (stage == Stage.AFTER_LEVEL) {
         afterLevel();
      }
   }

   private static void beforeLight(RenderLevelStageEvent event) {
      Camera camera = event.getCamera();
      shown = nearest(camera.getPosition());
      fresh = false;
      if (shown == null) {
         LOOK.impact = 0.0F;
      } else {
         shownAge = shown.riteAge(event.getPartialTick().getGameTimeDeltaPartialTick(false));
         Matrix4f pose = event.getPoseStack().last().pose();
         Matrix4f view = new Matrix4f(event.getModelViewMatrix()).mul(pose);
         look(shown, shownAge, camera.getPosition(), view, event.getProjectionMatrix());
         fresh = true;
         if (ObeliskRitePost.available()) {
            ObeliskRitePost.world(view, event.getProjectionMatrix(), LOOK);
         } else {
            fallbackSky(LateBuffers.get(), pose, shown);
         }
      }
   }

   private static void afterLevel() {
      if (fresh && shown != null && ObeliskRitePost.available()) {
         int hit = hitAt(shownAge);
         if (LOOK.impact > 0.001F && (heldFor != shown || heldHit != hit)) {
            ObeliskRitePost.hold();
            heldFor = shown;
            heldHit = hit;
         }

         ObeliskRitePost.lens(LOOK);
      }
   }

   @Nullable
   private static RunicObeliskBlockEntity nearest(Vec3 camera) {
      Minecraft minecraft = Minecraft.getInstance();
      RunicObeliskBlockEntity nearest = null;
      double best = 65536.0;

      for (RunicObeliskBlockEntity obelisk : ObeliskRiteClient.underway()) {
         if (!obelisk.isRemoved() && obelisk.getLevel() == minecraft.level && !(obelisk.riteAge(0.0F) < 0.0F)) {
            double distance = heart(obelisk).distanceToSqr(camera);
            if (distance < best) {
               nearest = obelisk;
               best = distance;
            }
         }
      }

      return nearest;
   }

   private static void fallbackSky(BufferSource buffers, Matrix4f pose, RunicObeliskBlockEntity obelisk) {
      ObeliskRitePost.Look look = LOOK;
      if (!(look.night < 0.01F) || !(look.aurora < 0.01F) || !(look.front < 0.0F)) {
         Vector3f axis = new Vector3f(look.pole).normalize();
         Vector3f side = new Vector3f(Math.abs(axis.y()) < 0.99F ? new Vector3f(0.0F, 1.0F, 0.0F) : new Vector3f(1.0F, 0.0F, 0.0F)).cross(axis).normalize();
         Vector3f up = new Vector3f(axis).cross(side);
         float distance = Minecraft.getInstance().gameRenderer.getRenderDistance() * 1.5F;
         float width = distance * 0.0022F;
         Vector3f eye = new Vector3f();
         RandomSource random = RandomSource.create(obelisk.getBlockPos().asLong());
         float fogStart = RenderSystem.getShaderFogStart();
         RenderSystem.setShaderFogStart(Float.MAX_VALUE);
         VertexConsumer consumer = buffers.getBuffer(ModRenderTypes.GLOW);
         float healed = look.front;

         for (int i = 0; i < 240; i++) {
            float theta = (float)Math.acos(1.0F - random.nextFloat() * (1.0F - Mth.cos(1.5F)));
            float phi = random.nextFloat() * (float) (Math.PI * 2);
            float magnitude = random.nextFloat();
            float[] colour = magnitude > 0.9F ? RunicObeliskRenderer.GEMS[i % 3] : RunicObeliskRenderer.PALE;
            if (!(look.night < 0.01F) && (!(healed >= 0.0F) || !(theta < healed))) {
               int count = 2 + Math.min(8, (int)(look.trails / 0.06F));
               float swirl = look.swirl * (float)Math.exp(-theta * 2.5F);
               List<Vector3f> points = new ArrayList<>();

               for (int j = 0; j < count; j++) {
                  float back = look.trails * j / (count - 1.0F);
                  Vector3f direction = direction(axis, side, up, theta, phi + look.wheel + swirl - back);
                  if (direction.y() < 0.02F) {
                     break;
                  }

                  points.add(direction.mul(distance));
               }

               if (points.size() >= 2) {
                  GlowDraw.taperedRibbon(
                     consumer,
                     pose,
                     points.toArray(new Vector3f[0]),
                     eye,
                     width * (0.6F + magnitude),
                     colour[0],
                     colour[1],
                     colour[2],
                     look.night * (0.3F + 0.7F * magnitude)
                  );
               }
            }
         }

         if (look.aurora > 0.01F) {
            for (int ix = 0; ix < 72; ix++) {
               float phi = (ix + random.nextFloat() * 0.6F) / 72.0F * (float) (Math.PI * 2);
               float lower = look.auroraEdge + 0.06F * Mth.sin(phi * 3.0F + look.time * 0.4F);
               float sway = 0.6F + 0.4F * Mth.sin(look.time * (1.1F + random.nextFloat()) + ix * 1.7F);
               float[] colour = RunicObeliskRenderer.GEMS[ix * 7 % 3];
               Vector3f[] ray = new Vector3f[5];

               for (int j = 0; j < ray.length; j++) {
                  ray[j] = direction(axis, side, up, lower * (1.0F - 0.65F * j / (ray.length - 1.0F)), phi).mul(distance);
               }

               if (ray[0].y() > distance * 0.02F) {
                  GlowDraw.taperedRibbon(consumer, pose, ray, eye, width * 4.0F, colour[0], colour[1], colour[2], 0.4F * look.aurora * sway);
               }
            }
         }

         if (look.front >= 0.0F && look.front < 2.6F) {
            float strength = 1.0F - Easing.smoothstep(0.4F, 2.6F, look.front);

            for (int c = 0; c < 3; c++) {
               float theta = look.front + (c - 1) * 0.02F;
               float[] colour = RunicObeliskRenderer.GEMS[c];
               List<Vector3f> ring = new ArrayList<>();

               for (int j = 0; j <= 96; j++) {
                  Vector3f direction = direction(axis, side, up, theta, j / 96.0F * (float) (Math.PI * 2));
                  if (direction.y() < 0.02F) {
                     line(consumer, pose, ring, eye, width * 6.0F, colour, strength);
                  } else {
                     ring.add(direction.mul(distance));
                  }
               }

               line(consumer, pose, ring, eye, width * 6.0F, colour, strength);
            }
         }

         buffers.endBatch(ModRenderTypes.GLOW);
         RenderSystem.setShaderFogStart(fogStart);
      }
   }

   private static void line(VertexConsumer consumer, Matrix4f pose, List<Vector3f> points, Vector3f eye, float width, float[] colour, float alpha) {
      if (points.size() >= 2) {
         GlowDraw.ribbon(consumer, pose, points.toArray(new Vector3f[0]), eye, width, colour[0], colour[1], colour[2], alpha);
      }

      points.clear();
   }

   private static Vector3f direction(Vector3f axis, Vector3f side, Vector3f up, float theta, float phi) {
      float sin = Mth.sin(theta);
      return new Vector3f(axis).mul(Mth.cos(theta)).add(new Vector3f(side).mul(sin * Mth.cos(phi))).add(new Vector3f(up).mul(sin * Mth.sin(phi)));
   }

   @SubscribeEvent
   public static void onRenderHand(RenderHandEvent event) {
      if (shown != null && LOOK.impact > 0.001F && ObeliskRitePost.available()) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void onRenderGui(Post event) {
      GuiGraphics graphics = event.getGuiGraphics();
      int width = graphics.guiWidth();
      int height = graphics.guiHeight();
      if (shown != null && LOOK.impact > 0.001F && !ObeliskRitePost.available()) {
         impactOverlay(graphics, width, height, LOOK);
      }

      if (flash > 0.001F) {
         graphics.fill(0, 0, width, height, (int)(flash * flash * 235.0F) << 24 | 16184063);
      }
   }

   private static void impactOverlay(GuiGraphics graphics, int width, int height, ObeliskRitePost.Look look) {
      int style = (int)look.impactStyle;
      boolean white = style == 3;
      int alpha = (int)(Mth.clamp(look.impact, 0.0F, 1.0F) * 0.9F * 255.0F);
      graphics.fill(0, 0, width, height, alpha << 24 | (white ? 16513279 : 459532));
      float x = (look.focusAhead ? look.focusX : 0.5F) * width;
      float y = (1.0F - (look.focusAhead ? look.focusY : 0.5F)) * height;
      float reach = Mth.sqrt(width * width + height * height);
      RandomSource random = RandomSource.create((long)(look.time * 10.0F) * 31L + style);
      int lines = 110;

      for (int i = 0; i < lines; i++) {
         if (!(random.nextFloat() < 0.4F)) {
            float angle = (i + random.nextFloat()) / lines * 360.0F;
            int from = (int)(Math.min(width, height) * (0.12F + 0.35F * random.nextFloat()));
            int thick = 1 + random.nextInt(3);
            int colour = white ? 459532 : (style == 2 ? gemRgb(i % 3) : 16513279);
            graphics.pose().pushPose();
            graphics.pose().translate(x, y, 0.0F);
            graphics.pose().mulPose(Axis.ZP.rotationDegrees(angle));
            graphics.fillGradient(-thick, from, thick, (int)reach, colour & 16777215, alpha << 24 | colour);
            graphics.pose().popPose();
         }
      }

      if (style == 4 || style == 1) {
         int size = (int)(Math.min(width, height) * (style == 4 ? 0.3F : 0.16F));

         for (int ix = 0; ix < 4; ix++) {
            graphics.pose().pushPose();
            graphics.pose().translate(x, y, 0.0F);
            graphics.pose().mulPose(Axis.ZP.rotationDegrees(ix * 45.0F + look.time * 40.0F));
            int thick = ix % 2 == 0 ? 3 : 2;
            graphics.fillGradient(-thick, -size, thick, 0, 16513279, alpha << 24 | 16513279);
            graphics.fillGradient(-thick, 0, thick, size, alpha << 24 | 16513279, 16513279);
            graphics.pose().popPose();
         }
      }
   }

   private static int gemRgb(int gem) {
      float[] c = RunicObeliskRenderer.GEMS[gem];
      return (int)(c[0] * 255.0F) << 16 | (int)(c[1] * 255.0F) << 8 | (int)(c[2] * 255.0F);
   }

   @SubscribeEvent
   public static void onClientTick(net.neoforged.neoforge.client.event.ClientTickEvent.Post event) {
      if (!Minecraft.getInstance().isPaused()) {
         flash = Math.max(0.0F, flash - 0.03F);
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      shown = null;
      heldFor = null;
      heldHit = -1;
      flash = 0.0F;
      LOOK.impact = 0.0F;
   }
}
