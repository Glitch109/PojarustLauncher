package com.amuletmod.client;

import com.amuletmod.entity.TimeFieldEntity;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class ChronoClient {
   private static final Map<Integer, ChronoClient.Pin> PINS = new HashMap<>();
   private static boolean cameraInStoppedTime;

   private ChronoClient() {
   }

   public static boolean isCameraInStoppedTime() {
      return cameraInStoppedTime;
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      Minecraft minecraft = Minecraft.getInstance();
      ClientLevel level = minecraft.level;
      if (level == null) {
         PINS.clear();
         cameraInStoppedTime = false;
      } else if (!minecraft.isPaused()) {
         boolean cameraInside = false;
         Set<Integer> held = new HashSet<>();
         Entity camera = minecraft.getCameraEntity();

         for (Entity entity : level.entitiesForRendering()) {
            if (entity instanceof TimeFieldEntity field && field.isStoppingTime()) {
               double radius = field.currentRadius(0.0F);
               if (camera != null && camera.getEyePosition().distanceToSqr(field.center()) < radius * radius) {
                  cameraInside = true;
               }

               for (Entity target : level.getEntities(
                  field,
                  field.reach(radius),
                  targetx -> field.encloses(targetx, radius) && (PINS.containsKey(targetx.getId()) || TimeFieldEntity.canFreeze(targetx))
               )) {
                  pin(target);
                  held.add(target.getId());
               }
            }
         }

         PINS.keySet().retainAll(held);
         cameraInStoppedTime = cameraInside;
      }
   }

   private static void pin(Entity entity) {
      ChronoClient.Pin pin = PINS.computeIfAbsent(
         entity.getId(),
         id -> new ChronoClient.Pin(
            entity.position(),
            entity.getYRot(),
            entity.getXRot(),
            entity instanceof LivingEntity livingx ? livingx.yHeadRot : 0.0F,
            entity instanceof LivingEntity livingx ? livingx.yBodyRot : 0.0F
         )
      );
      Vec3 at = pin.position();
      entity.setPos(at.x, at.y, at.z);
      entity.xo = entity.xOld = at.x;
      entity.yo = entity.yOld = at.y;
      entity.zo = entity.zOld = at.z;
      entity.setDeltaMovement(Vec3.ZERO);
      entity.setYRot(pin.yRot());
      entity.yRotO = pin.yRot();
      entity.setXRot(pin.xRot());
      entity.xRotO = pin.xRot();
      if (entity instanceof LivingEntity living) {
         living.yHeadRot = living.yHeadRotO = pin.headRot();
         living.yBodyRot = living.yBodyRotO = pin.bodyRot();
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      PINS.clear();
      cameraInStoppedTime = false;
   }

   private record Pin(Vec3 position, float yRot, float xRot, float headRot, float bodyRot) {
   }
}
