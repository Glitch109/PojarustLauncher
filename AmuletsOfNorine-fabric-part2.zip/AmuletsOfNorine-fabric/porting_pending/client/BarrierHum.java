package com.amuletmod.client;

import com.amuletmod.entity.BarrierEntity;
import com.amuletmod.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

public final class BarrierHum extends AbstractTickableSoundInstance {
   private final BarrierEntity barrier;
   private final float loudness;

   private BarrierHum(BarrierEntity barrier) {
      super((SoundEvent)ModSounds.AEGIS_SHIELD_LOOP.get(), SoundSource.PLAYERS, SoundInstance.createUnseededRandom());
      this.barrier = barrier;
      boolean dome = barrier.mode() == BarrierEntity.Mode.DOME;
      this.loudness = dome ? 0.9F : 0.55F;
      this.pitch = dome ? 0.88F : 1.0F;
      this.looping = true;
      this.delay = 0;
      this.follow();
   }

   public static void start(BarrierEntity barrier) {
      Minecraft.getInstance().getSoundManager().play(new BarrierHum(barrier));
   }

   public boolean canStartSilent() {
      return true;
   }

   public void tick() {
      if (this.barrier.isRemoved()) {
         this.stop();
      } else {
         this.follow();
      }
   }

   private void follow() {
      Vec3 at = this.barrier.center();
      this.x = at.x;
      this.y = at.y;
      this.z = at.z;
      this.volume = this.loudness * this.barrier.fade(0.0F);
   }
}
