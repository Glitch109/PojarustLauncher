package com.amuletmod.client;

import com.amuletmod.entity.MeteorVolleyEntity;
import com.amuletmod.util.Easing;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

public final class MeteorVolleyClient {
   private static final float AIM_ZOOM = 0.06F;
   private static final float RECOIL = -0.035F;

   private MeteorVolleyClient() {
   }

   public static void tick(MeteorVolleyEntity volley) {
      LocalPlayer player = Minecraft.getInstance().player;
      if (player != null && player.getId() == volley.casterId() && volley.fizzledAt() < 0) {
         int age = volley.tickCount;
         if (age <= 56) {
            ImpactFrames.focus(0.06F * Easing.smoothstep(0.0F, 44.0F, age));
         }

         for (int k = 0; k < 5; k++) {
            if (age == MeteorVolleyEntity.firesAt(k)) {
               ImpactFrames.punch(-0.035F);
               CameraShake.quake(0.6F, 5, 0);
            }
         }
      }
   }
}
