package com.amuletmod.client;

import com.amuletmod.AmuletMod;
import com.amuletmod.amulet.ability.strike.StrikeTarget;
import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.client.renderer.LateBuffers;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3f;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class StrikeTargetMarker {
   private static final ResourceLocation RETICLE = AmuletMod.id("textures/misc/strike_reticle.png");
   private static final float RETICLE_RADIUS = 2.6F;
   private static final float PILLAR_HEIGHT = 40.0F;
   @Nullable
   private static StrikeTarget target;

   private StrikeTargetMarker() {
   }

   public static void update(@Nullable StrikeTarget newTarget) {
      target = newTarget;
   }

   @Nullable
   private static Vec3 visiblePosition() {
      ClientLevel level = Minecraft.getInstance().level;
      return target != null && level != null && level.dimension() == target.dimension() ? target.position() : null;
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      Minecraft minecraft = Minecraft.getInstance();
      Vec3 at = visiblePosition();
      if (at != null
         && minecraft.level != null
         && minecraft.player != null
         && !minecraft.isPaused()
         && !(minecraft.player.position().distanceToSqr(at) > 9216.0)) {
         if (minecraft.level.getGameTime() % 3L == 0L) {
            double angle = minecraft.level.random.nextDouble() * (float) (Math.PI * 2);
            minecraft.level
               .addParticle(ParticleTypes.END_ROD, true, at.x + Math.cos(angle) * 2.6F * 0.8, at.y + 0.1, at.z + Math.sin(angle) * 2.6F * 0.8, 0.0, 0.06, 0.0);
         }
      }
   }

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      Vec3 at = visiblePosition();
      ClientLevel level = Minecraft.getInstance().level;
      if (event.getStage() == Stage.AFTER_PARTICLES && at != null && level != null) {
         Vec3 view = event.getCamera().getPosition();
         float time = ClientClock.time(event.getPartialTick().getGameTimeDeltaPartialTick(false));
         float pulse = 0.75F + 0.25F * Mth.sin(time * 0.15F);
         BufferSource buffers = LateBuffers.get();
         PoseStack poseStack = event.getPoseStack();
         poseStack.pushPose();
         poseStack.translate(at.x - view.x, at.y - view.y, at.z - view.z);
         poseStack.pushPose();
         poseStack.translate(0.0F, 0.06F, 0.0F);
         poseStack.mulPose(Axis.YP.rotationDegrees(time * 1.5F));
         RenderType reticle = ModRenderTypes.skyGlowXray(RETICLE);
         VertexConsumer consumer = buffers.getBuffer(reticle);
         Matrix4f pose = poseStack.last().pose();
         float r = 1.0F * pulse;
         float g = 0.3F * pulse;
         float b = 0.6F * pulse;
         corner(consumer, pose, -2.6F, -2.6F, 0.0F, 0.0F, r, g, b);
         corner(consumer, pose, -2.6F, 2.6F, 0.0F, 1.0F, r, g, b);
         corner(consumer, pose, 2.6F, 2.6F, 1.0F, 1.0F, r, g, b);
         corner(consumer, pose, 2.6F, -2.6F, 1.0F, 0.0F, r, g, b);
         buffers.endBatch(reticle);
         poseStack.popPose();
         Vector3f eye = new Vector3f((float)(view.x - at.x), (float)(view.y - at.y), (float)(view.z - at.z));
         VertexConsumer pillar = buffers.getBuffer(ModRenderTypes.GLOW_XRAY);
         Matrix4f pillarPose = poseStack.last().pose();
         Vector3f[] points = new Vector3f[9];

         for (int i = 0; i < points.length; i++) {
            points[i] = new Vector3f(0.0F, 40.0F * i / (points.length - 1), 0.0F);
         }

         GlowDraw.ribbon(pillar, pillarPose, points, eye, 0.12F, 1.0F, 0.55F, 0.8F, 0.55F * pulse);
         GlowDraw.ribbon(pillar, pillarPose, points, eye, 0.5F, 1.0F, 0.3F, 0.6F, 0.2F * pulse);
         buffers.endBatch(ModRenderTypes.GLOW_XRAY);
         poseStack.popPose();
      }
   }

   private static void corner(VertexConsumer consumer, Matrix4f pose, float x, float z, float u, float v, float r, float g, float b) {
      consumer.addVertex(pose, x, 0.0F, z).setUv(u, v).setColor(r, g, b, 1.0F);
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      target = null;
   }
}
