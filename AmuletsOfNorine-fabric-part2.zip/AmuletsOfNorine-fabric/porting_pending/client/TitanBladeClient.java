package com.amuletmod.client;

import com.amuletmod.client.renderer.GlowDraw;
import com.amuletmod.client.renderer.LateBuffers;
import com.amuletmod.client.renderer.ModRenderTypes;
import com.amuletmod.entity.TitanBladeEntity;
import com.amuletmod.entity.TitanSlashEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import org.joml.Matrix4f;
import org.joml.Vector3f;

@EventBusSubscriber(
   modid = "amuletmod",
   value = {Dist.CLIENT}
)
public final class TitanBladeClient {
   private static final DustParticleOptions EMBER = new DustParticleOptions(new Vector3f(1.0F, 0.55F, 0.15F), 0.8F);
   private static final DustParticleOptions WHITE_HOT = new DustParticleOptions(new Vector3f(1.0F, 0.93F, 0.78F), 0.6F);
   private static final DustParticleOptions FROST = new DustParticleOptions(new Vector3f(0.55F, 0.8F, 1.0F), 0.9F);
   private static final int BEAM_TICKS = 6;
   private static final List<TitanBladeClient.Beam> BEAMS = new ArrayList<>();

   private TitanBladeClient() {
   }

   private static boolean mine(int ownerId) {
      LocalPlayer player = Minecraft.getInstance().player;
      return player != null && player.getId() == ownerId;
   }

   public static void tickSlash(TitanSlashEntity slash) {
      ClientLevel level = (ClientLevel)slash.level();
      RandomSource random = level.random;
      int age = slash.tickCount;
      float scale = slash.scale();
      if (age == 1 && mine(slash.ownerId())) {
         CameraShake.quake(0.22F, 3, 0);
      }

      if (age <= 4) {
         float angle = Math.min(slash.swing(age), TitanSlashEntity.SWEEP);

         for (int i = 0; i < 4; i++) {
            Vec3 at = slash.arc(angle - random.nextFloat() * 0.4F, slash.radius());
            Vec3 off = slash.sweep().scale(0.1 + random.nextDouble() * 0.15);
            level.addParticle(random.nextInt(3) == 0 ? WHITE_HOT : EMBER, at.x, at.y, at.z, off.x, off.y + 0.02, off.z);
         }
      }

      if (slash.thrown()) {
         int launch = slash.launchAge();
         if (age == launch && mine(slash.ownerId())) {
            CameraShake.quake(0.5F, 6, 0);
            ImpactFrames.punch(0.012F);
         }

         float since = slash.sinceStop(age);
         if (age > launch) {
            Vec3 bow = slash.bow();
            Vec3 sweep = slash.sweep();
            Vec3 heading = slash.heading();
            Vec3 middle = slash.flying(age);
            float radius = slash.radius() * slash.thrownSize(age);
            if (since < 0.0F) {
               for (int i = 0; i < 3; i++) {
                  float angle = (random.nextFloat() * 2.0F - 1.0F) * TitanSlashEntity.SWEEP * 0.9F;
                  Vec3 at = TitanSlashEntity.crescentPoint(middle, bow, sweep, radius, angle, random.nextFloat() * 0.12F * radius);
                  level.addParticle(
                     random.nextInt(3) == 0 ? WHITE_HOT : EMBER,
                     at.x,
                     at.y,
                     at.z,
                     -heading.x * 0.2 + TitanFistClient.spread(random, 0.02),
                     -heading.y * 0.2 + 0.01,
                     -heading.z * 0.2 + TitanFistClient.spread(random, 0.02)
                  );
               }
            } else {
               if (since < 1.0F) {
                  BlockState wall = TitanFistClient.blockAt(level, middle.add(heading.scale(0.3)));
                  if (wall != null) {
                     TitanFistClient.burst(level, random, ParticleTypes.CRIT, middle, 16, 0.6 * scale, 0.5);
                     TitanFistClient.burst(level, random, new BlockParticleOption(ParticleTypes.BLOCK, wall), middle, 14, 0.5 * scale, 0.25);
                  }
               }

               int segments = 24;
               float from = (since - 1.0F) / 10.0F;
               float to = since / 10.0F;

               for (int k = 0; k < segments; k++) {
                  float breaks = slash.breaksAt(k, segments);
                  if (!(breaks < from) && !(breaks >= to)) {
                     float angle = Mth.lerp((k + 0.5F) / segments, -TitanSlashEntity.SWEEP, TitanSlashEntity.SWEEP);
                     Vec3 out = bow.scale(Mth.cos(angle)).add(sweep.scale(Mth.sin(angle)));

                     for (int i = 0; i < 3; i++) {
                        Vec3 at = TitanSlashEntity.crescentPoint(middle, bow, sweep, radius, angle, random.nextFloat() * 0.15F * radius);
                        Vec3 drift = out.scale(0.03 + random.nextDouble() * 0.04).add(heading.scale(0.05));
                        level.addParticle(
                           i == 0 ? WHITE_HOT : EMBER,
                           at.x,
                           at.y,
                           at.z,
                           drift.x + TitanFistClient.spread(random, 0.02),
                           drift.y + TitanFistClient.spread(random, 0.02),
                           drift.z + TitanFistClient.spread(random, 0.02)
                        );
                     }
                  }
               }
            }
         }
      }
   }

   public static void tickBlade(TitanBladeEntity blade) {
      ClientLevel level = (ClientLevel)blade.level();
      RandomSource random = level.random;
      int age = blade.tickCount;
      Vec3 position = blade.position();
      switch (blade.phase()) {
         case 0:
            Vec3 circle = position.subtract(0.0, 0.6700000047683716, 0.0);
            if (age <= 8) {
               for (int i = 0; i < 3; i++) {
                  double angle = random.nextDouble() * (float) (Math.PI * 2);
                  double r = 0.35 + random.nextDouble() * 0.25;
                  level.addParticle(
                     ParticleTypes.END_ROD,
                     circle.x + Math.cos(angle) * r,
                     circle.y,
                     circle.z + Math.sin(angle) * r,
                     0.0,
                     0.04 + random.nextDouble() * 0.04,
                     0.0
                  );
               }
            } else if (random.nextInt(10) == 0) {
               level.addParticle(
                  FROST,
                  position.x + TitanFistClient.spread(random, 0.15),
                  position.y + TitanFistClient.spread(random, 0.5),
                  position.z + TitanFistClient.spread(random, 0.15),
                  0.0,
                  0.01,
                  0.0
               );
            }
         case 1:
         case 3:
         default:
            break;
         case 2:
            if (blade.sincePhase(age) < 10.0F && random.nextInt(2) == 0) {
               level.addParticle(
                  ParticleTypes.ELECTRIC_SPARK,
                  position.x,
                  position.y,
                  position.z,
                  TitanFistClient.spread(random, 0.1),
                  0.05,
                  TitanFistClient.spread(random, 0.1)
               );
            }
            break;
         case 4:
            Vec3 heading = blade.fired() ? blade.heading() : new Vec3(0.0, 1.0, 0.0);
            Vec3 middle = blade.face() != null ? position.add(heading.scale(-0.27F)) : position;
            ItemParticleOption pixels = new ItemParticleOption(ParticleTypes.ITEM, blade.weapon());

            for (int i = 0; i < 3; i++) {
               Vec3 at = middle.add(heading.scale((random.nextDouble() - 0.5) * 2.0 * 0.62F));
               level.addParticle(pixels, at.x, at.y, at.z, TitanFistClient.spread(random, 0.03), 0.03, TitanFistClient.spread(random, 0.03));
            }
      }
   }

   public static void fired(TitanBladeEntity blade) {
      Vec3 from = blade.from();
      Vec3 to = blade.to();
      BEAMS.add(new TitanBladeClient.Beam(from, to, ClientClock.ticks()));
      if (mine(blade.ownerId())) {
         CameraShake.quake(0.15F, 2, 0);
      }

      Direction face = blade.face();
      if (face != null) {
         ClientLevel level = (ClientLevel)blade.level();
         RandomSource random = level.random;
         Vec3 normal = Vec3.atLowerCornerOf(face.getNormal());
         TitanFistClient.burst(level, random, ParticleTypes.CRIT, to.add(normal.scale(0.1)), 10, 0.15, 0.4);
         TitanFistClient.burst(level, random, FROST, to.add(normal.scale(0.1)), 6, 0.2, 0.1);
         BlockState block = TitanFistClient.blockAt(level, to.subtract(normal.scale(0.1)));
         if (block != null) {
            for (int i = 0; i < 12; i++) {
               level.addParticle(
                  new BlockParticleOption(ParticleTypes.BLOCK, block),
                  to.x,
                  to.y,
                  to.z,
                  normal.x * 0.2 + TitanFistClient.spread(random, 0.15),
                  normal.y * 0.2 + 0.1 + TitanFistClient.spread(random, 0.1),
                  normal.z * 0.2 + TitanFistClient.spread(random, 0.15)
               );
            }
         }
      }
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      if (!BEAMS.isEmpty()) {
         long now = ClientClock.ticks();
         BEAMS.removeIf(beam -> now - beam.at() > 6L);
      }
   }

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      if (event.getStage() == Stage.AFTER_PARTICLES && !BEAMS.isEmpty()) {
         Camera camera = event.getCamera();
         Vec3 view = camera.getPosition();
         PoseStack poseStack = event.getPoseStack();
         Matrix4f pose = poseStack.last().pose();
         BufferSource buffers = LateBuffers.get();
         VertexConsumer consumer = buffers.getBuffer(ModRenderTypes.GLOW);
         Vector3f eye = new Vector3f();

         for (TitanBladeClient.Beam beam : BEAMS) {
            float age = ClientClock.since(beam.at(), event.getPartialTick().getGameTimeDeltaPartialTick(false));
            float light = 1.0F - Mth.clamp(age / 6.0F, 0.0F, 1.0F);
            if (!(light <= 0.0F)) {
               Vector3f from = beam.from().subtract(view).toVector3f();
               Vector3f to = beam.to().subtract(view).toVector3f();
               int segments = Mth.clamp((int)(beam.from().distanceTo(beam.to()) / 8.0), 1, 40);
               GlowDraw.farBeam(
                  consumer, pose, from, to, eye, segments, 0.012F, 0.06F, 0.7F, TitanHud.BLUE[0], TitanHud.BLUE[1], TitanHud.BLUE[2], 0.7F * light
               );
               GlowDraw.farBeam(consumer, pose, from, to, eye, segments, 0.004F, 0.02F, 0.22F, 1.0F, 0.97F, 0.9F, light);
            }
         }

         buffers.endBatch(ModRenderTypes.GLOW);
      }
   }

   @SubscribeEvent
   public static void onLoggingOut(LoggingOut event) {
      BEAMS.clear();
   }

   private record Beam(Vec3 from, Vec3 to, long at) {
   }
}
