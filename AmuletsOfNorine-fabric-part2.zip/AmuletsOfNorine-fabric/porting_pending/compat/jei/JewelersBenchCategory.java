package com.amuletmod.compat.jei;

import com.amuletmod.AmuletMod;
import com.amuletmod.bench.JewelersBenchMenu;
import com.amuletmod.bench.JewelersBenchRecipe;
import com.amuletmod.registry.ModItems;
import java.util.HashMap;
import java.util.Map;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableAnimated;
import mezz.jei.api.gui.drawable.IDrawableAnimated.StartDirection;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;

public class JewelersBenchCategory implements IRecipeCategory<JewelersBenchRecipe> {
   public static final RecipeType<JewelersBenchRecipe> TYPE = RecipeType.create("amuletmod", "jewelers_bench", JewelersBenchRecipe.class);
   private static final ResourceLocation TEXTURE = AmuletMod.id("textures/gui/jewelers_bench.png");
   private static final int MAT_U = 5;
   private static final int MAT_V = 5;
   private static final int MAT_W = 166;
   private static final int MAT_H = 66;
   private static final int TIME_COLOR = 15391664;
   private final IGuiHelper guiHelper;
   private final IDrawable background;
   private final IDrawable icon;
   private final Map<Integer, IDrawableAnimated> bars = new HashMap<>();

   public JewelersBenchCategory(IGuiHelper guiHelper) {
      this.guiHelper = guiHelper;
      this.background = guiHelper.createDrawable(TEXTURE, 5, 5, 166, 66);
      this.icon = guiHelper.createDrawableIngredient(VanillaTypes.ITEM_STACK, new ItemStack((ItemLike)ModItems.JEWELERS_BENCH.get()));
   }

   public RecipeType<JewelersBenchRecipe> getRecipeType() {
      return TYPE;
   }

   public Component getTitle() {
      return Component.translatable("container.amuletmod.jewelers_bench");
   }

   public IDrawable getBackground() {
      return this.background;
   }

   public IDrawable getIcon() {
      return this.icon;
   }

   public void setRecipe(IRecipeLayoutBuilder builder, JewelersBenchRecipe recipe, IFocusGroup focuses) {
      NonNullList<Ingredient> ingredients = recipe.getIngredients();
      builder.addSlot(RecipeIngredientRole.INPUT, 7, 30).addIngredients((Ingredient)ingredients.get(0));

      for (int i = 0; i < JewelersBenchMenu.CROSS_XY.length; i++) {
         builder.addSlot(RecipeIngredientRole.INPUT, JewelersBenchMenu.CROSS_XY[i][0] - 5, JewelersBenchMenu.CROSS_XY[i][1] - 5)
            .addIngredients((Ingredient)ingredients.get(1 + i));
      }

      builder.addSlot(RecipeIngredientRole.OUTPUT, 137, 30).addItemStack(recipe.getResultItem(Minecraft.getInstance().level.registryAccess()));
   }

   public void draw(JewelersBenchRecipe recipe, IRecipeSlotsView slots, GuiGraphics graphics, double mouseX, double mouseY) {
      this.bars
         .computeIfAbsent(
            recipe.craftTime(),
            timex -> this.guiHelper.createAnimatedDrawable(this.guiHelper.createDrawable(TEXTURE, 176, 0, 36, 10), timex, StartDirection.LEFT, false)
         )
         .draw(graphics, 92, 33);
      Font font = Minecraft.getInstance().font;
      float seconds = recipe.craftTime() / 20.0F;
      Component time = Component.translatable(
         "jei.amuletmod.jewelers_bench.time", new Object[]{seconds == (int)seconds ? Integer.toString((int)seconds) : String.format("%.1f", seconds)}
      );
      int centerX = 145;
      graphics.drawString(font, time, centerX - font.width(time) / 2, 55, 15391664, false);
   }
}
