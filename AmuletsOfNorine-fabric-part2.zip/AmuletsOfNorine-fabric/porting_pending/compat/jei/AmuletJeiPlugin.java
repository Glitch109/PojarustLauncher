package com.amuletmod.compat.jei;

import com.amuletmod.AmuletMod;
import com.amuletmod.bench.JewelersBenchMenu;
import com.amuletmod.client.screen.JewelersBenchScreen;
import com.amuletmod.registry.ModItems;
import com.amuletmod.registry.ModMenus;
import com.amuletmod.registry.ModRecipes;
import java.util.Collection;
import java.util.List;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.gui.handlers.IGuiClickableArea;
import mezz.jei.api.gui.handlers.IGuiContainerHandler;
import mezz.jei.api.recipe.IFocusFactory;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.registration.IGuiHandlerRegistration;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import mezz.jei.api.registration.IRecipeTransferRegistration;
import mezz.jei.api.runtime.IRecipesGui;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.ItemLike;

@JeiPlugin
public class AmuletJeiPlugin implements IModPlugin {
   private static final ResourceLocation ID = AmuletMod.id("jei_plugin");

   public ResourceLocation getPluginUid() {
      return ID;
   }

   public void registerCategories(IRecipeCategoryRegistration registration) {
      registration.addRecipeCategories(new IRecipeCategory[]{new JewelersBenchCategory(registration.getJeiHelpers().getGuiHelper())});
   }

   public void registerRecipes(IRecipeRegistration registration) {
      if (Minecraft.getInstance().level != null) {
         registration.addRecipes(
            JewelersBenchCategory.TYPE,
            Minecraft.getInstance()
               .level
               .getRecipeManager()
               .getAllRecipesFor((RecipeType)ModRecipes.JEWELERS_BENCH_TYPE.get())
               .stream()
               .map(RecipeHolder::value)
               .toList()
         );
      }
   }

   public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
      registration.addRecipeCatalyst(new ItemStack((ItemLike)ModItems.JEWELERS_BENCH.get()), new mezz.jei.api.recipe.RecipeType[]{JewelersBenchCategory.TYPE});
   }

   public void registerGuiHandlers(IGuiHandlerRegistration registration) {
      registration.addGuiContainerHandler(JewelersBenchScreen.class, new IGuiContainerHandler<JewelersBenchScreen>() {
         public Collection<IGuiClickableArea> getGuiClickableAreas(final JewelersBenchScreen screen, double mouseX, double mouseY) {
            final IGuiClickableArea bar = IGuiClickableArea.createBasic(97, 38, 36, 10, new mezz.jei.api.recipe.RecipeType[]{JewelersBenchCategory.TYPE});
            return List.of(new IGuiClickableArea() {
               public Rect2i getArea() {
                  return bar.getArea();
               }

               public boolean isTooltipEnabled() {
                  return ((JewelersBenchMenu)screen.getMenu()).maxProgress() <= 0;
               }

               public void onClick(IFocusFactory focusFactory, IRecipesGui recipesGui) {
                  bar.onClick(focusFactory, recipesGui);
               }
            });
         }
      });
   }

   public void registerRecipeTransferHandlers(IRecipeTransferRegistration registration) {
      registration.addRecipeTransferHandler(JewelersBenchMenu.class, (MenuType)ModMenus.JEWELERS_BENCH.get(), JewelersBenchCategory.TYPE, 0, 6, 7, 36);
   }
}
