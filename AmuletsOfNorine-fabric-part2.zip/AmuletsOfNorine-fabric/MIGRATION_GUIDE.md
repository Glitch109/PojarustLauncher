# Migration guide: NeoForge 1.21.1 → Fabric 1.21.11 (Mojang mappings)

Project: `/home/claude/AmuletsOfNorine-fabric`, sources in `src/main/java/com/amuletmod`.
Original (decompiled, untouched) NeoForge sources: `porting_original/com/amuletmod/...`.
Reference for real 1.21.11 API usage (Mojang names): `/home/claude/ref/fabric-api` — **grep it before
guessing a signature** (e.g. `grep -rn "hurtServer" /home/claude/ref/fabric-api --include=*.java`).
Vanilla data/asset JSON reference: `/home/claude/ref/mcmeta-data`, `/home/claude/ref/mcmeta-assets`.
There is NO compiler available: write conservative code and double-check every vanilla signature you are not sure of.

## What is already done (don't redo)
* `com.amuletmod.neo.*` is a compatibility shim so that most NeoForge-style handler code compiles unchanged:
  `@SubscribeEvent`, `@EventBusSubscriber` (marker only; classes are listed in `neo/Handlers.java`),
  `NeoForge.EVENT_BUS`, `EventHooks`, `Tags`, `PacketDistributor`, `IPayloadContext`, `IEntityWithComplexSpawn`,
  `neo/event/*` (event classes), `neo/registry/*` (`DeferredRegister/Holder/Item/Block`).
  Events are fired from `neo/hooks/FabricHooks.java` and `mixin/*Mixin.java`.
  **If you add a new `@SubscribeEvent` handler class, add it to `neo/Handlers.java`.**
* Curios replaced by `amulet/AmuletSlots` + `amulet/SlotResult` (one synced data-attachment slot on the player).
* Imports `net.neoforged.*` were rewritten by script; remaining `net.neoforged` imports must be removed by you.
* `ResourceLocation` → `Identifier` (class `net.minecraft.resources.Identifier`, `ResourceKey.identifier()`).
* `.isClientSide` → `.isClientSide()` (it is a method now); `x.serverLevel()` → `((ServerLevel) x.level())`.
* Mob effects: use `com.amuletmod.util.VanillaEffects.X` (Holder<MobEffect>), not `MobEffects`.
* Registry objects are created inside `DeferredRegister` suppliers; inside them `DeferredRegister.currentKey()` gives the
  ResourceKey (needed for `Item.Properties.setId`, `BlockBehaviour.Properties.setId`, `EntityType.Builder.build(key)`).
* Client-only code (everything that touched `net.minecraft.client`, renderers, shaders, HUD) is parked in
  `porting_pending/` and is NOT part of the build. `com.amuletmod.client.*` contains no-op STUBS with the static methods
  that common code calls. Do not port client code unless told to; keep calling the stubs.

## API changes you must apply (1.21.1 → 1.21.11)
**Damage / entities**
* `entity.hurt(source, amount)` → `entity.hurtServer(serverLevel, source, amount)` (server side only). Overriding `hurt` in own
  entities → override `hurtServer(ServerLevel, DamageSource, float)`; `isInvulnerableTo(ServerLevel, DamageSource)`.
* `LivingEntity.getHealth/setHealth/heal/die(DamageSource)` unchanged. `Entity.level()` returns `Level`;
  use `(ServerLevel) entity.level()` after an `!isClientSide()` check.
* `EntityType.Builder.build(ResourceKey)` (done in ModEntities). Entity constructors `(EntityType<?>, Level)` unchanged.
* Spawn data (`IEntityWithComplexSpawn`) has no Fabric equivalent: replace by `SynchedEntityData` fields or by
  overriding `getAddEntityPacket`/sending a small payload on `PlayerEvent.StartTracking`.
* `Entity.teleportTo(ServerLevel, x,y,z, Set<Relative>, yRot, xRot, boolean setCamera)` for cross-dimension teleports.
* `ServerLevel.sendParticles`, `playSound(null, x,y,z, SoundEvent, SoundSource, vol, pitch)` unchanged.
* `Level.explode(...)` signature changed: `explode(Entity, DamageSource, ExplosionDamageCalculator, double x,y,z, float r, boolean fire, Level.ExplosionInteraction)`; check usages.
* `level.getEntities(...)`, `getEntitiesOfClass(...)` unchanged. `LivingEntity.addEffect(MobEffectInstance)` unchanged;
  `MobEffectInstance(Holder<MobEffect>, int, int)`.
* `AttributeModifier(Identifier id, double, Operation)` — modifiers are identified by an `Identifier`, not a UUID.
* `Mob.setTarget`, goals: `Goal` API unchanged; `Wolf.createAttributes()` etc. unchanged.

**Saving data**
* Entities: `addAdditionalSaveData(ValueOutput out)` / `readAdditionalSaveData(ValueInput in)`
  (package `net.minecraft.world.level.storage`). Write: `out.putInt/putString/putBoolean/putFloat/putDouble/putLong(key, v)`,
  `out.store(key, codec, value)`, `out.child(key)` (ValueOutput), `out.list(key)` / `out.childrenList(key)`.
  Read: `in.getIntOr(key, def)`, `getStringOr`, `getBooleanOr`, `getFloatOr`, `getDoubleOr`, `getLongOr`,
  `in.read(key, codec)` → `Optional`, `in.child(key)` → `Optional<ValueInput>`, `in.childOrEmpty(key)`, `in.listOrEmpty`, `in.childrenListOrEmpty`.
  Verify exact names with `grep -rn "ValueInput\|ValueOutput" /home/claude/ref/fabric-api`.
* BlockEntity: `saveAdditional(ValueOutput)` / `loadAdditional(ValueInput)`; no HolderLookup.Provider parameter any more.
* `CompoundTag` getters return `Optional`: `tag.getInt(k)` → `tag.getIntOr(k, 0)`, `getString(k)` → `getStringOr(k, "")`,
  `getCompound(k)` → `Optional<CompoundTag>` (`getCompoundOrEmpty(k)`), `getBoolean` → `getBooleanOr`, `getList(k, type)` → `getListOrEmpty(k)`,
  `contains(k, 10)` → `contains(k)`, `getUUID` → read via `NbtUtils`/codec. `CompoundTag` ListTag access changed, check source.
* `StackData` helper already adapted (returns a *copy* of the custom data tag).

**Items / blocks / menus**
* `Item.use(Level, Player, InteractionHand)` returns `InteractionResult` (no more `InteractionResultHolder`);
  `InteractionResult.SUCCESS/CONSUME/FAIL/PASS`, `InteractionResult.SUCCESS.heldItemTransformedTo(stack)`.
* `Item.appendHoverText(ItemStack, Item.TooltipContext, TooltipDisplay, Consumer<Component>, TooltipFlag)`.
* `Item.inventoryTick(ItemStack, ServerLevel, Entity, @Nullable EquipmentSlot)`.
* `Item.Properties.setId(ResourceKey<Item>)` is mandatory (use `DeferredRegister.currentKey()`); block items need `.useBlockDescriptionPrefix()`.
* Block: `BlockBehaviour.useWithoutItem(...)` / `useItemOn(...)` replaced the old `use`; `Block.neighborChanged` etc. mostly the same;
  `BlockBehaviour.Properties.setId`. `getCloneItemStack(LevelReader, BlockPos, BlockState, boolean)`.
* Menus: Fabric `ExtendedScreenHandlerType<T, D>` (net.fabricmc.fabric.api.screenhandler.v1) + `ExtendedScreenHandlerFactory<D>`
  replace `IMenuTypeExtension` / `player.openMenu(provider, buf -> ...)`. `IItemHandler/ItemStackHandler/SlotItemHandler`
  → vanilla `SimpleContainer` + `Slot`.
* Recipes: `Recipe` API changed in 1.21.2 (`RecipeInput`, `Recipe.placementInfo()`, `recipeBookCategory()`, `matches(I, Level)`,
  `assemble(I, HolderLookup.Provider)`); `Ingredient` has no `getItems()` any more (use `Ingredient.items()` / `test`).
  Recipe JSON is already converted (ingredients are plain strings / `#tags`).
* Creative tabs: `CreativeModeTab.builder()...` as before (Neo's `withTabsBefore` removed).
* Criteria triggers: `SimpleCriterionTrigger` – check against `/home/claude/ref/fabric-api` and `mcmeta` for the codec style.
* Tags: use `TagKey`, `BlockTags/ItemTags/EntityTypeTags/DamageTypeTags` (names mostly same).

**Rendering is NOT part of this phase** (renderers, models, HUD, shaders live in `porting_pending/`).

## Style rules
* Don't change behaviour/balance numbers. Keep class and method names so other files still compile.
* Keep `@SubscribeEvent` handlers as they are (they work through the shim).
* If something cannot be ported with certainty, leave the original logic, add `// TODO(port): <reason>` and note it in
  `PORTING_STATUS.md` (append a line, never delete others' lines).
* Remove every remaining `net.neoforged` / `top.theillusivec4` import. Remove `@Override`-less decompiler artefacts only if needed.
* Decompiler artefacts to clean when you see them: raw types with casts like `(EntityType)X.get()`, `new CustomPacketPayload[0]` varargs (fine).
