use jni::objects::{JClass, JString};
use jni::sys::jstring;
use jni::JNIEnv;
use std::ffi::{CStr, CString};

#[no_mangle]
pub extern "system" fn Java_dev_pojarust_launcher_Native_version(env: JNIEnv, _c: JClass) -> jstring {
    env.new_string(env!("CARGO_PKG_VERSION")).unwrap().into_raw()
}

/// dlopen для .so игры. "" = успех, иначе текст ошибки.
#[no_mangle]
pub extern "system" fn Java_dev_pojarust_launcher_Native_loadGame(
    mut env: JNIEnv, _c: JClass, path: JString,
) -> jstring {
    let p: String = env.get_string(&path).map(|s| s.into()).unwrap_or_default();
    let c = CString::new(p).unwrap();
    let msg = unsafe {
        let h = libc::dlopen(c.as_ptr(), libc::RTLD_NOW | libc::RTLD_GLOBAL);
        if h.is_null() {
            let e = libc::dlerror();
            if e.is_null() { "dlopen failed".to_string() } else { CStr::from_ptr(e).to_string_lossy().into_owned() }
        } else { String::new() }
    };
    env.new_string(msg).unwrap().into_raw()
}
