package dev.pojarust.launcher

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

object ApkImporter {
    private const val TITLE_ENTRY = "assets/resource_packs/vanilla/textures/ui/title.png"

    fun gameDir(ctx: Context) = File(ctx.filesDir, "mc").apply { mkdirs() }

    /** Копирует выбранный APK, достаёт arm64 .so и делает копию с логотипом "Patch Edition". */
    fun import(ctx: Context, uri: Uri): String {
        val dir = gameDir(ctx)
        val base = File(dir, "base.apk")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> base.outputStream().use { i.copyTo(it) } }

        val libDir = File(dir, "lib").apply { deleteRecursively(); mkdirs() }
        var found = false
        ZipFile(base).use { z ->
            for (e in z.entries()) {
                if (e.name.startsWith("lib/arm64-v8a/") && e.name.endsWith(".so")) {
                    z.getInputStream(e).use { i ->
                        File(libDir, e.name.substringAfterLast('/')).outputStream().use { i.copyTo(it) }
                    }
                    found = true
                }
            }
        }
        if (!found) return "В APK нет lib/arm64-v8a/libminecraftpe.so (нужен arm64 APK)"
        patchTitle(ctx, base, File(dir, "patched.apk"))
        return "OK"
    }

    /** Переписывает zip, подменяя title.png. Подпись не нужна: APK грузится как набор ассетов. */
    private fun patchTitle(ctx: Context, src: File, dst: File) {
        val title = ctx.assets.open("title.png").readBytes()
        ZipFile(src).use { z ->
            ZipOutputStream(dst.outputStream().buffered()).use { out ->
                for (e in z.entries()) {
                    if (e.name.startsWith("META-INF/")) continue
                    out.putNextEntry(ZipEntry(e.name))
                    if (e.name == TITLE_ENTRY) out.write(title)
                    else z.getInputStream(e).use { it.copyTo(out) }
                    out.closeEntry()
                }
            }
        }
    }
}
