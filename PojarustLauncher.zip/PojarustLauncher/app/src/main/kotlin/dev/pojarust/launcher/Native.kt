package dev.pojarust.launcher

/** Мост к Rust-библиотеке (rust/src/lib.rs). */
object Native {
    init { System.loadLibrary("pojarust_native") }
    /** Загружает .so игры через Rust (dlopen). Возвращает "" при успехе или текст ошибки. */
    external fun loadGame(path: String): String
    external fun version(): String
}
