package dev.pojarust.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            setBackgroundColor(Color.parseColor("#1b1b1b"))
        }
        val title = TextView(this).apply {
            text = "PojarustLauncher"; textSize = 28f; setTextColor(Color.WHITE)
        }
        status = TextView(this).apply { setTextColor(Color.LTGRAY); text = "Rust core: ${Native.version()}" }
        val imp = Button(this).apply { text = "Импортировать APK Minecraft"; setOnClickListener { pick() } }
        val run = Button(this).apply { text = "Запустить"; setOnClickListener { launch() } }
        listOf(title, status, imp, run).forEach { root.addView(it) }
        setContentView(root)
    }

    private fun pick() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }, 1)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req != 1 || res != RESULT_OK || data?.data == null) return
        status.text = "Импорт..."
        Thread {
            val r = try { ApkImporter.import(this, data.data!!) } catch (e: Exception) { "Ошибка: $e" }
            runOnUiThread { status.text = if (r == "OK") "APK импортирован, логотип: Patch Edition" else r }
        }.start()
    }

    private fun launch() {
        val lib = File(ApkImporter.gameDir(this), "lib")
        if (!lib.exists()) { status.text = "Сначала импортируйте APK"; return }
        // грузим все .so: сначала зависимости, libminecraftpe.so последней
        val pending = (lib.listFiles()?.filter { it.name.endsWith(".so") } ?: emptyList())
            .sortedBy { if (it.name == "libminecraftpe.so") 1 else 0 }.toMutableList()
        var lastErr = ""
        while (pending.isNotEmpty()) {
            val before = pending.size
            val it = pending.iterator()
            while (it.hasNext()) {
                val f = it.next()
                if (f.name == "libminecraftpe.so" && pending.size > 1) continue
                val err = Native.loadGame(f.absolutePath)
                if (err.isEmpty()) it.remove() else lastErr = "${f.name}: $err"
            }
            if (pending.size == before) { status.text = lastErr; return }
        }
        // TODO: здесь запускается прокси-Activity игры (как в LeviLauncher):
        // DexClassLoader на patched.apk + AssetManager.addAssetPath(patched.apk)
        status.text = "Нативные библиотеки загружены через Rust"
    }
}
